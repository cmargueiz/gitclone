// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import java.awt.event.KeyEvent;
import java.util.regex.Pattern;

public class Texto
{
    public String cadenaDUI;
    public String cadenaNIT;
    
    public Texto() {
        this.cadenaDUI = "";
        this.cadenaNIT = "";
    }
    
    public void convertirMinusculaMayuscula(final KeyEvent arg0) {
        final char charecter = arg0.getKeyChar();
        if (Character.isLowerCase(charecter)) {
            arg0.setKeyChar(Character.toUpperCase(charecter));
        }
    }
    
    public void textoSoloNumeros(final KeyEvent arg0) {
        final char caracter = arg0.getKeyChar();
        if ((caracter < '0' || caracter > '9') && caracter != '\b') {
            arg0.consume();
        }
    }
    
    public boolean formatoDuiNit(final int tipoDocumento, final String texto) {
        boolean estado = false;
        switch (tipoDocumento) {
            case 1: {
                if (texto.length() == 9) {
                    for (int i = 0; i < texto.length(); ++i) {
                        if (i == 8) {
                            this.cadenaDUI = String.valueOf(this.cadenaDUI) + "-";
                        }
                        this.cadenaDUI = String.valueOf(this.cadenaDUI) + texto.substring(i, i + 1);
                    }
                    estado = true;
                    break;
                }
                estado = false;
                break;
            }
            case 2: {
                if (texto.length() == 14) {
                    for (int i = 0; i < texto.length(); ++i) {
                        if (i == 4 || i == 10 || i == 13) {
                            this.cadenaNIT = String.valueOf(this.cadenaNIT) + "-";
                        }
                        this.cadenaNIT = String.valueOf(this.cadenaNIT) + texto.substring(i, i + 1);
                    }
                    estado = true;
                    break;
                }
                estado = false;
                break;
            }
        }
        return estado;
    }
    
    public static String[] getIdCombos(final String textoCombo) {
    	
    	return textoCombo.split(" ");
    	
    }
    
    
    public static boolean comparacioRegexp(final String regexp, final String cadena) {
    	
    	if (Pattern.matches(regexp,cadena)) {
			return true;
		}
    	return false;
	}
    
    public static boolean validarDui(final String dui) {
    	if (Pattern.matches("\\d{8}", dui)) {
			return true;
		}
    	return false;
    }
    
    public static boolean validarNit(final String dui) {
    	if (Pattern.matches("[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]", dui)) {
			return true;
		}
    	return false;
    }
    
    
    public static String getDui(final String dui) {
    	String duiPrint="";
		if (validarDui(dui)) {
			duiPrint = dui.substring(0, 7)+"-"+dui.substring(7,8 );
			return duiPrint;
		}
		return null;
	}
    
    public static String  getNit(final String nit) {
    	String nitPrint="";
    	if (validarNit(nit)) {
			nitPrint=nit.substring(0, 4)+"-"+nit.substring(4,10)+"-"+nit.substring(10, 13)+"-"+nit.substring(13);
			return nitPrint;
		}
    	return null;
	}
    
    public static boolean validarTelefono(final String tel) {
		if (tel!=null) {
			if (!tel.isEmpty()) {
				String regexp = "[0-9]+";	
				return Pattern.matches(regexp,tel);			
			}
			return false;
		}
		return false;
	}
    
}
