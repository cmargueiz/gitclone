// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import java.util.regex.Pattern;

public class Numero_a_Letra
{
    private final String[] UNIDADES;
    private final String[] DECENAS;
    private final String[] CENTENAS;
    
    public Numero_a_Letra() {
        this.UNIDADES = new String[] { "", "un ", "dos ", "tres ", "cuatro ", "cinco ", "seis ", "siete ", "ocho ", "nueve " };
        this.DECENAS = new String[] { "diez ", "once ", "doce ", "trece ", "catorce ", "quince ", "dieciseis ", "diecisiete ", "dieciocho ", "diecinueve", "veinte ", "treinta ", "cuarenta ", "cincuenta ", "sesenta ", "setenta ", "ochenta ", "noventa " };
        this.CENTENAS = new String[] { "", "ciento ", "doscientos ", "trecientos ", "cuatrocientos ", "quinientos ", "seiscientos ", "setecientos ", "ochocientos ", "novecientos " };
    }
    
    public String Convertir(String numero, final boolean mayusculas) {
        String literal = "";
        numero = numero.replace(".", ",");
        if (numero.indexOf(",") == -1) {
            numero = String.valueOf(numero) + ",00";
        }
        if (!Pattern.matches("\\d{1,9},\\d{1,2}", numero)) {
            return literal = null;
        }
        final String[] Num = numero.split(",");
        final String parte_decimal = String.valueOf(Num[1]) + "/100 Dolares";
        if (Integer.parseInt(Num[0]) == 0) {
            literal = "cero ";
        }
        else if (Integer.parseInt(Num[0]) > 999999) {
            literal = this.getMillones(Num[0]);
        }
        else if (Integer.parseInt(Num[0]) > 999) {
            literal = this.getMiles(Num[0]);
        }
        else if (Integer.parseInt(Num[0]) > 99) {
            literal = this.getCentenas(Num[0]);
        }
        else if (Integer.parseInt(Num[0]) > 9) {
            literal = this.getDecenas(Num[0]);
        }
        else {
            literal = this.getUnidades(Num[0]);
        }
        if (mayusculas) {
            return (String.valueOf(literal) + parte_decimal).toUpperCase();
        }
        return String.valueOf(literal) + parte_decimal;
    }
    
    private String getUnidades(final String numero) {
        final String num = numero.substring(numero.length() - 1);
        return this.UNIDADES[Integer.parseInt(num)];
    }
    
    private String getDecenas(final String num) {
        final int n = Integer.parseInt(num);
        if (n < 10) {
            return this.getUnidades(num);
        }
        if (n <= 19) {
            return this.DECENAS[n - 10];
        }
        final String u = this.getUnidades(num);
        if (u.equals("")) {
            return this.DECENAS[Integer.parseInt(num.substring(0, 1)) + 8];
        }
        return String.valueOf(this.DECENAS[Integer.parseInt(num.substring(0, 1)) + 8]) + "y " + u;
    }
    
    private String getCentenas(final String num) {
        if (Integer.parseInt(num) <= 99) {
            return this.getDecenas(new StringBuilder(String.valueOf(Integer.parseInt(num))).toString());
        }
        if (Integer.parseInt(num) == 100) {
            return " cien ";
        }
        return String.valueOf(this.CENTENAS[Integer.parseInt(num.substring(0, 1))]) + this.getDecenas(num.substring(1));
    }
    
    private String getMiles(final String numero) {
        final String c = numero.substring(numero.length() - 3);
        final String m = numero.substring(0, numero.length() - 3);
        String n = "";
        if (Integer.parseInt(m) > 0) {
            n = this.getCentenas(m);
            return String.valueOf(n) + "mil " + this.getCentenas(c);
        }
        return new StringBuilder().append(this.getCentenas(c)).toString();
    }
    
    private String getMillones(final String numero) {
        final String miles = numero.substring(numero.length() - 6);
        final String millon = numero.substring(0, numero.length() - 6);
        String n = "";
        if (millon.length() > 1) {
            n = String.valueOf(this.getCentenas(millon)) + "millones ";
        }
        else {
            n = String.valueOf(this.getUnidades(millon)) + "millon ";
        }
        return String.valueOf(n) + this.getMiles(miles);
    }
}
