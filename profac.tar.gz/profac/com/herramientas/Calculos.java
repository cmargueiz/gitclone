// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;
import javax.swing.JTable;

import profac.com.database.consultasSQL_SERVER;
import profac.com.database.insertSQL_SERVER;

public class Calculos
{
    public F_Contabilidad contabilidad;
    public consultasSQL_SERVER consultaSql;
    public insertSQL_SERVER insertSql;
    public String usuario;
    public String fechaSistema;
    public String fechaActual;
    public String nombreOficina;
    public String nombreUsuario;
    private JTable tblGastosServicios;
    private JTable tblMontosPendientes;
    
    public Calculos() {
        contabilidad = new F_Contabilidad();
        consultaSql = new consultasSQL_SERVER();
        insertSql = new insertSQL_SERVER();
        tblGastosServicios = new JTable();
        tblMontosPendientes = new JTable();
    }
    
    @SuppressWarnings("unused")
	public int generarReciboServicio(final String idServicio, final Double lecturaInicial, final Double lecturaFinal, final String fechaFiltro, final int partidaContable) {
        int resultado3 = 0;
        try {
            final Double consumoMes = lecturaFinal - lecturaInicial;
            Double montoCapital = 0.0;
            final Double montoInteres = 0.0;
            Double montoMora = 0.0;
            final Double montoSeguro = 0.0;
            Double montoOtros = 0.0;
            Double montoTotal = 0.0;
            Double montoCapitalPen = 0.0;
            Double montoInteresPen = 0.0;
            Double montoMoraPen = 0.0;
            Double montoSeguroPen = 0.0;
            Double montoOtrosPen = 0.0;
            Double montoCuotaPen = 0.0;
            final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            final Date fechaDate = formato.parse(fechaActual);
            final Calendar calendar = Calendar.getInstance();
            calendar.setTime(fechaDate);
            calendar.add(5, 10);
            final String fechaPago = formato.format(calendar.getTime());
            consultaSql.obtenerDatosServicio(idServicio);
            tblGastosServicios.setModel(consultaSql.llenarTablaGastosLineaServicio(consultaSql.lineaServicio.substring(5, 12)));
            for (int i = 0; i < tblGastosServicios.getRowCount(); ++i) {
                final String string;
                switch (string = tblGastosServicios.getValueAt(i, 3).toString()) {
                    case "F": {
                        montoOtros += Double.parseDouble(tblGastosServicios.getValueAt(i, 1).toString());
                        break;
                    }
                    case "V": {
                        montoCapital += consumoMes * Double.parseDouble(tblGastosServicios.getValueAt(i, 1).toString());
                        break;
                    }
                    default:
                        break;
                }
            }
            montoTotal += montoCapital + montoOtros;
            tblMontosPendientes.setModel(consultaSql.llenarTablaMontosPendientes(idServicio));
            montoCapitalPen = Double.parseDouble(tblMontosPendientes.getValueAt(0, 0).toString());
            montoInteresPen = Double.parseDouble(tblMontosPendientes.getValueAt(0, 1).toString());
            montoMoraPen = Double.parseDouble(tblMontosPendientes.getValueAt(0, 2).toString());
            montoSeguroPen = Double.parseDouble(tblMontosPendientes.getValueAt(0, 3).toString());
            montoOtrosPen = Double.parseDouble(tblMontosPendientes.getValueAt(0, 4).toString());
            montoCuotaPen = Double.parseDouble(tblMontosPendientes.getValueAt(0, 5).toString());
            if (montoCapitalPen > 0.0 || montoInteresPen > 0.0 || montoMoraPen > 0.0 || montoSeguroPen > 0.0 || montoOtrosPen > 0.0 || montoCuotaPen > 0.0) {
                montoMora += 3.0;
            }
            final int resultado4 = insertSql.insertReciboGenerado(idServicio, "P", fechaSistema, fechaActual, fechaPago, consultaSql.obtenerIdUsuario(usuario, consultaSql.obtenerIDOficina(nombreOficina)), fechaFiltro.substring(0, 4), fechaFiltro.substring(4, 6));
            if (resultado4 > 0) {
                final int resultado5 = insertSql.insertNuevoPlanPagos(idServicio, fechaSistema, fechaPago, montoCapital, 0.0, 0.0, 0.0, montoOtros, montoTotal, "P", consultaSql.obtenerIdUsuario(usuario, consultaSql.obtenerIDOficina(nombreOficina)), "P", fechaActual, montoCapitalPen + montoCapital, 0.0, montoMoraPen + montoMora, 0.0, montoOtrosPen + montoOtros, montoCuotaPen + montoTotal, consultaSql.obtenerNumeroCuota(idServicio), consultaSql.obtenerReciboGenerado(idServicio, fechaFiltro.substring(0, 4), fechaFiltro.substring(4, 6)));
                if (resultado5 > 0) {
                    contabilidad.movimientoContable_generacionRecibo(consultaSql.obtenerIDOficina(nombreOficina), fechaSistema, fechaActual, usuario, idServicio, montoCapital, partidaContable);
                    ++resultado3;
                }
            }
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "al procesar la informacion y generar el recibo -- " + e.toString(), "ERROR!", 0);
        }
        return resultado3;
    }
}
