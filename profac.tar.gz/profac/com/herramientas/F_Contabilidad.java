// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.JTable;

import profac.com.database.consultasSQL_SERVER;
import profac.com.database.deleteSQL_SERVER;
import profac.com.database.insertSQL_SERVER;
import profac.com.database.updateSQL_SERVER;

public class F_Contabilidad
{
    public consultasSQL_SERVER consultaSql;
    public updateSQL_SERVER updateSql;
    public insertSQL_SERVER insertSql;
    public deleteSQL_SERVER deleteSql;
    public JTable tblDistribucion;
    public ResultSet rs;
    
    public F_Contabilidad() {
        consultaSql = new consultasSQL_SERVER();
        updateSql = new updateSQL_SERVER();
        insertSql = new insertSQL_SERVER();
        deleteSql = new deleteSQL_SERVER();
        tblDistribucion = new JTable();
    }
    
    @SuppressWarnings("unused")
	public void movimientoContable_generacionRecibo(String idOficina, String fechaSistema, String fechaActual, String usuario, String idServicio, Double monto, int partidaContable) {
        Double montoDebe = 0.0;
        Double montoHaber = 0.0;
        tblDistribucion.setModel(consultaSql.obtenerDistribucionContable_generacionRecibos(idOficina));
        for (int i = 0; i < tblDistribucion.getRowCount(); ++i) {
            String string;
            switch (string = tblDistribucion.getValueAt(i, 4).toString()) {
                case "D": {
                    montoDebe = monto;
                    break;
                }
                case "H": {
                    montoHaber = monto;
                    break;
                }
                default:
                    break;
            }
            insertSql.insertNuevoMovimientoContable(1, partidaContable, tblDistribucion.getValueAt(i, 1).toString(), montoDebe, montoHaber, "PCHK/" + partidaContable, fechaSistema, tblDistribucion.getValueAt(i, 5).toString(), "", idOficina, fechaSistema, consultaSql.obtenerIdUsuario(usuario, idOficina), -1, "", idServicio);
        }
    }
    
    @SuppressWarnings("unused")
	public void movimientoContable_pagoRecibo(String idTipoServicio, String idOficina, String formaPago, double ncapital, double ninteres, double nmora, double nfondo, double notros, double ntotal, int partidaContable, String fechaSistema, String usuario, String idServicio, String ncomprobante, int banco, int numeroRecibo) {
        Double montoDebe = 0.0;
        Double montoHaber = 0.0;
        Double totalAux = ntotal;
        Double monto = 0.0;
        String tipoUpdate = "";
        tblDistribucion.setModel(consultaSql.obtenerDistribucionContable_pagoRecibos(idOficina, formaPago, idTipoServicio));
        for (int i = 0; i < tblDistribucion.getRowCount(); ++i) {
            montoDebe = 0.0;
            montoHaber = 0.0;
            monto = 0.0;
            Label_0753: {
                String substring;
                switch (substring = tblDistribucion.getValueAt(i, 0).toString().substring(0, 3)) {
                    case "CAJ": {
                        System.out.println("para la caja");
                        String string;
                        switch (string = tblDistribucion.getValueAt(i, 4).toString()) {
                            case "D": {
                                montoDebe = totalAux;
                                break;
                            }
                            case "H": {
                                montoHaber = totalAux;
                                break;
                            }
                            default:
                                break;
                        }
                        monto = totalAux;
                        break Label_0753;
                    }
                    default:
                        break;
                }
                String substring2;
                switch (substring2 = tblDistribucion.getValueAt(i, 0).toString().substring(0, 3)) {
                    case "CAP": {
                        System.out.println("para el capital");
                        if (ncapital > 0.0 && ntotal > 0.0) {
                            if (ntotal > ncapital) {
                                ntotal -= ncapital;
                            }
                            else {
                                ncapital = ntotal;
                                ntotal = 0.0;
                            }
                        }
                        monto = ncapital;
                        tipoUpdate = "CAP";
                        break;
                    }
                    case "FON": {
                        System.out.println("para el fondo");
                        if (nfondo > 0.0 && ntotal > 0.0) {
                            if (ntotal > nfondo) {
                                ntotal -= nfondo;
                            }
                            else {
                                nfondo = ntotal;
                                ntotal = 0.0;
                            }
                        }
                        monto = nfondo;
                        tipoUpdate = "FON";
                        break;
                    }
                    case "INT": {
                        System.out.println("para el interes");
                        if (ninteres > 0.0 && ntotal > 0.0) {
                            if (ntotal > ninteres) {
                                ntotal -= ninteres;
                            }
                            else {
                                ninteres = ntotal;
                                ntotal = 0.0;
                            }
                        }
                        monto = ninteres;
                        tipoUpdate = "INT";
                        break;
                    }
                    case "MOR": {
                        System.out.println("para la mora");
                        if (nmora > 0.0 && ntotal > 0.0) {
                            if (ntotal > nmora) {
                                ntotal -= nmora;
                            }
                            else {
                                nmora = ntotal;
                                ntotal = 0.0;
                            }
                        }
                        monto = nmora;
                        tipoUpdate = "MOR";
                        break;
                    }
                    case "OTR": {
                        System.out.println("para los otros");
                        if (notros > 0.0 && ntotal > 0.0) {
                            if (ntotal > notros) {
                                ntotal -= notros;
                            }
                            else {
                                notros = ntotal;
                                ntotal = 0.0;
                            }
                        }
                        monto = notros;
                        tipoUpdate = "OTR";
                        break;
                    }
                    default:
                        break;
                }
                String string2;
                switch (string2 = tblDistribucion.getValueAt(i, 4).toString()) {
                    case "D": {
                        montoDebe = monto;
                        break;
                    }
                    case "H": {
                        montoHaber = monto;
                        break;
                    }
                    default:
                        break;
                }
            }
            if (monto > 0.0) {
                System.out.println("el monto es mayor " + monto);
                insertSql.insertNuevoMovimientoContable(1, partidaContable, tblDistribucion.getValueAt(i, 1).toString(), montoDebe, montoHaber, ncomprobante, fechaSistema, tblDistribucion.getValueAt(i, 5).toString(), "", idOficina, fechaSistema, consultaSql.obtenerIdUsuario(usuario, idOficina), banco, "", idServicio);
                updateSql.modificarSaldosPlanPagos_servicios(tipoUpdate, monto, numeroRecibo);
            }
        }
    }
    
    public boolean partidaContable(int numeroPartida, JTable tblDetalle, String observacion, String fechaDocumento, String fechaContable, String comprobante, int idBanco, String nombreCheque, String numeroCheque) {
        boolean resultado_operacionContable = false;
        int resultado_partidaContable = insertSql.insertNuevaPartidaContable(numeroPartida, consultaSql.obtenerIDOficina(Variables.nombreOficina), String.valueOf(comprobante) + numeroCheque, observacion, fechaDocumento, fechaContable, fechaDocumento, consultaSql.obtenerIdUsuario(Variables.usuario, consultaSql.obtenerIDOficina(Variables.nombreOficina)));
        if (resultado_partidaContable != 0) {
            for (int i = 0; i < tblDetalle.getRowCount(); ++i) {
                String poliza = "";
                if (Double.parseDouble(tblDetalle.getValueAt(i, 3).toString()) > 0.0) {
                    poliza = "EG";
                }
                else if (Double.parseDouble(tblDetalle.getValueAt(i, 4).toString()) > 0.0) {
                    poliza = "EG";
                }
                int resultado_movimientoContable = insertSql.insertNuevoMovimientoContable(1, numeroPartida, consultaSql.obtenerIdCuentaContable(tblDetalle.getValueAt(i, 0).toString(), consultaSql.obtenerIDOficina(Variables.nombreOficina)), Double.parseDouble(tblDetalle.getValueAt(i, 3).toString()), Double.parseDouble(tblDetalle.getValueAt(i, 4).toString()), String.valueOf(comprobante) + numeroCheque, fechaContable, tblDetalle.getValueAt(i, 1).toString(), poliza, consultaSql.obtenerIDOficina(Variables.nombreOficina), fechaDocumento, consultaSql.obtenerIdUsuario(Variables.usuario, consultaSql.obtenerIDOficina(Variables.nombreOficina)), idBanco, nombreCheque, "");
                if (resultado_movimientoContable == 0) {
                    Variables.error = insertSql.error;
                    resultado_operacionContable = false;
                    deleteSql.deletePartidaContable(numeroPartida);
                    deleteSql.deleteMovimientoContable(numeroPartida);
                    return resultado_operacionContable;
                }
            }
            resultado_operacionContable = true;
        }
        else {
            Variables.error = insertSql.error;
            resultado_operacionContable = false;
        }
        return resultado_operacionContable;
    }
    
    public boolean cuentaContable(String id, String cuenta, String cuentaSup, int tipoCuenta, int nivel, int clase, String descripcion, String fechaActual, int idUsuario, String claseCuenta, Double saldoInicial, Double saldoFinal, String idOficina, Double montoPresupuesto, Double montoEjecutado) {
        boolean resultado = false;
        if (insertSql.insertNuevaCuenta(id, cuenta, cuentaSup, clase, nivel, clase, descripcion, fechaActual, fechaActual, idUsuario, claseCuenta, 0.0, 0.0, Variables.idOficina) != 0) {
            if (insertSql.insertPrecupuestoCuenta(idOficina, idUsuario, id, montoPresupuesto, montoEjecutado, fechaActual) != 0) {
                resultado = true;
            }
            else {
                deleteSql.deleteCuentaContable(id, idOficina);
                resultado = false;
            }
        }
        else {
            resultado = false;
        }
        return resultado;
    }
    
    public boolean agregarComprobante_madificarPartida(String numeroCheque, String fechaActual, int partidaSeleccionada, String idOficina, JTable tblDetalle, int idBanco, String nombreCheque, String nombreBanco, Double montoCheque, String descripcionPartida) {
        boolean resultado = false;
        int cont = 0;
        if (updateSql.modificarPartidaContable(numeroCheque, fechaActual, partidaSeleccionada, idOficina) != 0) {
            for (int i = 0; i < tblDetalle.getRowCount(); ++i) {
                if (updateSql.modificarMovimientosContables(numeroCheque, fechaActual, partidaSeleccionada, consultaSql.obtenerIdCuentaContable(tblDetalle.getValueAt(i, 0).toString(), idOficina), idBanco, nombreCheque, idOficina) != 0) {
                    ++cont;
                }
                else {
                    System.out.println("ERROR EN modificarMovimientosContables() -- " + updateSql.error);
                }
            }
            if (cont == tblDetalle.getRowCount()) {
                if (modificarCorrelativo(numeroCheque, idBanco)) {
                    if (insertarCheque(partidaSeleccionada, idBanco, numeroCheque, nombreCheque, montoCheque, fechaActual, descripcionPartida)) {
                        resultado = true;
                    }
                    else {
                        System.out.println("ERROR EN insertNuevoCheque() -- " + insertSql.error);
                    }
                }
            }
            else {
                System.out.println("ERROR EN cont == tblDetalle.getRowCount() producido en modificarMovimientosContables");
            }
        }
        else {
            System.out.println("ERROR EN modificarPartidaContable() -- " + updateSql.error);
            resultado = false;
        }
        return resultado;
    }
    
    public boolean modificarCorrelativo(String numeroCheque, int idBanco) {
        return updateSql.modificarCorrelativoCheque(Integer.parseInt(numeroCheque), idBanco) != 0;
    }
    
    public boolean insertarCheque(int partidaSeleccionada, int idBanco, String numeroCheque, String nombreCheque, Double montoCheque, String fechaActual, String descripcionPartida) {
        if (insertSql.insertNuevoCheque(partidaSeleccionada, idBanco, Integer.parseInt(numeroCheque), nombreCheque, montoCheque, fechaActual, descripcionPartida) != 0) {
            return true;
        }
        System.out.println("ERROR EN insertNuevoCheque() -- " + insertSql.error);
        return false;
    }
    
    public boolean insertarBanco(int op, String nombreBanco, String tipoCuenta, String cuentaBancaria, String idCuentaContable, String cuentaContable, int idBanco, int correlativo, int idUsuario, String fechaActual) {
        boolean resultado = false;
        switch (op) {
            case 0: {
                resultado = (updateSql.modificarBanco(nombreBanco, tipoCuenta, cuentaBancaria, idCuentaContable, idBanco) != 0);
                break;
            }
            case 1: {
                if (consultaSql.verificarBanco(cuentaContable) != 0) {
                    JOptionPane.showMessageDialog(null, "La cuenta contable '" + cuentaContable + "' ya esta asignada a un banco", "ERROR!", 0);
                    resultado = false;
                    break;
                }
                resultado = (insertSql.insertNuevoBanco(nombreBanco, tipoCuenta, cuentaBancaria, idCuentaContable, correlativo, idUsuario, fechaActual) != 0);
                break;
            }
        }
        return resultado;
    }
    
    public boolean partidaContable_ingresoProducto(int numeroPartida, JTable tblDetalle, String observacion, String fechaDocumento, String fechaContable, int idBanco, String nombreCheque, String numeroCheque, String idOficina, int idUsuario, String idTipoMovimiento) {
        boolean resultado_operacionContable = false;
        JTable tblDiscon = new JTable();
        Double debeAux = 0.0;
        Double haberAux = 0.0;
        if (insertSql.insertNuevaPartidaContable(numeroPartida, idOficina, "PCHK/" + numeroPartida, observacion, fechaDocumento, fechaContable, fechaDocumento, idUsuario) != 0) {
            for (int i = 0; i < tblDetalle.getRowCount(); ++i) {
                tblDiscon.setModel(consultaSql.obtenerDisconIngresoProducto(consultaSql.obtenerIdSubRubro(Integer.parseInt(tblDetalle.getValueAt(i, 0).toString())), idOficina, idTipoMovimiento));
                for (int j = 0; j < tblDiscon.getRowCount(); ++j) {
                    if (tblDiscon.getValueAt(j, 5).toString().equals("D")) {
                        haberAux = 0.0;
                        if (tblDiscon.getValueAt(j, 3).toString().substring(0, 3).equals("IVA")) {
                            debeAux = Double.parseDouble(tblDetalle.getValueAt(i, 4).toString());
                        }
                        else {
                            debeAux = Double.parseDouble(tblDetalle.getValueAt(i, 5).toString()) - Double.parseDouble(tblDetalle.getValueAt(i, 4).toString());
                        }
                    }
                    else {
                        debeAux = 0.0;
                        haberAux = Double.parseDouble(tblDetalle.getValueAt(i, 5).toString());
                    }
                    String poliza = "";
                    if (insertSql.insertNuevoMovimientoContable(1, numeroPartida, tblDiscon.getValueAt(j, 0).toString(), debeAux, haberAux, "PCHK/" + numeroPartida, fechaContable, tblDiscon.getValueAt(j, 4).toString(), poliza, idOficina, fechaDocumento, idUsuario, idBanco, nombreCheque, "") == 0) {
                        Variables.error = insertSql.error;
                        resultado_operacionContable = false;
                        deleteSql.deletePartidaContable(numeroPartida);
                        deleteSql.deleteMovimientoContable(numeroPartida);
                        return resultado_operacionContable;
                    }
                }
            }
            resultado_operacionContable = true;
        }
        else {
            Variables.error = insertSql.error;
            resultado_operacionContable = false;
        }
        return resultado_operacionContable;
    }
    
    public boolean partidaContable_facturacionProductos(int numeroPartida, JTable tblDetalle, String observacion, String fechaDocumento, String fechaContable, int idBanco, String nombreCheque, String numeroCheque, String idOficina, int idUsuario, String idTipoMovimiento, int numFactura, String tipoFactura) {
        boolean resultado_operacionContable = false;
        JTable tblDiscon = new JTable();
        Double debeAux = 0.0;
        Double haberAux = 0.0;
        Double costoAux = 0.0;
        Double montoTotal = 0.0;
        Double montoIva = 0.0;
        Double monto = 0.0;
        Double cantidad = 0.0;
        Variables.numeroPartida = numeroPartida;
        if (insertSql.insertNuevaPartidaContable(numeroPartida, idOficina, String.valueOf(tipoFactura.substring(0, 3)) + "-" + numFactura, observacion, fechaDocumento, fechaContable, fechaDocumento, idUsuario) != 0) {
            for (int i = 0; i < tblDetalle.getRowCount(); ++i) {
                tblDiscon.setModel(consultaSql.obtenerDisconIngresoProducto(consultaSql.obtenerIdSubRubro(Integer.parseInt(tblDetalle.getValueAt(i, 0).toString())), idOficina, idTipoMovimiento));
                for (int j = 0; j < tblDiscon.getRowCount(); ++j) {
                    montoIva = Double.parseDouble(tblDetalle.getValueAt(i, 4).toString()) * Variables.porcentajeIva;
                    montoTotal = Double.parseDouble(tblDetalle.getValueAt(i, 4).toString()) - montoIva;
                    costoAux = consultaSql.obtenerCostoProducto(Integer.parseInt(tblDetalle.getValueAt(i, 0).toString()));
                    cantidad = Double.parseDouble(tblDetalle.getValueAt(i, 2).toString());
                    if (tblDiscon.getValueAt(j, 3).toString().substring(0, 3).equals("CAJ")) {
                        monto = montoTotal + montoIva;
                    }
                    else if (tblDiscon.getValueAt(j, 3).toString().substring(0, 3).equals("IVA")) {
                        monto = montoIva;
                    }
                    else if (tblDiscon.getValueAt(j, 3).toString().substring(0, 3).equals("ING")) {
                        monto = montoTotal;
                    }
                    else if (tblDiscon.getValueAt(j, 3).toString().substring(0, 3).equals("COS") || tblDiscon.getValueAt(j, 3).toString().substring(0, 3).equals("INV")) {
                        monto = costoAux * cantidad;
                    }
                    else {
                        monto = montoTotal + montoIva;
                    }
                    if (tblDiscon.getValueAt(j, 5).toString().equals("D")) {
                        haberAux = 0.0;
                        debeAux = monto;
                    }
                    else {
                        haberAux = monto;
                        debeAux = 0.0;
                    }
                    String poliza = "";
                    if (insertSql.insertNuevoMovimientoContable(1, numeroPartida, tblDiscon.getValueAt(j, 0).toString(), debeAux, haberAux, String.valueOf(tipoFactura.substring(0, 3)) + "-" + numFactura, fechaContable, tblDiscon.getValueAt(j, 4).toString(), poliza, idOficina, fechaDocumento, idUsuario, idBanco, nombreCheque, "") == 0) {
                        Variables.error = insertSql.error;
                        resultado_operacionContable = false;
                        deleteSql.deletePartidaContable(numeroPartida);
                        deleteSql.deleteMovimientoContable(numeroPartida);
                        return resultado_operacionContable;
                    }
                }
            }
            resultado_operacionContable = true;
        }
        else {
            Variables.error = insertSql.error;
            resultado_operacionContable = false;
        }
        return resultado_operacionContable;
    }
}
