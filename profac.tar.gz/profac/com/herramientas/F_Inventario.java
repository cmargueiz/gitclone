// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import javax.swing.JTable;
import profac.com.database.consultasSQL_SERVER;
import profac.com.database.deleteSQL_SERVER;
import profac.com.database.updateSQL_SERVER;
import profac.com.database.insertSQL_SERVER;

public class F_Inventario
{
    public F_Contabilidad contabilidad;
    public insertSQL_SERVER insertSql;
    public updateSQL_SERVER updateSql;
    public deleteSQL_SERVER deleteSql;
    public consultasSQL_SERVER consultaSql;
    
    public F_Inventario() {
        this.contabilidad = new F_Contabilidad();
        this.insertSql = new insertSQL_SERVER();
        this.updateSql = new updateSQL_SERVER();
        this.deleteSql = new deleteSQL_SERVER();
        this.consultaSql = new consultasSQL_SERVER();
    }
    
    public boolean nuevaBodega(final int idBodega, final String nombreBodega, final String idOficina, final String nombreUsuario, final String descripcion, final String direccion, final String ciudad, final String telefono, final String fechaActual, final int idUsuario2) {
        boolean resultado = false;
        resultado = (this.insertSql.insertNuevaBodega(idBodega, nombreBodega, idOficina, this.consultaSql.obtenerIdUsuario_porNombre(nombreUsuario, idOficina), descripcion, direccion, ciudad, telefono, fechaActual, idUsuario2) != 0);
        return resultado;
    }
    
    public boolean modificarBodega(final int idBodega, final String nombreBodega, final String idOficina, final String nombreUsuario, final String descripcion, final String direccion, final String ciudad, final String telefono, final String fechaActual, final int idUsuario2) {
        boolean resultado = false;
        resultado = (this.updateSql.modificarBodega(idBodega, nombreBodega, idOficina, this.consultaSql.obtenerIdUsuario_porNombre(nombreUsuario, idOficina), descripcion, direccion, ciudad, telefono, fechaActual, idUsuario2) != 0);
        return resultado;
    }
    
    public boolean nuevoRubro(final int idRubroSubrubro, final int idRubroSubrubroSup, final String nombreRubroSubrubro, final String fechaActual, final int idUsuario, final String descripcion, final String idOficina) {
        boolean resultado = false;
        resultado = (this.insertSql.insertNuevoRubro(idRubroSubrubro, idRubroSubrubroSup, nombreRubroSubrubro, fechaActual, idUsuario, descripcion, idOficina) != 0);
        return resultado;
    }
    
    public boolean nuevoSubrubro(final int idRubroSubrubro, final int idRubroSubrubroSup, final String nombreRubroSubrubro, final String fechaActual, final int idUsuario, final String descripcion, final String idOficina) {
        boolean resultado = false;
        resultado = (this.insertSql.insertNuevoSubRubro(idRubroSubrubro, idRubroSubrubroSup, nombreRubroSubrubro, fechaActual, idUsuario, descripcion, idOficina) != 0);
        return resultado;
    }
    
    public boolean nuevoProducto(final String codigoProducto, final int idProveedor, final String nombreProducto, final String descripcion, final String fechaActual, final int idUsuario, final Double pesoProducto, final String unidadMedida, final Double stockMinimo, final Double stockMaximo, final Double costoProducto, final Double precioProducto, final Double descuento1, final Double descuento2, final Double descuento3, final String rutaImgProducto, final String tipoProducto, final int estadoProducto, final int idSubrubro) {
        boolean resultado = false;
        resultado = (this.insertSql.insertNuevoProducto(codigoProducto, idProveedor, nombreProducto, descripcion, fechaActual, idUsuario, pesoProducto, unidadMedida, stockMinimo, stockMaximo, costoProducto, precioProducto, descuento1, descuento2, descuento3, rutaImgProducto, tipoProducto, estadoProducto, idSubrubro) != 0);
        return resultado;
    }
    
    public boolean nuevaOrdenCompra(final JTable tblDetalleOrdenCompra, final int idProveedor, final String fechaReg, final String fechaPag, final String descripcion, final int idUsuario, final String idOficina, final int idOrdenCompra) {
        boolean resultado = false;
        if (this.insertSql.insertOrdenCompra(idProveedor, fechaReg, fechaPag, descripcion, idUsuario, idOficina) != 0) {
            for (int i = 0; i < tblDetalleOrdenCompra.getRowCount(); ++i) {
                if (this.insertSql.insertOrdenCompra_detalle(idOrdenCompra, Integer.parseInt(tblDetalleOrdenCompra.getValueAt(i, 0).toString()), Double.parseDouble(tblDetalleOrdenCompra.getValueAt(i, 2).toString()), Double.parseDouble(tblDetalleOrdenCompra.getValueAt(i, 3).toString()), Double.parseDouble(tblDetalleOrdenCompra.getValueAt(i, 4).toString())) != 0) {
                    resultado = true;
                }
                else {
                    resultado = false;
                    this.deleteSql.deleteOrdenCompra(idOrdenCompra);
                    this.deleteSql.deleteOrdenCompra_detalle(idOrdenCompra);
                }
            }
        }
        else {
            resultado = false;
        }
        return resultado;
    }
    
    public boolean nuevoIngresoProducto(final JTable tblDetalleIngreso, final int idOrdenCompra, final String tipoFactura, final String numeroFactura, final String idFormaPago, final String fechaRegistro, final int idUsuario, final String idOficina, final int idProveedor, final int idBodega, final String numeroDocumento, final String idTipoMovimiento) {
        boolean resultado = false;
        if (this.insertSql.insertIngresoProducto(idOrdenCompra, tipoFactura, numeroFactura, idFormaPago, fechaRegistro, idUsuario, idOficina, idProveedor) != 0) {
            for (int i = 0; i < tblDetalleIngreso.getRowCount(); ++i) {
                resultado = (this.insertSql.insertKardexProducto(Integer.parseInt(tblDetalleIngreso.getValueAt(i, 0).toString()), idTipoMovimiento, idBodega, numeroDocumento, Double.parseDouble(tblDetalleIngreso.getValueAt(i, 2).toString()), fechaRegistro, idUsuario, idOficina) != 0);
            }
            resultado = (this.contabilidad.partidaContable_ingresoProducto(this.consultaSql.obtenerSigIdPartidaContable(), tblDetalleIngreso, "PARTIDA DE INGRESO DE PRODUCTO A BODEGA", fechaRegistro, fechaRegistro, -1, "", "", Variables.idOficina, Variables.idUsuario, idTipoMovimiento) && resultado);
        }
        else {
            resultado = false;
        }
        return resultado;
    }
}
