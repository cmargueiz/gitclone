// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import java.awt.Color;
import java.time.LocalDate;

public class Variables
{
    public static Ajustes ajustes;
    public static boolean ventana_nuevaBodega;
    public static boolean ventana_editarBodega;
    public static boolean ventana_NuevoRubroSubrubro;
    public static boolean ventana_EditarRubroSubrubro;
    public static boolean ventana_nuevoProducto;
    public static boolean ventana_editarProducto;
    public static boolean ventana_lista_producto;
    public static boolean ventana_nuevaOrdenCompra;
    public static boolean ventana_editarOrdenCompra;
    public static boolean ventana_listaOrdenCompra;
    public static boolean ventana_ingresarOrdenCompra;
    public static boolean ventana_nuevo_pedido;
    public static String nombreSoftware1;
    public static String nombreSoftware2;
    public static String copyRight;
    public static String fuenteLetra;
    public static Color color_uno;
    public static Color color_dos;
    public static Color color_tres;
    public static int tamTituloTabla;
    public static int tamContenidoTabla;
    public static double porcentajeIva;
    public static String nombreOficina;
    public static String idOficina;
    public static String nombreUsuario;
    public static int idUsuario;
    public static String cargoUsuario;
    public static String fechaSistema;
    public static String usuario;
    public static String fechaActual;
    public static String error;
    public static boolean bandera_fechaInicio;
    public static boolean bandera_fechaFin;
    public static String fechaInicio;
    public static String fechaFin;
    public static String numeroPartidaSeleccionada;
    public static String descripcionPartidaSeleccionada;
    public static String fechaContablePartidaSeleccionada;
    public static String usuarioPartidaContable;
    public static Double montoCheque;
    public static String idBodega;
    public static String nombreBodega;
    public static String fechaMod;
    public static String encargadoBodega;
    public static String direccionBodega;
    public static String descripcionBodega;
    public static String ciudadBodega;
    public static String telefonoBodega;
    public static String idRubro;
    public static String idSubrubro;
    public static String idSubrubro_;
    public static String idOrdenCompra;
    public static String codCliente;
    public static String nombreCliente;
    public static String direccionCliente;
    public static String telefonoCliente;
    public static String nitCliente;
    public static String duiCliente;
    public static String idProductoSeleccionado;
    public static String descripcionProductoSeleccionado;
    public static String cantidadProductoSeleccionado;
    public static String precioProductoSeleccionado;
    public static String formaPago;
    public static int numeroPartida;
    
    static {
        Variables.ajustes = new Ajustes();
        Variables.ventana_nuevaBodega = false;
        Variables.ventana_editarBodega = false;
        Variables.ventana_NuevoRubroSubrubro = false;
        Variables.ventana_EditarRubroSubrubro = false;
        Variables.ventana_nuevoProducto = false;
        Variables.ventana_editarProducto = false;
        Variables.ventana_lista_producto = false;
        Variables.ventana_nuevaOrdenCompra = false;
        Variables.ventana_editarOrdenCompra = false;
        Variables.ventana_listaOrdenCompra = false;
        Variables.ventana_ingresarOrdenCompra = false;
        Variables.ventana_nuevo_pedido = false;
        Variables.nombreSoftware1 = "SIACE";
        Variables.nombreSoftware2 = "Sistema Integral de Administraci\u00f3n y Control Empresarial";
        Variables.copyRight = "2021 SIACE";
        Variables.fuenteLetra = "Book Antiqua";
        Variables.color_uno = new Color(227, 227, 227);
        Variables.color_dos = new Color(0, 38, 77);
        Variables.color_tres = new Color(57, 81, 115);
        Variables.tamTituloTabla = Variables.ajustes.ajustarTexto(0, Variables.ajustes.calcularPuntoY(2.78));
        Variables.tamContenidoTabla = Variables.ajustes.ajustarTexto(1, Variables.ajustes.calcularPuntoY(1.4));
        Variables.porcentajeIva = 0.13;
        Variables.bandera_fechaInicio = false;
        Variables.bandera_fechaFin = false;
        
    }
}
