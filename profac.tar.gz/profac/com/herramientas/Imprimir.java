// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import net.sf.jasperreports.engine.JRDataSource;
import java.util.Collection;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.JasperReport;
import javax.swing.table.TableModel;
import java.util.ArrayList;
import net.sf.jasperreports.engine.JasperPrint;
import java.awt.Component;
import javax.swing.JOptionPane;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.JasperExportManager;
import java.util.Map;
import net.sf.jasperreports.engine.JasperFillManager;
import java.util.HashMap;
import javax.swing.JTable;
import profac.com.database.consultasSQL_SERVER;
import profac.com.database.conexionSQL_SERVER;

public class Imprimir
{
    public conexionSQL_SERVER conexionSql;
    public consultasSQL_SERVER consultaSql;
    public JTable tblCuentasContables;
    public JTable tblCuentasContables_sumar;
    
    public Imprimir() {
        this.conexionSql = new conexionSQL_SERVER();
        this.consultaSql = new consultasSQL_SERVER();
        this.tblCuentasContables = new JTable();
        this.tblCuentasContables_sumar = new JTable();
    }
    
    public void imprimirPartidaContable(final String archivo, final int numPartida, final String usuario, final String nombreUsuario, final String nombreOficina, final String concep, final Double debe, final Double haber) {
        final String url = "src/reportes/" + archivo;
        try {
            final HashMap map = new HashMap();
            map.put("numPartida", numPartida);
            map.put("usuario", usuario);
            map.put("nombreUsuario", nombreUsuario);
            map.put("nombreOficina", nombreOficina);
            map.put("concep", concep);
            map.put("debe", debe);
            map.put("haber", haber);
            final JasperPrint jasperPrintWindow = JasperFillManager.fillReport(url, map, conexionSQL_SERVER.getConnection());
            JasperExportManager.exportReportToPdfFile(jasperPrintWindow, "C:/Program Files/ProFacV1/Reportes/" + archivo + ".pdf");
            final JasperViewer jasperViewer = new JasperViewer(jasperPrintWindow, false);
            jasperViewer.setVisible(true);
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
    }
    
    public void imprimirCatalogoCuentas(final String archivo, final String nombreUsuario, final String nombreOficina) {
        final String url = "src/reportes/" + archivo;
        try {
            final HashMap map = new HashMap();
            map.put("nombreUsuario", nombreUsuario);
            map.put("nombreOficina", nombreOficina);
            final JasperPrint jasperPrintWindow = JasperFillManager.fillReport(url, map, conexionSQL_SERVER.getConnection());
            JasperExportManager.exportReportToPdfFile(jasperPrintWindow, "C:/Program Files/ProFacV1/Reportes/" + archivo + ".pdf");
            final JasperViewer jasperViewer = new JasperViewer(jasperPrintWindow, false);
            jasperViewer.setVisible(true);
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
    }
    
    public void imprimirListadoPartidas(final String archivo, final String nombreUsuario, final String nombreOficina, final String fechaInicio, final String fechaFin) {
        final String url = "src/reportes/" + archivo;
        try {
            final HashMap map = new HashMap();
            map.put("nombreUsuario", nombreUsuario);
            map.put("nombreOficina", nombreOficina);
            map.put("fechaInicio", fechaInicio);
            map.put("fechaFin", fechaFin);
            final JasperPrint jasperPrintWindow = JasperFillManager.fillReport(url, map, conexionSQL_SERVER.getConnection());
            JasperExportManager.exportReportToPdfFile(jasperPrintWindow, "C:/Program Files/ProFacV1/Reportes/" + archivo + ".pdf");
            final JasperViewer jasperViewer = new JasperViewer(jasperPrintWindow, false);
            jasperViewer.setVisible(true);
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
    }
    
    public void imprimirUsuarioRegistrado(final String archivo, final String nombreOficina, final String nombreUsuario, final String usuario, final String password, final String estado) {
        final String url = "src/reportes/" + archivo;
        try {
            final HashMap map = new HashMap();
            map.put("nombreOficina", nombreOficina);
            map.put("nombreUsuario", nombreUsuario);
            map.put("usuario", usuario);
            map.put("contra", password);
            map.put("estado", estado);
            final JasperPrint jasperPrintWindow = JasperFillManager.fillReport(url, map, conexionSQL_SERVER.getConnection());
            JasperExportManager.exportReportToPdfFile(jasperPrintWindow, "C:/Program Files/ProFacV1/Reportes/" + archivo + ".pdf");
            final JasperViewer jasperViewer = new JasperViewer(jasperPrintWindow, false);
            jasperViewer.setVisible(true);
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
    }
    
    @SuppressWarnings({ "static-access", "rawtypes", "unchecked" })
	public void imprimirLibroContable_balanceComprobacion(String archivo, String usuario, String nombreOficina, String fecha1, String fecha2) {
		String url = "src/reportes/"+archivo;
		try {
			HashMap map = new HashMap();
			map.put("usuario", usuario);
			map.put("nombreOficina", nombreOficina);
			map.put("fecha1", fecha1);
			map.put("fecha2", fecha2);
			JasperPrint jasperPrintWindow = JasperFillManager.fillReport(url, map, conexionSql.getConnection());
			JasperExportManager.exportReportToPdfFile(jasperPrintWindow,"C:/Program Files/ProFacV1/Reportes/"+archivo+".pdf");
			JasperViewer jasperViewer = new JasperViewer(jasperPrintWindow,false);
			jasperViewer.setVisible(true);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "error al imprimir reporte -- "+e.toString(),"ERROR!",JOptionPane.ERROR_MESSAGE);
		}
	}
    
    public void imprimirCheque(final String archivo, final String ciudad, final String dia, final String mes, final String anio, final double monto, final String nombre, final String montoLetra, final int numeroPartida, final String descripcionPartida) {
        final String url = "src/reportes/" + archivo;
        try {
            final HashMap map = new HashMap();
            map.put("ciudad", ciudad);
            map.put("dia", dia);
            map.put("mes", mes);
            map.put("anio", anio);
            map.put("monto", monto);
            map.put("nombre", nombre);
            map.put("montoLetra", montoLetra);
            map.put("numeroPartida", numeroPartida);
            map.put("descripcion", descripcionPartida);
            final JasperPrint jasperPrintWindow = JasperFillManager.fillReport(url, map, conexionSQL_SERVER.getConnection());
            JasperExportManager.exportReportToPdfFile(jasperPrintWindow, "C:/Program Files/ProFacV1/Reportes/" + archivo + ".pdf");
            final JasperViewer jasperViewer = new JasperViewer(jasperPrintWindow, false);
            jasperViewer.setVisible(true);
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
    }
    
    public void imprimirReciboPago(final String archivo, final String fechaRecibo, final String nRecibo, final String montoPagado, final String tipoServicio, final String idServicio, final String nombreOficina, final String usuario, final String tipoRecibo, final String telefonoOficina) {
        final String url = "src/reportes/" + archivo;
        try {
            final HashMap map = new HashMap();
            map.put("fechaRecibo", fechaRecibo);
            map.put("nRecibo", nRecibo);
            map.put("montoPagado", montoPagado);
            map.put("tipoServicio", tipoServicio);
            map.put("idServicio", idServicio);
            map.put("nombreOficina", nombreOficina);
            map.put("usuario", usuario);
            map.put("tipoRecibo", tipoRecibo);
            map.put("telefonoOficina", telefonoOficina);
            final JasperPrint jasperPrintWindow = JasperFillManager.fillReport(url, map, conexionSQL_SERVER.getConnection());
            JasperExportManager.exportReportToPdfFile(jasperPrintWindow, "C:/Program Files/ProFacV1/Reportes/" + archivo + ".pdf");
            final JasperViewer jasperViewer = new JasperViewer(jasperPrintWindow, false);
            jasperViewer.setVisible(true);
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
    }
}
