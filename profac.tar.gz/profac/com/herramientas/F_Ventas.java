// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import javax.swing.JTable;
import profac.com.database.updateSQL_SERVER;
import profac.com.database.consultasSQL_SERVER;
import profac.com.database.insertSQL_SERVER;

public class F_Ventas
{
    public F_Inventario inventario;
    public F_Contabilidad contabilidad;
    public insertSQL_SERVER insertSql;
    public consultasSQL_SERVER consultaSql;
    public updateSQL_SERVER updateSql;
    
    public F_Ventas() {
        this.inventario = new F_Inventario();
        this.contabilidad = new F_Contabilidad();
        this.insertSql = new insertSQL_SERVER();
        this.consultaSql = new consultasSQL_SERVER();
        this.updateSql = new updateSQL_SERVER();
    }
    
    public boolean cobrarPedido(final JTable tblDetalle, final String idOficina, final String codCliente, final String fechaActual, final int idUsuario, final Double montoTotal, final int idBodega, final int numFactura, final String tipoFactura, final String formaPago) {
        boolean resultado = false;
        int idPedidoActual = 0;
        if (this.insertSql.insertPedidoVenta(idOficina, codCliente, fechaActual, idUsuario, montoTotal) != 0) {
            idPedidoActual = this.consultaSql.obtenerIdPedido(idOficina, codCliente, fechaActual, idUsuario, montoTotal);
            for (int i = 0; i < tblDetalle.getRowCount(); ++i) {
                resultado = (this.insertSql.insertPedidoVenta_detalle(idPedidoActual, Integer.parseInt(tblDetalle.getValueAt(i, 0).toString()), idBodega, Double.parseDouble(tblDetalle.getValueAt(i, 2).toString()), Double.parseDouble(tblDetalle.getValueAt(i, 3).toString()), Double.parseDouble(tblDetalle.getValueAt(i, 4).toString())) != 0 && this.insertSql.insertKardexProducto(Integer.parseInt(tblDetalle.getValueAt(i, 0).toString()), "FAC01", idBodega, Integer.toString(numFactura), Double.parseDouble(tblDetalle.getValueAt(i, 2).toString()) * -1.0, fechaActual, idUsuario, idOficina) != 0);
            }
            resultado = (this.contabilidad.partidaContable_facturacionProductos(this.consultaSql.obtenerSigIdPartidaContable(), tblDetalle, "VENTA DE PRODUCTO " + fechaActual, fechaActual, fechaActual, -1, "", "", idOficina, idUsuario, "FAC01", numFactura, tipoFactura) && resultado && this.updateSql.modificarCorrelativoTipoFactura(numFactura, idOficina, tipoFactura) != 0 && this.insertSql.insertFacturaVenta(formaPago, idPedidoActual, Variables.numeroPartida, fechaActual, montoTotal, tipoFactura) != 0);
        }
        else {
            resultado = false;
        }
        return resultado;
    }
}
