// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.herramientas;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Window;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.Base64;
import java.util.Iterator;
import java.util.Scanner;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;

import profac.com.login.Login;
import profac.com.submodulo.contabilidad.NuevaPartidaContable;

public class Ajustes
{
    public int ancho;
    public int alto;
    public int fuente_15;
    public ImageIcon img;
    public Icon icon;
    public int lecturaMedidor_banderaImprimir;
    public String lecturaMedidor_tipoDocumento;
    
    public Ajustes() {
        ancho = Toolkit.getDefaultToolkit().getScreenSize().width;
        alto = Toolkit.getDefaultToolkit().getScreenSize().height;
    }
    
    public int calcularPuntoX(double valor) {
        int pValor = (int)Math.round(valor * ancho / 100.0);
        return pValor;
    }
    
    public int calcularPuntoY(double valor) {
        int pValor = (int)Math.round(valor * alto / 100.0);
        return pValor;
    }
    
    public void setOpaque_login(Login login, boolean opaque) {
        try {
            Class<?> awtUtilsClass = Class.forName("com.sun.awt.AWTUtilities");
            if (awtUtilsClass != null) {
                Method method = awtUtilsClass.getMethod("setWindowOpaque", Window.class, Boolean.TYPE);
                method.invoke(null, login, opaque);
            }
        }
        catch (Exception ex) {}
    }
    
    public void setOpaque_nuevaPartida(NuevaPartidaContable npc, boolean opaque) {
        try {
            Class<?> awtUtilsClass = Class.forName("com.sun.awt.AWTUtilities");
            if (awtUtilsClass != null) {
                Method method = awtUtilsClass.getMethod("setWindowOpaque", Window.class, Boolean.TYPE);
                method.invoke(null, npc, opaque);
            }
        }
        catch (Exception ex) {}
    }
    
    public Icon ajustarImagen(String rutaImagen, JLabel label, int max_X, int max_Y, int x, int y) {
        int difx = max_X - x;
        int dify = max_Y - y;
        int newx = label.getWidth() - difx;
        int newy = label.getHeight() - dify;
        try {
            img = new ImageIcon(Ajustes.class.getResource(String.valueOf(rutaImagen) + "/" + newx + ".png"));
            icon = new ImageIcon(img.getImage().getScaledInstance(newx, newy, 1));
        }
        catch (Exception e) {
            img = new ImageIcon(Ajustes.class.getResource(String.valueOf(rutaImagen) + "/" + x + ".png"));
            icon = new ImageIcon(img.getImage().getScaledInstance(label.getWidth(), label.getHeight(), 1));
        }
        return icon;
    }
    
    public Icon ajustarImagen_menu(String rutaImagen, int max_X, int max_Y, int x, int y) {
        int difx = x;
        int dify = y;
        int newx = difx;
        int newy = dify;
        img = new ImageIcon(Ajustes.class.getResource(String.valueOf(rutaImagen) + "/" + newx + ".png"));
        if (x > max_X || y > max_Y) {
            icon = new ImageIcon(img.getImage().getScaledInstance(x, y, 1));
        }
        else {
            icon = new ImageIcon(img.getImage().getScaledInstance(newx, newy, 1));
        }
        return icon;
    }
    
    public Icon ajustarImagen_(String rutaImagen, JLabel label) {
        img = new ImageIcon(Ajustes.class.getResource(rutaImagen));
        return icon = new ImageIcon(img.getImage().getScaledInstance(label.getWidth(), label.getHeight(), 1));
    }
    
    public int ajustarTexto(int tipo, int tamObjeto) {
        int texto = 0;
        switch (tipo) {
            case 0: {
                texto = tamObjeto - 12;
                break;
            }
            case 1: {
                texto = tamObjeto - 3;
                break;
            }
            case 2: {
                texto = tamObjeto - 6;
                break;
            }
            case 3: {
                texto = tamObjeto - 26;
                break;
            }
        }
        return texto;
    }
    
    public void verificarCarpetaConfiguracion() {
        String ubicacionCarpeta = "C:/ProFacV1";
        try {
            File carpeta = new File(ubicacionCarpeta);
            if (!carpeta.exists()) {
                if (JOptionPane.showConfirmDialog(null, "La carpeta carpeta de configuracion no fue encontrada, ¿Desea Crearla?", "ERROR!", 0) != 0) {
                    return;
                }
                if (crearCarpetaConfiguracion(String.valueOf(ubicacionCarpeta) + "/Reportes") && crearCarpetaConfiguracion(String.valueOf(ubicacionCarpeta) + "/Config") && crearArchivoConfiguracion_baseDatos(String.valueOf(ubicacionCarpeta) + "/Config", "/ip.conf", "127.0.0.0") && crearArchivoConfiguracion_baseDatos(String.valueOf(ubicacionCarpeta) + "/Config", "/name.conf", "null") && crearArchivoConfiguracion_baseDatos(String.valueOf(ubicacionCarpeta) + "/Config", "/user.conf", "null") && crearArchivoConfiguracion_baseDatos(String.valueOf(ubicacionCarpeta) + "/Config", "/pass.conf", "null")) {
                    JOptionPane.showMessageDialog(null, "carpeta de configuracion creada correctamente", "OK!", 1);
                }
            }
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
    }
    
    public boolean crearCarpetaConfiguracion(String rutaCarpeta) {
        boolean resultado = false;
        try {
            File carpeta = new File(rutaCarpeta);
            if (!carpeta.exists() && carpeta.mkdirs()) {
                resultado = true;
            }
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
        return resultado;
    }
    
    public boolean crearArchivoConfiguracion_baseDatos(String rutaCarpeta, String nombreArchivo, String contenido) {
        boolean resultado = false;
        try {
            File archivo = new File(String.valueOf(rutaCarpeta) + nombreArchivo);
            if (!archivo.exists()) {
                archivo.createNewFile();
            }
            FileWriter fw = new FileWriter(archivo);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(encriptar(contenido));
            bw.close();
            resultado = true;
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
        return resultado;
    }
    
    public String leerArchivo(String rutaArchivo) {
        String cadena = "";
        try {
            Scanner input = new Scanner(new File(rutaArchivo));
            while (input.hasNextLine()) {
                cadena = String.valueOf(cadena) + input.nextLine();
            }
            input.close();
            cadena = desencriptar(cadena);
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.toString(), "ERROR!", 0);
        }
        return cadena;
    }
    
    public boolean modificarArchivoConfiguracion(String rutaArchivo, String contenidoNUevo, String nombreArchivo) {
        boolean resultado = false;
        try {
            File archivo = new File(String.valueOf(rutaArchivo) + nombreArchivo);
            if (archivo.delete() && crearArchivoConfiguracion_baseDatos(rutaArchivo, nombreArchivo, contenidoNUevo)) {
                resultado = true;
            }
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "ERROR!", 0);
        }
        return resultado;
    }
    
    public static String encriptar(String s) throws UnsupportedEncodingException {
        return Base64.getEncoder().encodeToString(s.getBytes("utf-8"));
    }
    
    public static String desencriptar(String s) throws UnsupportedEncodingException {
        byte[] decode = Base64.getDecoder().decode(s.getBytes());
        return new String(decode, "utf-8");
    }
    
    public String obtenerFecha(String anio, int mesIndex) {
        String mes = "";
        switch (mesIndex) {
            case 0: {
                mes = "01";
                break;
            }
            case 1: {
                mes = "02";
                break;
            }
            case 2: {
                mes = "03";
                break;
            }
            case 3: {
                mes = "04";
                break;
            }
            case 4: {
                mes = "05";
                break;
            }
            case 5: {
                mes = "06";
                break;
            }
            case 6: {
                mes = "07";
                break;
            }
            case 7: {
                mes = "08";
                break;
            }
            case 8: {
                mes = "09";
                break;
            }
            case 9: {
                mes = "10";
                break;
            }
            case 10: {
                mes = "11";
                break;
            }
            case 11: {
                mes = "12";
                break;
            }
        }
        String fecha = String.valueOf(anio) + mes + "01";
        return fecha;
    }
    

    public JTable configurarTabla(final JTable tabla) {
        DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        TableColumnModel columnModel = tabla.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = tabla.getTableHeader();
        Font fuente = new Font(Variables.fuenteLetra, 1,Variables.tamTituloTabla);
        header.setFont(fuente);
        tabla.setFont(new Font(Variables.fuenteLetra, Font.PLAIN, Variables.tamContenidoTabla));
        alinear.setHorizontalAlignment(0);
         for (int i = 0; i < columnModel.getColumnCount(); i++) {
			columnModel.getColumn(i).setCellRenderer(alinear);
		}
         tabla.setColumnModel(columnModel);
         return tabla;
    }
    
    public JTable configurarTabla(final JTable tabla,int[] tamanos) {
        DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        TableColumnModel columnModel = tabla.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = tabla.getTableHeader();
        Font fuente = new Font(Variables.fuenteLetra, 1,Variables.tamTituloTabla);
        header.setFont(fuente);
        tabla.setFont(new Font(Variables.fuenteLetra, Font.PLAIN, Variables.tamContenidoTabla));
        alinear.setHorizontalAlignment(0);
         for (int i = 0; i < columnModel.getColumnCount(); i++) {
			columnModel.getColumn(i).setCellRenderer(alinear);
			columnModel.getColumn(i).setPreferredWidth(tamanos[i]);;
		}
         tabla.setColumnModel(columnModel);
         
         return tabla;
    }
    

    @SuppressWarnings("unused")
	public JTable configurarTabla(JTable tabla, int[] tamanos, int[] alinear_) {
        JTable tablaRetorno = null;
        TableColumnModel columnModel = tabla.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = tabla.getTableHeader();
        Font fuente = new Font(Variables.fuenteLetra, 1,Variables.tamTituloTabla);
        header.setFont(fuente);
        tabla.setFont(new Font(Variables.fuenteLetra, Font.PLAIN, Variables.tamContenidoTabla));
        for (int i = 0; i < columnModel.getColumnCount(); i++) {
        	DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        	if(alinear_[i] == 0) {
        		alinear.setHorizontalAlignment(0);
        	}else {
        		alinear.setHorizontalAlignment(2);
        	}
        	columnModel.getColumn(i).setCellRenderer(alinear);
			columnModel.getColumn(i).setPreferredWidth(tamanos[i]);
		}
         tabla.setColumnModel(columnModel);
         tabla.setDefaultEditor(Object.class, null);
         return tabla;
    }
    
    
}
