package profac.com.herramientas;
import java.util.Calendar;
import java.util.regex.Pattern;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Fechas {

	DateTimeFormatter formatter;
	LocalDate localDate = LocalDate.now();
	public Calendar operadorFechas = Calendar.getInstance();
	public String fechaUsuario;
	public String fechaSistema;
	public boolean fechaValidaParaUsuarios(final String fecha) {
		if (fecha!=null) {
			if (!fecha.isEmpty()) {
				String regexp = "(0?[0-9]|[12][0-9]|3[01])(0?[1-9]|1[012])((18|19|20|21)\\d\\d)";	
				return Pattern.matches(regexp,fecha);			
			}
			return false;
		}
		return false;
	}
	
	
		
	public String fechaParaUsuario(final String fecha) {
		
			if (fechaValidaParaUsuarios(fecha)) {
				String dia =  fecha.substring(0, 2);
				String mes = fecha.substring(2, 4);
				String anio = fecha.substring(4,8);
				
				this.fechaUsuario = dia + "/" + mes + "/" + anio;
				return this.fechaUsuario;
			}
		formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		this.fechaUsuario =  localDate.format(formatter);
		return this.fechaUsuario;
	}
	

	
	public String fechaParaSistema() {			
		try {
			
			String[] fecha =  this.fechaUsuario.split("/");
				String dia =  fecha[0];
				String mes = fecha[1];
				String anio = fecha[2];
				final String fechaSistemaString = anio + "-" + mes + "-" + dia;			
			LocalDate fechaUsuarioDate = LocalDate.parse(fechaSistemaString);
			return fechaUsuarioDate.toString();
			
		} catch (NullPointerException e) {
			System.out.println("El usuario no ingreso una fecha");
			return LocalDate.now().toString();
		}	
	}
	
	public String fechaParaSistema(final String fechaUsuario) {			
		try {
			
			String[] fecha =  fechaUsuario.split("/");
				String dia =  fecha[0];
				String mes = fecha[1];
				String anio = fecha[2];
				final String fechaSistemaString = anio + "-" + mes + "-" + dia;			
			LocalDate fechaUsuarioDate = LocalDate.parse(fechaSistemaString);
			return fechaUsuarioDate.toString();
			
		} catch (NullPointerException e) {
			System.out.println("El usuario no ingreso una fecha");
			return LocalDate.now().toString();
		}	
	}
	
	
	public String operarFechas(int operacion,final String fecha,int valorOperar) {
		 String dia =  fecha.substring(0, 2);
		 String mes = fecha.substring(3, 5);
		 String anio = fecha.substring(6,10);
		
		switch (operacion) {
		case 1:
			int diaOperado = Integer.parseInt(dia) + valorOperar;
			dia = (diaOperado<10 && diaOperado<=31) ? dia="0"+diaOperado: String.valueOf(diaOperado);
			break;
		case 2:
			int mesOperado = Integer.parseInt(mes) + valorOperar;
			mes = (mesOperado<10 && mesOperado<=31) ? mes="0"+mesOperado: String.valueOf(mesOperado);
			break;
		case 3:
			int anioOperado = Integer.parseInt(anio) + valorOperar;
			anio = (anioOperado<10 && anioOperado<=31) ? anio="0"+anioOperado: String.valueOf(anioOperado);
			break;
		default:
			break;
		}
		
		return dia + "/" + mes + "/" + anio;
	}
		
}



