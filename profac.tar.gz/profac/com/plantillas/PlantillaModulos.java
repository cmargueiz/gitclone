package profac.com.plantillas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import Animacion.Animacion;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Variables;
import profac.com.login.Login;
import profac.com.modulos.Principal;

public class PlantillaModulos extends JFrame{
    /**
	 * @author Frank Castro
	 */
	private static final long serialVersionUID = 1L;
    public Ajustes ajustes = new Ajustes();
    
    private JPanel contentPane;
    private JLabel btnMinimizar;
    private JLabel btnCerrar;
    private JLabel lblNombreOficina;
    private JLabel lblFechaSistema;
    private JPanel jp_menuLateral;
    private JLabel lblUsuarioLateral;
    private JLabel lblNombreUsuarioLateral;
    private JLabel lblCargoUsuarioLateral;
    private JLabel btnMenuPricipal;
    private JLabel btnConfiguracion;
    private JLabel btnCerrarSesion;
    
    public boolean bandera_menuLateral = false;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                   PlantillaModulos frame = new PlantillaModulos();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public PlantillaModulos() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                lblNombreUsuarioLateral.setText(Variables.nombreUsuario);
                lblCargoUsuarioLateral.setText(Variables.cargoUsuario);
                lblNombreOficina.setText(Variables.nombreOficina);
                lblFechaSistema.setText(Variables.fechaSistema);
                lblUsuarioLateral.setText(Variables.usuario);
            }
        });
        setDefaultCloseOperation(3);
        setResizable(false);
        setUndecorated(true);
        setBounds(0, 0, ajustes.ancho, ajustes.alto);
        contentPane = new JPanel();
        contentPane.setBackground(Variables.color_tres);
        contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        jp_menuLateral = new JPanel();
        jp_menuLateral.setBackground(Variables.color_uno);
        jp_menuLateral.setBounds(ajustes.calcularPuntoX(15.63) * -1, ajustes.calcularPuntoY(6.57), ajustes.calcularPuntoX(15.63), ajustes.alto - ajustes.calcularPuntoY(6.57));
        contentPane.add(jp_menuLateral);
        jp_menuLateral.setLayout(null);
        
        JLabel lblLogo = new JLabel("");
        lblLogo.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(1.39), ajustes.calcularPuntoX(10.52), ajustes.calcularPuntoY(18.7));
        lblLogo.setIcon(ajustes.ajustarImagen("/general_07_icono_logo", lblLogo, 202, 202, 202, 202));
        jp_menuLateral.add(lblLogo);
        
        lblNombreUsuarioLateral = new JLabel("Nombre de Usuario");
        lblNombreUsuarioLateral.setForeground(Variables.color_dos);
        lblNombreUsuarioLateral.setHorizontalAlignment(0);
        lblNombreUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreUsuarioLateral.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(21.76), ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(1.85));
        jp_menuLateral.add(lblNombreUsuarioLateral);
        
        lblCargoUsuarioLateral = new JLabel("Cargo de Usuario");
        lblCargoUsuarioLateral.setForeground(Variables.color_dos);
        lblCargoUsuarioLateral.setHorizontalAlignment(0);
        lblCargoUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblCargoUsuarioLateral.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(25.46), ajustes.calcularPuntoX(14.32), ajustes.calcularPuntoY(2.31));
        jp_menuLateral.add(lblCargoUsuarioLateral);
        
        JSeparator s1 = new JSeparator();
        s1.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(28.24), ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(0.28));
        jp_menuLateral.add(s1);
        
        JPanel jp_opcionesMenuLateral = new JPanel();
        jp_opcionesMenuLateral.setOpaque(false);
        jp_opcionesMenuLateral.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(29.17), ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(59.72));
        jp_menuLateral.add(jp_opcionesMenuLateral);
        
        jp_opcionesMenuLateral.setLayout(null);
        JPanel jp_btnMenuPrincipal = new JPanel();
        jp_btnMenuPrincipal.setBackground(Variables.color_tres);
        jp_btnMenuPrincipal.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnMenuPrincipal.setBounds(0, 0, ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnMenuPrincipal);
        jp_btnMenuPrincipal.setLayout(null);
        
        btnMenuPricipal = new JLabel("");
        btnMenuPricipal.setCursor(Cursor.getPredefinedCursor(12));
        btnMenuPricipal.setBounds(0, 0, ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(4.17));
        btnMenuPricipal.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_dos);
            }
        });
        btnMenuPricipal.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                boton(4);
            }
        });
        jp_btnMenuPrincipal.add(btnMenuPricipal);
        
        JLabel lblIconoBtn_menuPrincipal = new JLabel("");
        lblIconoBtn_menuPrincipal.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.08), ajustes.calcularPuntoY(3.24));
        lblIconoBtn_menuPrincipal.setIcon(ajustes.ajustarImagen("/general_08_icono_menuprincipal", lblIconoBtn_menuPrincipal, 40, 35, 40, 35));
        jp_btnMenuPrincipal.add(lblIconoBtn_menuPrincipal);
        
        JLabel lblNombreBtn_menuPrincipal = new JLabel("Menu Principal");
        lblNombreBtn_menuPrincipal.setForeground(Variables.color_uno);
        lblNombreBtn_menuPrincipal.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_menuPrincipal.setBounds(ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(10.94), ajustes.calcularPuntoY(3.24));
        jp_btnMenuPrincipal.add(lblNombreBtn_menuPrincipal);
        
        JPanel jp_btnConfiguracion = new JPanel();
        jp_btnConfiguracion.setLayout(null);
        jp_btnConfiguracion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnConfiguracion.setBackground(Variables.color_tres);
        jp_btnConfiguracion.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnConfiguracion);
        
        btnConfiguracion = new JLabel("");
        btnConfiguracion.setCursor(Cursor.getPredefinedCursor(12));
        btnConfiguracion.setBounds(0, 0, ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(4.17));
        btnConfiguracion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_dos);
            }
        });
        btnConfiguracion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Modulo en Mantenimiento", "ALERTA!", 2);
            }
        });
        jp_btnConfiguracion.add(btnConfiguracion);
        JLabel lblIconoBtn_configuracion = new JLabel("");
        lblIconoBtn_configuracion.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.08), ajustes.calcularPuntoY(3.24));
        lblIconoBtn_configuracion.setIcon(ajustes.ajustarImagen("/general_09_icono_configuracion", lblIconoBtn_configuracion, 40, 35, 40, 35));
        jp_btnConfiguracion.add(lblIconoBtn_configuracion);
        
        JLabel lblNombreBtn_configuracion = new JLabel("Configuraci\u00f3n");
        lblNombreBtn_configuracion.setForeground(SystemColor.controlHighlight);
        lblNombreBtn_configuracion.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_configuracion.setBounds(ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(10.94), ajustes.calcularPuntoY(3.24));
        jp_btnConfiguracion.add(lblNombreBtn_configuracion);
        
        JPanel jp_btnCerrarSesion = new JPanel();
        jp_btnCerrarSesion.setLayout(null);
        jp_btnCerrarSesion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnCerrarSesion.setBackground(Variables.color_tres);
        jp_btnCerrarSesion.setBounds(0, ajustes.calcularPuntoY(11.11), ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnCerrarSesion);
        
        btnCerrarSesion = new JLabel("");
        btnCerrarSesion.setCursor(Cursor.getPredefinedCursor(12));
        btnCerrarSesion.setBounds(0, 0, ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(4.17));
        btnCerrarSesion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_dos);
            }
        });
        btnCerrarSesion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                boton(3);
            }
        });
        jp_btnCerrarSesion.add(btnCerrarSesion);
        
        JLabel lblIconoBtn_cerrarSesion = new JLabel("");
        lblIconoBtn_cerrarSesion.setBounds(ajustes.calcularPuntoX(0.52), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.82), ajustes.calcularPuntoY(3.24));
        lblIconoBtn_cerrarSesion.setIcon(ajustes.ajustarImagen("/general_10_icono_cerrarSesion", lblIconoBtn_cerrarSesion, 35, 35, 35, 35));
        jp_btnCerrarSesion.add(lblIconoBtn_cerrarSesion);
        
        JLabel lblNombreBtn_cerrarSesion = new JLabel("Cerrar Sesi\u00f3n");
        lblNombreBtn_cerrarSesion.setForeground(SystemColor.controlHighlight);
        lblNombreBtn_cerrarSesion.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_cerrarSesion.setBounds(ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(10.94), ajustes.calcularPuntoY(3.24));
        jp_btnCerrarSesion.add(lblNombreBtn_cerrarSesion);
        
        JSeparator s2 = new JSeparator();
        s2.setBounds(ajustes.calcularPuntoX(0.78), ajustes.alto - ajustes.calcularPuntoY(9.72), ajustes.calcularPuntoX(14.06), ajustes.calcularPuntoY(0.28));
        jp_menuLateral.add(s2);
        
        lblUsuarioLateral = new JLabel("usuario");
        lblUsuarioLateral.setForeground(Variables.color_tres);
        lblUsuarioLateral.setHorizontalAlignment(0);
        lblUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblUsuarioLateral.setBounds(0, ajustes.alto - ajustes.calcularPuntoY(8.8), ajustes.calcularPuntoX(15.63), ajustes.calcularPuntoY(1.85));
        jp_menuLateral.add(lblUsuarioLateral);
        
        JPanel jp_info = new JPanel();
        jp_info.setBackground(Variables.color_uno);
        jp_info.setBorder(new BevelBorder(0, null, null, null, null));
        jp_info.setBounds(0, 0, ajustes.ancho, ajustes.calcularPuntoY(2.78));
        jp_info.setLayout(null);
        contentPane.add(jp_info);
        
        btnMinimizar = new JLabel("");
        btnMinimizar.setCursor(Cursor.getPredefinedCursor(12));
        btnMinimizar.setBounds(ajustes.ancho - ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(0.65), ajustes.calcularPuntoX(1.04), ajustes.calcularPuntoY(1.85));
        btnMinimizar.setIcon(ajustes.ajustarImagen("/general_03_icono_minimizar", btnMinimizar, 20, 20, 20, 20));
        btnMinimizar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                cambioImage_(btnMinimizar, "/general_03_icono_minimizar_select", 20);
            }
        });
        btnMinimizar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                cambioImage_(btnMinimizar, "/general_03_icono_minimizar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                boton(1);
            }
        });
        jp_info.add(btnMinimizar);
        
        btnCerrar = new JLabel("");
        btnCerrar.setCursor(Cursor.getPredefinedCursor(12));
        btnCerrar.setBackground(Variables.color_uno);
        btnCerrar.setBounds(ajustes.ancho - ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.04), ajustes.calcularPuntoY(1.85));
        btnCerrar.setIcon(ajustes.ajustarImagen("/general_04_icono_cerrar", btnCerrar, 20, 20, 20, 20));
        btnCerrar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                cambioImage_(btnCerrar, "/general_04_icono_cerrar_select", 20);
            }
        });
        btnCerrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                cambioImage_(btnCerrar, "/general_04_icono_cerrar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                boton(3);
            }
        });
        jp_info.add(btnCerrar);
        
        JLabel lblNombreVentana = new JLabel("Plantilla Modulo");
        lblNombreVentana.setForeground(Variables.color_dos);
        lblNombreVentana.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreVentana.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.ancho / 3, ajustes.calcularPuntoY(1.85));
        jp_info.add(lblNombreVentana);
        
        lblNombreOficina = new JLabel("Nombre de Oficina");
        lblNombreOficina.setForeground(Variables.color_dos);
        lblNombreOficina.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreOficina.setBounds(ajustes.ancho / 3 + ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.ancho / 3, ajustes.calcularPuntoY(1.85));
        jp_info.add(lblNombreOficina);
        
        lblFechaSistema = new JLabel("Fecha del Sistema");
        lblFechaSistema.setForeground(Variables.color_dos);
        lblFechaSistema.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblFechaSistema.setBounds(ajustes.ancho / 3 + ajustes.ancho / 3 + ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.ancho / 3 - ajustes.calcularPuntoX(4.43), ajustes.calcularPuntoY(1.85));
        jp_info.add(lblFechaSistema);
        
        JPanel jp_menu = new JPanel();
        jp_menu.setBackground(Variables.color_dos);
        jp_menu.setBorder(new LineBorder(Variables.color_dos));
        jp_menu.setBounds(0, ajustes.calcularPuntoY(2.78), ajustes.ancho, ajustes.calcularPuntoY(3.8));
        jp_menu.setLayout(null);
        contentPane.add(jp_menu);
        
        JLabel btnMenuLateral = new JLabel("");
        btnMenuLateral.setCursor(Cursor.getPredefinedCursor(12));
        btnMenuLateral.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.98), ajustes.calcularPuntoY(2.87));
        btnMenuLateral.setIcon(ajustes.ajustarImagen("/general_05_icono_menulateral", btnMenuLateral, 38, 31, 38, 31));
        btnMenuLateral.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                cambioImage_(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
        });
        btnMenuLateral.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                cambioImage_(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                boton(2);
            }
        });
        jp_menu.add(btnMenuLateral);
        
        JPanel jp_contenedor = new JPanel();
        jp_contenedor.setOpaque(false);
        jp_contenedor.setBounds(0, ajustes.calcularPuntoY(6.57), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(8.8));
        jp_contenedor.setLayout(null);
        contentPane.add(jp_contenedor);
        
        JPanel jp_copyright = new JPanel();
        jp_copyright.setLayout(null);
        jp_copyright.setOpaque(false);
        jp_copyright.setBounds(ajustes.calcularPuntoX(47.66), ajustes.calcularPuntoY(98.15), ajustes.calcularPuntoX(4.69), ajustes.calcularPuntoY(1.3));
        contentPane.add(jp_copyright);
        
        JLabel lblIconoCopyRight = new JLabel("");
        lblIconoCopyRight.setBounds(0, 0, ajustes.calcularPuntoX(0.73), ajustes.calcularPuntoY(1.3));
        lblIconoCopyRight.setIcon(ajustes.ajustarImagen("/general_00_icono_copyright_gris", lblIconoCopyRight, 14, 14, 14, 14));
        jp_copyright.add(lblIconoCopyRight);
        
        JLabel lblNombreCopyRight = new JLabel(Variables.copyRight);
        lblNombreCopyRight.setForeground(Variables.color_uno);
        lblNombreCopyRight.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.3))));
        lblNombreCopyRight.setBounds(ajustes.calcularPuntoX(1.04), 0, ajustes.calcularPuntoX(3.65), ajustes.calcularPuntoY(1.3));
        jp_copyright.add(lblNombreCopyRight);
    }
    
    @Override
    public void dispose() {
        getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void cambioImage_(final JLabel lblImg,String cadenaImagen,int tamImg) {
        lblImg.setIcon(ajustes.ajustarImagen(cadenaImagen, lblImg, tamImg, tamImg, tamImg, tamImg));
    }
    
    public void boton(final int op) {
        switch (op) {
            case 0: {
                System.exit(2);
                break;
            }
            case 1: {
                setExtendedState(1);
                break;
            }
            case 2: {
                if (!bandera_menuLateral) {
                    Animacion.mover_derecha(ajustes.calcularPuntoX(15.63) * -1, 0, 5L, 5, jp_menuLateral);
                    bandera_menuLateral = true;
                    break;
                }
                Animacion.mover_izquierda(0, ajustes.calcularPuntoX(15.63) * -1, 5L, 5, jp_menuLateral);
                bandera_menuLateral = false;
                break;
            }
            case 3: {
                if (JOptionPane.showConfirmDialog(rootPane, "¿Desea Cerrar Sesi\u00f3n?", "Cerrar Sesi\u00f3n", 0) == 0) {
                   Login login = new Login();
                    login.setVisible(true);
                    dispose();
                    break;
                }
                break;
            }
            case 4: {
               Principal pri = new Principal();
                pri.setVisible(true);
                dispose();
                break;
            }
        }
    }
}
