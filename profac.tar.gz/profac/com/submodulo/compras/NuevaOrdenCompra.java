// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.compras;

import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import javax.swing.text.Document;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.event.WindowListener;
import javax.swing.table.TableModel;
import profac.com.herramientas.Variables;
import javax.swing.ComboBoxModel;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Inventario;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevaOrdenCompra extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Inventario inventario;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaOrden;
    private JLabel btnNuevaOrden;
    private JLabel lblIconoBtn_nuevaOrden;
    private JLabel lblNombreBtn_nuevaOrden;
    private JPanel jp_btnBuscarOrden;
    private JLabel btnBuscarOrden;
    private JLabel lblIconoBtn_buscarOrden;
    private JLabel lblNombreBtn_buscarOrden;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JTextField txtNombreBuscar;
    private JTable tblProductos;
    private JTextField txtNOrden;
    private JLabel lblFechaRegistro;
    private JTextField txtFechaReg;
    private JLabel lblFechaPago;
    private JTextField txtFechaPag;
    private JLabel lblProveedor;
    private JComboBox<Object> cbxProveedor;
    private JLabel lblDescripcion;
    private JTextField txtDescripcion;
    private JLabel lblIdProducto;
    private JTextField txtidProducto;
    private JLabel lblNombreProducto;
    private JTextField txtNombreProducto;
    private JLabel lblCantidadProducto;
    private JTextField txtCantidadProducto;
    private JLabel lblPrecioProducto;
    private JTextField txtPrecioProducto;
    private JPanel jp_btnAgregar;
    private JPanel jp_tblOrdenCompra;
    private JTextField txtTotalPrecio;
    private JLabel lblTotal;
    private JLabel label;
    private JLabel lblIconoBtn_agregar;
    private JLabel lblNombreBtn_agregar;
    private JLabel btnAgregar;
    private JTable tblDetalleOrdenCompra;
    DefaultTableModel modeloTblDetalle;
    public int contadorFecha;
    private JLabel lblSubrubro;
    private JComboBox<Object> cbxSubrubro;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevaOrdenCompra frame = new NuevaOrdenCompra();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevaOrdenCompra() {
        this.ajustes = new Ajustes();
        this.inventario = new F_Inventario();
        this.consultaSql = new consultasSQL_SERVER();
        this.contadorFecha = 0;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevaOrdenCompra.this.cbxSubrubro.setModel(NuevaOrdenCompra.this.consultaSql.getDataComboBox("select nombre from subcategoria order by idSubcategoria asc"));
                NuevaOrdenCompra.this.txtFechaReg.setText(Variables.fechaActual);
                NuevaOrdenCompra.this.txtFechaPag.setText(Variables.fechaActual);
                NuevaOrdenCompra.this.cbxProveedor.setModel(NuevaOrdenCompra.this.consultaSql.getDataComboBox("select nombre from proveedor order by nombre asc"));
                NuevaOrdenCompra.this.tblProductos.setModel(NuevaOrdenCompra.this.consultaSql.llenarTablaListaProductos_ordenCompra("%%"));
                NuevaOrdenCompra.this.configurarTabla(0);
                NuevaOrdenCompra.this.txtNOrden.setText(Integer.toString(NuevaOrdenCompra.this.consultaSql.obtenerSigIdOrdenCompra()));
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaOrden = new JPanel()).setLayout(null);
        this.jp_btnNuevaOrden.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaOrden.setBackground(Variables.color_tres);
        this.jp_btnNuevaOrden.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaOrden);
        (this.btnNuevaOrden = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaOrden.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaOrden.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnNuevaOrden.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaOrden.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnNuevaOrden.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaOrden.add(this.btnNuevaOrden);
        (this.lblIconoBtn_nuevaOrden = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaOrden.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaOrden));
        this.jp_btnNuevaOrden.add(this.lblIconoBtn_nuevaOrden);
        (this.lblNombreBtn_nuevaOrden = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaOrden.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaOrden.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaOrden.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaOrden.add(this.lblNombreBtn_nuevaOrden);
        (this.jp_btnBuscarOrden = new JPanel()).setLayout(null);
        this.jp_btnBuscarOrden.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarOrden.setBackground(Variables.color_tres);
        this.jp_btnBuscarOrden.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarOrden);
        (this.btnBuscarOrden = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarOrden.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarOrden.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnBuscarOrden.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarOrden.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnBuscarOrden.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarOrden.add(this.btnBuscarOrden);
        (this.lblIconoBtn_buscarOrden = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarOrden.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarOrden));
        this.jp_btnBuscarOrden.add(this.lblIconoBtn_buscarOrden);
        (this.lblNombreBtn_buscarOrden = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarOrden.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarOrden.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarOrden.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarOrden.add(this.lblNombreBtn_buscarOrden);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaOrdenCompra.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaOrdenCompra.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.43), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblnewlabel = new JLabel("Crear Nueva Orden de Compra")).setForeground(Variables.color_uno);
        this.lblnewlabel.setHorizontalAlignment(0);
        this.lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.calcularPuntoY(1.85)));
        this.lblnewlabel.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.31));
        jp_contenido.add(this.lblnewlabel);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JPanel jp_productos = new JPanel();
        jp_productos.setBackground(Variables.color_uno);
        jp_productos.setBorder(new BevelBorder(0, null, null, null, null));
        jp_productos.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(77.31));
        jp_contenido.add(jp_productos);
        jp_productos.setLayout(null);
        final JSeparator separator_1 = new JSeparator();
        separator_1.setForeground(Variables.color_dos);
        separator_1.setBounds(this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(1.85), this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(0.19));
        jp_productos.add(separator_1);
        final JLabel lblBuscarProducto = new JLabel("Buscar Producto");
        lblBuscarProducto.setForeground(Variables.color_dos);
        lblBuscarProducto.setHorizontalAlignment(0);
        lblBuscarProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblBuscarProducto.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(28.39), this.ajustes.calcularPuntoY(1.85));
        jp_productos.add(lblBuscarProducto);
        final JSeparator separator_2 = new JSeparator();
        separator_2.setForeground(Variables.color_dos);
        separator_2.setBounds(this.ajustes.calcularPuntoX(19.27), this.ajustes.calcularPuntoY(1.85), this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(0.19));
        jp_productos.add(separator_2);
        final JSeparator separator_3 = new JSeparator();
        separator_3.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(3.24), this.ajustes.calcularPuntoX(28.29), this.ajustes.calcularPuntoY(0.19));
        jp_productos.add(separator_3);
        final JLabel lblNombreDeProducto = new JLabel("Nombre de Producto:");
        lblNombreDeProducto.setForeground(Variables.color_dos);
        lblNombreDeProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreDeProducto.setHorizontalAlignment(0);
        lblNombreDeProducto.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(4.17), this.ajustes.calcularPuntoX(22.66), this.ajustes.calcularPuntoY(1.85));
        jp_productos.add(lblNombreDeProducto);
        (this.txtNombreBuscar = new JTextField()).setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreBuscar.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(6.48), this.ajustes.calcularPuntoX(22.66), this.ajustes.calcularPuntoY(2.78));
        jp_productos.add(this.txtNombreBuscar);
        this.txtNombreBuscar.setColumns(10);
        final JPanel jp_btnBuscar = new JPanel();
        jp_btnBuscar.setLayout(null);
        jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscar.setBackground(Variables.color_tres);
        jp_btnBuscar.setBounds(this.ajustes.calcularPuntoX(23.7), this.ajustes.calcularPuntoY(6.48), this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(8.8));
        jp_productos.add(jp_btnBuscar);
        final JLabel btnBuscar = new JLabel("");
        btnBuscar.setCursor(Cursor.getPredefinedCursor(12));
        btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
            }
        });
        btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_dos);
            }
        });
        btnBuscar.setBounds(0, 0, this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(8.8));
        jp_btnBuscar.add(btnBuscar);
        final JLabel lblIconoBtn_buscar = new JLabel("");
        lblIconoBtn_buscar.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/general-16-icono-buscar.png", lblIconoBtn_buscar));
        jp_btnBuscar.add(lblIconoBtn_buscar);
        final JLabel lblNombreBtn_buscar = new JLabel("Buscar");
        lblNombreBtn_buscar.setHorizontalAlignment(0);
        lblNombreBtn_buscar.setForeground(Variables.color_uno);
        lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_buscar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(2.78));
        jp_btnBuscar.add(lblNombreBtn_buscar);
        (this.lblSubrubro = new JLabel("Sub-Rubro:")).setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblSubrubro.setForeground(Variables.color_dos);
        this.lblSubrubro.setHorizontalAlignment(0);
        this.lblSubrubro.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(10.19), this.ajustes.calcularPuntoX(22.66), this.ajustes.calcularPuntoY(1.85));
        jp_productos.add(this.lblSubrubro);
        (this.cbxSubrubro = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cbxSubrubro.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxSubrubro.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(12.5), this.ajustes.calcularPuntoX(22.66), this.ajustes.calcularPuntoY(2.78));
        jp_productos.add(this.cbxSubrubro);
        final JPanel jp_tblProductos = new JPanel();
        jp_tblProductos.setBackground(Variables.color_uno);
        jp_tblProductos.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(16.2), this.ajustes.calcularPuntoX(28.39), this.ajustes.calcularPuntoY(60.19));
        jp_productos.add(jp_tblProductos);
        jp_tblProductos.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, this.ajustes.calcularPuntoX(28.39), this.ajustes.calcularPuntoY(60.19));
        jp_tblProductos.add(scrollPane);
        (this.tblProductos = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblProductos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevaOrdenCompra.this.seleccionarProducto();
            }
        });
        this.tblProductos.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        scrollPane.setViewportView(this.tblProductos);
        final JLabel lblNOrdenCompra = new JLabel("Nº Orden de Compra:");
        lblNOrdenCompra.setForeground(Variables.color_uno);
        lblNOrdenCompra.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNOrdenCompra.setHorizontalAlignment(0);
        lblNOrdenCompra.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNOrdenCompra);
        (this.txtNOrden = new JTextField()).setHorizontalAlignment(0);
        this.txtNOrden.setEditable(false);
        this.txtNOrden.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNOrden.setBackground(Variables.color_uno);
        this.txtNOrden.setForeground(Variables.color_dos);
        this.txtNOrden.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNOrden);
        this.txtNOrden.setColumns(10);
        (this.lblFechaRegistro = new JLabel("Fecha Registro:")).setForeground(Variables.color_uno);
        this.lblFechaRegistro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaRegistro.setHorizontalAlignment(0);
        this.lblFechaRegistro.setBounds((this.ajustes.ancho - 25) / 10 * 6 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaRegistro);
        (this.txtFechaReg = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaReg.setEditable(false);
        this.txtFechaReg.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaReg.setBackground(Variables.color_uno);
        this.txtFechaReg.setForeground(Variables.color_dos);
        this.txtFechaReg.setBounds((this.ajustes.ancho - 25) / 10 * 6 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaReg);
        this.txtFechaReg.setColumns(10);
        (this.lblFechaPago = new JLabel("Fecha de Pago:")).setForeground(Variables.color_uno);
        this.lblFechaPago.setHorizontalAlignment(0);
        this.lblFechaPago.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaPago.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaPago);
        (this.txtFechaPag = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaPag.setDocument(new LimitadorCaracteres(this.txtFechaPag, 10));
        this.txtFechaPag.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(final FocusEvent arg0) {
                NuevaOrdenCompra.this.contadorFecha = 0;
                NuevaOrdenCompra.this.txtFechaPag.setText("");
            }
        });
        this.txtFechaPag.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(final KeyEvent arg0) {
                final int k = arg0.getKeyChar();
                if (k >= 48 && k <= 57) {
                    if (NuevaOrdenCompra.this.contadorFecha == 2 || NuevaOrdenCompra.this.contadorFecha == 4) {
                        NuevaOrdenCompra.this.txtFechaPag.setText(String.valueOf(NuevaOrdenCompra.this.txtFechaPag.getText()) + "/");
                    }
                    final NuevaOrdenCompra this$0 = NuevaOrdenCompra.this;
                    ++this$0.contadorFecha;
                }
                else {
                    arg0.setKeyChar('\f');
                }
            }
        });
        this.txtFechaPag.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaPag.setBackground(Variables.color_uno);
        this.txtFechaPag.setForeground(Variables.color_dos);
        this.txtFechaPag.setColumns(10);
        this.txtFechaPag.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaPag);
        (this.lblProveedor = new JLabel("Proveedor:")).setForeground(Variables.color_uno);
        this.lblProveedor.setHorizontalAlignment(0);
        this.lblProveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblProveedor.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(11.57), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblProveedor);
        (this.cbxProveedor = new JComboBox<Object>()).setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxProveedor.setBackground(Variables.color_uno);
        this.cbxProveedor.setForeground(Variables.color_dos);
        this.cbxProveedor.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(13.89), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxProveedor);
        (this.lblDescripcion = new JLabel("Descripci\u00f3n:")).setForeground(Variables.color_uno);
        this.lblDescripcion.setHorizontalAlignment(0);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(18.52), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.78), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescripcion);
        (this.txtDescripcion = new JTextField()).setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setBackground(Variables.color_uno);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(20.83), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcion);
        this.txtDescripcion.setColumns(10);
        (this.lblIdProducto = new JLabel("ID Producto:")).setForeground(Variables.color_uno);
        this.lblIdProducto.setHorizontalAlignment(0);
        this.lblIdProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblIdProducto.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(25.46), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblIdProducto);
        (this.txtidProducto = new JTextField()).setHorizontalAlignment(0);
        this.txtidProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtidProducto.setBackground(Variables.color_uno);
        this.txtidProducto.setForeground(Variables.color_dos);
        this.txtidProducto.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(27.78), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtidProducto);
        this.txtidProducto.setColumns(10);
        (this.lblNombreProducto = new JLabel("Nombre de Producto:")).setForeground(Variables.color_uno);
        this.lblNombreProducto.setHorizontalAlignment(0);
        this.lblNombreProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreProducto.setBounds((this.ajustes.ancho - 25) / 10 * 4 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(25.46), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNombreProducto);
        (this.txtNombreProducto = new JTextField()).setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreProducto.setBackground(Variables.color_uno);
        this.txtNombreProducto.setForeground(Variables.color_dos);
        this.txtNombreProducto.setColumns(10);
        this.txtNombreProducto.setBounds((this.ajustes.ancho - 25) / 10 * 4 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(27.78), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreProducto);
        (this.lblCantidadProducto = new JLabel("Cantidad:")).setForeground(Variables.color_uno);
        this.lblCantidadProducto.setHorizontalAlignment(0);
        this.lblCantidadProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCantidadProducto.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(25.46), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblCantidadProducto);
        (this.txtCantidadProducto = new JTextField()).setText("0.00");
        this.txtCantidadProducto.setHorizontalAlignment(0);
        this.txtCantidadProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCantidadProducto.setBackground(Variables.color_uno);
        this.txtCantidadProducto.setForeground(Variables.color_dos);
        this.txtCantidadProducto.setColumns(10);
        this.txtCantidadProducto.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(27.78), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCantidadProducto);
        (this.lblPrecioProducto = new JLabel("Precio:")).setForeground(Variables.color_uno);
        this.lblPrecioProducto.setHorizontalAlignment(0);
        this.lblPrecioProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPrecioProducto.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(25.46), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblPrecioProducto);
        (this.txtPrecioProducto = new JTextField()).setText("0.00");
        this.txtPrecioProducto.setHorizontalAlignment(0);
        this.txtPrecioProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPrecioProducto.setBackground(Variables.color_uno);
        this.txtPrecioProducto.setForeground(Variables.color_dos);
        this.txtPrecioProducto.setColumns(10);
        this.txtPrecioProducto.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(27.78), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtPrecioProducto);
        (this.jp_btnAgregar = new JPanel()).setBackground(Variables.color_uno);
        this.jp_btnAgregar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnAgregar.setBounds((this.ajustes.ancho - 25) / 10 * 9 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(25.46), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(5.09));
        jp_contenido.add(this.jp_btnAgregar);
        this.jp_btnAgregar.setLayout(null);
        (this.btnAgregar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnAgregar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnAgregar.setBackground(Variables.color_uno);
                NuevaOrdenCompra.this.lblIconoBtn_agregar.setIcon(NuevaOrdenCompra.this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar.png", NuevaOrdenCompra.this.lblIconoBtn_agregar));
                NuevaOrdenCompra.this.lblNombreBtn_agregar.setForeground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaOrdenCompra.this.llenarTabla();
            }
        });
        this.btnAgregar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaOrdenCompra.this.jp_btnAgregar.setBackground(Variables.color_dos);
                NuevaOrdenCompra.this.lblIconoBtn_agregar.setIcon(NuevaOrdenCompra.this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar-select.png", NuevaOrdenCompra.this.lblIconoBtn_agregar));
                NuevaOrdenCompra.this.lblNombreBtn_agregar.setForeground(Variables.color_uno);
            }
        });
        this.btnAgregar.setBounds(0, 0, this.ajustes.calcularPuntoX(8.59), this.ajustes.calcularPuntoY(5.09));
        this.jp_btnAgregar.add(this.btnAgregar);
        (this.lblIconoBtn_agregar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(4.17));
        this.lblIconoBtn_agregar.setIcon(this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar.png", this.lblIconoBtn_agregar));
        this.jp_btnAgregar.add(this.lblIconoBtn_agregar);
        (this.lblNombreBtn_agregar = new JLabel("Agregar")).setForeground(Variables.color_dos);
        this.lblNombreBtn_agregar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_agregar.setHorizontalAlignment(0);
        this.lblNombreBtn_agregar.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(5.47), this.ajustes.calcularPuntoY(4.17));
        this.jp_btnAgregar.add(this.lblNombreBtn_agregar);
        (this.jp_tblOrdenCompra = new JPanel()).setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(32.41), this.ajustes.calcularPuntoX(66.3), this.ajustes.calcularPuntoY(45.83));
        jp_contenido.add(this.jp_tblOrdenCompra);
        this.jp_tblOrdenCompra.setLayout(null);
        final JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(0, 0, this.ajustes.calcularPuntoX(66.3), this.ajustes.calcularPuntoY(45.83));
        this.jp_tblOrdenCompra.add(scrollPane_1);
        (this.tblDetalleOrdenCompra = new JTable()).setBackground(Variables.color_uno);
        this.tblDetalleOrdenCompra.setForeground(Variables.color_dos);
        this.tblDetalleOrdenCompra.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        (this.modeloTblDetalle = new DefaultTableModel()).addColumn("ID");
        this.modeloTblDetalle.addColumn("Nombre de Producto");
        this.modeloTblDetalle.addColumn("Cant.");
        this.modeloTblDetalle.addColumn("Precio Uni.");
        this.modeloTblDetalle.addColumn("Precio Total");
        this.tblDetalleOrdenCompra.setModel(this.modeloTblDetalle);
        this.configurarTabla(1);
        scrollPane_1.setViewportView(this.tblDetalleOrdenCompra);
        (this.lblTotal = new JLabel("Total:")).setForeground(Variables.color_uno);
        this.lblTotal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblTotal.setHorizontalAlignment(4);
        this.lblTotal.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(79.17), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblTotal);
        (this.txtTotalPrecio = new JTextField()).setHorizontalAlignment(0);
        this.txtTotalPrecio.setText("0.00");
        this.txtTotalPrecio.setColumns(10);
        this.txtTotalPrecio.setForeground(Variables.color_dos);
        this.txtTotalPrecio.setBackground(Variables.color_uno);
        this.txtTotalPrecio.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtTotalPrecio.setBounds(this.ajustes.calcularPuntoX(83.33), this.ajustes.calcularPuntoY(79.17), this.ajustes.calcularPuntoX(15.1), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtTotalPrecio);
        (this.label = new JLabel("$")).setForeground(Variables.color_uno);
        this.label.setHorizontalAlignment(0);
        this.label.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
        this.label.setBounds(this.ajustes.calcularPuntoX(81.25), this.ajustes.calcularPuntoY(79.17), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.label);
        this.menuEmergente();
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void configurarTabla(final int op) {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        switch (op) {
            case 0: {
                final TableColumnModel columnModel = this.tblProductos.getColumnModel();
                header = this.tblProductos.getTableHeader();
                header.setFont(fuente);
                header.setForeground(Variables.color_dos);
                alinear.setHorizontalAlignment(0);
                columnModel.getColumn(0).setPreferredWidth(30);
                columnModel.getColumn(0).setCellRenderer(alinear);
                columnModel.getColumn(1).setPreferredWidth(250);
                columnModel.getColumn(2).setPreferredWidth(75);
                columnModel.getColumn(2).setCellRenderer(alinear);
                break;
            }
            case 1: {
                final TableColumnModel columnModel = this.tblDetalleOrdenCompra.getColumnModel();
                header = this.tblDetalleOrdenCompra.getTableHeader();
                header.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
                header.setForeground(Variables.color_dos);
                alinear.setHorizontalAlignment(0);
                columnModel.getColumn(0).setPreferredWidth(50);
                columnModel.getColumn(0).setCellRenderer(alinear);
                columnModel.getColumn(1).setPreferredWidth(500);
                columnModel.getColumn(2).setPreferredWidth(75);
                columnModel.getColumn(2).setCellRenderer(alinear);
                columnModel.getColumn(3).setPreferredWidth(100);
                columnModel.getColumn(3).setCellRenderer(alinear);
                columnModel.getColumn(4).setPreferredWidth(100);
                columnModel.getColumn(4).setCellRenderer(alinear);
                break;
            }
        }
    }
    
    public void seleccionarProducto() {
        this.txtidProducto.setText((String)this.tblProductos.getValueAt(this.tblProductos.getSelectedRow(), 0));
        this.txtNombreProducto.setText((String)this.tblProductos.getValueAt(this.tblProductos.getSelectedRow(), 1));
    }
    
    public void llenarTabla() {
        final Object[] object = { this.txtidProducto.getText(), this.txtNombreProducto.getText(), this.txtCantidadProducto.getText(), this.txtPrecioProducto.getText(), null };
        final double cant = Double.parseDouble(this.txtCantidadProducto.getText());
        final double precio = Double.parseDouble(this.txtPrecioProducto.getText());
        object[4] = Double.toString(cant * precio);
        this.modeloTblDetalle.addRow(object);
        this.txtidProducto.setText("");
        this.txtNombreProducto.setText("");
        this.txtCantidadProducto.setText("0.00");
        this.txtPrecioProducto.setText("0.00");
        final double precioTotal = Double.parseDouble(this.txtTotalPrecio.getText());
        this.txtTotalPrecio.setText(Double.toString(cant * precio + precioTotal));
    }
    
    public void menuEmergente() {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JMenuItem mntmBorrarItem = new JMenuItem("Borrar", new ImageIcon(this.getClass().getResource("/images/general-19-icono-borrar.png")));
        mntmBorrarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmBorrarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final double cant = Double.parseDouble((String)NuevaOrdenCompra.this.tblDetalleOrdenCompra.getValueAt(NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow(), 2));
                final double precio = Double.parseDouble((String)NuevaOrdenCompra.this.tblDetalleOrdenCompra.getValueAt(NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow(), 3));
                final double precioTotal = Double.parseDouble(NuevaOrdenCompra.this.txtTotalPrecio.getText());
                NuevaOrdenCompra.this.txtTotalPrecio.setText(Double.toString(precioTotal - cant * precio));
                final int fila = NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow();
                if (fila != -1) {
                    NuevaOrdenCompra.this.modeloTblDetalle.removeRow(fila);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Debe seleccionar una fila", "ADVERTENCIA!", 2);
                }
            }
        });
        popupMenu.add(mntmBorrarItem);
        this.tblDetalleOrdenCompra.setComponentPopupMenu(popupMenu);
        final JMenuItem mntmEditarItem = new JMenuItem("Editar", new ImageIcon(this.getClass().getResource("/images/general-20-icono-editar.png")));
        mntmEditarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmEditarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                NuevaOrdenCompra.this.txtidProducto.setText((String)NuevaOrdenCompra.this.tblDetalleOrdenCompra.getValueAt(NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow(), 0));
                NuevaOrdenCompra.this.txtNombreProducto.setText((String)NuevaOrdenCompra.this.tblDetalleOrdenCompra.getValueAt(NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow(), 1));
                NuevaOrdenCompra.this.txtCantidadProducto.setText((String)NuevaOrdenCompra.this.tblDetalleOrdenCompra.getValueAt(NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow(), 2));
                NuevaOrdenCompra.this.txtPrecioProducto.setText((String)NuevaOrdenCompra.this.tblDetalleOrdenCompra.getValueAt(NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow(), 3));
                final double cant = Double.parseDouble(NuevaOrdenCompra.this.txtCantidadProducto.getText());
                final double precio = Double.parseDouble(NuevaOrdenCompra.this.txtPrecioProducto.getText());
                final double precioTotal = Double.parseDouble(NuevaOrdenCompra.this.txtTotalPrecio.getText());
                NuevaOrdenCompra.this.txtTotalPrecio.setText(Double.toString(precioTotal - cant * precio));
                final int fila = NuevaOrdenCompra.this.tblDetalleOrdenCompra.getSelectedRow();
                if (fila != -1) {
                    NuevaOrdenCompra.this.modeloTblDetalle.removeRow(fila);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Debe seleccionar una fila", "ADVERTENCIA!", 2);
                }
            }
        });
        popupMenu.add(mntmEditarItem);
        this.tblDetalleOrdenCompra.setComponentPopupMenu(popupMenu);
    }
    
    public void guardar() {
        boolean resultado = false;
        final String nOrden = Integer.toString(this.consultaSql.obtenerSigIdOrdenCompra());
        if (!nOrden.equals(this.txtNOrden.getText())) {
            this.txtNOrden.setText(nOrden);
            JOptionPane.showMessageDialog(null, "La Partida N°" + this.txtNOrden.getText().toString() + " ya fue utilizada por otro usuario, se cambio al Nº" + this.txtNOrden.getText(), "ALERTA!", 2);
        }
        resultado = this.inventario.nuevaOrdenCompra(this.tblDetalleOrdenCompra, this.consultaSql.obtenerIdProveedor(this.cbxProveedor.getSelectedItem().toString()), this.txtFechaReg.getText(), this.txtFechaPag.getText(), this.txtDescripcion.getText(), Variables.idUsuario, Variables.idOficina, Integer.parseInt(this.txtNOrden.getText()));
        if (resultado) {
            JOptionPane.showMessageDialog(null, "Orden de Compra Nº " + this.txtNOrden.getText() + " Guardado correctamente ", "OK!", 1);
            return;
        }
        JOptionPane.showMessageDialog(null, "Al crear la orden de compra -- " + Variables.error, "ERROR!", 0);
    }
}
