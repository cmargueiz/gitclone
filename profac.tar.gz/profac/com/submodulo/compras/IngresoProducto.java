// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.compras;

import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.text.DecimalFormat;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.border.LineBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.event.WindowListener;
import javax.swing.ComboBoxModel;
import profac.com.herramientas.Variables;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Inventario;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class IngresoProducto extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Inventario inventario;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JLabel lblTipoDeIngreso;
    private JComboBox<Object> cbxTipoIngreso;
    private JLabel lblFechaDeIngreso;
    private JTextField txtFechaIngreso;
    private JLabel lblNOrden;
    private JTextField txtNOrdenCompra;
    private JPanel jp_btnBuscarOC;
    private JLabel lblBodega;
    private JComboBox<Object> cbxBodega;
    private JLabel lblIconoBtn_buscarOrden;
    private JLabel btnBuscarOrden;
    private JLabel lblProveedor;
    private JComboBox<Object> cbxProveedor;
    private JLabel lblFormaPago;
    private JComboBox<Object> cbxFormaPago;
    private JPanel jp_btnOpcion1;
    private JLabel lblFondoBtn_opcion1;
    private JLabel lblIconoBtn_opcion1;
    private JLabel lblNombreBtn_opcion1;
    private JLabel btnOpcion1;
    private JPanel jp_btnOpcion2;
    private JLabel btnOpcion2;
    private JLabel lblIconoBtn_opcion2;
    private JLabel lblNombreBtn_opcion2;
    private JLabel lblFondoBtn_opcion2;
    private JPanel jp_DetalleOpcion1;
    private JLabel lblIdProducto;
    private JTextField txtIdProducto;
    private JLabel lblNombreDeProdcuto;
    private JTextField txtNombreProducto;
    private JLabel lblCantidadProducto;
    private JTextField txtCantidadProducto;
    private JLabel lblPrecioProducto;
    private JTextField txtPrecioProducto;
    private JPanel jp_btnAgregar;
    private JLabel btnAgregar;
    private JLabel lblIconoBtn_agregar;
    private JLabel lblNombreBtn_agregar;
    private JLabel lblPrecioProducto_iva;
    private JTextField txtPrecioProducto_iva;
    private JLabel lblPrecioProducto_total;
    private JTextField txtPrecioProducto_total;
    private JPanel jp_detalleOrdenCompra;
    public boolean v_btnOpcion1;
    public boolean v_btnOpcion2;
    private JTextField txtTotalPrecio;
    private JLabel lblTotalIva;
    private JTextField txtTotalIva;
    private JLabel lblTotalFactura;
    private JTextField txtTotalFactura;
    private JScrollPane scrollPane;
    private JTable tblDetalleOrdenCompra;
    private JLabel lblApartadoParaLa;
    private JPanel jp_DetalleOpcion2;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final IngresoProducto frame = new IngresoProducto();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public IngresoProducto() {
        this.ajustes = new Ajustes();
        this.inventario = new F_Inventario();
        this.consultaSql = new consultasSQL_SERVER();
        this.v_btnOpcion1 = true;
        this.v_btnOpcion2 = false;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                IngresoProducto.this.txtFechaIngreso.setText(Variables.fechaActual);
                IngresoProducto.this.cbxBodega.setModel(IngresoProducto.this.consultaSql.getDataComboBox("select nombreBodega from bodega where oficina_idoficina = '" + Variables.idOficina + "'"));
                IngresoProducto.this.cbxProveedor.setModel(IngresoProducto.this.consultaSql.getDataComboBox("select nombre from proveedor order by nombre asc"));
                IngresoProducto.this.cbxFormaPago.setModel(IngresoProducto.this.consultaSql.getDataComboBox("select CONCAT(idformaPago,' - ',descripcion) from formaPago"));
                if (Variables.ventana_ingresarOrdenCompra) {
                    IngresoProducto.this.buscarOrdenCompra(Variables.idOrdenCompra);
                }
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaPartida = new JPanel()).setLayout(null);
        this.jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
        this.jp_btnNuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaPartida);
        (this.btnNuevaPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaPartida.add(this.btnNuevaPartida);
        (this.lblIconoBtn_nuevaPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaPartida));
        this.jp_btnNuevaPartida.add(this.lblIconoBtn_nuevaPartida);
        (this.lblNombreBtn_nuevaPartida = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaPartida.add(this.lblNombreBtn_nuevaPartida);
        (this.jp_btnBuscarPartida = new JPanel()).setLayout(null);
        this.jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
        this.jp_btnBuscarPartida.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarPartida);
        (this.btnBuscarPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarPartida.add(this.btnBuscarPartida);
        (this.lblIconoBtn_buscarPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarPartida));
        this.jp_btnBuscarPartida.add(this.lblIconoBtn_buscarPartida);
        (this.lblNombreBtn_buscarPartida = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarPartida.add(this.lblNombreBtn_buscarPartida);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                IngresoProducto.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                IngresoProducto.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.43), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblnewlabel = new JLabel("Ingreso de Productos")).setForeground(Variables.color_uno);
        this.lblnewlabel.setHorizontalAlignment(0);
        this.lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.calcularPuntoY(1.85)));
        this.lblnewlabel.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.31));
        jp_contenido.add(this.lblnewlabel);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        (this.lblTipoDeIngreso = new JLabel("Tipo de Ingreso:")).setForeground(Variables.color_uno);
        this.lblTipoDeIngreso.setHorizontalAlignment(0);
        this.lblTipoDeIngreso.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblTipoDeIngreso.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblTipoDeIngreso);
        (this.cbxTipoIngreso = new JComboBox<Object>()).setModel(new DefaultComboBoxModel<Object>(new String[] { "Compra Local", "Compra para Proyectos", "Donaciones" }));
        this.cbxTipoIngreso.setBackground(Variables.color_uno);
        this.cbxTipoIngreso.setForeground(Variables.color_dos);
        this.cbxTipoIngreso.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxTipoIngreso.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxTipoIngreso);
        (this.lblFechaDeIngreso = new JLabel("Fecha de Ingreso:")).setForeground(Variables.color_uno);
        this.lblFechaDeIngreso.setHorizontalAlignment(0);
        this.lblFechaDeIngreso.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaDeIngreso.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaDeIngreso);
        (this.txtFechaIngreso = new JTextField()).setBackground(Variables.color_uno);
        this.txtFechaIngreso.setForeground(Variables.color_dos);
        this.txtFechaIngreso.setHorizontalAlignment(0);
        this.txtFechaIngreso.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaIngreso.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaIngreso);
        this.txtFechaIngreso.setColumns(10);
        (this.lblNOrden = new JLabel("Nº Orden:")).setForeground(Variables.color_uno);
        this.lblNOrden.setHorizontalAlignment(0);
        this.lblNOrden.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNOrden.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(10.65), this.ajustes.calcularPuntoX(7.81), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNOrden);
        (this.txtNOrdenCompra = new JTextField()).setHorizontalAlignment(0);
        this.txtNOrdenCompra.setForeground(Variables.color_dos);
        this.txtNOrdenCompra.setBackground(Variables.color_uno);
        this.txtNOrdenCompra.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNOrdenCompra.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(12.96), this.ajustes.calcularPuntoX(7.81), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNOrdenCompra);
        this.txtNOrdenCompra.setColumns(10);
        (this.jp_btnBuscarOC = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarOC.setBackground(Variables.color_uno);
        this.jp_btnBuscarOC.setBounds(this.ajustes.calcularPuntoX(9.64), this.ajustes.calcularPuntoY(10.65), this.ajustes.calcularPuntoX(2.86), this.ajustes.calcularPuntoY(5.09));
        jp_contenido.add(this.jp_btnBuscarOC);
        this.jp_btnBuscarOC.setLayout(null);
        (this.btnBuscarOrden = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarOrden.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnBuscarOC.setBackground(Variables.color_uno);
                IngresoProducto.this.lblIconoBtn_buscarOrden.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", IngresoProducto.this.lblIconoBtn_buscarOrden));
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                IngresoProducto.this.buscarOrdenCompra(IngresoProducto.this.txtNOrdenCompra.getText());
            }
        });
        this.btnBuscarOrden.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnBuscarOC.setBackground(Variables.color_dos);
                IngresoProducto.this.lblIconoBtn_buscarOrden.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar-select.png", IngresoProducto.this.lblIconoBtn_buscarOrden));
            }
        });
        this.btnBuscarOrden.setBounds(0, 0, this.ajustes.calcularPuntoX(2.86), this.ajustes.calcularPuntoY(5.09));
        this.jp_btnBuscarOC.add(this.btnBuscarOrden);
        (this.lblIconoBtn_buscarOrden = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(4.17));
        this.lblIconoBtn_buscarOrden.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", this.lblIconoBtn_buscarOrden));
        this.jp_btnBuscarOC.add(this.lblIconoBtn_buscarOrden);
        (this.lblBodega = new JLabel("Bodega:")).setHorizontalAlignment(0);
        this.lblBodega.setForeground(Variables.color_uno);
        this.lblBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBodega.setBounds(this.ajustes.calcularPuntoX(13.02), this.ajustes.calcularPuntoY(10.65), this.ajustes.calcularPuntoX(27.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblBodega);
        (this.cbxBodega = new JComboBox<Object>()).setBackground(Variables.color_uno);
        this.cbxBodega.setForeground(Variables.color_dos);
        this.cbxBodega.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxBodega.setBounds(this.ajustes.calcularPuntoX(13.02), this.ajustes.calcularPuntoY(12.96), this.ajustes.calcularPuntoX(27.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxBodega);
        (this.lblProveedor = new JLabel("Proveedor:")).setHorizontalAlignment(0);
        this.lblProveedor.setForeground(Variables.color_uno);
        this.lblProveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblProveedor.setBounds((this.ajustes.ancho - 25) / 10 * 4 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(10.65), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblProveedor);
        (this.cbxProveedor = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cbxProveedor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxProveedor.setBackground(Variables.color_uno);
        this.cbxProveedor.setBounds((this.ajustes.ancho - 25) / 10 * 4 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(12.96), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxProveedor);
        (this.lblFormaPago = new JLabel("Forma de Pago:")).setHorizontalAlignment(0);
        this.lblFormaPago.setForeground(Variables.color_uno);
        this.lblFormaPago.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFormaPago.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(10.65), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFormaPago);
        (this.cbxFormaPago = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cbxFormaPago.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxFormaPago.setBackground(Variables.color_uno);
        this.cbxFormaPago.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(12.96), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxFormaPago);
        (this.jp_btnOpcion1 = new JPanel()).setOpaque(false);
        this.jp_btnOpcion1.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(17.59), this.ajustes.calcularPuntoX(10.42), this.ajustes.calcularPuntoY(4.63));
        jp_contenido.add(this.jp_btnOpcion1);
        this.jp_btnOpcion1.setLayout(null);
        (this.btnOpcion1 = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnOpcion1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                if (!IngresoProducto.this.v_btnOpcion1) {
                    IngresoProducto.this.lblFondoBtn_opcion1.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-30-icono-pestana.png", IngresoProducto.this.lblFondoBtn_opcion1));
                    IngresoProducto.this.lblNombreBtn_opcion1.setForeground(Variables.color_dos);
                    IngresoProducto.this.lblIconoBtn_opcion1.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-32-icono-productos-select.png", IngresoProducto.this.lblIconoBtn_opcion1));
                }
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                if (!IngresoProducto.this.v_btnOpcion1) {
                    IngresoProducto.this.seleccionarOpcion(1);
                }
            }
        });
        this.btnOpcion1.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                if (!IngresoProducto.this.v_btnOpcion1) {
                    IngresoProducto.this.lblFondoBtn_opcion1.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-30-icono-pestana-select.png", IngresoProducto.this.lblFondoBtn_opcion1));
                    IngresoProducto.this.lblNombreBtn_opcion1.setForeground(Variables.color_uno);
                    IngresoProducto.this.lblIconoBtn_opcion1.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-32-icono-productos.png", IngresoProducto.this.lblIconoBtn_opcion1));
                }
            }
        });
        this.btnOpcion1.setBounds(0, 0, this.ajustes.calcularPuntoX(10.42), this.ajustes.calcularPuntoY(4.63));
        this.jp_btnOpcion1.add(this.btnOpcion1);
        (this.lblIconoBtn_opcion1 = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.7));
        this.lblIconoBtn_opcion1.setIcon(this.ajustes.ajustarImagen_("/images/general-32-icono-productos.png", this.lblIconoBtn_opcion1));
        this.jp_btnOpcion1.add(this.lblIconoBtn_opcion1);
        (this.lblNombreBtn_opcion1 = new JLabel("Productos")).setForeground(Variables.color_uno);
        this.lblNombreBtn_opcion1.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNombreBtn_opcion1.setHorizontalAlignment(0);
        this.lblNombreBtn_opcion1.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(6.77), this.ajustes.calcularPuntoY(3.7));
        this.jp_btnOpcion1.add(this.lblNombreBtn_opcion1);
        (this.lblFondoBtn_opcion1 = new JLabel("")).setBounds(0, 0, this.ajustes.calcularPuntoX(10.42), this.ajustes.calcularPuntoY(4.63));
        this.lblFondoBtn_opcion1.setIcon(this.ajustes.ajustarImagen_("/images/general-30-icono-pestana-select.png", this.lblFondoBtn_opcion1));
        this.jp_btnOpcion1.add(this.lblFondoBtn_opcion1);
        (this.jp_btnOpcion2 = new JPanel()).setLayout(null);
        this.jp_btnOpcion2.setOpaque(false);
        this.jp_btnOpcion2.setBounds(this.ajustes.calcularPuntoX(11.72), this.ajustes.calcularPuntoY(17.59), this.ajustes.calcularPuntoX(10.42), this.ajustes.calcularPuntoY(4.63));
        jp_contenido.add(this.jp_btnOpcion2);
        (this.btnOpcion2 = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent e) {
                if (!IngresoProducto.this.v_btnOpcion2) {
                    IngresoProducto.this.lblFondoBtn_opcion2.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-30-icono-pestana.png", IngresoProducto.this.lblFondoBtn_opcion2));
                    IngresoProducto.this.lblNombreBtn_opcion2.setForeground(Variables.color_dos);
                    IngresoProducto.this.lblIconoBtn_opcion2.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-31-icono-factura-select.png", IngresoProducto.this.lblIconoBtn_opcion2));
                }
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                if (!IngresoProducto.this.v_btnOpcion2) {
                    IngresoProducto.this.seleccionarOpcion(2);
                }
            }
        });
        this.btnOpcion2.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent e) {
                if (!IngresoProducto.this.v_btnOpcion2) {
                    IngresoProducto.this.lblFondoBtn_opcion2.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-30-icono-pestana-select.png", IngresoProducto.this.lblFondoBtn_opcion2));
                    IngresoProducto.this.lblNombreBtn_opcion2.setForeground(Variables.color_uno);
                    IngresoProducto.this.lblIconoBtn_opcion2.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/general-31-icono-factura.png", IngresoProducto.this.lblIconoBtn_opcion2));
                }
            }
        });
        this.btnOpcion2.setCursor(Cursor.getPredefinedCursor(12));
        this.btnOpcion2.setBounds(0, 0, this.ajustes.calcularPuntoX(10.42), this.ajustes.calcularPuntoY(4.63));
        this.jp_btnOpcion2.add(this.btnOpcion2);
        (this.lblIconoBtn_opcion2 = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.7));
        this.lblIconoBtn_opcion2.setIcon(this.ajustes.ajustarImagen_("/images/general-31-icono-factura-select.png", this.lblIconoBtn_opcion2));
        this.jp_btnOpcion2.add(this.lblIconoBtn_opcion2);
        (this.lblNombreBtn_opcion2 = new JLabel("Factura")).setHorizontalAlignment(0);
        this.lblNombreBtn_opcion2.setForeground(Variables.color_dos);
        this.lblNombreBtn_opcion2.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNombreBtn_opcion2.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(6.77), this.ajustes.calcularPuntoY(3.7));
        this.jp_btnOpcion2.add(this.lblNombreBtn_opcion2);
        (this.lblFondoBtn_opcion2 = new JLabel("")).setBounds(0, 0, this.ajustes.calcularPuntoX(10.42), this.ajustes.calcularPuntoY(4.63));
        this.lblFondoBtn_opcion2.setIcon(this.ajustes.ajustarImagen_("/images/general-30-icono-pestana.png", this.lblFondoBtn_opcion2));
        this.jp_btnOpcion2.add(this.lblFondoBtn_opcion2);
        (this.jp_DetalleOpcion1 = new JPanel()).setBorder(new LineBorder(Variables.color_dos, 2));
        this.jp_DetalleOpcion1.setOpaque(false);
        this.jp_DetalleOpcion1.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(22.22), this.ajustes.ancho - 50, this.ajustes.calcularPuntoY(59.72));
        jp_contenido.add(this.jp_DetalleOpcion1);
        this.jp_DetalleOpcion1.setLayout(null);
        (this.lblIdProducto = new JLabel("ID Producto:")).setHorizontalAlignment(0);
        this.lblIdProducto.setForeground(Variables.color_uno);
        this.lblIdProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblIdProducto.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(this.lblIdProducto);
        (this.txtIdProducto = new JTextField()).setHorizontalAlignment(0);
        this.txtIdProducto.setForeground(Variables.color_dos);
        this.txtIdProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtIdProducto.setColumns(10);
        this.txtIdProducto.setBackground(Variables.color_uno);
        this.txtIdProducto.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(3.7), (this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtIdProducto);
        (this.lblNombreDeProdcuto = new JLabel("Nombre de Producto:")).setHorizontalAlignment(0);
        this.lblNombreDeProdcuto.setForeground(Variables.color_uno);
        this.lblNombreDeProdcuto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreDeProdcuto.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.6), 20);
        this.jp_DetalleOpcion1.add(this.lblNombreDeProdcuto);
        (this.txtNombreProducto = new JTextField()).setForeground(Variables.color_dos);
        this.txtNombreProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreProducto.setColumns(10);
        this.txtNombreProducto.setBackground(Variables.color_uno);
        this.txtNombreProducto.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(3.7), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtNombreProducto);
        (this.lblCantidadProducto = new JLabel("Cantidad:")).setHorizontalAlignment(0);
        this.lblCantidadProducto.setForeground(Variables.color_uno);
        this.lblCantidadProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCantidadProducto.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(this.lblCantidadProducto);
        (this.txtCantidadProducto = new JTextField()).setText("0.00");
        this.txtCantidadProducto.setHorizontalAlignment(0);
        this.txtCantidadProducto.setForeground(Variables.color_dos);
        this.txtCantidadProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCantidadProducto.setColumns(10);
        this.txtCantidadProducto.setBackground(Variables.color_uno);
        this.txtCantidadProducto.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.7), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtCantidadProducto);
        (this.lblPrecioProducto = new JLabel("Precio:")).setHorizontalAlignment(0);
        this.lblPrecioProducto.setForeground(Variables.color_uno);
        this.lblPrecioProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPrecioProducto.setBounds((this.ajustes.ancho - 25) / 10 * 6 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(this.lblPrecioProducto);
        (this.txtPrecioProducto = new JTextField()).setText("0.00");
        this.txtPrecioProducto.setHorizontalAlignment(0);
        this.txtPrecioProducto.setForeground(Variables.color_dos);
        this.txtPrecioProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPrecioProducto.setColumns(10);
        this.txtPrecioProducto.setBackground(Variables.color_uno);
        this.txtPrecioProducto.setBounds((this.ajustes.ancho - 25) / 10 * 6 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.7), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtPrecioProducto);
        (this.lblPrecioProducto_iva = new JLabel("IVA:")).setHorizontalAlignment(0);
        this.lblPrecioProducto_iva.setForeground(Variables.color_uno);
        this.lblPrecioProducto_iva.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPrecioProducto_iva.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(this.lblPrecioProducto_iva);
        (this.txtPrecioProducto_iva = new JTextField()).setText("0.00");
        this.txtPrecioProducto_iva.setHorizontalAlignment(0);
        this.txtPrecioProducto_iva.setForeground(Variables.color_dos);
        this.txtPrecioProducto_iva.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPrecioProducto_iva.setColumns(10);
        this.txtPrecioProducto_iva.setBackground(Variables.color_uno);
        this.txtPrecioProducto_iva.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.7), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtPrecioProducto_iva);
        (this.lblPrecioProducto_total = new JLabel("Total:")).setHorizontalAlignment(0);
        this.lblPrecioProducto_total.setForeground(Variables.color_uno);
        this.lblPrecioProducto_total.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPrecioProducto_total.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(this.lblPrecioProducto_total);
        (this.txtPrecioProducto_total = new JTextField()).setText("0.00");
        this.txtPrecioProducto_total.setHorizontalAlignment(0);
        this.txtPrecioProducto_total.setForeground(Variables.color_dos);
        this.txtPrecioProducto_total.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPrecioProducto_total.setColumns(10);
        this.txtPrecioProducto_total.setBackground(Variables.color_uno);
        this.txtPrecioProducto_total.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.7), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtPrecioProducto_total);
        (this.jp_btnAgregar = new JPanel()).setLayout(null);
        this.jp_btnAgregar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnAgregar.setBackground(Variables.color_uno);
        this.jp_btnAgregar.setBounds((this.ajustes.ancho - 25) / 10 * 9 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(5.09));
        this.jp_DetalleOpcion1.add(this.jp_btnAgregar);
        (this.btnAgregar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnAgregar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnAgregar.setBackground(Variables.color_uno);
                IngresoProducto.this.lblIconoBtn_agregar.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar.png", IngresoProducto.this.lblIconoBtn_agregar));
                IngresoProducto.this.lblNombreBtn_agregar.setForeground(Variables.color_dos);
            }
        });
        this.btnAgregar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                IngresoProducto.this.jp_btnAgregar.setBackground(Variables.color_dos);
                IngresoProducto.this.lblIconoBtn_agregar.setIcon(IngresoProducto.this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar-select.png", IngresoProducto.this.lblIconoBtn_agregar));
                IngresoProducto.this.lblNombreBtn_agregar.setForeground(Variables.color_uno);
            }
        });
        this.btnAgregar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(5.09));
        this.jp_btnAgregar.add(this.btnAgregar);
        (this.lblIconoBtn_agregar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(4.17));
        this.lblIconoBtn_agregar.setIcon(this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar.png", this.lblIconoBtn_agregar));
        this.jp_btnAgregar.add(this.lblIconoBtn_agregar);
        (this.lblNombreBtn_agregar = new JLabel("Agregar")).setHorizontalAlignment(0);
        this.lblNombreBtn_agregar.setForeground(Variables.color_dos);
        this.lblNombreBtn_agregar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_agregar.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.65), this.ajustes.calcularPuntoY(4.17));
        this.jp_btnAgregar.add(this.lblNombreBtn_agregar);
        (this.jp_detalleOrdenCompra = new JPanel()).setBackground(Variables.color_uno);
        this.jp_detalleOrdenCompra.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(7.41), this.ajustes.ancho - 80, this.ajustes.calcularPuntoY(39.81));
        this.jp_DetalleOpcion1.add(this.jp_detalleOrdenCompra);
        this.jp_detalleOrdenCompra.setLayout(null);
        (this.scrollPane = new JScrollPane()).setBounds(0, 0, this.ajustes.ancho - 80, this.ajustes.calcularPuntoY(39.81));
        this.jp_detalleOrdenCompra.add(this.scrollPane);
        (this.tblDetalleOrdenCompra = new JTable()).setBackground(Variables.color_uno);
        this.tblDetalleOrdenCompra.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.scrollPane.setViewportView(this.tblDetalleOrdenCompra);
        final JLabel lblTotalPrecio = new JLabel("Total Precio:");
        lblTotalPrecio.setForeground(Variables.color_uno);
        lblTotalPrecio.setHorizontalAlignment(4);
        lblTotalPrecio.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblTotalPrecio.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(49.07), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(lblTotalPrecio);
        final JLabel lblSigno = new JLabel("$");
        lblSigno.setHorizontalAlignment(0);
        lblSigno.setForeground(Variables.color_uno);
        lblSigno.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
        lblSigno.setBounds((this.ajustes.ancho - 25) / 10 * 9 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(48.61), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(lblSigno);
        (this.txtTotalPrecio = new JTextField()).setEditable(false);
        this.txtTotalPrecio.setText("0.00");
        this.txtTotalPrecio.setForeground(Variables.color_dos);
        this.txtTotalPrecio.setHorizontalAlignment(4);
        this.txtTotalPrecio.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtTotalPrecio.setBackground(Variables.color_uno);
        this.txtTotalPrecio.setBounds((this.ajustes.ancho - 25) / 10 * 9, this.ajustes.calcularPuntoY(48.61), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtTotalPrecio);
        this.txtTotalPrecio.setColumns(10);
        (this.lblTotalIva = new JLabel("Total IVA:")).setHorizontalAlignment(4);
        this.lblTotalIva.setForeground(Variables.color_uno);
        this.lblTotalIva.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblTotalIva.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(52.78), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(this.lblTotalIva);
        final JLabel lblSigno_1 = new JLabel("$");
        lblSigno_1.setHorizontalAlignment(0);
        lblSigno_1.setForeground(Variables.color_uno);
        lblSigno_1.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
        lblSigno_1.setBounds((this.ajustes.ancho - 25) / 10 * 9 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(52.31), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(lblSigno_1);
        (this.txtTotalIva = new JTextField()).setEditable(false);
        this.txtTotalIva.setText("0.00");
        this.txtTotalIva.setHorizontalAlignment(4);
        this.txtTotalIva.setForeground(Variables.color_dos);
        this.txtTotalIva.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtTotalIva.setColumns(10);
        this.txtTotalIva.setBackground(Variables.color_uno);
        this.txtTotalIva.setBounds((this.ajustes.ancho - 25) / 10 * 9, this.ajustes.calcularPuntoY(52.31), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtTotalIva);
        (this.lblTotalFactura = new JLabel("Total Factura:")).setHorizontalAlignment(4);
        this.lblTotalFactura.setForeground(Variables.color_uno);
        this.lblTotalFactura.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblTotalFactura.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(56.48), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(1.85));
        this.jp_DetalleOpcion1.add(this.lblTotalFactura);
        final JLabel lblSigno_2 = new JLabel("$");
        lblSigno_2.setHorizontalAlignment(0);
        lblSigno_2.setForeground(Variables.color_uno);
        lblSigno_2.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
        lblSigno_2.setBounds((this.ajustes.ancho - 25) / 10 * 9 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(56.02), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(lblSigno_2);
        (this.txtTotalFactura = new JTextField()).setEditable(false);
        this.txtTotalFactura.setText("0.00");
        this.txtTotalFactura.setHorizontalAlignment(4);
        this.txtTotalFactura.setForeground(Variables.color_dos);
        this.txtTotalFactura.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtTotalFactura.setColumns(10);
        this.txtTotalFactura.setBackground(Variables.color_uno);
        this.txtTotalFactura.setBounds((this.ajustes.ancho - 25) / 10 * 9, this.ajustes.calcularPuntoY(56.02), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(2.78));
        this.jp_DetalleOpcion1.add(this.txtTotalFactura);
        (this.jp_DetalleOpcion2 = new JPanel()).setOpaque(false);
        this.jp_DetalleOpcion2.setVisible(false);
        this.jp_DetalleOpcion2.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(22.22), this.ajustes.ancho - 50, this.ajustes.calcularPuntoY(59.72));
        jp_contenido.add(this.jp_DetalleOpcion2);
        (this.lblApartadoParaLa = new JLabel("APARTADO PARA LA INFORMACION DE LA FACTURA")).setFont(new Font("Tahoma", 0, 28));
        this.jp_DetalleOpcion2.add(this.lblApartadoParaLa);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        final TableColumnModel columnModel = this.tblDetalleOrdenCompra.getColumnModel();
        header = this.tblDetalleOrdenCompra.getTableHeader();
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(600);
        columnModel.getColumn(2).setPreferredWidth(75);
        columnModel.getColumn(2).setCellRenderer(alinear);
        columnModel.getColumn(3).setPreferredWidth(75);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(75);
        columnModel.getColumn(4).setCellRenderer(alinear);
        columnModel.getColumn(5).setPreferredWidth(75);
        columnModel.getColumn(5).setCellRenderer(alinear);
    }
    
    public void seleccionarOpcion(final int op) {
        switch (op) {
            case 1: {
                this.v_btnOpcion1 = true;
                this.lblFondoBtn_opcion1.setIcon(this.ajustes.ajustarImagen_("/images/general-30-icono-pestana-select.png", this.lblFondoBtn_opcion1));
                this.lblNombreBtn_opcion1.setForeground(Variables.color_uno);
                this.lblIconoBtn_opcion1.setIcon(this.ajustes.ajustarImagen_("/images/general-32-icono-productos.png", this.lblIconoBtn_opcion1));
                this.jp_DetalleOpcion1.setVisible(true);
                this.v_btnOpcion2 = false;
                this.lblFondoBtn_opcion2.setIcon(this.ajustes.ajustarImagen_("/images/general-30-icono-pestana.png", this.lblFondoBtn_opcion2));
                this.lblNombreBtn_opcion2.setForeground(Variables.color_dos);
                this.lblIconoBtn_opcion2.setIcon(this.ajustes.ajustarImagen_("/images/general-31-icono-factura-select.png", this.lblIconoBtn_opcion2));
                this.jp_DetalleOpcion2.setVisible(false);
                break;
            }
            case 2: {
                this.v_btnOpcion1 = false;
                this.lblFondoBtn_opcion1.setIcon(this.ajustes.ajustarImagen_("/images/general-30-icono-pestana.png", this.lblFondoBtn_opcion1));
                this.lblNombreBtn_opcion1.setForeground(Variables.color_dos);
                this.lblIconoBtn_opcion1.setIcon(this.ajustes.ajustarImagen_("/images/general-32-icono-productos-select.png", this.lblIconoBtn_opcion1));
                this.jp_DetalleOpcion1.setVisible(false);
                this.v_btnOpcion2 = true;
                this.lblFondoBtn_opcion2.setIcon(this.ajustes.ajustarImagen_("/images/general-30-icono-pestana-select.png", this.lblFondoBtn_opcion2));
                this.lblNombreBtn_opcion2.setForeground(Variables.color_uno);
                this.lblIconoBtn_opcion2.setIcon(this.ajustes.ajustarImagen_("/images/general-31-icono-factura.png", this.lblIconoBtn_opcion2));
                this.jp_DetalleOpcion2.setVisible(true);
                break;
            }
        }
    }
    
    public void buscarOrdenCompra(final String txtOrdenCompra) {
        Double totalPrecio = 0.0;
        Double totalIva = 0.0;
        Double total = 0.0;
        final DecimalFormat df = new DecimalFormat("###.##");
        if (txtOrdenCompra.length() == 0) {
            final ListaOrdenCompra loc = new ListaOrdenCompra();
            loc.setVisible(Variables.ventana_listaOrdenCompra = true);
            this.dispose();
        }
        else {
            this.tblDetalleOrdenCompra.setModel(this.consultaSql.obtenerOrdenCompra(Integer.parseInt(txtOrdenCompra)));
            this.configurarTabla();
            if (this.tblDetalleOrdenCompra.getRowCount() <= 0) {
                if (JOptionPane.showConfirmDialog(null, "La orden de compra buscada no existe, ¿Desea abrir el listado?", "ALERTA", 0) == 0) {
                    final ListaOrdenCompra loc = new ListaOrdenCompra();
                    loc.setVisible(Variables.ventana_listaOrdenCompra = true);
                    this.dispose();
                }
                return;
            }
            for (int i = 0; i < this.tblDetalleOrdenCompra.getRowCount(); ++i) {
                totalPrecio += Double.parseDouble(this.tblDetalleOrdenCompra.getValueAt(i, 3).toString());
                totalIva += Double.parseDouble(this.tblDetalleOrdenCompra.getValueAt(i, 4).toString());
                total += Double.parseDouble(this.tblDetalleOrdenCompra.getValueAt(i, 5).toString());
            }
            this.txtTotalIva.setText(df.format(total * 0.13));
            final double aux = total - total * 0.13;
            this.txtTotalPrecio.setText(df.format(aux));
            this.txtTotalFactura.setText(df.format(total));
        }
    }
    
    public void guardar() {
        if (this.tblDetalleOrdenCompra.getRowCount() <= 0) {
            JOptionPane.showMessageDialog(null, "Primero debe seleccionar una orden de compra o los productos para ingresar", "ERROR!", 0);
            return;
        }
        if (this.inventario.nuevoIngresoProducto(this.tblDetalleOrdenCompra, Integer.parseInt(this.txtNOrdenCompra.getText()), "CCF", "", this.cbxFormaPago.getSelectedItem().toString().substring(0, 5), Variables.fechaActual, Variables.idUsuario, Variables.idOficina, this.consultaSql.obtenerIdProveedor(this.cbxProveedor.getSelectedItem().toString()), this.consultaSql.obtenerIdBodega_nombre(this.cbxBodega.getSelectedItem().toString(), Variables.idOficina), "", "IN001")) {
            JOptionPane.showMessageDialog(null, "Ingreso de producto guardado correctamente", "OK!", 1);
            return;
        }
        JOptionPane.showMessageDialog(null, "No se pudo guardar la informacion -- " + Variables.error, "ERROR!", 0);
    }
}
