// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.compras;

import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import javax.swing.text.Document;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.event.WindowListener;
import javax.swing.table.TableModel;
import profac.com.herramientas.Variables;
import javax.swing.ComboBoxModel;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaOrdenCompra extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JLabel lblDescripcion;
    private JTextField txtDescripcionBuscar;
    private JLabel lblDesde;
    private JTextField txtFecha1;
    private JLabel lblHasta;
    private JTextField txtFecha2;
    private JPanel jp_tblOrdenesCompra;
    private JScrollPane scrollPane;
    private JTable tblOrdenCompra;
    private JLabel lblIconoBtn_buscar;
    private JLabel lblNombreBtn_buscar;
    private JLabel btnBuscar;
    public int contadorFecha;
    private JComboBox<Object> cbxProveedorBuscar;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaOrdenCompra frame = new ListaOrdenCompra();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaOrdenCompra() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.contadorFecha = 0;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaOrdenCompra.this.cbxProveedorBuscar.setModel(ListaOrdenCompra.this.consultaSql.getDataComboBox("select nombre from proveedor order by nombre asc"));
                ListaOrdenCompra.this.txtFecha1.setText(Variables.fechaSistema);
                ListaOrdenCompra.this.txtFecha2.setText(Variables.fechaSistema);
                ListaOrdenCompra.this.tblOrdenCompra.setModel(ListaOrdenCompra.this.consultaSql.llenarTablaListaOrdenCompra("%%"));
                ListaOrdenCompra.this.configurarTabla();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaPartida = new JPanel()).setLayout(null);
        this.jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
        this.jp_btnNuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaPartida);
        (this.btnNuevaPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaPartida.add(this.btnNuevaPartida);
        (this.lblIconoBtn_nuevaPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaPartida));
        this.jp_btnNuevaPartida.add(this.lblIconoBtn_nuevaPartida);
        (this.lblNombreBtn_nuevaPartida = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaPartida.add(this.lblNombreBtn_nuevaPartida);
        (this.jp_btnBuscarPartida = new JPanel()).setLayout(null);
        this.jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
        this.jp_btnBuscarPartida.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarPartida);
        (this.btnBuscarPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarPartida.add(this.btnBuscarPartida);
        (this.lblIconoBtn_buscarPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarPartida));
        this.jp_btnBuscarPartida.add(this.lblIconoBtn_buscarPartida);
        (this.lblNombreBtn_buscarPartida = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarPartida.add(this.lblNombreBtn_buscarPartida);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                if (Variables.ventana_listaOrdenCompra) {
                    final IngresoProducto ipr = new IngresoProducto();
                    Variables.ventana_listaOrdenCompra = false;
                    Variables.ventana_ingresarOrdenCompra = false;
                    ipr.setVisible(true);
                    ListaOrdenCompra.this.dispose();
                }
                else {
                    ListaOrdenCompra.this.dispose();
                }
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaOrdenCompra.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.43), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblnewlabel = new JLabel("Lista de Orden de Compra")).setForeground(Variables.color_uno);
        this.lblnewlabel.setHorizontalAlignment(0);
        this.lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.calcularPuntoY(1.85)));
        this.lblnewlabel.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.31));
        jp_contenido.add(this.lblnewlabel);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        (this.lblDescripcion = new JLabel("Descripci\u00f3n:")).setHorizontalAlignment(0);
        this.lblDescripcion.setForeground(Variables.color_uno);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescripcion);
        (this.txtDescripcionBuscar = new JTextField()).setBackground(Variables.color_uno);
        this.txtDescripcionBuscar.setForeground(Variables.color_dos);
        this.txtDescripcionBuscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoX(2.78))));
        this.txtDescripcionBuscar.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcionBuscar);
        this.txtDescripcionBuscar.setColumns(10);
        final JLabel lblProveedor = new JLabel("Proveedor:");
        lblProveedor.setHorizontalAlignment(0);
        lblProveedor.setForeground(Variables.color_uno);
        lblProveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblProveedor.setBounds((this.ajustes.ancho - 25) / 10 * 4 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblProveedor);
        (this.cbxProveedorBuscar = new JComboBox<Object>()).setBackground(Variables.color_uno);
        this.cbxProveedorBuscar.setForeground(Variables.color_dos);
        this.cbxProveedorBuscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxProveedorBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 4 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxProveedorBuscar);
        (this.lblDesde = new JLabel("Desde:")).setHorizontalAlignment(0);
        this.lblDesde.setForeground(Variables.color_uno);
        this.lblDesde.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDesde.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(10.65), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDesde);
        (this.txtFecha1 = new JTextField()).setDocument(new LimitadorCaracteres(this.txtFecha1, 10));
        this.txtFecha1.setHorizontalAlignment(0);
        this.txtFecha1.setBackground(Variables.color_uno);
        this.txtFecha1.setForeground(Variables.color_dos);
        this.txtFecha1.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFecha1.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(12.96), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        this.txtFecha1.setColumns(10);
        this.txtFecha1.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(final FocusEvent arg0) {
                ListaOrdenCompra.this.contadorFecha = 0;
                ListaOrdenCompra.this.txtFecha1.setText("");
            }
        });
        this.txtFecha1.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(final KeyEvent arg0) {
                final int k = arg0.getKeyChar();
                if (k >= 48 && k <= 57) {
                    if (ListaOrdenCompra.this.contadorFecha == 2 || ListaOrdenCompra.this.contadorFecha == 4) {
                        ListaOrdenCompra.this.txtFecha1.setText(String.valueOf(ListaOrdenCompra.this.txtFecha1.getText()) + "/");
                    }
                    final ListaOrdenCompra this$0 = ListaOrdenCompra.this;
                    ++this$0.contadorFecha;
                }
                else {
                    arg0.setKeyChar('\f');
                }
            }
        });
        jp_contenido.add(this.txtFecha1);
        (this.lblHasta = new JLabel("Hasta:")).setHorizontalAlignment(0);
        this.lblHasta.setForeground(Variables.color_uno);
        this.lblHasta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblHasta.setBounds((this.ajustes.ancho - 25) / 10 * 2 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(10.65), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblHasta);
        (this.txtFecha2 = new JTextField()).setDocument(new LimitadorCaracteres(this.txtFecha2, 10));
        this.txtFecha2.setHorizontalAlignment(0);
        this.txtFecha2.setForeground(Variables.color_dos);
        this.txtFecha2.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFecha2.setColumns(10);
        this.txtFecha2.setBackground(Variables.color_uno);
        this.txtFecha2.setBounds((this.ajustes.ancho - 25) / 10 * 2 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(12.96), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        this.txtFecha2.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(final FocusEvent arg0) {
                ListaOrdenCompra.this.contadorFecha = 0;
                ListaOrdenCompra.this.txtFecha2.setText("");
            }
        });
        this.txtFecha2.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(final KeyEvent arg0) {
                final int k = arg0.getKeyChar();
                if (k >= 48 && k <= 57) {
                    if (ListaOrdenCompra.this.contadorFecha == 2 || ListaOrdenCompra.this.contadorFecha == 4) {
                        ListaOrdenCompra.this.txtFecha2.setText(String.valueOf(ListaOrdenCompra.this.txtFecha2.getText()) + "/");
                    }
                    final ListaOrdenCompra this$0 = ListaOrdenCompra.this;
                    ++this$0.contadorFecha;
                }
                else {
                    arg0.setKeyChar('\f');
                }
            }
        });
        jp_contenido.add(this.txtFecha2);
        final JPanel jp_btnBuscar = new JPanel();
        jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscar.setBackground(Variables.color_uno);
        jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(11.11));
        jp_contenido.add(jp_btnBuscar);
        jp_btnBuscar.setLayout(null);
        (this.btnBuscar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_uno);
                ListaOrdenCompra.this.lblIconoBtn_buscar.setIcon(ListaOrdenCompra.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", ListaOrdenCompra.this.lblIconoBtn_buscar));
                ListaOrdenCompra.this.lblNombreBtn_buscar.setForeground(Variables.color_dos);
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_dos);
                ListaOrdenCompra.this.lblIconoBtn_buscar.setIcon(ListaOrdenCompra.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar-select.png", ListaOrdenCompra.this.lblIconoBtn_buscar));
                ListaOrdenCompra.this.lblNombreBtn_buscar.setForeground(Variables.color_uno);
            }
        });
        this.btnBuscar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(11.11));
        jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(6.61), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.91), this.ajustes.calcularPuntoY(6.94));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", this.lblIconoBtn_buscar));
        jp_btnBuscar.add(this.lblIconoBtn_buscar);
        (this.lblNombreBtn_buscar = new JLabel("Buscar")).setForeground(Variables.color_dos);
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
        this.lblNombreBtn_buscar.setHorizontalAlignment(0);
        this.lblNombreBtn_buscar.setBounds(0, this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_btnBuscar.add(this.lblNombreBtn_buscar);
        (this.jp_tblOrdenesCompra = new JPanel()).setBackground(Variables.color_uno);
        this.jp_tblOrdenesCompra.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(18.06), this.ajustes.ancho - 50, this.ajustes.calcularPuntoY(63.89));
        jp_contenido.add(this.jp_tblOrdenesCompra);
        this.jp_tblOrdenesCompra.setLayout(null);
        (this.scrollPane = new JScrollPane()).setBounds(0, 0, this.ajustes.ancho - 50, this.ajustes.calcularPuntoY(63.89));
        this.jp_tblOrdenesCompra.add(this.scrollPane);
        (this.tblOrdenCompra = new JTable()).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaOrdenCompra.this.seleccionarOrdenCompra();
            }
        });
        this.tblOrdenCompra.setForeground(Variables.color_dos);
        this.tblOrdenCompra.setBackground(Variables.color_uno);
        this.tblOrdenCompra.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.scrollPane.setViewportView(this.tblOrdenCompra);
        this.menuEmergente();
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        final TableColumnModel columnModel = this.tblOrdenCompra.getColumnModel();
        header = this.tblOrdenCompra.getTableHeader();
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(500);
        columnModel.getColumn(2).setPreferredWidth(300);
        columnModel.getColumn(3).setPreferredWidth(75);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(75);
        columnModel.getColumn(4).setCellRenderer(alinear);
        columnModel.getColumn(5).setPreferredWidth(100);
    }
    
    public void menuEmergente() {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JMenuItem mntmEditarItem = new JMenuItem("Editar orden de compra", new ImageIcon(this.getClass().getResource("/images/general-20-icono-editar.png")));
        mntmEditarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmEditarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Esta opcion esta en mantenimiento", "ALERTA!", 2);
            }
        });
        popupMenu.add(mntmEditarItem);
        this.tblOrdenCompra.setComponentPopupMenu(popupMenu);
        final JMenuItem mntmIngresarItem = new JMenuItem("Ingresar orden de compra", new ImageIcon(this.getClass().getResource("/images/general-20-icono-editar.png")));
        mntmEditarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmEditarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Esta opcion esta en mantenimiento", "ALERTA!", 2);
            }
        });
        popupMenu.add(mntmIngresarItem);
        this.tblOrdenCompra.setComponentPopupMenu(popupMenu);
        final JMenuItem mntmVerItem = new JMenuItem("Ver orden de compra", new ImageIcon(this.getClass().getResource("/images/general-20-icono-editar.png")));
        mntmEditarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmEditarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Esta opcion esta en mantenimiento", "ALERTA!", 2);
            }
        });
        popupMenu.add(mntmVerItem);
        this.tblOrdenCompra.setComponentPopupMenu(popupMenu);
    }
    
    public void seleccionarOrdenCompra() {
        if (Variables.ventana_listaOrdenCompra) {
            final IngresoProducto ipr = new IngresoProducto();
            Variables.ventana_listaOrdenCompra = false;
            Variables.ventana_ingresarOrdenCompra = true;
            Variables.idOrdenCompra = this.tblOrdenCompra.getValueAt(this.tblOrdenCompra.getSelectedRow(), 0).toString();
            ipr.setVisible(true);
            this.dispose();
        }
    }
}
