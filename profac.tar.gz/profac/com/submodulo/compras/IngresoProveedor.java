package profac.com.submodulo.compras;

import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.eclipse.jdt.internal.compiler.lookup.ImportBinding;

//import Component;
import profac.com.database.consultasSQL_SERVER;
import profac.com.database.insertSQL_SERVER;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Variables;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import profac.com.herramientas.Fechas;
import profac.com.herramientas.Texto;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
public class IngresoProveedor extends JFrame{
    
	
	
	/**
	 * @author Frank Castro 
	 */
	
	private static final long serialVersionUID = 1L;
	
	public Ajustes ajustes = new Ajustes();
	public Fechas fechasHandler = new Fechas();
    public consultasSQL_SERVER consultaSql = new consultasSQL_SERVER();
    public insertSQL_SERVER  insertSql = new insertSQL_SERVER(); 
    
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JTextField txtidproveedor;

	private JLabel lblidproveedor;

	private JLabel lblNombreProveedor;

	private JComboBox<?> cmbBox;
	private JTextField txtNombreProveedor;
	private JTextField txtNIT;
	private JTextField txtNRC;
	private JLabel lblNit;
	private JLabel lblNrc;
	private JLabel lblDireccionDelProveedor;
	private JTextField txtDireccionProveedor;
	private JLabel lblPais;
	private JLabel lblEstado;
	private JComboBox<Object> cmbPais;
	private JLabel lblTipoProveedor;
	private JComboBox<Object> cmbTipoProveedor;
	private JLabel lblRetencion;
	private JComboBox<Object> cmbRetencion;
	private JLabel lblTelefono1;
	private JTextField txtTelefono1;
	private JTextField txtExtension1;
	private JTextField txtTelefono2;
	private JTextField txtExtension2;
	private JTextField txtTelefono3;
	private JTextField txtExtension3;
	private JLabel lblPersonaDeContacto;
	private JLabel lblExtension;
	private JTextField txtContacto;
	private JTextField txtBuscarCuenta;
	private JTable tbnCuentaContable;

	private JLabel lblSeleccionarCuentaContable;
	private JTextField txtEstado;

//	protected Component lblNombreBtn_buscar;

	protected JLabel lblIconoBtn_buscar;

	private JPanel panel;
	private JLabel lbljp_buscarcuenta;
	private JLabel lbl_jpBuscarCuentaImagen;
	private JLabel lbl_jpCuentaTexto;

	private JPanel jpCuentaContable;
    
	public DefaultTableModel modeloCuentas = new DefaultTableModel();
	
	
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    IngresoProveedor frame = new IngresoProveedor();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public IngresoProveedor() {
    	addWindowListener(new WindowAdapter() {
    		@Override
    		public void windowOpened(WindowEvent e) {
    			setTextProveedorId();
    			llenarTablaCuentaContable();
    			configurarTabla();
    		}
    	});
        setDefaultCloseOperation(3);
        setResizable(false);
        setUndecorated(true);
        setBounds(0, ajustes.calcularPuntoY(6.57), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(8.8));
        contentPane = new JPanel();
        contentPane.setBackground(Variables.color_tres);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, ajustes.ancho, ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        contentPane.add(jp_botones);
        
        jp_btnNuevaPartida = new JPanel();
        jp_btnNuevaPartida.setLayout(null);
        jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnNuevaPartida.setBackground(Variables.color_tres);
        jp_btnNuevaPartida.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnNuevaPartida);
        
        btnNuevaPartida = new JLabel("");
        btnNuevaPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnNuevaPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnNuevaPartida.add(btnNuevaPartida);
        
        lblIconoBtn_nuevaPartida = new JLabel("");
        lblIconoBtn_nuevaPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_nuevaPartida.setIcon(ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", lblIconoBtn_nuevaPartida));
        jp_btnNuevaPartida.add(lblIconoBtn_nuevaPartida);
        
        lblNombreBtn_nuevaPartida = new JLabel("Nueva");
        lblNombreBtn_nuevaPartida.setHorizontalAlignment(0);
        lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_nuevaPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnNuevaPartida.add(lblNombreBtn_nuevaPartida);
        
        jp_btnBuscarPartida = new JPanel();
        jp_btnBuscarPartida.setLayout(null);
        jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscarPartida.setBackground(Variables.color_tres);
        jp_btnBuscarPartida.setBounds(ajustes.calcularPuntoX(4.95), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnBuscarPartida);
        
        btnBuscarPartida = new JLabel("");
        btnBuscarPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnBuscarPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnBuscarPartida.add(btnBuscarPartida);
        
        lblIconoBtn_buscarPartida = new JLabel("");
        lblIconoBtn_buscarPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_buscarPartida.setIcon(ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", lblIconoBtn_buscarPartida));
        jp_btnBuscarPartida.add(lblIconoBtn_buscarPartida);
        
        lblNombreBtn_buscarPartida = new JLabel("Buscar");
        lblNombreBtn_buscarPartida.setHorizontalAlignment(0);
        lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_buscarPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnBuscarPartida.add(lblNombreBtn_buscarPartida);
        
        jp_btnGuardar = new JPanel();
        jp_btnGuardar.setLayout(null);
        jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnGuardar.setBackground(Variables.color_tres);
        jp_btnGuardar.setBounds(ajustes.calcularPuntoX(9.11), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnGuardar);
        
        btnGuardar = new JLabel("");
        btnGuardar.setCursor(Cursor.getPredefinedCursor(12));
        btnGuardar.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_tres);
            }
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		insertarProveedor();
        	}
        });
        btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        jp_btnGuardar.add(btnGuardar);
        
        lblIconoBtn_guardar = new JLabel("");
        lblIconoBtn_guardar.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_guardar.setIcon(ajustes.ajustarImagen("/botones_04_icono_guardar", lblIconoBtn_guardar, 50, 50, 50, 50));
        jp_btnGuardar.add(lblIconoBtn_guardar);
        
        lblNombreBtn_guardar = new JLabel("Guardar");
        lblNombreBtn_guardar.setHorizontalAlignment(0);
        lblNombreBtn_guardar.setForeground(Variables.color_uno);
        lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_guardar.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnGuardar.add(lblNombreBtn_guardar);
        
        jp_btnImprimir = new JPanel();
        jp_btnImprimir.setLayout(null);
        jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnImprimir.setBackground(Variables.color_tres);
        jp_btnImprimir.setBounds(ajustes.calcularPuntoX(13.28), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnImprimir);
        
        btnImprimir = new JLabel("");
        btnImprimir.setCursor(Cursor.getPredefinedCursor(12));
        btnImprimir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        jp_btnImprimir.add(btnImprimir);
        
        lblIconoBtn_imprimir = new JLabel("");
        lblIconoBtn_imprimir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_imprimir.setIcon(ajustes.ajustarImagen("/botones_05_icono_imprimir", lblIconoBtn_imprimir, 50, 50, 50, 50));
        jp_btnImprimir.add(lblIconoBtn_imprimir);
        
        lblNombreBtn_imprimir = new JLabel("Imprimir");
        lblNombreBtn_imprimir.setHorizontalAlignment(0);
        lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_imprimir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnImprimir.add(lblNombreBtn_imprimir);
        
        jp_btnSalir = new JPanel();
        jp_btnSalir.setBackground(Variables.color_tres);
        jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnSalir.setBounds(ajustes.calcularPuntoX(26.04), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnSalir);
        jp_btnSalir.setLayout(null);
        
        btnSalir = new JLabel("");
        btnSalir.setCursor(Cursor.getPredefinedCursor(12));
        btnSalir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
        });
        btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        jp_btnSalir.add(btnSalir);
        
        JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.43), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        jp_btnSalir.add(lblIconoBtn_salir);
        
        JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnSalir.add(lblNombreBtn_salir);
        
        JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, ajustes.calcularPuntoY(8.33), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(17.13));
        contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        
        lblnewlabel = new JLabel("Ingreso de Proveedores");
        lblnewlabel.setForeground(Variables.color_uno);
        lblnewlabel.setHorizontalAlignment(0);
        lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, ajustes.calcularPuntoY(1.85)));
        lblnewlabel.setBounds(0, ajustes.calcularPuntoY(0.46), ajustes.ancho, ajustes.calcularPuntoY(2.31));
        jp_contenido.add(lblnewlabel);
        JSeparator separator = new JSeparator();
        separator.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(3.24), ajustes.ancho - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        
        (this.lblidproveedor = new JLabel("ID Proveedor")).setHorizontalAlignment(0);
        this.lblidproveedor.setForeground(Variables.color_uno);
        this.lblidproveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));               
        lblidproveedor.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(4.818), ajustes.calcularPuntoX(10.147), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblidproveedor);
        
        (this.txtidproveedor = new JTextField()).setBackground(Variables.color_uno);
        txtidproveedor.setEditable(false);
        this.txtidproveedor.setForeground(Variables.color_dos);
        this.txtidproveedor.setHorizontalAlignment(0);
        this.txtidproveedor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        txtidproveedor.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(7.161), ajustes.calcularPuntoX(10), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtidproveedor);
        txtidproveedor.setColumns(10);
        
        (this.lblNombreProveedor = new JLabel("Nombre del Proveedor")).setHorizontalAlignment(0);
        this.lblNombreProveedor.setForeground(Variables.color_uno);
        this.lblNombreProveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                       
        lblNombreProveedor.setBounds(this.ajustes.calcularPuntoX(11.912), ajustes.calcularPuntoY(4.818), ajustes.calcularPuntoX(51.544), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblNombreProveedor);
        
        (this.txtNombreProveedor = new JTextField()).setBackground(Variables.color_uno);
        this.txtNombreProveedor.setForeground(Variables.color_dos);
        this.txtNombreProveedor.setHorizontalAlignment(0);
        this.txtNombreProveedor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        txtNombreProveedor.setBounds(this.ajustes.calcularPuntoX(11.765), ajustes.calcularPuntoY(7.031), ajustes.calcularPuntoX(51.691), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtNombreProveedor);
        txtNombreProveedor.setColumns(10);
        
        (this.txtNIT = new JTextField()).setBackground(Variables.color_uno);
        txtNIT.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent evt) {
				Character letra = evt.getKeyChar();
				if (txtNIT.getText().length()>13) {
					evt.consume();
				}
				if (Character.isLetter(letra) || (evt.getKeyChar() == KeyEvent.VK_SPACE)) {
					evt.consume();

				}
				

        	}
        });
        txtNIT.addFocusListener(new FocusAdapter() {
        	@Override
        	public void focusLost(FocusEvent e) {
        		txtNIT.setText(Texto.getNit(txtNIT.getText()));
        	}
        });
        this.txtNIT.setForeground(Variables.color_dos);
        this.txtNIT.setHorizontalAlignment(0);
        this.txtNIT.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));        
        txtNIT.setBounds(this.ajustes.calcularPuntoX(64.338), ajustes.calcularPuntoY(7.031), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtNIT);
        txtNIT.setColumns(10);
        
        (this.txtNRC = new JTextField()).setBackground(Variables.color_uno);
        txtNRC.addFocusListener(new FocusAdapter() {
        	@Override
        	public void focusLost(FocusEvent e) {
        		txtNRC.setText(Texto.getDui(txtNRC.getText()));
        	}
        });
        txtNRC.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent evt) {
        		Character letra = evt.getKeyChar();
				if (txtNRC.getText().length()>7) {
					evt.consume();
				}
				if (Character.isLetter(letra) || (evt.getKeyChar() == KeyEvent.VK_SPACE)) {
					evt.consume();

				}
        	}
        });
        this.txtNRC.setForeground(Variables.color_dos);
        this.txtNRC.setHorizontalAlignment(0);
        this.txtNRC.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                
        txtNRC.setBounds(this.ajustes.calcularPuntoX(81.985), ajustes.calcularPuntoY(7.031), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtNRC);
        txtNRC.setColumns(10);
        
        (this.lblNit = new JLabel("NIT")).setHorizontalAlignment(0);
        this.lblNit.setForeground(Variables.color_uno);
        this.lblNit.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                               
        lblNit.setBounds(this.ajustes.calcularPuntoX(64.338), ajustes.calcularPuntoY(4.818), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblNit);
        
        (this.lblNrc = new JLabel("NRC")).setHorizontalAlignment(0);
        this.lblNrc.setForeground(Variables.color_uno);
        this.lblNrc.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                       
        lblNrc.setBounds(this.ajustes.calcularPuntoX(81.985), ajustes.calcularPuntoY(4.818), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblNrc);
        
        (this.lblDireccionDelProveedor = new JLabel("Direccion del Proveedor")).setHorizontalAlignment(0);
        this.lblDireccionDelProveedor.setForeground(Variables.color_uno);
        this.lblDireccionDelProveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                               
        lblDireccionDelProveedor.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(11.068), ajustes.calcularPuntoX(62.574), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblDireccionDelProveedor);
        
        (this.txtDireccionProveedor = new JTextField()).setBackground(Variables.color_uno);
        this.txtDireccionProveedor.setForeground(Variables.color_dos);
        this.txtDireccionProveedor.setHorizontalAlignment(0);
        this.txtDireccionProveedor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                        
        txtDireccionProveedor.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(13.932), ajustes.calcularPuntoX(62.574), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtDireccionProveedor);
        txtDireccionProveedor.setColumns(10);
        
        (this.lblPais = new JLabel("Pais")).setHorizontalAlignment(0);
        this.lblPais.setForeground(Variables.color_uno);
        this.lblPais.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                               
        lblPais.setBounds(this.ajustes.calcularPuntoX(64.338), ajustes.calcularPuntoY(11.068), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblPais);
        
        (this.lblEstado = new JLabel("Estado")).setHorizontalAlignment(0);
        this.lblEstado.setForeground(Variables.color_uno);
        this.lblEstado.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                                       
        lblEstado.setBounds(this.ajustes.calcularPuntoX(81.985), ajustes.calcularPuntoY(11.068), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblEstado);
                
        (this.cmbPais = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cmbPais.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cmbPais.setBackground(Variables.color_uno);        
        cmbPais.setModel(new DefaultComboBoxModel<Object>(new String[] {
        		"El Salvador",
        		"Afganistán", 	"Islas Gland", 	"Albania", 	"Alemania", 	"Andorra", 	"Angola", 	"Anguilla", 	"Antártida", 	"Antigua y Barbuda", 	"Antillas Holandesas", 	
        		"Arabia Saudí", 	"Argelia", 	"Argentina", 	"Armenia", 	"Aruba", 	"Australia", 	"Austria", 	"Azerbaiyán", 	"Bahamas", 	"Bahréin", 	"Bangladesh", 	"Barbados",
        		"Bielorrusia", 	"Bélgica", 	"Belice", 	"Benin", 	"Bermudas", 	"Bhután", 	"Bolivia", 	"Bosnia y Herzegovina", 	"Botsuana", 	"Isla Bouvet", 	"Brasil", 	
        		"Brunéi", 	"Bulgaria", 	"Burkina Faso", 	"Burundi", 	"Cabo Verde", 	"Islas Caimán", 	"Camboya", 	"Camerún", 	"Canadá", 	"República Centroafricana", 	
        		"Chad", 	"República Checa", 	"Chile", 	"China", 	"Chipre", 	"Isla de Navidad", 	"Ciudad del Vaticano", 	"Islas Cocos", 	"Colombia", 	"Comoras", 	
        		"República Democrática del Congo", 	"Congo", 	"Islas Cook", 	"Corea del Norte", 	"Corea del Sur", 	"Costa de Marfil", 	"Costa Rica", 	"Croacia", 	"Cuba", 	
        		"Dinamarca", 	"Dominica", 	"República Dominicana", 	"Ecuador", 	"Egipto", 	"Emiratos Árabes Unidos", 	"Eritrea", 	"Eslovaquia", 	
        		"Eslovenia", 	"España", 	"Islas ultramarinas de Estados Unidos", 	"Estados Unidos", 	"Estonia", 	"Etiopía", 	"Islas Feroe", 	"Filipinas", 	"Finlandia", 	
        		"Fiyi", 	"Francia", 	"Gabón", 	"Gambia", 	"Georgia", 	"Islas Georgias del Sur y Sandwich del Sur", 	"Ghana", 	"Gibraltar", 	"Granada", 	"Grecia", 	
        		"Groenlandia", 	"Guadalupe", 	"Guam", 	"Guatemala", 	"Guayana Francesa", 	"Guinea", 	"Guinea Ecuatorial", 	"Guinea-Bissau", 	"Guyana", 	"Haití", 	
        		"Islas Heard y McDonald", 	"Honduras", 	"Hong Kong", 	"Hungría", 	"India", 	"Indonesia", 	"Irán", 	"Iraq", 	"Irlanda", 	"Islandia", 	"Israel", 	
        		"Italia", 	"Jamaica", 	"Japón", 	"Jordania", 	"Kazajstán", 	"Kenia", 	"Kirguistán", 	"Kiribati", 	"Kuwait", 	"Laos", 	"Lesotho", 	"Letonia", 	"Líbano", 	
        		"Liberia", 	"Libia", 	"Liechtenstein", 	"Lituania", 	"Luxemburgo", 	"Macao", 	"ARY Macedonia", 	"Madagascar", 	"Malasia", 	"Malawi", 	"Maldivas", 	
        		"Malí", 	"Malta", 	"Islas Malvinas", 	"Islas Marianas del Norte", 	"Marruecos", 	"Islas Marshall", 	"Martinica", 	"Mauricio", 	"Mauritania", 	"Mayotte", 	
        		"México", 	"Micronesia", 	"Moldavia", 	"Mónaco", 	"Mongolia", 	"Montserrat", 	"Mozambique", 	"Myanmar", 	"Namibia", 	"Nauru", 	"Nepal", 	"Nicaragua", 	
        		"Níger", 	"Nigeria", 	"Niue", 	"Isla Norfolk", 	"Noruega", 	"Nueva Caledonia", 	"Nueva Zelanda", 	"Omán", 	"Países Bajos", 	"Pakistán", 	"Palau", 	
        		"Palestina", 	"Panamá", 	"Papúa Nueva Guinea", 	"Paraguay", 	"Perú", 	"Islas Pitcairn", 	"Polinesia Francesa", 	"Polonia", 	"Portugal", 	"Puerto Rico", 	
        		"Qatar", 	"Reino Unido", 	"Reunión", 	"Ruanda", 	"Rumania", 	"Rusia", 	"Sahara Occidental", 	"Islas Salomón", 	"Samoa", 	"Samoa Americana", 	
        		"San Cristóbal y Nevis", 	"San Marino", 	"San Pedro y Miquelón", 	"San Vicente y las Granadinas", 	"Santa Helena", 	"Santa Lucía", 	"Santo Tomé y Príncipe", 	
        		"Senegal", 	"Serbia y Montenegro", 	"Seychelles", 	"Sierra Leona", 	"Singapur", 	"Siria", 	"Somalia", 	"Sri Lanka", 	"Suazilandia", 	"Sudáfrica", 	
        		"Sudán", 	"Suecia", 	"Suiza", 	"Surinam", 	"Svalbard y Jan Mayen", 	"Tailandia", 	"Taiwán", 	"Tanzania", 	"Tayikistán", 	
        		"Territorio Británico del Océano Índico", 	"Territorios Australes Franceses", 	"Timor Oriental", 	"Togo", 	"Tokelau", 	"Tonga", 	"Trinidad y Tobago", 	
        		"Túnez", 	"Islas Turcas y Caicos", 	"Turkmenistán", 	"Turquía", 	"Tuvalu", 	"Ucrania", 	"Uganda", 	"Uruguay", 	"Uzbekistán", 	"Vanuatu", 	"Venezuela", 	
        		"Vietnam", 	"Islas Vírgenes Británicas", 	"Islas Vírgenes de los Estados Unidos", 	"Wallis y Futuna", 	"Yemen", 	"Yibuti", 	"Zambia", 	"Zimbabue"
        }));        
        cmbPais.setBounds(this.ajustes.calcularPuntoX(64.338), ajustes.calcularPuntoY(13.932), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(cmbPais);
        
        (this.lblTipoProveedor = new JLabel("Tipo de Proveedor")).setHorizontalAlignment(0);
        this.lblTipoProveedor.setForeground(Variables.color_uno);
        this.lblTipoProveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                                               
        lblTipoProveedor.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(18.88), ajustes.calcularPuntoX(10.735), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblTipoProveedor);
        
        (this.cmbTipoProveedor = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cmbTipoProveedor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cmbTipoProveedor.setBackground(Variables.color_uno);        
        cmbTipoProveedor.setModel(new DefaultComboBoxModel<Object>(new String[] {"Proveedor", "Prestador de Servicios", "Donante"}));       
        cmbTipoProveedor.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(21.745), ajustes.calcularPuntoX(10.735), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(cmbTipoProveedor);
        
        (this.lblRetencion = new JLabel("Porcentaje de Retencion")).setHorizontalAlignment(0);
        this.lblRetencion.setForeground(Variables.color_uno);
        this.lblRetencion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                                                       
        lblRetencion.setBounds(this.ajustes.calcularPuntoX(11.912), ajustes.calcularPuntoY(18.88), ajustes.calcularPuntoX(10.735), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(lblRetencion);
        
        (this.cmbRetencion = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cmbRetencion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cmbRetencion.setBackground(Variables.color_uno);        
        cmbRetencion.setModel(new DefaultComboBoxModel(new String[] {"13", "10", "0"}));               
        cmbRetencion.setBounds(162, 167, 146, 18);
        jp_contenido.add(cmbRetencion);
        
        (this.lblTelefono1 = new JLabel("Telefono de Contacto")).setHorizontalAlignment(0);
        this.lblTelefono1.setForeground(Variables.color_uno);
        this.lblTelefono1.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                                                               
        lblTelefono1.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(25.651), ajustes.calcularPuntoX(10.735), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblTelefono1);
        
        (this.txtTelefono1 = new JTextField()).setBackground(Variables.color_uno);
        txtTelefono1.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		Character letra = e.getKeyChar();
				if (Character.isLetter(letra) || (e.getKeyChar() == KeyEvent.VK_SPACE)) {
					e.consume();

				}
        	}
        });
        this.txtTelefono1.setForeground(Variables.color_dos);
        this.txtTelefono1.setHorizontalAlignment(0);
        this.txtTelefono1.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                
        txtTelefono1.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(29.036), ajustes.calcularPuntoX(15.368), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtTelefono1);
        txtTelefono1.setColumns(10);
        
        (this.txtExtension1 = new JTextField()).setBackground(Variables.color_uno);
        txtExtension1.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		Character letra = e.getKeyChar();
				if (Character.isLetter(letra) || (e.getKeyChar() == KeyEvent.VK_SPACE)) {
					e.consume();

				}
        	}
        });
        this.txtExtension1.setForeground(Variables.color_dos);
        this.txtExtension1.setHorizontalAlignment(0);
        this.txtExtension1.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                        
        txtExtension1.setBounds(this.ajustes.calcularPuntoX(17.132), ajustes.calcularPuntoY(29.036), ajustes.calcularPuntoX(5.515), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtExtension1);
        txtExtension1.setColumns(10);
        
        (this.txtTelefono2 = new JTextField()).setBackground(Variables.color_uno);
        txtTelefono2.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		Character letra = e.getKeyChar();
				if (Character.isLetter(letra) || (e.getKeyChar() == KeyEvent.VK_SPACE)) {
					e.consume();

				}
        	}
        	
        });
        this.txtTelefono2.setForeground(Variables.color_dos);
        this.txtTelefono2.setHorizontalAlignment(0);
        this.txtTelefono2.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                                
        txtTelefono2.setColumns(10);
        txtTelefono2.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(32.943), ajustes.calcularPuntoX(15.368), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtTelefono2);
        
        (this.txtExtension2 = new JTextField()).setBackground(Variables.color_uno);
        txtExtension2.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		Character letra = e.getKeyChar();
				if (Character.isLetter(letra) || (e.getKeyChar() == KeyEvent.VK_SPACE)) {
					e.consume();

				}
        	}
        });
        this.txtExtension2.setForeground(Variables.color_dos);
        this.txtExtension2.setHorizontalAlignment(0);
        this.txtExtension2.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                                        
        txtExtension2.setColumns(10);
        txtExtension2.setBounds(this.ajustes.calcularPuntoX(17.132), ajustes.calcularPuntoY(32.943), ajustes.calcularPuntoX(5.515), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtExtension2);
        
        (this.txtTelefono3 = new JTextField()).setBackground(Variables.color_uno);
        txtTelefono3.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		Character letra = e.getKeyChar();
				if (Character.isLetter(letra) || (e.getKeyChar() == KeyEvent.VK_SPACE)) {
					e.consume();

				}
        	}
        });
        this.txtTelefono3.setForeground(Variables.color_dos);
        this.txtTelefono3.setHorizontalAlignment(0);
        this.txtTelefono3.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                                                
        txtTelefono3.setColumns(10);
        txtTelefono3.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(37.109), ajustes.calcularPuntoX(15.368), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtTelefono3);
        
        (this.txtExtension3 = new JTextField()).setBackground(Variables.color_uno);
        txtExtension3.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		Character letra = e.getKeyChar();
				if (Character.isLetter(letra) || (e.getKeyChar() == KeyEvent.VK_SPACE)) {
					e.consume();

				}
        	}
        });
        this.txtExtension3.setForeground(Variables.color_dos);
        this.txtExtension3.setHorizontalAlignment(0);
        this.txtExtension3.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                                                        
        txtExtension3.setColumns(10);
        txtExtension3.setBounds(this.ajustes.calcularPuntoX(17.132), ajustes.calcularPuntoY(36.849), ajustes.calcularPuntoX(5.515), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtExtension3);
        
        (this.lblPersonaDeContacto = new JLabel("Persona de Contacto")).setHorizontalAlignment(0);
        this.lblPersonaDeContacto.setForeground(Variables.color_uno);
        this.lblPersonaDeContacto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                                                                       
        lblPersonaDeContacto.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(41.146), ajustes.calcularPuntoX(21.765), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblPersonaDeContacto);
        
        (this.lblExtension = new JLabel("Extension")).setHorizontalAlignment(0);
        this.lblExtension.setForeground(Variables.color_uno);
        this.lblExtension.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                                                                               
        lblExtension.setBounds(this.ajustes.calcularPuntoX(17.132), ajustes.calcularPuntoY(25.651), ajustes.calcularPuntoX(5.515), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblExtension);
        
        (this.txtContacto = new JTextField()).setBackground(Variables.color_uno);
        this.txtContacto.setForeground(Variables.color_dos);
        this.txtContacto.setHorizontalAlignment(0);
        this.txtContacto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                                                                
        txtContacto.setBounds(this.ajustes.calcularPuntoX(0.882), ajustes.calcularPuntoY(43.62), ajustes.calcularPuntoX(21.765), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtContacto);
        txtContacto.setColumns(10);
        
        (this.txtBuscarCuenta = new JTextField()).setBackground(Variables.color_uno);
        txtBuscarCuenta.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		tbnCuentaContable.setModel(consultaSql.obtenerCuentasContablesLike(txtBuscarCuenta.getText()));
        	}
        });
        this.txtBuscarCuenta.setForeground(Variables.color_dos);
        this.txtBuscarCuenta.setHorizontalAlignment(0);
        this.txtBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));                                                                                        
        txtBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(26.324), ajustes.calcularPuntoY(21.745), ajustes.calcularPuntoX(54.779), ajustes.calcularPuntoY(2.344));
        jp_contenido.add(txtBuscarCuenta);
        txtBuscarCuenta.setColumns(10);
        
//////////////////////////////

        final JPanel jp_btnBuscarCuenta = new JPanel();
        jp_btnBuscarCuenta.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscarCuenta.setBackground(Variables.color_uno);
        jp_btnBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(81.985), ajustes.calcularPuntoY(17.708), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(6.38));
        jp_contenido.add(jp_btnBuscarCuenta);
        jp_btnBuscarCuenta.setLayout(null);
        (this.lbljp_buscarcuenta = new JLabel("")).addMouseListener(new MouseAdapter() {
        	@Override
            public void mouseExited(final MouseEvent arg0) {
            jp_btnBuscarCuenta.setBackground(Variables.color_uno);
            IngresoProveedor.this.lbl_jpBuscarCuentaImagen.setIcon(IngresoProveedor.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", IngresoProveedor.this.lbl_jpBuscarCuentaImagen));
            IngresoProveedor.this.lbl_jpCuentaTexto.setForeground(Variables.color_dos);
            }
            });
        lbljp_buscarcuenta.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		modeloCuentas = consultaSql.obtenerCuentasContablesLike(txtBuscarCuenta.getText());
        		tbnCuentaContable.setModel(modeloCuentas);
        	}
        });
            this.lbljp_buscarcuenta.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
            	jp_btnBuscarCuenta.setBackground(Variables.color_dos);
                IngresoProveedor.this.lbl_jpBuscarCuentaImagen.setIcon(IngresoProveedor.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar-select.png", IngresoProveedor.this.lbl_jpBuscarCuentaImagen));
                IngresoProveedor.this.lbl_jpCuentaTexto.setForeground(Variables.color_uno);
        	}
            });
        this.lbljp_buscarcuenta.setCursor(Cursor.getPredefinedCursor(12));
        this.lbljp_buscarcuenta.setBounds(this.ajustes.calcularPuntoX(0), ajustes.calcularPuntoY(0), ajustes.calcularPuntoX(16.765), ajustes.calcularPuntoY(6.38));
        jp_btnBuscarCuenta.add(this.lbljp_buscarcuenta);
        (this.lbl_jpBuscarCuentaImagen = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(7.941), ajustes.calcularPuntoY(0), ajustes.calcularPuntoX(-7.868)/2, ajustes.calcularPuntoY(5.99));
        lbl_jpBuscarCuentaImagen.setBounds(this.ajustes.calcularPuntoX(1.838), ajustes.calcularPuntoY(0), ajustes.calcularPuntoX(4.265), ajustes.calcularPuntoY(6.38));
        this.lbl_jpBuscarCuentaImagen.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", this.lbl_jpBuscarCuentaImagen));
        jp_btnBuscarCuenta.add(this.lbl_jpBuscarCuentaImagen);
        (this.lbl_jpCuentaTexto = new JLabel("Buscar")).setForeground(Variables.color_dos);
        this.lbl_jpCuentaTexto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
        this.lbl_jpCuentaTexto.setHorizontalAlignment(0);
        this.lbl_jpCuentaTexto.setBounds(this.ajustes.calcularPuntoX(5.147), ajustes.calcularPuntoY(0), ajustes.calcularPuntoX(11.618), ajustes.calcularPuntoY(6.38));
        jp_btnBuscarCuenta.add(this.lbl_jpCuentaTexto);
  
        (this.jpCuentaContable = new JPanel()).setBackground(Variables.color_uno);
        jpCuentaContable.setBounds(this.ajustes.calcularPuntoX(26.324), ajustes.calcularPuntoY(25.651), ajustes.calcularPuntoX(72.426), ajustes.calcularPuntoY(20.312));
        jp_contenido.add(jpCuentaContable);
        this.jpCuentaContable.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBackground(Variables.color_uno);
        scrollPane.setBounds(0, 0, ajustes.calcularPuntoX(72.426), ajustes.calcularPuntoY(20.312));
        this.jpCuentaContable.add(scrollPane);
        	(this.tbnCuentaContable = new JTable()).addMouseListener(new MouseAdapter() {
            	@Override
                public void mouseClicked(final MouseEvent e) {
                	//IngresoProveedor.this.seleccionarProducto();
                	}
                });
        this.tbnCuentaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        scrollPane.setViewportView(this.tbnCuentaContable);
        //this.menuEmergente();             
        (this.lblSeleccionarCuentaContable = new JLabel("Seleccionar cuenta Contable:")).setHorizontalAlignment(0);
        this.lblSeleccionarCuentaContable.setForeground(Variables.color_uno);
        this.lblSeleccionarCuentaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));                                                                                                       
        lblSeleccionarCuentaContable.setBounds(this.ajustes.calcularPuntoX(26.324), ajustes.calcularPuntoY(18.88), ajustes.calcularPuntoX(54.779), ajustes.calcularPuntoY(1.823));
        jp_contenido.add(lblSeleccionarCuentaContable);
        
        txtEstado = new JTextField();
        txtEstado.setBounds(1115, 106, 228, 18);
        jp_contenido.add(txtEstado);
        txtEstado.setColumns(10);
    }
    
    
    public void configurarTabla() {
    	final int[] tamano = {30,30,30,100};
    	final int[] alinear = {0,0,0,0,0};
    	this.tbnCuentaContable =  this.ajustes.configurarTabla(tbnCuentaContable, tamano, alinear);
    }
    
    public void llenarTablaCuentaContable() {
    	this.modeloCuentas = this.consultaSql.obtenerCuentasContablesLike(null);
    	this.tbnCuentaContable.setModel(this.consultaSql.obtenerCuentasContablesLike(null));
    }
    
    
    public void llenarTablaCuentaContable(final String cuenta) {
    	this.modeloCuentas = this.consultaSql.obtenerCuentasContablesLike(cuenta);
    	this.tbnCuentaContable.setModel(modeloCuentas);
    }
    
    public void setTextProveedorId() {	
    	this.txtidproveedor.setText(String.valueOf(this.consultaSql.contarProveedores()+1));
    }
    
    public void insertarProveedor() {
    	try {
    		final int idproveedor = Integer.parseInt(this.txtidproveedor.getText());
        	final String nombre = this.txtNombreProveedor.getText();
        	final String zonaId = this.txtEstado.getText();
        	final String direccion = this.txtDireccionProveedor.getText();
        	final String fechaReg = this.fechasHandler.fechaParaSistema(Variables.fechaActual);
        	final String fechaMod = this.fechasHandler.fechaParaSistema(Variables.fechaActual);
        	final int idUsuario = Variables.idUsuario;
        	final String nit = this.txtNIT.getText();
        	final String nrc = this.txtNRC.getText();
        	final String tipoProveedor = this.cmbTipoProveedor.getSelectedItem().toString();
        	final int filaSeleccionada = this.tbnCuentaContable.getSelectedRow();
        	
        	final String cuentaContableId = this.tbnCuentaContable.getValueAt(filaSeleccionada, 0).toString();
        	
        	final int retencion= Integer.parseInt(this.cmbRetencion.getSelectedItem().toString());
        	final String pais = this.cmbPais.getSelectedItem().toString();
        	final String telefono1 = this.txtTelefono1.getText();
        	final String telefono2 = this.txtTelefono2.getText();
        	final String telefono3 = this.txtTelefono3.getText();
        	final String contacto = this.txtContacto.getSelectedText();
        	final String ext1 = this.txtExtension1.getText();
        	final String ext2 = this.txtExtension2.getText();
        	final String ext3 = this.txtExtension3.getText();
        	final String estado = this.txtEstado.getText();
        	
        	if ((this.txtTelefono1!=null)) {
				if (this.insertSql.insertProveedor(nombre, zonaId, direccion, fechaReg, fechaMod, idUsuario, nit, nrc, tipoProveedor, cuentaContableId, retencion, pais, telefono1, telefono2, telefono3, contacto, ext1, ext2, ext3, estado)>0) {
					JOptionPane.showMessageDialog(contentPane, "Registro Almacenado Correctamente");
				}else {
					JOptionPane.showMessageDialog(contentPane, "Registro NO Almacenado Correctamente","Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		} catch (Exception e) {
			System.err.println(e.toString());
			JOptionPane.showMessageDialog(contentPane, "Debe ingresar la informacion requerida","Error", JOptionPane.ERROR_MESSAGE);
		}

    	
    	
    }
    
    
    @Override
    public void dispose() {
        getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
}
