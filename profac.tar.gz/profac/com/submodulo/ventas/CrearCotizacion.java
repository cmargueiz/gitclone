package profac.com.submodulo.ventas;

import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import profac.com.database.consultasSQL_SERVER;
import profac.com.database.insertSQL_SERVER;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Variables;
import profac.com.herramientas.Fechas;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ImageIcon;


public class CrearCotizacion extends JFrame{
    
	/**
	 * @author Frank Castro 
	 */
	
	private static final long serialVersionUID = 1L;
	
	public Ajustes ajustes = new Ajustes();
    public consultasSQL_SERVER consultaSql = new consultasSQL_SERVER();
    public insertSQL_SERVER insertsql = new insertSQL_SERVER();
    
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField txtCotizacion;
    private JTextField textField_4;
    private JTextField textField_5;
    private JTextField textField_6;
    private JTextField txtVendedor;
    private JTextField txtCodProducto;
    private JTextField txtProducto;
    private JLabel lblNewLabel_10;
    private JTextField txtDescripcion;
    private JLabel lblNewLabel_11;
    private JTextField txtStock;
    private JLabel lblNewLabel_12;
    private JTextField txtCantidad;
    private JTextField txtPrecio;
    private JTextField txtTotal;

	private JLabel lblNewLabel_1;

	private JLabel lblNewLabel_2;

	private JLabel lblNewLabel_3;

	private JLabel lblNewLabel_4;

	private JLabel lblNewLabel_5;

	private JLabel lblNewLabel_6;

	private JLabel lblNewLabel_7;

	private JLabel lblNewLabel_8;

	private JLabel lblNewLabel_9;

	private JTextField txtUnidad;

	private JLabel lblNewLabel_13;

	private JLabel lblNewLabel_14;

	private JLabel lblNewLabel_15;

	private JLabel lblNewLabel_16;

	private JTextField txtDescuento;

	private JComboBox cmbFormaPago;

	private JLabel lblNewLabel_17;

	private JPanel jp_cotizacion;
	private JTable tblCotizacion = new JTable();

	private JPanel jp_btnCambiarVendedor;

	private JLabel btnCambiarVendedor;

	private JLabel lblIconoBtn_cambiarVendedor;
	private JPanel jp_btnAgregarCotizacion;
	private JLabel btnAgregarAgregarCotizacion;
	private JLabel lblIconoBtn_agregarCotizacion;
	private JLabel lblNombreBtn_agregarCotizacion;
    
	public DefaultTableModel modeloProducto = new DefaultTableModel();
	public DefaultTableModel modeloCotizacion = new DefaultTableModel();
	public Fechas fechasHandler = new Fechas();
	
	public ArrayList<String[]> listaIngreso = new ArrayList<>();
	private JTable tblProducto;
	
	
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    CrearCotizacion frame = new CrearCotizacion();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public CrearCotizacion() {
        setDefaultCloseOperation(3);
        setResizable(false);
        setUndecorated(true);
        setBounds(0, ajustes.calcularPuntoY(6.57), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(8.8));
        contentPane = new JPanel();
        contentPane.setBackground(Variables.color_tres);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, ajustes.ancho, ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        contentPane.add(jp_botones);
        
        jp_btnNuevaPartida = new JPanel();
        jp_btnNuevaPartida.setLayout(null);
        jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnNuevaPartida.setBackground(Variables.color_tres);
        jp_btnNuevaPartida.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnNuevaPartida);
        
        btnNuevaPartida = new JLabel("");
        btnNuevaPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnNuevaPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnNuevaPartida.add(btnNuevaPartida);
        
        lblIconoBtn_nuevaPartida = new JLabel("");
        lblIconoBtn_nuevaPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_nuevaPartida.setIcon(ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", lblIconoBtn_nuevaPartida));
        jp_btnNuevaPartida.add(lblIconoBtn_nuevaPartida);
        
        lblNombreBtn_nuevaPartida = new JLabel("Nueva");
        lblNombreBtn_nuevaPartida.setHorizontalAlignment(0);
        lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_nuevaPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnNuevaPartida.add(lblNombreBtn_nuevaPartida);
        
        jp_btnBuscarPartida = new JPanel();
        jp_btnBuscarPartida.setLayout(null);
        jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscarPartida.setBackground(Variables.color_tres);
        jp_btnBuscarPartida.setBounds(ajustes.calcularPuntoX(4.95), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnBuscarPartida);
        
        btnBuscarPartida = new JLabel("");
        btnBuscarPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnBuscarPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnBuscarPartida.add(btnBuscarPartida);
        
        lblIconoBtn_buscarPartida = new JLabel("");
        lblIconoBtn_buscarPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_buscarPartida.setIcon(ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", lblIconoBtn_buscarPartida));
        jp_btnBuscarPartida.add(lblIconoBtn_buscarPartida);
        
        lblNombreBtn_buscarPartida = new JLabel("Buscar");
        lblNombreBtn_buscarPartida.setHorizontalAlignment(0);
        lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_buscarPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnBuscarPartida.add(lblNombreBtn_buscarPartida);
        
        jp_btnGuardar = new JPanel();
        jp_btnGuardar.setLayout(null);
        jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnGuardar.setBackground(Variables.color_tres);
        jp_btnGuardar.setBounds(ajustes.calcularPuntoX(9.11), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnGuardar);
        
        btnGuardar = new JLabel("");
        btnGuardar.setCursor(Cursor.getPredefinedCursor(12));
        btnGuardar.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        jp_btnGuardar.add(btnGuardar);
        
        lblIconoBtn_guardar = new JLabel("");
        lblIconoBtn_guardar.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_guardar.setIcon(ajustes.ajustarImagen("/botones_04_icono_guardar", lblIconoBtn_guardar, 50, 50, 50, 50));
        jp_btnGuardar.add(lblIconoBtn_guardar);
        
        lblNombreBtn_guardar = new JLabel("Guardar");
        lblNombreBtn_guardar.setHorizontalAlignment(0);
        lblNombreBtn_guardar.setForeground(Variables.color_uno);
        lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_guardar.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnGuardar.add(lblNombreBtn_guardar);
        
        jp_btnImprimir = new JPanel();
        jp_btnImprimir.setLayout(null);
        jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnImprimir.setBackground(Variables.color_tres);
        jp_btnImprimir.setBounds(ajustes.calcularPuntoX(13.28), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnImprimir);
        
        btnImprimir = new JLabel("");
        btnImprimir.setCursor(Cursor.getPredefinedCursor(12));
        btnImprimir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        jp_btnImprimir.add(btnImprimir);
        
        lblIconoBtn_imprimir = new JLabel("");
        lblIconoBtn_imprimir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_imprimir.setIcon(ajustes.ajustarImagen("/botones_05_icono_imprimir", lblIconoBtn_imprimir, 50, 50, 50, 50));
        jp_btnImprimir.add(lblIconoBtn_imprimir);
        
        lblNombreBtn_imprimir = new JLabel("Imprimir");
        lblNombreBtn_imprimir.setHorizontalAlignment(0);
        lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_imprimir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnImprimir.add(lblNombreBtn_imprimir);
        
        jp_btnSalir = new JPanel();
        jp_btnSalir.setBackground(Variables.color_tres);
        jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnSalir.setBounds(ajustes.calcularPuntoX(26.04), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnSalir);
        jp_btnSalir.setLayout(null);
        
        btnSalir = new JLabel("");
        btnSalir.setCursor(Cursor.getPredefinedCursor(12));
        btnSalir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
        });
        btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        jp_btnSalir.add(btnSalir);
        
        JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.43), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        jp_btnSalir.add(lblIconoBtn_salir);
        
        JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnSalir.add(lblNombreBtn_salir);
        
        JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, ajustes.calcularPuntoY(8.33), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(17.13));
        contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        
        lblnewlabel = new JLabel("Realizar Cotizacion");
        lblnewlabel.setForeground(Variables.color_uno);
        lblnewlabel.setHorizontalAlignment(0);
        lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, ajustes.calcularPuntoY(1.85)));
        lblnewlabel.setBounds(0, ajustes.calcularPuntoY(0.46), ajustes.ancho, ajustes.calcularPuntoY(2.31));
        jp_contenido.add(lblnewlabel);
        JSeparator separator = new JSeparator();
        separator.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(3.24), ajustes.ancho - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        
        (this.lblnewlabel = new JLabel("Cliente")).setHorizontalAlignment(0);
        this.lblnewlabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblnewlabel.setForeground(Variables.color_uno);
        this.lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblnewlabel.setBounds(this.ajustes.calcularPuntoX(2.86),this.ajustes.calcularPuntoY(4.94), this.ajustes.calcularPuntoX(32.27),this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblnewlabel);
        
        (this.textField = new JTextField()).setBackground(Variables.color_uno);
        this.textField.setHorizontalAlignment(0);
        this.textField.setForeground(Variables.color_dos);
        this.textField.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.textField.setBounds(this.ajustes.calcularPuntoX(2.8),this.ajustes.calcularPuntoY(7.94), this.ajustes.calcularPuntoX(32.27), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.textField);
        textField.setColumns(10);
        
        (this.lblNewLabel_1 = new JLabel("Direccion")).setHorizontalAlignment(0);
        this.lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_1.setForeground(Variables.color_uno);
        this.lblNewLabel_1.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_1.setBounds(this.ajustes.calcularPuntoX(2.8),this.ajustes.calcularPuntoY(13.02),this.ajustes.calcularPuntoX(47.35),  this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_1);
        
        (this.textField_1 = new JTextField()).setBackground(Variables.color_uno);
        this.textField_1.setHorizontalAlignment(0);
        this.textField_1.setForeground(Variables.color_dos);
        this.textField_1.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.textField_1.setBounds(this.ajustes.calcularPuntoX(2.8),this.ajustes.calcularPuntoY(16.40),this.ajustes.calcularPuntoX(47.79), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.textField_1);
        textField_1.setColumns(10);
        
        (this.lblNewLabel_2 = new JLabel("Fecha")).setHorizontalAlignment(0);
        this.lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_2.setForeground(Variables.color_uno);
        this.lblNewLabel_2.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_2.setBounds(this.ajustes.calcularPuntoX(87.42), this.ajustes.calcularPuntoY(4.94),this.ajustes.calcularPuntoX(10.29), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_2);
        
        (this.textField_2 = new JTextField()).setBackground(Variables.color_uno);
        this.textField_2.setHorizontalAlignment(0);
        this.textField_2.setForeground(Variables.color_dos);
        this.textField_2.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.textField_2.setBounds(this.ajustes.calcularPuntoX(87.42), this.ajustes.calcularPuntoY(7.94), this.ajustes.calcularPuntoX(10.29), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.textField_2);
        textField_2.setColumns(10);
        
        (this.lblNewLabel_3 = new JLabel("Numero de Cotizacion")).setHorizontalAlignment(0);;
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_3.setForeground(Variables.color_uno);
        this.lblNewLabel_3.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_3.setBounds(this.ajustes.calcularPuntoX(72.20),this.ajustes.calcularPuntoY(4.42) ,this.ajustes.calcularPuntoX(10.29), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_3);
        
        (this.txtCotizacion = new JTextField()).setBackground(Variables.color_uno);
        this.txtCotizacion.setHorizontalAlignment(0);
        this.txtCotizacion.setForeground(Variables.color_dos);
        this.txtCotizacion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCotizacion.setBounds(this.ajustes.calcularPuntoX(72.20),this.ajustes.calcularPuntoY(7.94),this.ajustes.calcularPuntoX(10.29), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCotizacion);
        txtCotizacion.setColumns(10);
        
        (this.lblNewLabel_4 = new JLabel("Telefono")).setHorizontalAlignment(0);;
        lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_4.setForeground(Variables.color_uno);
        this.lblNewLabel_4.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_4.setBounds(this.ajustes.calcularPuntoX(36.02), this.ajustes.calcularPuntoY(4.42),this.ajustes.calcularPuntoX(14.63), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_4);
        
        (this.textField_4 = new JTextField()).setBackground(Variables.color_uno);
        this.textField_4.setHorizontalAlignment(0);
        this.textField_4.setForeground(Variables.color_dos);
        this.textField_4.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        textField_4.setBounds(this.ajustes.calcularPuntoX(36.02), this.ajustes.calcularPuntoY(7.94),this.ajustes.calcularPuntoX(14.70), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.textField_4);
        textField_4.setColumns(10);
        
        (this.lblNewLabel_5 = new JLabel("N.I.T")).setHorizontalAlignment(0);;
        this.lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_5.setForeground(Variables.color_uno);
        this.lblNewLabel_5.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_5.setBounds(this.ajustes.calcularPuntoX(52.05), this.ajustes.calcularPuntoY(13.02),this.ajustes.calcularPuntoX(24.41), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_5);
        
        (this.textField_5 = new JTextField()).setBackground(Variables.color_uno);
        this.textField_5.setHorizontalAlignment(0);
        this.textField_5.setForeground(Variables.color_dos);
        this.textField_5.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.textField_5.setBounds(this.ajustes.calcularPuntoX(52.05), this.ajustes.calcularPuntoY(16.40), this.ajustes.calcularPuntoX(24.41), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.textField_5);
        textField_5.setColumns(10);
        
        (this.lblNewLabel_6 = new JLabel("D.U.I")).setHorizontalAlignment(0);
        this.lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_6.setForeground(Variables.color_uno);
        this.lblNewLabel_6.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_6.setBounds(this.ajustes.calcularPuntoX(79.33),this.ajustes.calcularPuntoY(13.02), this.ajustes.calcularPuntoX(18.38), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_6);
        
        (this.textField_6 = new JTextField()).setBackground(Variables.color_uno);
        this.textField_6.setHorizontalAlignment(0);
        this.textField_6.setForeground(Variables.color_dos);
        this.textField_6.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.textField_6.setBounds(this.ajustes.calcularPuntoX(79.33),this.ajustes.calcularPuntoY(16.40) ,this.ajustes.calcularPuntoX(18.38), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(textField_6);
        textField_6.setColumns(10);
        
        (this.lblNewLabel_7 = new JLabel("Vendendor")).setHorizontalAlignment(0);
        this.lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_7.setForeground(Variables.color_uno);
        this.lblNewLabel_7.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_7.setBounds(this.ajustes.calcularPuntoX(2.86),this.ajustes.calcularPuntoY(22.78), this.ajustes.calcularPuntoX(26.76), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_7);
        
        (this.txtVendedor = new JTextField()).setBackground(Variables.color_uno);
        this.txtVendedor.setHorizontalAlignment(0);
        this.txtVendedor.setForeground(Variables.color_dos);
        this.txtVendedor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtVendedor.setBounds(this.ajustes.calcularPuntoX(2.86),this.ajustes.calcularPuntoY(26.17),this.ajustes.calcularPuntoX(26.76), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtVendedor);
        txtVendedor.setColumns(10);
        
        (this.lblNewLabel_8 = new JLabel("Codigo de producto")).setHorizontalAlignment(0);
        this.lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_8.setForeground(Variables.color_uno);
        this.lblNewLabel_8.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_8.setBounds(this.ajustes.calcularPuntoX(2.86),this.ajustes.calcularPuntoY(31.11),this.ajustes.calcularPuntoX(8.75), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_8);
        
        (this.txtCodProducto = new JTextField()).setBackground(Variables.color_uno);
        this.txtCodProducto.setHorizontalAlignment(0);
        this.txtCodProducto.setForeground(Variables.color_dos);
        this.txtCodProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCodProducto.setBounds(this.ajustes.calcularPuntoX(2.86),this.ajustes.calcularPuntoY(35.93), this.ajustes.calcularPuntoX(9.55), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCodProducto);
        txtCodProducto.setColumns(10);
        
        (this.lblNewLabel_9 = new JLabel("Nombre del Producto")).setHorizontalAlignment(0);
        this.lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_9.setForeground(Variables.color_uno);
        this.lblNewLabel_9.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_9.setBounds(this.ajustes.calcularPuntoX(14.70),this.ajustes.calcularPuntoY(31.38), this.ajustes.calcularPuntoX(14.92), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_9);
        
        (this.txtProducto = new JTextField()).setBackground(Variables.color_uno);
        this.txtProducto.setHorizontalAlignment(0);
        this.txtProducto.setForeground(Variables.color_dos);
        this.txtProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        txtProducto.setBounds(this.ajustes.calcularPuntoX(13.30), this.ajustes.calcularPuntoY(35.93), this.ajustes.calcularPuntoX(16.10), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtProducto);
        txtProducto.setColumns(10);
        
        (this.lblNewLabel_10 = new JLabel("Descripcion")).setHorizontalAlignment(0);
        this.lblNewLabel_10.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_10.setForeground(Variables.color_uno);
        this.lblNewLabel_10.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_10.setBounds(this.ajustes.calcularPuntoX(31.54),this.ajustes.calcularPuntoY(31.38), this.ajustes.calcularPuntoX(18.38), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_10);
        
        (this.txtDescripcion = new JTextField()).setBackground(Variables.color_uno);
        this.txtDescripcion.setHorizontalAlignment(0);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        txtDescripcion.setBounds(this.ajustes.calcularPuntoX(30.29), this.ajustes.calcularPuntoY(35.93), this.ajustes.calcularPuntoX(19.63), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcion);
        txtDescripcion.setColumns(10);
        
        (this.lblNewLabel_11 = new JLabel("Disponibildad")).setHorizontalAlignment(0);
        this.lblNewLabel_11.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_11.setForeground(Variables.color_uno);
        this.lblNewLabel_11.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_11.setBounds(this.ajustes.calcularPuntoX(52.05), this.ajustes.calcularPuntoY(22.78), this.ajustes.calcularPuntoX(13.16), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_11);
        
        (this.txtStock = new JTextField()).setBackground(Variables.color_uno);
        this.txtStock.setHorizontalAlignment(0);
        this.txtStock.setForeground(Variables.color_dos);
        this.txtStock.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtStock.setBounds(this.ajustes.calcularPuntoX(52.05), this.ajustes.calcularPuntoY(26.17), this.ajustes.calcularPuntoX(13.16), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtStock);
        txtStock.setColumns(10);
        
        (this.lblNewLabel_12 = new JLabel("Unidad de Medidas")).setHorizontalAlignment(0);
        this.lblNewLabel_12.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_12.setForeground(Variables.color_uno);
        this.lblNewLabel_12.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_12.setBounds(this.ajustes.calcularPuntoX(52.05), this.ajustes.calcularPuntoY(31.38), this.ajustes.calcularPuntoX(13.16), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_12);
        
        (this.txtUnidad = new JTextField()).setForeground(Variables.color_dos);
        this.txtUnidad.setForeground(Variables.color_dos);
        this.txtUnidad.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtUnidad.setBounds(this.ajustes.calcularPuntoX(52.05), this.ajustes.calcularPuntoY(35.93),this.ajustes.calcularPuntoX(13.16) , this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(txtUnidad);
        
        (this.lblNewLabel_13 = new JLabel("Cantidad")).setHorizontalAlignment(0);
        this.lblNewLabel_13.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_13.setForeground(Variables.color_uno);
        this.lblNewLabel_13.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_13.setBounds(this.ajustes.calcularPuntoX(66.17), this.ajustes.calcularPuntoY(31.38), this.ajustes.calcularPuntoX(9.55), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_13);
        
        (this.txtCantidad = new JTextField()).setBackground(Variables.color_uno);
        this.txtCantidad.setHorizontalAlignment(0);
        this.txtCantidad.setForeground(Variables.color_dos);
        this.txtCantidad.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCantidad.setBounds(this.ajustes.calcularPuntoX(66.17), this.ajustes.calcularPuntoY(35.93), this.ajustes.calcularPuntoX(9.55), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCantidad);
        txtCantidad.setColumns(10);
        
        (this.lblNewLabel_14 = new JLabel("Precio")).setHorizontalAlignment(0);
        this.lblNewLabel_14.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_14.setForeground(Variables.color_uno);
        this.lblNewLabel_14.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_14.setBounds(this.ajustes.calcularPuntoX(76.76), this.ajustes.calcularPuntoY(31.38), this.ajustes.calcularPuntoX(9.55), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_14);
        
        (this.txtPrecio = new JTextField()).setBackground(Variables.color_uno);
        this.txtPrecio.setHorizontalAlignment(0);
        this.txtPrecio.setForeground(Variables.color_dos);
        this.txtPrecio.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPrecio.setBounds(this.ajustes.calcularPuntoX(76.76), this.ajustes.calcularPuntoY(35.93), this.ajustes.calcularPuntoX(9.55), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtPrecio);
        txtPrecio.setColumns(10);
        
        (this.lblNewLabel_15 = new JLabel("Total")).setHorizontalAlignment(0);
        this.lblNewLabel_15.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_15.setForeground(Variables.color_uno);
        this.lblNewLabel_15.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_15.setBounds(this.ajustes.calcularPuntoX(87.42), this.ajustes.calcularPuntoY(31.38), this.ajustes.calcularPuntoX(10.29), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_15);
        
        (this.txtTotal = new JTextField()).setBackground(Variables.color_uno);
        this.txtTotal.setHorizontalAlignment(0);
        this.txtTotal.setForeground(Variables.color_dos);
        this.txtTotal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        txtTotal.setBounds(this.ajustes.calcularPuntoX(87.42), this.ajustes.calcularPuntoY(35.93), this.ajustes.calcularPuntoX(10.29), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtTotal);
        txtTotal.setColumns(10);
        
        (this.lblNewLabel_16 = new JLabel("Tipo de Descuento")).setHorizontalAlignment(0);
        this.lblNewLabel_16.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_16.setForeground(Variables.color_uno);
        this.lblNewLabel_16.setFont(new Font(Variables.fuenteLetra, 1, 17));
        lblNewLabel_16.setBounds(this.ajustes.calcularPuntoX(66.54), this.ajustes.calcularPuntoY(22.78), this.ajustes.calcularPuntoX(14.70), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_16);
        
        (this.txtDescuento = new JTextField()).setForeground(Variables.color_dos);
        this.txtDescuento.setForeground(Variables.color_dos);
        this.txtDescuento.setFont(new Font(Variables.fuenteLetra, 0, 23));
        txtDescuento.setBounds(this.ajustes.calcularPuntoX(66.54), this.ajustes.calcularPuntoY(25.91), this.ajustes.calcularPuntoX(14.70), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescuento);
        
        (this.lblNewLabel_17 = new JLabel("Forma de Pago")).setHorizontalAlignment(0);
        this.lblNewLabel_17.setHorizontalAlignment(SwingConstants.CENTER);
        this.lblNewLabel_17.setForeground(Variables.color_uno);
        this.lblNewLabel_17.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNewLabel_17.setBounds(this.ajustes.calcularPuntoX(83.01), this.ajustes.calcularPuntoY(22.78), this.ajustes.calcularPuntoX(14.70), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNewLabel_17);
        
        (this.cmbFormaPago = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cmbFormaPago.setForeground(Variables.color_dos);
        this.cmbFormaPago.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        cmbFormaPago.setBounds(this.ajustes.calcularPuntoX(83.01), this.ajustes.calcularPuntoY(25.91), this.ajustes.calcularPuntoX(14.70), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cmbFormaPago);
        
        (this.jp_cotizacion = new JPanel()).setBackground(Variables.color_uno);;
        this.jp_cotizacion.setBounds(this.ajustes.calcularPuntoX(2.86), this.ajustes.calcularPuntoY(41.40), this.ajustes.calcularPuntoX(94.85), this.ajustes.calcularPuntoY(39.84));
        jp_contenido.add(jp_cotizacion);
        this.jp_cotizacion.setLayout(null);
        
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBackground(Variables.color_uno);
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.88), this.ajustes.calcularPuntoY(1.56), this.ajustes.calcularPuntoX(73.60), this.ajustes.calcularPuntoY(36.97));
        jp_cotizacion.add(scrollPane);
        
        (this.tblCotizacion = new JTable()).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                CrearCotizacion.this.seleccionarProducto();
            }
        });
        this.tblCotizacion.setFont(new Font(Variables.fuenteLetra, 0, Variables.tamContenidoTabla));
        scrollPane.setViewportView(this.tblCotizacion);
        
        tblProducto = new JTable();
        scrollPane.setRowHeaderView(tblProducto);
    	
	

        
        (this.jp_btnAgregarCotizacion = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnAgregarCotizacion.setBackground(Variables.color_uno);
        this.jp_btnAgregarCotizacion.setBounds(this.ajustes.calcularPuntoX(75.29), this.ajustes.calcularPuntoY(3.25), this.ajustes.calcularPuntoX(18.65), this.ajustes.calcularPuntoY(9.26));
        jp_cotizacion.add(this.jp_btnAgregarCotizacion);
        this.jp_btnAgregarCotizacion.setLayout(null);
        
        (btnAgregarAgregarCotizacion = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent e) {
                CrearCotizacion.this.jp_btnAgregarCotizacion.setBackground(Variables.color_uno);
                CrearCotizacion.this.lblIconoBtn_agregarCotizacion.setIcon(CrearCotizacion.this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar.png", CrearCotizacion.this.lblIconoBtn_agregarCotizacion));
                CrearCotizacion.this.lblNombreBtn_agregarCotizacion.setForeground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
//            	CrearCotizacion.this.llenarTabla();
            }
        });
        this.btnAgregarAgregarCotizacion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent e) {
            	CrearCotizacion.this.jp_btnAgregarCotizacion.setBackground(Variables.color_dos);
            	CrearCotizacion.this.lblIconoBtn_agregarCotizacion.setIcon(CrearCotizacion.this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar-select.png", CrearCotizacion.this.lblIconoBtn_agregarCotizacion));
            	CrearCotizacion.this.lblNombreBtn_agregarCotizacion.setForeground(Variables.color_uno);
            }
        });
        this.btnAgregarAgregarCotizacion.setCursor(Cursor.getPredefinedCursor(12));
        this.btnAgregarAgregarCotizacion.setBounds(0, 0, this.ajustes.calcularPuntoX(18.65), this.ajustes.calcularPuntoY(9.26));
        jp_btnAgregarCotizacion.add(this.btnAgregarAgregarCotizacion);
        
        (this.lblIconoBtn_agregarCotizacion = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(4.17), this.ajustes.calcularPuntoY(7.41));
        this.lblIconoBtn_agregarCotizacion.setIcon(this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar.png", this.lblIconoBtn_agregarCotizacion));
        jp_btnAgregarCotizacion.add(lblIconoBtn_agregarCotizacion);
        
        (this.lblNombreBtn_agregarCotizacion = new JLabel("AGREGAR COTIZACION")).setForeground(Variables.color_dos);
        this.lblNombreBtn_agregarCotizacion.setHorizontalAlignment(0);
        this.lblNombreBtn_agregarCotizacion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.1))));
        this.lblNombreBtn_agregarCotizacion.setBounds(this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(13.02), this.ajustes.calcularPuntoY(7.41));
        jp_btnAgregarCotizacion.add(this.lblNombreBtn_agregarCotizacion);
        
        (this.jp_btnCambiarVendedor = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnCambiarVendedor.setBackground(Variables.color_uno);
        this.jp_btnCambiarVendedor.setBounds(this.ajustes.calcularPuntoX(32.72), this.ajustes.calcularPuntoY(23.82),  this.ajustes.calcularPuntoX(5.73), this.ajustes.calcularPuntoY(5.09));
        jp_contenido.add(this.jp_btnCambiarVendedor);
        this.jp_btnCambiarVendedor.setLayout(null);
        
        (this.btnCambiarVendedor = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnCambiarVendedor.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent e) {
                CrearCotizacion.this.jp_btnCambiarVendedor.setBackground(Variables.color_uno);
                CrearCotizacion.this.lblIconoBtn_cambiarVendedor.setIcon(CrearCotizacion.this.ajustes.ajustarImagen_("/varios_08_icono_cambiar_usuario/varios_08_icono_cambiar_usuario30.png", CrearCotizacion.this.lblIconoBtn_cambiarVendedor));
            }
        });
        this.btnCambiarVendedor.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent e) {
            	CrearCotizacion.this.jp_btnCambiarVendedor.setBackground(Variables.color_dos);
            	CrearCotizacion.this.lblIconoBtn_cambiarVendedor.setIcon(CrearCotizacion.this.ajustes.ajustarImagen_("/varios_08_icono_cambiar_usuario/varios_08_icono_cambiar_usuario_select.png", CrearCotizacion.this.lblIconoBtn_cambiarVendedor));
            }
        });
        this.btnCambiarVendedor.setBounds(0, 0,  this.ajustes.calcularPuntoX(5.73), this.ajustes.calcularPuntoY(5.09));
        jp_btnCambiarVendedor.add(btnCambiarVendedor);
        
        (this.lblIconoBtn_cambiarVendedor = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(1.67), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(4.17));
        this.lblIconoBtn_cambiarVendedor.setIcon(new ImageIcon(CrearCotizacion.class.getResource("/varios_08_icono_cambiar_usuario/varios_08_icono_cambiar_usuario30.png")));
        jp_btnCambiarVendedor.add(this.lblIconoBtn_cambiarVendedor);
    }
    
    protected void seleccionarProducto() {
		// TODO Auto-generated method stub
		
	}

    public void iniciarTablaCotizacion() {
    	this.modeloCotizacion.addColumn("Cod Producto");
    	this.modeloCotizacion.addColumn("Nombre");
    	this.modeloCotizacion.addColumn("Unidad");
    	this.modeloCotizacion.addColumn("Cantidad");
    	this.modeloCotizacion.addColumn("Precio Unit");
    	this.modeloCotizacion.addColumn("Precio Total");
    }
    
    public void configurarTabla(){
    	final int[] tamanoProducto = {20,20,60};
    	this.tblProducto = this.ajustes.configurarTabla(tblProducto,tamanoProducto); 
    	final int[] tamanoCotizacion = {20,50,20,20,20,20};
    	this.tblCotizacion = this.ajustes.configurarTabla(tblCotizacion,tamanoCotizacion);
    }
    
	public void llenarTablaProducto() {
		this.modeloProducto = this.consultaSql.obtenerDatosProductosCotizacion(null,0);;
		this.tblProducto.setModel(modeloCotizacion);
	}
	
	
	public void llenarTablaProducto(final String cod,final String producto) {
		this.modeloProducto = this.consultaSql.obtenerDatosProductosCotizacion(producto,Integer.parseInt(cod));;
		this.tblProducto.setModel(modeloCotizacion);
	}
	
	
public void llenarFormaPago() {
	final String consulta = "select descripcion from formaPago;";
	this.cmbFormaPago.setModel(this.consultaSql.getDataComboBox(consulta));
	
}

public void actualizarTablaCotizacion() {
	final String idProducto = this.txtCodProducto.getText();
	final String producto = this.txtProducto.getText();
	final String unidad = this.txtUnidad.getText();
	final String cant = this.txtCantidad.getText();
	final String precio = this.txtPrecio.getText();
	final String precioTotal = Double.parseDouble(cant)*Double.parseDouble(precio)+"";
	final String[] fila = {idProducto,producto,unidad,cant,precio,precioTotal};
	this.modeloCotizacion.addRow(fila);;
	this.tblCotizacion.setModel(modeloCotizacion);	
}


public void ingresarListaCotizacion() {
	final String idCotizacion = this.txtCotizacion.getText();
	final String idProducto = this.txtCodProducto.getText();
	final String  cant = this.txtCantidad.getText();
	final String precio = this.txtPrecio.getText();
	final String precioTotal = Double.parseDouble(cant)*Double.parseDouble(precio)+"";
	
	final String[] fila = {idCotizacion,idProducto,cant,precioTotal};
	this.listaIngreso.add(fila);
	
}


public void borrarItemListaGuardar() {
	
}


public void insertCotizacion() {
	final String fechaReg = this.fechasHandler.fechaParaSistema(Variables.fechaActual);
	final int usuarioId = Variables.idUsuario;	
	final double monto = calcularMonto(); 
	
}

public void insertDetalleCotizacion() {
	int result=0;
	for (String[] detalle : listaIngreso) {
		if (this.insertsql.insertDetalleCotizacionProducto(detalle[0],detalle[1],detalle[2],detalle[3],detalle[4])>0) {
			result++;
		}
	}
	
	if (result>0) {
		JOptionPane.showMessageDialog(contentPane, "Registro Almacenado Correctamente");
	}else {
		JOptionPane.showMessageDialog(contentPane, "Registro NO Almacenado Correctamente","Error",JOptionPane.ERROR_MESSAGE);
	}
	
}


public double calcularMonto() {
	double var = 0;
	final int tam = this.modeloCotizacion.getRowCount();
	for (int i = 0; i < tam; i++) {
		final int parseInt=Integer.parseInt(this.modeloCotizacion.getValueAt(i,4).toString());
		var+=parseInt ;
	}
	return var;
}


	

public void menuEmergente() {
    final JPopupMenu popupMenu = new JPopupMenu();
    final JMenuItem mntmBorrarItem = new JMenuItem("Borrar", new ImageIcon(this.getClass().getResource("/images/general-19-icono-borrar.png")));
    mntmBorrarItem.setCursor(Cursor.getPredefinedCursor(12));
    mntmBorrarItem.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(final ActionEvent e) {
        	borrarItemListaGuardar();
        }
    });
    popupMenu.add(mntmBorrarItem);

    this.tblCotizacion.setComponentPopupMenu(popupMenu);
}
	

	@Override
    public void dispose() {
        getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
}
