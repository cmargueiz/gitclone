package profac.com.submodulo.contabilidad;

import java.awt.*;

import java.awt.Container;

import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.ComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Variables;
import profac.com.submodulo.inventario.VerIngreso;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Choice;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.ComboBoxModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Contabilidad;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.ComboBoxModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.database.insertSQL_SERVER;
import profac.com.herramientas.F_Contabilidad;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;
import profac.com.herramientas.Texto;
import javax.swing.ListSelectionModel;

public class VicularCuentasContables extends JFrame {

	/**
	 * @author Frank Castro
	 */

	private static final long serialVersionUID = 1L;

	public Ajustes ajustes = new Ajustes();
	public consultasSQL_SERVER consultaSql = new consultasSQL_SERVER();
	public insertSQL_SERVER insertSQL = new insertSQL_SERVER();

	private JPanel contentPane;
	private JPanel jp_btnSalir;
	private JLabel btnSalir;
	private JPanel jp_btnNuevaPartida;
	private JLabel btnNuevaPartida;
	private JLabel lblIconoBtn_nuevaPartida;
	private JLabel lblNombreBtn_nuevaPartida;
	private JPanel jp_btnBuscarPartida;
	private JLabel btnBuscarPartida;
	private JLabel lblIconoBtn_buscarPartida;
	private JLabel lblNombreBtn_buscarPartida;
	private JPanel jp_btnGuardar;
	private JLabel btnGuardar;
	private JLabel lblIconoBtn_guardar;
	private JLabel lblNombreBtn_guardar;
	private JPanel jp_btnImprimir;
	private JLabel btnImprimir;
	private JLabel lblIconoBtn_imprimir;
	private JLabel lblNombreBtn_imprimir;
	private JLabel lblnewlabel;
	private JComboBox txtNomOficina;
	private JLabel lbltipservicio;

	private Object comboBox;
	private JComboBox<Object> comboBox_1;
	private JComboBox<Object> comboBox_2;
	private JComboBox<Object> cmbTipoServicio;
	private JLabel lblFromapago;
	private JComboBox<Object> cmbFormaPago;

	private JPanel jp_tipoOperacion1;
	private JPanel jp_tipoOperacion2;
	private JScrollPane scrollPane_1;
	private JPanel jp_tipoOperacion3;
	private JScrollPane scrollPane_2;
	private JTable tblTiOperacion1;

	private JSeparator separator_1;
	private JTextField txtTipoServicioSelecionado;
	private JTable tblOperaciones = new JTable();;
	private JTable tblCuentas=new JTable();;

	private JLabel lblBuscarServicio;
	private JLabel lblNewLabel_1;
	private JTable tblCuantasVinculadas = new JTable();

	private JLabel lblNewLabel_1_1;
	private JPanel jp_btnAplicar;
	private JLabel btnAplicar;
	private JLabel lblIconoBtn_aplicar;
	private JLabel lblNombreBtn_aplicar;
	private JTextField txtTipodepagoseleccionado;
	private JLabel chckProducto;
	private JLabel lbIconochckProducto;
	private JLabel lblNombreChckProducto;
	private JPanel jp_chckservicio;
	private JLabel chckServicio;
	private JLabel lbIconochckServicio;
	private JLabel lblNombreChckServicio;

	private ArrayList<String[]> listaIngresoServicio = new ArrayList<>();
	private ArrayList<String[]> listaIngresoProducto = new ArrayList<>();

	public DefaultTableModel modeloCuentasVinculadas = new DefaultTableModel();
	
	public int filaSelccionadaCuentasVinculadas = 0;

	public boolean chckbxProducto = true;
	public boolean chckbxServicio = false;
	private JLabel lblTipomov;
	private JLabel lblSubrubro;
	private JComboBox<Object> cmbTipoMovimiento;

	private JComboBox<Object> cbxsubrubo;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					VicularCuentasContables frame = new VicularCuentasContables();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public VicularCuentasContables() {
		this.chckbxProducto = true;
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				llenarCmbFormaPago();
				llenarCmbOficina();
				llenarCmbTipoServicio();
				llenarCmbTipoMovimiento();
				llenarCmbSubrubro();
				llenarTablaCuentas();
				llenarTablaOperaciones();
				llenarCmbTipoServicio();
				iniciarTablaCuentasVinculadas();
				configurarTablas();
			}
		});
		setDefaultCloseOperation(3);
		setResizable(false);
		setUndecorated(true);
		setBounds(0, ajustes.calcularPuntoY(6.57), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(8.8));
		contentPane = new JPanel();
		contentPane.setBackground(Variables.color_tres);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel jp_botones = new JPanel();
		jp_botones.setBackground(Variables.color_uno);
		jp_botones.setBorder(null);
		jp_botones.setBounds(0, 0, ajustes.ancho, ajustes.calcularPuntoY(8.33));
		jp_botones.setLayout(null);
		contentPane.add(jp_botones);

		jp_btnNuevaPartida = new JPanel();
		jp_btnNuevaPartida.setLayout(null);
		jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnNuevaPartida.setBackground(Variables.color_tres);
		jp_btnNuevaPartida.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnNuevaPartida);

		btnNuevaPartida = new JLabel("");
		btnNuevaPartida.setCursor(Cursor.getPredefinedCursor(12));
		btnNuevaPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnNuevaPartida.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnNuevaPartida.setBackground(Variables.color_tres);
			}
		});
		btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnNuevaPartida.setBackground(Variables.color_dos);
			}
		});
		jp_btnNuevaPartida.add(btnNuevaPartida);

		lblIconoBtn_nuevaPartida = new JLabel("");
		lblIconoBtn_nuevaPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_nuevaPartida
				.setIcon(ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", lblIconoBtn_nuevaPartida));
		jp_btnNuevaPartida.add(lblIconoBtn_nuevaPartida);

		lblNombreBtn_nuevaPartida = new JLabel("Nueva");
		lblNombreBtn_nuevaPartida.setHorizontalAlignment(0);
		lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
		lblNombreBtn_nuevaPartida
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_nuevaPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnNuevaPartida.add(lblNombreBtn_nuevaPartida);

		jp_btnBuscarPartida = new JPanel();
		jp_btnBuscarPartida.setLayout(null);
		jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnBuscarPartida.setBackground(Variables.color_tres);
		jp_btnBuscarPartida.setBounds(ajustes.calcularPuntoX(4.95), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnBuscarPartida);

		btnBuscarPartida = new JLabel("");
		btnBuscarPartida.setCursor(Cursor.getPredefinedCursor(12));
		btnBuscarPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnBuscarPartida.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnBuscarPartida.setBackground(Variables.color_tres);
			}
		});
		btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnBuscarPartida.setBackground(Variables.color_dos);
			}
		});
		jp_btnBuscarPartida.add(btnBuscarPartida);

		lblIconoBtn_buscarPartida = new JLabel("");
		lblIconoBtn_buscarPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_buscarPartida.setIcon(
				ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", lblIconoBtn_buscarPartida));
		jp_btnBuscarPartida.add(lblIconoBtn_buscarPartida);

		lblNombreBtn_buscarPartida = new JLabel("Buscar");
		lblNombreBtn_buscarPartida.setHorizontalAlignment(0);
		lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
		lblNombreBtn_buscarPartida
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_buscarPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnBuscarPartida.add(lblNombreBtn_buscarPartida);

		jp_btnGuardar = new JPanel();
		jp_btnGuardar.setLayout(null);
		jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnGuardar.setBackground(Variables.color_tres);
		jp_btnGuardar.setBounds(ajustes.calcularPuntoX(9.11), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnGuardar);

		btnGuardar = new JLabel("");
		btnGuardar.setCursor(Cursor.getPredefinedCursor(12));
		btnGuardar.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnGuardar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnGuardar.setBackground(Variables.color_tres);
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				if (chckbxProducto) {
					guardarLista();
					iniciarTablaCuentasVinculadas();
					// llenarTablaCuentasVinculadasProducto();

				} else {
					guardarLista();
					iniciarTablaCuentasVinculadas();
					// llenarTablaCuentasVinculadasServicios();
				}

			}
		});
		btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnGuardar.setBackground(Variables.color_dos);
			}
		});
		jp_btnGuardar.add(btnGuardar);

		lblIconoBtn_guardar = new JLabel("");
		lblIconoBtn_guardar.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_guardar
				.setIcon(ajustes.ajustarImagen("/botones_04_icono_guardar", lblIconoBtn_guardar, 50, 50, 50, 50));
		jp_btnGuardar.add(lblIconoBtn_guardar);

		lblNombreBtn_guardar = new JLabel("Guardar");
		lblNombreBtn_guardar.setHorizontalAlignment(0);
		lblNombreBtn_guardar.setForeground(Variables.color_uno);
		lblNombreBtn_guardar
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_guardar.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnGuardar.add(lblNombreBtn_guardar);

		jp_btnImprimir = new JPanel();
		jp_btnImprimir.setLayout(null);
		jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnImprimir.setBackground(Variables.color_tres);
		jp_btnImprimir.setBounds(ajustes.calcularPuntoX(13.28), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnImprimir);

		btnImprimir = new JLabel("");
		btnImprimir.setCursor(Cursor.getPredefinedCursor(12));
		btnImprimir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnImprimir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnImprimir.setBackground(Variables.color_tres);
			}
		});
		btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnImprimir.setBackground(Variables.color_dos);
			}
		});
		jp_btnImprimir.add(btnImprimir);

		lblIconoBtn_imprimir = new JLabel("");
		lblIconoBtn_imprimir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_imprimir
				.setIcon(ajustes.ajustarImagen("/botones_05_icono_imprimir", lblIconoBtn_imprimir, 50, 50, 50, 50));
		jp_btnImprimir.add(lblIconoBtn_imprimir);

		lblNombreBtn_imprimir = new JLabel("Imprimir");
		lblNombreBtn_imprimir.setHorizontalAlignment(0);
		lblNombreBtn_imprimir.setForeground(Variables.color_uno);
		lblNombreBtn_imprimir
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_imprimir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnImprimir.add(lblNombreBtn_imprimir);

		jp_btnSalir = new JPanel();
		jp_btnSalir.setBackground(Variables.color_tres);
		jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnSalir.setBounds(ajustes.calcularPuntoX(26.04), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnSalir);
		jp_btnSalir.setLayout(null);

		btnSalir = new JLabel("");
		btnSalir.setCursor(Cursor.getPredefinedCursor(12));
		btnSalir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnSalir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnSalir.setBackground(Variables.color_tres);
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnSalir.setBackground(Variables.color_dos);
			}
		});
		jp_btnSalir.add(btnSalir);

		JLabel lblIconoBtn_salir = new JLabel("");
		lblIconoBtn_salir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.43),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_salir.setIcon(ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
		jp_btnSalir.add(lblIconoBtn_salir);

		JLabel lblNombreBtn_salir = new JLabel("Salir");
		lblNombreBtn_salir.setForeground(Variables.color_uno);
		lblNombreBtn_salir.setHorizontalAlignment(0);
		lblNombreBtn_salir
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_salir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnSalir.add(lblNombreBtn_salir);

		JPanel jp_contenido = new JPanel();
		jp_contenido.setOpaque(false);
		jp_contenido.setBounds(10, 64, ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(17.13));
		contentPane.add(jp_contenido);
		jp_contenido.setLayout(null);

		lblnewlabel = new JLabel("Vincular Cuentas Contables");
		lblnewlabel.setForeground(Variables.color_uno);
		lblnewlabel.setHorizontalAlignment(0);
		lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, ajustes.calcularPuntoY(1.85)));
		lblnewlabel.setBounds(0, ajustes.calcularPuntoY(0.46), ajustes.ancho, ajustes.calcularPuntoY(2.31));
		jp_contenido.add(lblnewlabel);
		JSeparator separator = new JSeparator();
		separator.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(3.24),
				ajustes.ancho - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.19));
		jp_contenido.add(separator);

		final JLabel lblNomOficina = new JLabel("Nombre de Oficina");
		lblNomOficina.setHorizontalAlignment(0);
		lblNomOficina.setForeground(Variables.color_uno);
		lblNomOficina.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblNomOficina.setBounds(this.ajustes.calcularPuntoX(0.73), this.ajustes.calcularPuntoY(4.68),
				this.ajustes.calcularPuntoX(7.35), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(lblNomOficina);

		(this.txtNomOficina = new JComboBox()).setEditable(true);
		this.txtNomOficina.setForeground(Variables.color_dos);
		this.txtNomOficina.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.txtNomOficina.setBounds(this.ajustes.calcularPuntoX(9.9), this.ajustes.calcularPuntoY(4.16),
				this.ajustes.calcularPuntoX(35.58), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.txtNomOficina);

		(this.lbltipservicio = new JLabel("Tipo de servicio ")).setVisible(false);
		this.lbltipservicio.setHorizontalAlignment(0);
		this.lbltipservicio.setForeground(Variables.color_uno);
		this.lbltipservicio.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		this.lbltipservicio.setBounds(this.ajustes.calcularPuntoX(1.47), this.ajustes.calcularPuntoY(8.98),
				this.ajustes.calcularPuntoX(8.75), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lbltipservicio);

		(this.cmbTipoServicio = new JComboBox<Object>()).setForeground(Variables.color_dos);
		this.cmbTipoServicio.setVisible(false);
		this.cmbTipoServicio.setForeground(Variables.color_dos);
		this.cmbTipoServicio.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.cmbTipoServicio.setBounds(this.ajustes.calcularPuntoX(9.9), this.ajustes.calcularPuntoY(8.98),
				(this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(cmbTipoServicio);

		(this.lblFromapago = new JLabel("Forma de pago")).setHorizontalAlignment(0);
		lblFromapago.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblFromapago.setForeground(Variables.color_uno);
		this.lblFromapago.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		this.lblFromapago.setBounds(this.ajustes.calcularPuntoX(29.92), this.ajustes.calcularPuntoY(8.98),
				this.ajustes.calcularPuntoX(8.75), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lblFromapago);

		(this.cmbFormaPago = new JComboBox<Object>()).setForeground(Variables.color_dos);
		this.cmbFormaPago.setForeground(Variables.color_dos);
		this.cmbFormaPago.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.cmbFormaPago.setBounds(this.ajustes.calcularPuntoX(38.52), this.ajustes.calcularPuntoY(8.98),
				(this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(cmbFormaPago);

		(this.jp_tipoOperacion1 = new JPanel()).setBackground(Variables.color_uno);
		jp_tipoOperacion1.setFont(new Font("Dialog", Font.PLAIN, 12));
		jp_tipoOperacion1.setForeground(Color.BLACK);
		jp_tipoOperacion1.setOpaque(false);
		jp_tipoOperacion1.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Tipo de Operaciones",
				TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		this.jp_tipoOperacion1.setBounds(this.ajustes.calcularPuntoX(0.32), this.ajustes.calcularPuntoY(16.27),
				this.ajustes.calcularPuntoX(45.22), this.ajustes.calcularPuntoY(33.37));
		jp_contenido.add(this.jp_tipoOperacion1);
		jp_tipoOperacion1.setLayout(null);

		(this.lblNewLabel_1_1 = new JLabel("Buscar Tipos de Operaciones")).setHorizontalAlignment(0);
		jp_tipoOperacion1.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		this.lblNewLabel_1_1.setForeground(Variables.color_uno);
		this.lblNewLabel_1_1.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblNewLabel_1_1.setBounds(this.ajustes.calcularPuntoX(2.059), ajustes.calcularPuntoY(2.734),
				ajustes.calcularPuntoX(12.132), ajustes.calcularPuntoY(2.604));

		(this.txtTipodepagoseleccionado = new JTextField()).setForeground(Variables.color_dos);
		txtTipodepagoseleccionado.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				if ((evt.getKeyChar() == KeyEvent.VK_SPACE)) {
					evt.consume();
				} else {
					llenarTablaOperaciones(txtTipodepagoseleccionado.getText());
					
				}
			}
		});
		txtTipodepagoseleccionado.setBounds(187, 22, 266, 21);
		jp_tipoOperacion1.add(txtTipodepagoseleccionado);
		this.txtTipodepagoseleccionado.setHorizontalAlignment(SwingConstants.LEFT);
		this.txtTipodepagoseleccionado.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.txtTipodepagoseleccionado.setColumns(10);

		final JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Variables.color_uno);
		scrollPane.setBounds(this.ajustes.calcularPuntoX(0.36), this.ajustes.calcularPuntoY(5.59), 605, 210);
		jp_tipoOperacion1.add(scrollPane);

		(this.tblOperaciones = new JTable()).addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(final MouseEvent e) {
				VicularCuentasContables.this.seleccionarServicios();
			}
		});
		this.tblOperaciones.setFont(new Font(Variables.fuenteLetra, Font.PLAIN, Variables.tamContenidoTabla));
		scrollPane.setViewportView(this.tblOperaciones);

		(this.jp_tipoOperacion2 = new JPanel()).setBackground(Variables.color_uno);
		jp_tipoOperacion2.setOpaque(false);
		jp_tipoOperacion2.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Cuentas Contables",
				TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		jp_tipoOperacion2.setBounds(this.ajustes.calcularPuntoX(51.52), this.ajustes.calcularPuntoY(16.27),
				this.ajustes.calcularPuntoX(45.22), this.ajustes.calcularPuntoY(33.37));
		jp_contenido.add(jp_tipoOperacion2);
		jp_tipoOperacion2.setLayout(null);

		(this.lblNewLabel_1 = new JLabel("Buscar Tipo de Cuentas")).setHorizontalAlignment(0);
		lblNewLabel_1.setBounds(32, 24, 165, 14);
		jp_tipoOperacion2.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblNewLabel_1.setForeground(Variables.color_uno);
		this.lblNewLabel_1.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));

		(this.txtTipoServicioSelecionado = new JTextField()).setForeground(Variables.color_dos);
		txtTipoServicioSelecionado.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				if ((evt.getKeyChar() == KeyEvent.VK_SPACE)) {
					evt.consume();
				} else {
					llenarTablaCuentas(txtTipoServicioSelecionado.getText());
				}
			}
		});
		txtTipoServicioSelecionado.setBounds(182, 22, 266, 21);
		jp_tipoOperacion2.add(txtTipoServicioSelecionado);
		txtTipoServicioSelecionado.setHorizontalAlignment(SwingConstants.LEFT);
		this.txtTipoServicioSelecionado.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.txtTipoServicioSelecionado.setBackground(Color.WHITE);
		this.txtTipoServicioSelecionado.setColumns(10);

		final JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBackground(Variables.color_uno);
		scrollPane_1.setBounds(5, 41, 605, 210);
		jp_tipoOperacion2.add(scrollPane_1);

		(this.tblCuentas = new JTable()).addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent e) {
				VicularCuentasContables.this.seleccionarCuentas();
			}
		});
		tblCuentas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				final int fila = tblCuentas.getSelectedRow();
				final String cuenta = tblCuentas.getValueAt(fila, 2).toString();
				if (consultaSql.verificarCuentaContable(cuenta)>0) {
					JOptionPane.showMessageDialog(contentPane, "No puede seleccionar una cuenta Hija de la cuenta"+cuenta,"Error" ,JOptionPane.ERROR_MESSAGE);
					tblCuentas.clearSelection();
				}
			}
		});
		this.tblCuentas.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		scrollPane_1.setViewportView(this.tblCuentas);

		(this.jp_tipoOperacion3 = new JPanel()).setBackground(Variables.color_uno);
		jp_tipoOperacion3.setOpaque(false);
		jp_tipoOperacion3.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Distribucion Contable",
				TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		this.jp_tipoOperacion3.setBounds(this.ajustes.calcularPuntoX(0.32), this.ajustes.calcularPuntoY(58.0),
				this.ajustes.calcularPuntoX(96.42), 158);
		jp_contenido.add(jp_tipoOperacion3);
		jp_tipoOperacion3.setLayout(new GridLayout(0, 1, 0, 0));

		final JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.addMouseListener(new MouseAdapter() {

		});
		scrollPane_2.setBackground(Variables.color_uno);
		scrollPane_2.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(20.93),
				this.ajustes.calcularPuntoX(48.35), this.ajustes.calcularPuntoY(34.44));
		jp_tipoOperacion3.add(scrollPane_2);

		(this.tblCuantasVinculadas = new JTable()).addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent e) {
				VicularCuentasContables.this.seleccionarvincularCuentas();
			}
		});
		tblCuantasVinculadas.setEnabled(false);
		tblCuantasVinculadas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblCuantasVinculadas.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
	            if (e.getButton()==MouseEvent.BUTTON3){
	                 menuEmergente();
	            }
			}
		});
		scrollPane_2.setViewportView(tblCuantasVinculadas);

		(this.jp_btnAplicar = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
		this.jp_btnAplicar.setBounds(this.ajustes.calcularPuntoX(33.0), this.ajustes.calcularPuntoY(50.0),
				(this.ajustes.ancho - 50) / 10 * 3, this.ajustes.calcularPuntoY(7.4));
		jp_contenido.add(this.jp_btnAplicar);
		this.jp_btnAplicar.setLayout(null);

		(this.btnAplicar = new JLabel("")).addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(final MouseEvent arg0) {
				VicularCuentasContables.this.jp_btnAplicar.setBackground(Variables.color_uno);
				VicularCuentasContables.this.lblNombreBtn_aplicar.setForeground(Variables.color_dos);
				VicularCuentasContables.this.lblIconoBtn_aplicar.setIcon(
						VicularCuentasContables.this.ajustes.ajustarImagen_("/images/botones-09-icono-aplicar.png",
								VicularCuentasContables.this.lblIconoBtn_aplicar));
			}

			@Override
			public void mouseClicked(final MouseEvent e) {
				VicularCuentasContables.this.modificarCuentas(); // Hay realizar al boton aplicar este va realizar la
																	// vinculacion de la cuentas mostrando en la tabla
																	// principal , que esta abajo
			}
		});
		btnAplicar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				agregarRegistroTablaCuentasVinculadas();

			}
		});
		this.btnAplicar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(final MouseEvent arg0) {
				VicularCuentasContables.this.jp_btnAplicar.setBackground(Variables.color_dos);
				VicularCuentasContables.this.lblNombreBtn_aplicar.setForeground(Variables.color_uno);
				VicularCuentasContables.this.lblIconoBtn_aplicar.setIcon(VicularCuentasContables.this.ajustes
						.ajustarImagen_("/images/botones-09-icono-aplicar-select.png",
								VicularCuentasContables.this.lblIconoBtn_aplicar));
			}
		});
		this.btnAplicar.setCursor(Cursor.getPredefinedCursor(12));
		this.btnAplicar.setBounds(0, 0, (this.ajustes.ancho - 50) / 10 * 3, this.ajustes.calcularPuntoY(7.4));
		this.jp_btnAplicar.add(this.btnAplicar);

		(this.lblIconoBtn_aplicar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(1.90),
				this.ajustes.calcularPuntoY(0.80), this.ajustes.calcularPuntoX(2.70), this.ajustes.calcularPuntoY(5.0));
		this.lblIconoBtn_aplicar.setIcon(
				new ImageIcon(VicularCuentasContables.class.getResource("/images/botones-11-icono-aplicar.png")));
		this.jp_btnAplicar.add(this.lblIconoBtn_aplicar);

		(this.lblNombreBtn_aplicar = new JLabel("APLICAR CAMBIOS")).setForeground(Variables.color_dos);
		this.lblNombreBtn_aplicar
				.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
		this.lblNombreBtn_aplicar.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblNombreBtn_aplicar.setBounds(0, 0, (this.ajustes.ancho - 50) / 10 * 3, this.ajustes.calcularPuntoY(7.4));
		this.jp_btnAplicar.add(this.lblNombreBtn_aplicar);

		final JPanel jp_chckproducto = new JPanel();
		jp_chckproducto.setOpaque(false);
		jp_chckproducto.setBounds(638, 34, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
		jp_contenido.add(jp_chckproducto);
		jp_chckproducto.setLayout(null);

		(this.chckProducto = new JLabel("")).addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(final MouseEvent arg0) {
				VicularCuentasContables.this.chckbxProducto = true;
				VicularCuentasContables.this.chckbxServicio = false;
				VicularCuentasContables.this.verificarOpcion();
			}
		});
		chckProducto.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				iniciarTablaCuentasVinculadas();
			}
		});
		this.chckProducto.setCursor(Cursor.getPredefinedCursor(12));
		this.chckProducto.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
		jp_chckproducto.add(this.chckProducto);

		(this.lbIconochckProducto = new JLabel("")).setHorizontalAlignment(0);
		this.lbIconochckProducto.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46),
				this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
		this.lbIconochckProducto.setIcon(
				this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lbIconochckProducto));
		jp_chckproducto.add(this.lbIconochckProducto);

		final JLabel lblNombreChckProducto = new JLabel("Asignar Producto");
		lblNombreChckProducto.setForeground(Variables.color_uno);
		lblNombreChckProducto.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblNombreChckProducto.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46),
				(this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.6),
				this.ajustes.calcularPuntoY(2.78));
		jp_chckproducto.add(lblNombreChckProducto);

		final JPanel jp_chckservicio = new JPanel();
		jp_chckservicio.setLayout(null);
		jp_chckservicio.setOpaque(false);
		jp_chckservicio.setBounds(905, 34, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
		jp_contenido.add(jp_chckservicio);

		(this.chckServicio = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
		this.chckServicio.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(final MouseEvent e) {
				VicularCuentasContables.this.chckbxProducto = false;
				VicularCuentasContables.this.chckbxServicio = true;
				VicularCuentasContables.this.verificarOpcion();
				iniciarTablaCuentasVinculadas();
			}
		});
		this.chckServicio.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
		jp_chckservicio.add(this.chckServicio);

		(this.lbIconochckServicio = new JLabel("")).setHorizontalAlignment(0);
		this.lbIconochckServicio.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46),
				this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
		this.lbIconochckServicio
				.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lbIconochckServicio));
		jp_chckservicio.add(this.lbIconochckServicio);

		final JLabel lblNombreChckServicio = new JLabel("Asignar Servicio");
		lblNombreChckServicio.setForeground(Variables.color_uno);
		lblNombreChckServicio.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblNombreChckServicio.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46),
				(this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
		jp_chckservicio.add(lblNombreChckServicio);

		(this.lblTipomov = new JLabel("Tipo de movimiento")).setHorizontalAlignment(0);
		this.lblTipomov.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblTipomov.setForeground(Variables.color_uno);
		this.lblTipomov.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		this.lblTipomov.setBounds(this.ajustes.calcularPuntoX(1.47), this.ajustes.calcularPuntoY(8.98),
				this.ajustes.calcularPuntoX(8.75), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lblTipomov);

		(this.lblSubrubro = new JLabel("Tipo de Subrubro")).setHorizontalAlignment(0);
		this.lblSubrubro.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblSubrubro.setForeground(Variables.color_uno);
		this.lblSubrubro.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		this.lblSubrubro.setBounds(this.ajustes.calcularPuntoX(58.67), this.ajustes.calcularPuntoY(8.98),
				this.ajustes.calcularPuntoX(8.75), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lblSubrubro);

		(this.cbxsubrubo = new JComboBox<Object>()).setForeground(Variables.color_dos);
		cbxsubrubo.setEditable(true);
		this.cbxsubrubo.setForeground(Variables.color_dos);
		this.cbxsubrubo.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		cbxsubrubo.setBounds(this.ajustes.calcularPuntoX(68.01), this.ajustes.calcularPuntoY(8.98),
				(this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.cbxsubrubo);

		(this.cmbTipoMovimiento = new JComboBox<Object>()).setForeground(Variables.color_dos);
		this.cmbTipoMovimiento.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		cmbTipoMovimiento.setBounds(this.ajustes.calcularPuntoX(9.9), this.ajustes.calcularPuntoY(8.98),
				(this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.cmbTipoMovimiento);

	}

	public void verificarOpcion() {
		if (this.chckbxProducto && !this.chckbxServicio) {
			this.lbIconochckProducto.setIcon(
					this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lbIconochckProducto));
			this.lbIconochckServicio.setIcon(
					this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lbIconochckServicio));
			this.lblTipomov.setVisible(true);
			this.lblTipomov.setBounds(this.ajustes.calcularPuntoX(1.47), this.ajustes.calcularPuntoY(8.98),
					this.ajustes.calcularPuntoX(8.75), this.ajustes.calcularPuntoY(1.85));
			this.cmbTipoMovimiento.setVisible(true);
			this.cmbTipoMovimiento.setBounds(this.ajustes.calcularPuntoX(9.9), this.ajustes.calcularPuntoY(8.98),
					(this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
			this.lblSubrubro.setVisible(true);
			this.cbxsubrubo.setVisible(true);
			this.lbltipservicio.setVisible(false);
			this.cmbTipoServicio.setVisible(false);
		} else if (!this.chckbxProducto && this.chckbxServicio) {
			this.lbIconochckProducto.setIcon(
					this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lbIconochckProducto));
			this.lbIconochckServicio.setIcon(
					this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lbIconochckServicio));
			this.lblTipomov.setVisible(false);
			this.cmbTipoMovimiento.setVisible(false);
			this.lblSubrubro.setVisible(false);
			this.cbxsubrubo.setVisible(false);
			this.lbltipservicio.setVisible(true);
			this.cmbTipoServicio.setVisible(true);

		}
	}

	public void modificarCuentas() {

	}

	public void seleccionarServicios() {

	}

	public void seleccionarCuentas() {

	}

	public void seleccionarvincularCuentas() {

	}

	public void llenarCmbOficina() {
		try {
			int nivelAdmin = 1;

			if (nivelAdmin == 1) {
				String consulta = "SELECT CONCAT(oficina.idoficina,' - ',oficina.nombre) AS nombreOficina from oficina where oficina.idoficina!="
						+ Variables.idOficina;
				this.txtNomOficina.setModel(this.consultaSql.getDataComboBox(consulta));
				consulta = "SELECT CONCAT(oficina.idoficina,' - ',oficina.nombre) AS nombreOficina from oficina where oficina.idoficina="
						+ Variables.idOficina;
				this.txtNomOficina.addItem(this.consultaSql.getDataComboBox(consulta).getElementAt(0));
				this.txtNomOficina.setSelectedIndex(this.txtNomOficina.getModel().getSize() - 1);
			} else {
				String consulta = "SELECT CONCAT(oficina.idoficina,' - ',oficina.nombre) AS nombreOficina from oficina where oficina.idoficina="
						+ Variables.idOficina;
				this.txtNomOficina.setModel(this.consultaSql.getDataComboBox(consulta));
				this.txtNomOficina.setSelectedIndex(0);
				this.txtNomOficina.setEnabled(false);
			}
		} catch (NullPointerException e) {
			JOptionPane.showMessageDialog(contentPane, "Error", "Error al cargar formulario",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	public void llenarCmbTipoServicio() {
		try {
			final String consulta = "select CONCAT(tipoServicios.idtipoServicios ,' - ',tipoServicios.nombreServicio) from tipoServicios;";
			this.cmbTipoServicio.setModel(this.consultaSql.getDataComboBox(consulta));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(contentPane, "Error", "Error al cargar formulario",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void llenarCmbFormaPago() {
		try {
			final String consulta = "SELECT CONCAT(formaPago.idformaPago,' - ',formaPago.descripcion) as formPago FROM formaPago";
			this.cmbFormaPago.setModel(this.consultaSql.getDataComboBox(consulta));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(contentPane, "Error", "Error al cargar formulario",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void llenarCmbTipoMovimiento() {
		try {
			final String consulta = "select concat(idtipoMovimiento,' - ',descripcion) from tipoMovimiento;";
			this.cmbTipoMovimiento.setModel(this.consultaSql.getDataComboBox(consulta));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(contentPane, "Error", "Error al cargar formulario",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void llenarCmbSubrubro() {
		try {
			final String consulta = "select concat(idSubcategoria,' - ',nombre) from subcategoria;";
			this.cbxsubrubo.setModel(this.consultaSql.getDataComboBox(consulta));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(contentPane, "Error", "Error al cargar", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void llenarTablaOperaciones() {
		this.tblOperaciones.setModel(this.consultaSql.obtenerTablaTipoOperacionesLike(null));
	}

	public void llenarTablaOperaciones(final String tipoOperacion) {
		this.tblOperaciones.setModel(this.consultaSql.obtenerTablaTipoOperacionesLike(tipoOperacion));
	}

	public void llenarTablaCuentas() {
		this.tblCuentas.setModel(this.consultaSql.obtenerCuentasContablesLike(null));
	}

	public void llenarTablaCuentas(final String cuenta) {
		this.tblCuentas.setModel(this.consultaSql.obtenerCuentasContablesLike(cuenta));
	}

//	public void llenarTablaCuentasVinculadasProducto() {
//		modeloCuentasVinculadas = this.consultaSql.obtenerDatosVincularCuentas(true);
//		this.tblCuantasVinculadas.setModel(this.consultaSql.obtenerDatosVincularCuentas(true));
//	}
//
//	public void llenarTablaCuentasVinculadasServicios() {
//		modeloCuentasVinculadas = this.consultaSql.obtenerDatosVincularCuentas(false);
//		this.tblCuantasVinculadas.setModel(this.consultaSql.obtenerDatosVincularCuentas(false));
//	}

	public void agregarRegistroTablaCuentasVinculadas() {
		final int filaSeleccionadaCuentas = this.tblCuentas.getSelectedRow();
		final TableModel modeloCuentas = this.tblCuentas.getModel();
		final int filaSeleccionaOperaciones = this.tblOperaciones.getSelectedRow();
		final TableModel modeloOperaciones = this.tblOperaciones.getModel();
		final String cuentaContableId = modeloCuentas.getValueAt(filaSeleccionadaCuentas, 0).toString();
		final String cuenta = modeloCuentas.getValueAt(filaSeleccionadaCuentas, 1).toString();
		final String tipoOperacion = modeloOperaciones.getValueAt(filaSeleccionaOperaciones, 1).toString();

		if (chckbxProducto) {
			final String tipoMovimiento = Texto.getIdCombos(this.cmbTipoMovimiento.getSelectedItem().toString())[2]
					+ " " + Texto.getIdCombos(this.cmbTipoMovimiento.getSelectedItem().toString())[3] + " "
					+ Texto.getIdCombos(this.cmbTipoMovimiento.getSelectedItem().toString())[4];
			final String rubro = Texto.getIdCombos(this.cbxsubrubo.getSelectedItem().toString())[2];
			final String[] fila = { cuentaContableId, cuenta, tipoOperacion, tipoMovimiento, rubro };
			modeloCuentasVinculadas.addRow(fila);
			tblCuantasVinculadas.setModel(modeloCuentasVinculadas);
			agregarListaGuardar();
		} else {
			final String tipoServicio = Texto.getIdCombos(this.cmbTipoServicio.getSelectedItem().toString())[2];

			final String formaPago = Texto.getIdCombos(this.cmbFormaPago.getSelectedItem().toString())[2];

			final String[] fila = { cuentaContableId, cuenta, tipoOperacion, tipoServicio, formaPago };
			modeloCuentasVinculadas.addRow(fila);
			tblCuantasVinculadas.setModel(modeloCuentasVinculadas);
			agregarListaGuardar();
			;
		}

	}

	public void agregarListaGuardar() {
		final int filaSeleccionadaCuentas = this.tblCuentas.getSelectedRow();
		final TableModel modeloCuentas = this.tblCuentas.getModel();
		final int filaSeleccionaOperaciones = this.tblOperaciones.getSelectedRow();
		final TableModel modeloOperaciones = this.tblOperaciones.getModel();

		final String cuentaContableId = modeloCuentas.getValueAt(filaSeleccionadaCuentas, 0).toString();

		final String tipoOperacionesId = modeloOperaciones.getValueAt(filaSeleccionaOperaciones, 0).toString();
		final String idOficina = Texto.getIdCombos(this.txtNomOficina.getSelectedItem().toString())[0];
		

		if (chckbxProducto) {
			final int cantregistros = this.consultaSql.contarRegistrosDisconInvetario()+1;
			final String idMovimiento = Texto.getIdCombos(this.cmbTipoMovimiento.getSelectedItem().toString())[0];
			final String idrubro = Texto.getIdCombos(this.cbxsubrubo.getSelectedItem().toString())[0];
			final String[] registroIngresar = { cuentaContableId, idOficina, Variables.idUsuario + "", idMovimiento,
					cantregistros+ "", idrubro, tipoOperacionesId };
			this.listaIngresoProducto.add(registroIngresar);

		} else {
			final int cantregistros = this.consultaSql.contarRegistrosDistribucionesContables()+1;
			final String tipoServicioId = Texto.getIdCombos(this.cmbTipoServicio.getSelectedItem().toString())[0];
			final String formaPagoId = Texto.getIdCombos(this.cmbFormaPago.getSelectedItem().toString())[0];
			final String[] registroIngresar = { tipoOperacionesId, cuentaContableId, tipoServicioId,
					Variables.idUsuario + "", cantregistros+ "", "", formaPagoId };
			listaIngresoServicio.add(registroIngresar);
		}
	}

	public void guardarLista() {
		int result = 0;
		if (chckbxProducto) {
			for (String[] producto : this.listaIngresoProducto) {

				if (this.insertSQL.insertDisconInventario(producto[0], producto[1], producto[2], producto[3],
						producto[4], producto[5], producto[6]) > 0) {
					result++;
				}
				;
			}

		} else {
			for (String[] servicio : listaIngresoServicio) {
				if (this.insertSQL.insertDistribucionContableServicios(servicio[0], servicio[1], servicio[2],
						servicio[3], servicio[4], servicio[5], servicio[6]) > 0) {
					result++;
				}
			}

		}

		if (result > 0) {
			JOptionPane.showMessageDialog(contentPane, "Registro Guardado Correctamente", "Informacion",
					JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(contentPane, "Registro NO Guardado Correctamente", "ERROR",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void iniciarTablaCuentasVinculadas() {
		this.modeloCuentasVinculadas = new DefaultTableModel();
		modeloCuentasVinculadas.addColumn("ID Cuenta");
		modeloCuentasVinculadas.addColumn("Cuenta Contable");
		modeloCuentasVinculadas.addColumn("Tipo Operacion");
		if (chckbxProducto) {
			modeloCuentasVinculadas.addColumn("Tipo Movimiento");
			modeloCuentasVinculadas.addColumn("Rubro");
			listaIngresoProducto =  new ArrayList<>();
		}else {
			modeloCuentasVinculadas.addColumn("Tipo Servicio");
			modeloCuentasVinculadas.addColumn("Forma de Pago");
			listaIngresoServicio =  new ArrayList<>();
		}
		this.tblCuantasVinculadas.setModel(modeloCuentasVinculadas);
	}
	
	
	public void configurarTablas() {
		
		this.tblCuantasVinculadas = this.ajustes.configurarTabla(tblCuantasVinculadas);
		this.tblCuentas = this.ajustes.configurarTabla(tblCuentas);
		this.tblOperaciones =  this.ajustes.configurarTabla(tblOperaciones);
		
	}
	
	public void borrarItemListaGuardar() {
		final int filaSeleccionada = tblCuantasVinculadas.getSelectedRow();
		
		if (chckbxProducto) {
			modeloCuentasVinculadas.removeRow(filaSeleccionada);
			tblCuantasVinculadas.setModel(modeloCuentasVinculadas);
			listaIngresoProducto.remove(filaSeleccionada);
		}else {
			modeloCuentasVinculadas.removeRow(filaSeleccionada);
			tblCuantasVinculadas.setModel(modeloCuentasVinculadas);
			listaIngresoServicio.remove(filaSeleccionada);
		}
	}
	
	
    public void menuEmergente() {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JMenuItem mntmBorrarItem = new JMenuItem("Borrar", new ImageIcon(this.getClass().getResource("/images/general-19-icono-borrar.png")));
        mntmBorrarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmBorrarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
            	borrarItemListaGuardar();
            }
        });
        popupMenu.add(mntmBorrarItem);

        this.tblCuantasVinculadas.setComponentPopupMenu(popupMenu);
    }
	
	

	@Override
	public void dispose() {
		getFrame().setVisible(true);
		super.dispose();
	}

	private JFrame getFrame() {
		return this;
	}
}
