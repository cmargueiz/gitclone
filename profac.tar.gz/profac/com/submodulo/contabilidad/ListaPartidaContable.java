// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import javax.swing.text.Document;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import javax.swing.JOptionPane;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.event.WindowListener;
import javax.swing.table.TableModel;
import profac.com.herramientas.Variables;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaPartidaContable extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultasSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnEditarPartida;
    private JLabel btnEditarPartida;
    private JLabel lblIconoBtn_editarPartida;
    private JLabel lblNombreBtn_editarPartida;
    private JPanel jp_btnAnularPartida;
    private JLabel btnAnularPartida;
    private JLabel lblIconoBtn_anularPartida;
    private JLabel lblNombreBtn_anularPartida;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JTextField txtNumeroPartidaSeleccionado;
    private JTextField txtDescripcionPartidaSeleccionada;
    private JLabel lblFechaPartidaSeleccinada;
    private JLabel lblNombreUsuarioPartidaSeleccionada;
    private JTextField txtFechaPartidaSeleccionada;
    private JTextField txtNombreUsuarioPartidaSeleccionada;
    private JLabel lblFechaInicio;
    public JTextField txtFechaInicio;
    private JLabel lblFechaFinal;
    public JTextField txtFechaFinal;
    private JLabel lblIconoBtn_buscar;
    private JLabel lblNombreBtn_buscar;
    private JLabel btnBuscar;
    private JPanel jp_tblPartidasContables;
    private JLabel lblBuscarpor;
    private JTextField txtBuscar;
    private JTable tblPartidaContable;
    public String opcionBusqueda;
    public int contadorFecha;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaPartidaContable frame = new ListaPartidaContable();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaPartidaContable() {
        this.ajustes = new Ajustes();
        this.consultasSql = new consultasSQL_SERVER();
        this.opcionBusqueda = "";
        this.contadorFecha = 0;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaPartidaContable.this.txtFechaInicio.setText(Variables.fechaSistema);
                ListaPartidaContable.this.txtFechaFinal.setText(Variables.fechaActual);
                ListaPartidaContable.this.tblPartidaContable.setModel(ListaPartidaContable.this.consultasSql.llenarTablaPartidasContables(ListaPartidaContable.this.consultasSql.obtenerIDOficina(Variables.nombreOficina)));
                ListaPartidaContable.this.configurarTabla();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaPartida = new JPanel()).setLayout(null);
        this.jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
        this.jp_btnNuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaPartida);
        (this.btnNuevaPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                final NuevaPartidaContable npc = new NuevaPartidaContable();
                if (npc.isVisible()) {
                    JOptionPane.showMessageDialog(null, "Esta ventana ya se encuentra abierta", "ALERTA!", 1);
                }
                else {
                    npc.setVisible(true);
                }
            }
        });
        this.btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaPartida.add(this.btnNuevaPartida);
        (this.lblIconoBtn_nuevaPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaPartida));
        this.jp_btnNuevaPartida.add(this.lblIconoBtn_nuevaPartida);
        (this.lblNombreBtn_nuevaPartida = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaPartida.add(this.lblNombreBtn_nuevaPartida);
        (this.jp_btnEditarPartida = new JPanel()).setLayout(null);
        this.jp_btnEditarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnEditarPartida.setBackground(Variables.color_tres);
        this.jp_btnEditarPartida.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnEditarPartida);
        (this.btnEditarPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnEditarPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnEditarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnEditarPartida.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaPartidaContable.this.modificarPartida(ListaPartidaContable.this.txtNumeroPartidaSeleccionado.getText());
            }
        });
        this.btnEditarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnEditarPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnEditarPartida.add(this.btnEditarPartida);
        (this.lblIconoBtn_editarPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_editarPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-editarPartida.png", this.lblIconoBtn_editarPartida));
        this.jp_btnEditarPartida.add(this.lblIconoBtn_editarPartida);
        (this.lblNombreBtn_editarPartida = new JLabel("Editar")).setHorizontalAlignment(0);
        this.lblNombreBtn_editarPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_editarPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_editarPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnEditarPartida.add(this.lblNombreBtn_editarPartida);
        (this.jp_btnAnularPartida = new JPanel()).setLayout(null);
        this.jp_btnAnularPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnAnularPartida.setBackground(Variables.color_tres);
        this.jp_btnAnularPartida.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnAnularPartida);
        (this.btnAnularPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnAnularPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnAnularPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnAnularPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnAnularPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnAnularPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnAnularPartida.add(this.btnAnularPartida);
        (this.lblIconoBtn_anularPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_anularPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-08-icono-anularPartida.png", this.lblIconoBtn_anularPartida));
        this.jp_btnAnularPartida.add(this.lblIconoBtn_anularPartida);
        (this.lblNombreBtn_anularPartida = new JLabel("Anular")).setHorizontalAlignment(0);
        this.lblNombreBtn_anularPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_anularPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_anularPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnAnularPartida.add(this.lblNombreBtn_anularPartida);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaPartidaContable.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaPartidaContable.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        final JLabel lblListaPartidaContable = new JLabel("Listado de Partidas Contables");
        lblListaPartidaContable.setForeground(Variables.color_uno);
        lblListaPartidaContable.setHorizontalAlignment(0);
        lblListaPartidaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        lblListaPartidaContable.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(lblListaPartidaContable);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JLabel lblPartidaSeleccionada = new JLabel("Partida Seleccionada:");
        lblPartidaSeleccionada.setForeground(Variables.color_uno);
        lblPartidaSeleccionada.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblPartidaSeleccionada.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblPartidaSeleccionada);
        (this.txtNumeroPartidaSeleccionado = new JTextField()).setEditable(false);
        this.txtNumeroPartidaSeleccionado.setHorizontalAlignment(0);
        this.txtNumeroPartidaSeleccionado.setForeground(Variables.color_dos);
        this.txtNumeroPartidaSeleccionado.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNumeroPartidaSeleccionado.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(4.17), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNumeroPartidaSeleccionado);
        this.txtNumeroPartidaSeleccionado.setColumns(10);
        final JLabel lblDescripcion = new JLabel("Descripci\u00f3n:");
        lblDescripcion.setHorizontalAlignment(0);
        lblDescripcion.setForeground(Variables.color_uno);
        lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblDescripcion.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblDescripcion);
        (this.txtDescripcionPartidaSeleccionada = new JTextField()).setEditable(false);
        this.txtDescripcionPartidaSeleccionada.setForeground(Variables.color_dos);
        this.txtDescripcionPartidaSeleccionada.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcionPartidaSeleccionada.setBounds((this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(4.17), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcionPartidaSeleccionada);
        this.txtDescripcionPartidaSeleccionada.setColumns(10);
        (this.lblFechaPartidaSeleccinada = new JLabel("Fecha Contable:")).setHorizontalAlignment(0);
        this.lblFechaPartidaSeleccinada.setForeground(Variables.color_uno);
        this.lblFechaPartidaSeleccinada.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaPartidaSeleccinada.setBounds((this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaPartidaSeleccinada);
        (this.txtFechaPartidaSeleccionada = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaPartidaSeleccionada.setForeground(Variables.color_dos);
        this.txtFechaPartidaSeleccionada.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaPartidaSeleccionada.setEditable(false);
        this.txtFechaPartidaSeleccionada.setColumns(10);
        this.txtFechaPartidaSeleccionada.setBounds((this.ajustes.ancho - 25) / 10 * 7, this.ajustes.calcularPuntoY(4.17), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaPartidaSeleccionada);
        (this.lblNombreUsuarioPartidaSeleccionada = new JLabel("Nombre de Usuario:")).setHorizontalAlignment(0);
        this.lblNombreUsuarioPartidaSeleccionada.setForeground(Variables.color_uno);
        this.lblNombreUsuarioPartidaSeleccionada.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreUsuarioPartidaSeleccionada.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNombreUsuarioPartidaSeleccionada);
        (this.txtNombreUsuarioPartidaSeleccionada = new JTextField()).setHorizontalAlignment(0);
        this.txtNombreUsuarioPartidaSeleccionada.setForeground(Variables.color_dos);
        this.txtNombreUsuarioPartidaSeleccionada.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreUsuarioPartidaSeleccionada.setEditable(false);
        this.txtNombreUsuarioPartidaSeleccionada.setColumns(10);
        this.txtNombreUsuarioPartidaSeleccionada.setBounds((this.ajustes.ancho - 25) / 10 * 9, this.ajustes.calcularPuntoY(4.17), this.ajustes.ancho / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreUsuarioPartidaSeleccionada);
        (this.lblFechaInicio = new JLabel("Fecha Inicio:")).setForeground(Variables.color_uno);
        this.lblFechaInicio.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaInicio.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(9.26), this.ajustes.ancho / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaInicio);
        (this.txtFechaInicio = new JTextField()).setDocument(new LimitadorCaracteres(this.txtFechaInicio, 10));
        this.txtFechaInicio.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(final FocusEvent arg0) {
                ListaPartidaContable.this.contadorFecha = 0;
            }
        });
        this.txtFechaInicio.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(final KeyEvent arg0) {
                final int k = arg0.getKeyChar();
                if (k >= 48 && k <= 57) {
                    if (ListaPartidaContable.this.contadorFecha == 2 || ListaPartidaContable.this.contadorFecha == 4) {
                        ListaPartidaContable.this.txtFechaInicio.setText(String.valueOf(ListaPartidaContable.this.txtFechaInicio.getText()) + "/");
                    }
                    final ListaPartidaContable this$0 = ListaPartidaContable.this;
                    ++this$0.contadorFecha;
                }
                else {
                    arg0.setKeyChar('\f');
                }
            }
        });
        this.txtFechaInicio.setHorizontalAlignment(0);
        this.txtFechaInicio.setForeground(Variables.color_dos);
        this.txtFechaInicio.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaInicio.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(8.8), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        this.txtFechaInicio.setColumns(10);
        jp_contenido.add(this.txtFechaInicio);
        (this.lblFechaFinal = new JLabel("Fecha Final:")).setForeground(new Color(227, 227, 227));
        this.lblFechaFinal.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaFinal.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(13.89), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaFinal);
        (this.txtFechaFinal = new JTextField()).setDocument(new LimitadorCaracteres(this.txtFechaFinal, 10));
        this.txtFechaFinal.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(final FocusEvent arg0) {
                ListaPartidaContable.this.contadorFecha = 0;
            }
        });
        this.txtFechaFinal.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(final KeyEvent arg0) {
                final int k = arg0.getKeyChar();
                if (k >= 48 && k <= 57) {
                    if (ListaPartidaContable.this.contadorFecha == 2 || ListaPartidaContable.this.contadorFecha == 4) {
                        ListaPartidaContable.this.txtFechaFinal.setText(String.valueOf(ListaPartidaContable.this.txtFechaFinal.getText()) + "/");
                    }
                    final ListaPartidaContable this$0 = ListaPartidaContable.this;
                    ++this$0.contadorFecha;
                }
                else {
                    arg0.setKeyChar('\f');
                }
            }
        });
        this.txtFechaFinal.setHorizontalAlignment(0);
        this.txtFechaFinal.setForeground(Variables.color_dos);
        this.txtFechaFinal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaFinal.setColumns(10);
        this.txtFechaFinal.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(13.43), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaFinal);
        final JPanel jp_btnBuscar = new JPanel();
        jp_btnBuscar.setBackground(Variables.color_uno);
        jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 2 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(8.8), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(7.87));
        jp_contenido.add(jp_btnBuscar);
        jp_btnBuscar.setLayout(null);
        (this.btnBuscar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_uno);
                ListaPartidaContable.this.lblIconoBtn_buscar.setIcon(ListaPartidaContable.this.ajustes.ajustarImagen("/botones_07_icono_buscar", ListaPartidaContable.this.lblIconoBtn_buscar, 50, 50, 50, 50));
                ListaPartidaContable.this.lblNombreBtn_buscar.setForeground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaPartidaContable.this.buscarPartidas(ListaPartidaContable.this.txtFechaInicio.getText().toString(), ListaPartidaContable.this.txtFechaFinal.getText().toString());
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_dos);
                ListaPartidaContable.this.lblIconoBtn_buscar.setIcon(ListaPartidaContable.this.ajustes.ajustarImagen("/botones_07_icono_buscar_select", ListaPartidaContable.this.lblIconoBtn_buscar, 50, 50, 50, 50));
                ListaPartidaContable.this.lblNombreBtn_buscar.setForeground(Variables.color_uno);
            }
        });
        this.btnBuscar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(7.87));
        jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoBtn_buscar.setBounds(this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen("/botones_07_icono_buscar", this.lblIconoBtn_buscar, 50, 50, 50, 50));
        jp_btnBuscar.add(this.lblIconoBtn_buscar);
        (this.lblNombreBtn_buscar = new JLabel("Buscar")).setForeground(Variables.color_dos);
        this.lblNombreBtn_buscar.setHorizontalAlignment(0);
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNombreBtn_buscar.setBounds(0, this.ajustes.calcularPuntoY(5.56), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_btnBuscar.add(this.lblNombreBtn_buscar);
        (this.jp_tblPartidasContables = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_tblPartidasContables.setBackground(Variables.color_uno);
        this.jp_tblPartidasContables.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(18.52), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(63.43));
        jp_contenido.add(this.jp_tblPartidasContables);
        this.jp_tblPartidasContables.setLayout(null);
        (this.lblBuscarpor = new JLabel("Buscar por:")).setForeground(Variables.color_dos);
        this.lblBuscarpor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBuscarpor.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.39), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(1.85));
        this.jp_tblPartidasContables.add(this.lblBuscarpor);
        final JComboBox<Object> cbxOpcionesBuscar = new JComboBox<Object>();
        cbxOpcionesBuscar.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(final ItemEvent arg0) {
                if (arg0.getStateChange() == 1) {
                    ListaPartidaContable.this.opcionBusqueda = arg0.getItem().toString();
                }
            }
        });
        cbxOpcionesBuscar.setModel(new DefaultComboBoxModel<Object>(new String[] { "Selecciona Una Opci\u00f3n", "1- Numero de Partida Contable", "2- Descripcion de Partida Contable" }));
        cbxOpcionesBuscar.setForeground(Variables.color_dos);
        cbxOpcionesBuscar.setBorder(UIManager.getBorder("ComboBox.border"));
        cbxOpcionesBuscar.setBackground(Color.WHITE);
        cbxOpcionesBuscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        cbxOpcionesBuscar.setBounds((this.ajustes.ancho - 25) / 10 - 25, this.ajustes.calcularPuntoY(0.93), this.ajustes.ancho / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_tblPartidasContables.add(cbxOpcionesBuscar);
        (this.txtBuscar = new JTextField()).addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(final KeyEvent arg0) {
                ListaPartidaContable.this.buscarPartida();
            }
        });
        this.txtBuscar.setForeground(Variables.color_dos);
        this.txtBuscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscar.setBackground(Color.WHITE);
        this.txtBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(0.93), ((this.ajustes.ancho - 25) / 10 - 25) * 8 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(2.78));
        this.jp_tblPartidasContables.add(this.txtBuscar);
        this.txtBuscar.setColumns(10);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(4.63), this.ajustes.ancho - this.ajustes.calcularPuntoX(3.65), this.ajustes.calcularPuntoY(57.41));
        this.jp_tblPartidasContables.add(scrollPane);
        (this.tblPartidaContable = new JTable()).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                ListaPartidaContable.this.seleccionarPartida();
            }
        });
        this.tblPartidaContable.setForeground(Variables.color_dos);
        this.tblPartidaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        scrollPane.setViewportView(this.tblPartidaContable);
        this.menuEmergente();
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        final TableColumnModel columnModel = this.tblPartidaContable.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = this.tblPartidaContable.getTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(40);
        columnModel.getColumn(1).setCellRenderer(alinear);
        columnModel.getColumn(2).setPreferredWidth(500);
        columnModel.getColumn(3).setPreferredWidth(75);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(100);
        columnModel.getColumn(4).setCellRenderer(alinear);
    }
    
    public void seleccionarPartida() {
        this.txtNumeroPartidaSeleccionado.setText((String)this.tblPartidaContable.getValueAt(this.tblPartidaContable.getSelectedRow(), 0));
        Variables.numeroPartidaSeleccionada = this.txtNumeroPartidaSeleccionado.getText();
        this.txtDescripcionPartidaSeleccionada.setText((String)this.tblPartidaContable.getValueAt(this.tblPartidaContable.getSelectedRow(), 2));
        Variables.descripcionPartidaSeleccionada = this.txtDescripcionPartidaSeleccionada.getText();
        this.txtFechaPartidaSeleccionada.setText((String)this.tblPartidaContable.getValueAt(this.tblPartidaContable.getSelectedRow(), 3));
        Variables.fechaContablePartidaSeleccionada = this.txtFechaPartidaSeleccionada.getText();
        this.txtNombreUsuarioPartidaSeleccionada.setText((String)this.tblPartidaContable.getValueAt(this.tblPartidaContable.getSelectedRow(), 4));
        Variables.usuarioPartidaContable = this.txtNombreUsuarioPartidaSeleccionada.getText();
    }
    
    public void buscarPartidas(final String fechaInicio, final String fechaFin) {
        final String fechaError = "dd/MM/aaaa";
        if (fechaFin.equals(fechaError) || fechaInicio.equals(fechaError)) {
            JOptionPane.showMessageDialog(null, "Debe selecionar una fecha valida", "ERROR!", 0);
            return;
        }
        this.tblPartidaContable.setModel(this.consultasSql.llenarTablaPartidasContablesFechas(this.consultasSql.obtenerIDOficina(Variables.nombreOficina), fechaInicio, fechaFin));
    }
    
    public void modificarPartida(final String numeroPartida) {
        if (numeroPartida.length() == 0 || numeroPartida.length() == 0) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar una partida contable.", "ALERTA!", 2);
            return;
        }
        final ModificarPartidaContable mpc = new ModificarPartidaContable();
        mpc.setVisible(true);
    }
    
    public void menuEmergente() {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JMenuItem mntmBorrarMovimiento = new JMenuItem("Editar Partida Contable", new ImageIcon(this.getClass().getResource("/images/general-20-icono-editar.png")));
        mntmBorrarMovimiento.setCursor(Cursor.getPredefinedCursor(12));
        mntmBorrarMovimiento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                ListaPartidaContable.this.modificarPartida(ListaPartidaContable.this.txtNumeroPartidaSeleccionado.getText());
            }
        });
        popupMenu.add(mntmBorrarMovimiento);
        this.tblPartidaContable.setComponentPopupMenu(popupMenu);
    }
    
    public void buscarPartida() {
        final String substring;
        switch (substring = this.opcionBusqueda.substring(0, 1)) {
            case "": {
                JOptionPane.showMessageDialog(null, "Debe seleccionar una opcion de busqueda", "ALERTA!", 2);
                break;
            }
            case "1": {
                this.tblPartidaContable.setModel(this.consultasSql.llenarTablaBusquedaPartidaContable(1, Integer.parseInt(this.txtBuscar.getText()), this.txtBuscar.getText(), Variables.idOficina));
                break;
            }
            case "2": {
                this.tblPartidaContable.setModel(this.consultasSql.llenarTablaBusquedaPartidaContable(2, 0, "%" + this.txtBuscar.getText() + "%", Variables.idOficina));
                break;
            }
            default:
                break;
        }
        this.configurarTabla();
    }
}
