// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import profac.com.herramientas.Imprimir;
import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.herramientas.F_Contabilidad;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevaPartidaContable extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    public F_Contabilidad contabilidad;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblNuevaPartidaContable;
    private JPanel jp_cuentasContables;
    private JLabel lblBuscarCuenta;
    private JTextField txtBuscarCuenta;
    private JPanel jp_tblCuentas;
    private JSeparator separator_1;
    private JScrollPane scrollPane;
    private JTable tblCuentaContable;
    private JPanel jp_datosPartida;
    private JTextField txtObservacion;
    private JTextField txtCuenta;
    private JTextField txtDescripcionCuenta;
    private JTextField txtCargo;
    private JTextField txtAbono;
    private JTextField txtDescripcion;
    private JPanel jp_btnAgregar;
    private JLabel lblIconoBtn_agregar;
    private JLabel lblNombreBtn_agregar;
    private JLabel btnAgregar;
    private JPanel jp_tblDetallePartida;
    private JPanel jp_detalle;
    private JTable tblDetalle;
    private JTextField txtCargoTotal;
    private JTextField txtAbonoTotal;
    private JTextField txtFechaContable;
    private JTextField txtNumeroPartida;
    private JTextField txtFechaDocumento;
    public int bandera;
    public int banderaImprimir;
    public double montoCargo;
    public double montoAbono;
    DefaultTableModel modeloTblDetalle;
    private JLabel btnBuscar;
    private JPanel jp_btnBuscar;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevaPartidaContable frame = new NuevaPartidaContable();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevaPartidaContable() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.contabilidad = new F_Contabilidad();
        this.bandera = 0;
        this.banderaImprimir = 0;
        this.montoCargo = 0.0;
        this.montoAbono = 0.0;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevaPartidaContable.this.initVentana();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaPartida = new JPanel()).setLayout(null);
        this.jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
        this.jp_btnNuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaPartida);
        (this.btnNuevaPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaPartida.add(this.btnNuevaPartida);
        (this.lblIconoBtn_nuevaPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaPartida));
        this.jp_btnNuevaPartida.add(this.lblIconoBtn_nuevaPartida);
        (this.lblNombreBtn_nuevaPartida = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaPartida.add(this.lblNombreBtn_nuevaPartida);
        (this.jp_btnBuscarPartida = new JPanel()).setLayout(null);
        this.jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
        this.jp_btnBuscarPartida.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarPartida);
        (this.btnBuscarPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                final ListaPartidaContable lpc = new ListaPartidaContable();
                lpc.setVisible(true);
            }
        });
        this.btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarPartida.add(this.btnBuscarPartida);
        (this.lblIconoBtn_buscarPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarPartida));
        this.jp_btnBuscarPartida.add(this.lblIconoBtn_buscarPartida);
        (this.lblNombreBtn_buscarPartida = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarPartida.add(this.lblNombreBtn_buscarPartida);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevaPartidaContable.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevaPartidaContable.this.imprimir();
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaPartidaContable.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblNuevaPartidaContable = new JLabel("Nueva Partida Contable")).setForeground(Variables.color_uno);
        this.lblNuevaPartidaContable.setHorizontalAlignment(0);
        this.lblNuevaPartidaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNuevaPartidaContable.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblNuevaPartidaContable);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        (this.jp_cuentasContables = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_cuentasContables.setBackground(Variables.color_uno);
        this.jp_cuentasContables.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.17), this.ajustes.calcularPuntoX(18.23), this.ajustes.calcularPuntoY(77.78));
        jp_contenido.add(this.jp_cuentasContables);
        this.jp_cuentasContables.setLayout(null);
        (this.lblBuscarCuenta = new JLabel("Buscar Cuenta Contable")).setForeground(Variables.color_dos);
        this.lblBuscarCuenta.setHorizontalAlignment(0);
        this.lblBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBuscarCuenta.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(18.23), this.ajustes.calcularPuntoY(1.85));
        this.jp_cuentasContables.add(this.lblBuscarCuenta);
        (this.txtBuscarCuenta = new JTextField()).addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(final KeyEvent arg0) {
                switch (arg0.getKeyCode()) {
                    case 10: {
                        NuevaPartidaContable.this.buscarCuenta("%" + NuevaPartidaContable.this.txtBuscarCuenta.getText().toString() + "%");
                        break;
                    }
                    case 18: {
                        NuevaPartidaContable.this.buscarCuenta("%" + NuevaPartidaContable.this.txtBuscarCuenta.getText().toString() + "%");
                        break;
                    }
                }
            }
        });
        this.txtBuscarCuenta.setForeground(Variables.color_dos);
        this.txtBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscarCuenta.setBackground(Color.WHITE);
        this.txtBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78), this.ajustes.calcularPuntoX(12.24), this.ajustes.calcularPuntoY(2.78));
        this.jp_cuentasContables.add(this.txtBuscarCuenta);
        this.txtBuscarCuenta.setColumns(10);
        (this.jp_btnBuscar = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscar.setBackground(Variables.color_tres);
        this.jp_btnBuscar.setBounds(this.ajustes.calcularPuntoX(13.02), this.ajustes.calcularPuntoY(2.78), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_cuentasContables.add(this.jp_btnBuscar);
        this.jp_btnBuscar.setLayout(null);
        (this.btnBuscar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnBuscar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaPartidaContable.this.buscarCuenta("%" + NuevaPartidaContable.this.txtBuscarCuenta.getText().toString() + "%");
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaPartidaContable.this.jp_btnBuscar.setBackground(Variables.color_dos);
            }
        });
        this.btnBuscar.setBounds(0, 0, this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar.add(this.btnBuscar);
        final JLabel lblIconoBtn_buscar = new JLabel("");
        lblIconoBtn_buscar.setBounds(this.ajustes.calcularPuntoX(0.26), 0, this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/general-16-icono-buscar.png", lblIconoBtn_buscar));
        this.jp_btnBuscar.add(lblIconoBtn_buscar);
        final JLabel lblNombreBtn_buscar = new JLabel("Buscar");
        lblNombreBtn_buscar.setHorizontalAlignment(0);
        lblNombreBtn_buscar.setForeground(Variables.color_uno);
        lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.8))));
        lblNombreBtn_buscar.setBounds(this.ajustes.calcularPuntoX(1.56), 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar.add(lblNombreBtn_buscar);
        (this.separator_1 = new JSeparator()).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(6.48), this.ajustes.calcularPuntoX(17.19), this.ajustes.calcularPuntoY(0.19));
        this.jp_cuentasContables.add(this.separator_1);
        (this.jp_tblCuentas = new JPanel()).setLayout(null);
        this.jp_tblCuentas.setBorder(new BevelBorder(1, null, null, null, null));
        this.jp_tblCuentas.setBackground(Color.WHITE);
        this.jp_tblCuentas.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(7.41), this.ajustes.calcularPuntoX(17.19), this.ajustes.calcularPuntoY(69.44));
        this.jp_cuentasContables.add(this.jp_tblCuentas);
        (this.scrollPane = new JScrollPane()).setBackground(Color.WHITE);
        this.scrollPane.setBounds(0, 0, this.ajustes.calcularPuntoX(17.19), this.ajustes.calcularPuntoY(69.44));
        this.jp_tblCuentas.add(this.scrollPane);
        (this.tblCuentaContable = new JTable()).setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.tblCuentaContable.setForeground(Variables.color_dos);
        this.tblCuentaContable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaPartidaContable.this.seleccionarCuenta((String)NuevaPartidaContable.this.tblCuentaContable.getValueAt(NuevaPartidaContable.this.tblCuentaContable.getSelectedRow(), 0), (String)NuevaPartidaContable.this.tblCuentaContable.getValueAt(NuevaPartidaContable.this.tblCuentaContable.getSelectedRow(), 1));
            }
        });
        this.scrollPane.setViewportView(this.tblCuentaContable);
        (this.jp_datosPartida = new JPanel()).setOpaque(false);
        this.jp_datosPartida.setBounds(this.ajustes.calcularPuntoX(20.83), this.ajustes.calcularPuntoY(4.17), this.ajustes.ancho - this.ajustes.calcularPuntoX(22.14), this.ajustes.calcularPuntoY(77.78));
        jp_contenido.add(this.jp_datosPartida);
        this.jp_datosPartida.setLayout(null);
        final JLabel lblNumeroPartida = new JLabel("Numero de Partida");
        lblNumeroPartida.setHorizontalAlignment(0);
        lblNumeroPartida.setForeground(Variables.color_uno);
        lblNumeroPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNumeroPartida.setBounds(0, this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - this.ajustes.calcularPuntoX(22.14)) / 3 - this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblNumeroPartida);
        (this.txtNumeroPartida = new JTextField()).setEnabled(false);
        this.txtNumeroPartida.setHorizontalAlignment(0);
        this.txtNumeroPartida.setForeground(Variables.color_dos);
        this.txtNumeroPartida.setBackground(Color.WHITE);
        this.txtNumeroPartida.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNumeroPartida.setBounds(0, this.ajustes.calcularPuntoY(2.78), this.ajustes.calcularPuntoX(25.26), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtNumeroPartida);
        this.txtNumeroPartida.setColumns(10);
        final JLabel lblFechaContable = new JLabel("Fecha Contable");
        lblFechaContable.setHorizontalAlignment(0);
        lblFechaContable.setForeground(Variables.color_uno);
        lblFechaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaContable.setBounds(this.ajustes.calcularPuntoX(26.56), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(25.26), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblFechaContable);
        (this.txtFechaContable = new JTextField()).setEnabled(false);
        this.txtFechaContable.setBackground(Color.WHITE);
        this.txtFechaContable.setHorizontalAlignment(0);
        this.txtFechaContable.setForeground(Variables.color_dos);
        this.txtFechaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaContable.setBounds(this.ajustes.calcularPuntoX(26.56), this.ajustes.calcularPuntoY(2.78), this.ajustes.calcularPuntoX(25.26), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtFechaContable);
        this.txtFechaContable.setColumns(10);
        final JLabel lblFechaDocumento = new JLabel("Fecha de Documento");
        lblFechaDocumento.setHorizontalAlignment(0);
        lblFechaDocumento.setForeground(Variables.color_uno);
        lblFechaDocumento.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaDocumento.setBounds(this.ajustes.calcularPuntoX(53.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(24.74), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblFechaDocumento);
        (this.txtFechaDocumento = new JTextField()).setEnabled(false);
        this.txtFechaDocumento.setHorizontalAlignment(0);
        this.txtFechaDocumento.setForeground(Variables.color_dos);
        this.txtFechaDocumento.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaDocumento.setBackground(Color.WHITE);
        this.txtFechaDocumento.setBounds(this.ajustes.calcularPuntoX(53.13), this.ajustes.calcularPuntoY(2.78), this.ajustes.calcularPuntoX(24.74), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtFechaDocumento);
        this.txtFechaDocumento.setColumns(10);
        final JLabel lblObservacion = new JLabel("Observaci\u00f3n:");
        lblObservacion.setForeground(Color.WHITE);
        lblObservacion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.75))));
        lblObservacion.setBounds(0, this.ajustes.calcularPuntoY(7.41), this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblObservacion);
        (this.txtObservacion = new JTextField()).setForeground(Variables.color_dos);
        this.txtObservacion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtObservacion.setBackground(Color.WHITE);
        this.txtObservacion.setBounds(this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(6.94), this.ajustes.ancho - this.ajustes.calcularPuntoX(27.34), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtObservacion);
        this.txtObservacion.setColumns(10);
        final JLabel lblCuenta = new JLabel("Cuenta Contable");
        lblCuenta.setHorizontalAlignment(0);
        lblCuenta.setForeground(Variables.color_uno);
        lblCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblCuenta.setBounds(0, this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(15.1), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblCuenta);
        (this.txtCuenta = new JTextField()).setHorizontalAlignment(0);
        this.txtCuenta.setForeground(Variables.color_dos);
        this.txtCuenta.setBackground(Color.WHITE);
        this.txtCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuenta.setBounds(0, this.ajustes.calcularPuntoY(13.43), this.ajustes.calcularPuntoX(15.1), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtCuenta);
        this.txtCuenta.setColumns(10);
        final JLabel lblDescripcionCuenta = new JLabel("Descripci\u00f3n de Cuenta Contable");
        lblDescripcionCuenta.setHorizontalAlignment(0);
        lblDescripcionCuenta.setForeground(Variables.color_uno);
        lblDescripcionCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblDescripcionCuenta.setBounds(this.ajustes.calcularPuntoX(16.15), this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(22.66), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblDescripcionCuenta);
        (this.txtDescripcionCuenta = new JTextField()).setHorizontalAlignment(2);
        this.txtDescripcionCuenta.setForeground(Variables.color_dos);
        this.txtDescripcionCuenta.setColumns(10);
        this.txtDescripcionCuenta.setBackground(Color.WHITE);
        this.txtDescripcionCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcionCuenta.setBounds(this.ajustes.calcularPuntoX(16.15), this.ajustes.calcularPuntoY(13.43), this.ajustes.calcularPuntoX(22.66), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtDescripcionCuenta);
        final JLabel lblCargo = new JLabel("Cargo");
        lblCargo.setHorizontalAlignment(0);
        lblCargo.setForeground(Variables.color_uno);
        lblCargo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblCargo.setBounds(this.ajustes.calcularPuntoX(39.84), this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(14.58), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblCargo);
        (this.txtCargo = new JTextField()).setText("0.00");
        this.txtCargo.setHorizontalAlignment(0);
        this.txtCargo.setForeground(Variables.color_dos);
        this.txtCargo.setColumns(10);
        this.txtCargo.setBackground(Color.WHITE);
        this.txtCargo.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCargo.setBounds(this.ajustes.calcularPuntoX(39.84), this.ajustes.calcularPuntoY(13.43), this.ajustes.calcularPuntoX(14.58), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtCargo);
        final JLabel lblAbono = new JLabel("Abono");
        lblAbono.setHorizontalAlignment(0);
        lblAbono.setForeground(Variables.color_uno);
        lblAbono.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblAbono.setBounds(this.ajustes.calcularPuntoX(55.47), this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(14.58), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblAbono);
        (this.txtAbono = new JTextField()).setText("0.00");
        this.txtAbono.setHorizontalAlignment(0);
        this.txtAbono.setForeground(Variables.color_dos);
        this.txtAbono.setColumns(10);
        this.txtAbono.setBackground(Color.WHITE);
        this.txtAbono.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtAbono.setBounds(this.ajustes.calcularPuntoX(55.47), this.ajustes.calcularPuntoY(13.43), this.ajustes.calcularPuntoX(14.58), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtAbono);
        (this.jp_btnAgregar = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnAgregar.setBounds(this.ajustes.calcularPuntoX(70.83), this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(6.77), this.ajustes.calcularPuntoY(9.72));
        this.jp_datosPartida.add(this.jp_btnAgregar);
        this.jp_btnAgregar.setLayout(null);
        (this.btnAgregar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaPartidaContable.this.lblIconoBtn_agregar.setIcon(new ImageIcon(NuevaPartidaContable.class.getResource("/images/botones-06-icono-agregar.png")));
                NuevaPartidaContable.this.lblNombreBtn_agregar.setForeground(Variables.color_dos);
                NuevaPartidaContable.this.jp_btnAgregar.setBackground(Variables.color_uno);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaPartidaContable.this.agregarDetalle();
            }
        });
        this.btnAgregar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaPartidaContable.this.lblIconoBtn_agregar.setIcon(new ImageIcon(NuevaPartidaContable.class.getResource("/images/botones-06-icono-agregar-select.png")));
                NuevaPartidaContable.this.lblNombreBtn_agregar.setForeground(Variables.color_uno);
                NuevaPartidaContable.this.jp_btnAgregar.setBackground(Variables.color_dos);
            }
        });
        this.btnAgregar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnAgregar.setBounds(0, 0, this.ajustes.calcularPuntoX(6.77), this.ajustes.calcularPuntoY(9.26));
        this.jp_btnAgregar.add(this.btnAgregar);
        (this.lblIconoBtn_agregar = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoBtn_agregar.setBounds(this.ajustes.calcularPuntoX(1.41), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.91), this.ajustes.calcularPuntoY(6.94));
        this.lblIconoBtn_agregar.setIcon(this.ajustes.ajustarImagen_("/images/botones-06-icono-agregar.png", this.lblIconoBtn_agregar));
        this.jp_btnAgregar.add(this.lblIconoBtn_agregar);
        (this.lblNombreBtn_agregar = new JLabel("Agregar")).setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_agregar.setHorizontalAlignment(0);
        this.lblNombreBtn_agregar.setBounds(0, this.ajustes.calcularPuntoY(7.41), this.ajustes.calcularPuntoX(6.77), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnAgregar.add(this.lblNombreBtn_agregar);
        final JLabel lblDescripcion = new JLabel("Descripci\u00f3n:");
        lblDescripcion.setForeground(Variables.color_uno);
        lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblDescripcion.setBounds(0, this.ajustes.calcularPuntoY(18.06), this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(1.85));
        this.jp_datosPartida.add(lblDescripcion);
        (this.txtDescripcion = new JTextField()).setForeground(Variables.color_dos);
        this.txtDescripcion.setBackground(Color.WHITE);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setBounds(this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(17.59), this.ajustes.calcularPuntoX(64.74), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtDescripcion);
        this.txtDescripcion.setColumns(10);
        (this.jp_tblDetallePartida = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_tblDetallePartida.setBackground(Variables.color_uno);
        this.jp_tblDetallePartida.setBounds(0, this.ajustes.calcularPuntoY(21.76), this.ajustes.ancho - this.ajustes.calcularPuntoX(22.14), this.ajustes.calcularPuntoY(51.39));
        this.jp_datosPartida.add(this.jp_tblDetallePartida);
        this.jp_tblDetallePartida.setLayout(null);
        (this.jp_detalle = new JPanel()).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.ancho - this.ajustes.calcularPuntoX(23.18), this.ajustes.calcularPuntoY(49.54));
        this.jp_tblDetallePartida.add(this.jp_detalle);
        this.jp_detalle.setLayout(null);
        final JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(0, 0, this.ajustes.ancho - this.ajustes.calcularPuntoX(23.18), this.ajustes.calcularPuntoY(49.54));
        this.jp_detalle.add(scrollPane_1);
        (this.tblDetalle = new JTable()).setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.tblDetalle.setForeground(Variables.color_dos);
        (this.modeloTblDetalle = new DefaultTableModel()).addColumn("Cuenta");
        this.modeloTblDetalle.addColumn("Descripcion");
        this.modeloTblDetalle.addColumn("Concepto");
        this.modeloTblDetalle.addColumn("Cargo");
        this.modeloTblDetalle.addColumn("Abono");
        this.tblDetalle.setModel(this.modeloTblDetalle);
        this.configurarTabla(1);
        scrollPane_1.setViewportView(this.tblDetalle);
        final JLabel lblTotal = new JLabel("TOTAL");
        lblTotal.setHorizontalAlignment(4);
        lblTotal.setForeground(Variables.color_uno);
        lblTotal.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        lblTotal.setBounds(0, this.ajustes.calcularPuntoY(74.54), this.ajustes.calcularPuntoX(38.02), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(lblTotal);
        (this.txtCargoTotal = new JTextField()).setEnabled(false);
        this.txtCargoTotal.setText("0.00");
        this.txtCargoTotal.setHorizontalAlignment(0);
        this.txtCargoTotal.setForeground(Variables.color_dos);
        this.txtCargoTotal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCargoTotal.setBounds(this.ajustes.calcularPuntoX(39.84), this.ajustes.calcularPuntoY(74.54), this.ajustes.calcularPuntoX(14.54), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtCargoTotal);
        this.txtCargoTotal.setColumns(10);
        (this.txtAbonoTotal = new JTextField()).setEnabled(false);
        this.txtAbonoTotal.setHorizontalAlignment(0);
        this.txtAbonoTotal.setForeground(Variables.color_dos);
        this.txtAbonoTotal.setText("0.00");
        this.txtAbonoTotal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtAbonoTotal.setBounds(this.ajustes.calcularPuntoX(55.47), this.ajustes.calcularPuntoY(74.54), this.ajustes.calcularPuntoX(14.54), this.ajustes.calcularPuntoY(2.78));
        this.jp_datosPartida.add(this.txtAbonoTotal);
        this.txtAbonoTotal.setColumns(10);
        this.menuEmergente();
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void configurarTabla(final int op) {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        switch (op) {
            case 0: {
                final TableColumnModel columnModel = this.tblCuentaContable.getColumnModel();
                header = this.tblCuentaContable.getTableHeader();
                header.setFont(fuente);
                header.setForeground(Variables.color_dos);
                alinear.setHorizontalAlignment(0);
                columnModel.getColumn(0).setPreferredWidth(90);
                columnModel.getColumn(0).setCellRenderer(alinear);
                columnModel.getColumn(1).setPreferredWidth(200);
                break;
            }
            case 1: {
                final TableColumnModel columnModel = this.tblDetalle.getColumnModel();
                header = this.tblDetalle.getTableHeader();
                header.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
                header.setForeground(Variables.color_dos);
                alinear.setHorizontalAlignment(0);
                columnModel.getColumn(0).setPreferredWidth(100);
                columnModel.getColumn(0).setCellRenderer(alinear);
                columnModel.getColumn(1).setPreferredWidth(170);
                columnModel.getColumn(2).setPreferredWidth(100);
                columnModel.getColumn(3).setPreferredWidth(40);
                columnModel.getColumn(3).setCellRenderer(alinear);
                columnModel.getColumn(4).setPreferredWidth(40);
                columnModel.getColumn(4).setCellRenderer(alinear);
                break;
            }
        }
    }
    
    public void initVentana() {
        this.txtFechaContable.setText(Variables.fechaSistema);
        this.txtFechaDocumento.setText(Variables.fechaActual);
        this.txtNumeroPartida.setText(this.consultaSql.obtenerNumeroPartidaContable());
        this.tblCuentaContable.setModel(this.consultaSql.llenarTablaCuentasContables_nuevaPartida(this.consultaSql.obtenerIDOficina(Variables.nombreOficina)));
        this.configurarTabla(0);
    }
    
    public void buscarCuenta(final String nombreCuenta) {
        this.tblCuentaContable.setModel(this.consultaSql.llenarTablaCuentasContables_nombre(nombreCuenta, this.consultaSql.obtenerIDOficina(Variables.nombreOficina)));
        this.configurarTabla(0);
    }
    
    public void seleccionarCuenta(final String cuenta, final String descrip) {
        final int resultado = this.consultaSql.verificarCuentaContable(cuenta);
        if (resultado > 0) {
            JOptionPane.showMessageDialog(null, "La Cuenta '" + cuenta + " - " + descrip + " Tiene Sub-Cuentas", "ERROR!", 0);
            return;
        }
        this.txtCuenta.setText(cuenta);
        this.txtDescripcionCuenta.setText(descrip);
        this.txtCargo.requestFocus();
        this.txtCargo.setText("");
    }
    
    public void agregarDetalle() {
        if (this.txtCargo.getText().length() == 0) {
            this.txtCargo.setText("0.00");
        }
        if (this.txtAbono.getText().length() == 0) {
            this.txtAbono.setText("0.00");
        }
        this.bandera = 0;
        this.llenarTabla();
    }
    
    public void llenarTabla() {
        final Object[] object = { this.txtCuenta.getText(), this.txtDescripcionCuenta.getText(), this.txtDescripcion.getText(), this.txtCargo.getText(), this.txtAbono.getText() };
        this.modeloTblDetalle.addRow(object);
        final double cargo = Double.parseDouble(this.txtCargo.getText().toString());
        final double abono = Double.parseDouble(this.txtAbono.getText().toString());
        this.montoCargo += cargo;
        this.montoAbono += abono;
        this.txtCargoTotal.setText(Double.toString(this.montoCargo));
        this.txtAbonoTotal.setText(Double.toString(this.montoAbono));
        this.txtCuenta.requestFocus();
        this.txtCuenta.setEditable(true);
        this.txtCuenta.setText("");
        this.txtDescripcionCuenta.setEditable(true);
        this.txtDescripcionCuenta.setText("");
        this.txtDescripcion.setText("");
        this.txtCargo.setText("0.00");
        this.txtAbono.setText("0.00");
    }
    
    public void imprimir() {
        if (this.banderaImprimir != 1) {
            JOptionPane.showMessageDialog(null, "ALERTA! primero debe guardar la partida contable N°" + this.txtNumeroPartida.getText().toString());
            return;
        }
        final Imprimir imprimir = new Imprimir();
        final int resultado = this.consultaSql.verificarPartidaContableImprimir(Integer.parseInt(this.txtNumeroPartida.getText().toString()), Variables.usuario);
        if (resultado > 0) {
            imprimir.imprimirPartidaContable("rpt_partidaContable.jasper", Integer.parseInt(this.txtNumeroPartida.getText().toString()), Variables.usuario, Variables.nombreUsuario, Variables.nombreOficina, this.txtObservacion.getText().toString(), Double.parseDouble(this.txtCargoTotal.getText().toString()), Double.parseDouble(this.txtAbonoTotal.getText().toString()));
            return;
        }
        JOptionPane.showMessageDialog(null, "No se pudo generar partida para imprimir,vuelva a intentar", "ADVERTENCIA!", 1);
    }
    
    public void menuEmergente() {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JMenuItem mntmBorrarItem = new JMenuItem("Borrar", new ImageIcon(this.getClass().getResource("/images/general-19-icono-borrar.png")));
        mntmBorrarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmBorrarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final NuevaPartidaContable this$0 = NuevaPartidaContable.this;
                this$0.montoCargo -= Double.parseDouble((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 3));
                final NuevaPartidaContable this$2 = NuevaPartidaContable.this;
                this$2.montoAbono -= Double.parseDouble((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 4));
                NuevaPartidaContable.this.txtCargoTotal.setText(Double.toString(NuevaPartidaContable.this.montoCargo));
                NuevaPartidaContable.this.txtCargoTotal.setText(Double.toString(NuevaPartidaContable.this.montoAbono));
                final int fila = NuevaPartidaContable.this.tblDetalle.getSelectedRow();
                if (fila != -1) {
                    NuevaPartidaContable.this.modeloTblDetalle.removeRow(fila);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Debe seleccionar una fila", "ADVERTENCIA!", 2);
                }
            }
        });
        popupMenu.add(mntmBorrarItem);
        this.tblDetalle.setComponentPopupMenu(popupMenu);
        final JMenuItem mntmEditarItem = new JMenuItem("Editar", new ImageIcon(this.getClass().getResource("/images/general-20-icono-editar.png")));
        mntmEditarItem.setCursor(Cursor.getPredefinedCursor(12));
        mntmEditarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                NuevaPartidaContable.this.txtCuenta.setText((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 0));
                NuevaPartidaContable.this.txtDescripcion.setText((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 1));
                NuevaPartidaContable.this.txtCargo.setText((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 3));
                NuevaPartidaContable.this.txtAbono.setText((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 4));
                final NuevaPartidaContable this$0 = NuevaPartidaContable.this;
                this$0.montoCargo -= Double.parseDouble((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 3));
                final NuevaPartidaContable this$2 = NuevaPartidaContable.this;
                this$2.montoAbono -= Double.parseDouble((String)NuevaPartidaContable.this.tblDetalle.getValueAt(NuevaPartidaContable.this.tblDetalle.getSelectedRow(), 4));
                NuevaPartidaContable.this.txtCargoTotal.setText(Double.toString(NuevaPartidaContable.this.montoCargo));
                NuevaPartidaContable.this.txtAbonoTotal.setText(Double.toString(NuevaPartidaContable.this.montoAbono));
                final int fila = NuevaPartidaContable.this.tblDetalle.getSelectedRow();
                if (fila != -1) {
                    NuevaPartidaContable.this.modeloTblDetalle.removeRow(fila);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Debe seleccionar una fila", "ADVERTENCIA!", 2);
                }
                NuevaPartidaContable.this.txtCargo.requestFocus();
            }
        });
        popupMenu.add(mntmEditarItem);
        this.tblDetalle.setComponentPopupMenu(popupMenu);
    }
    
    public void guardar() {
        boolean resultado = false;
        if (Double.parseDouble(this.txtCargoTotal.getText().toString()) > Double.parseDouble(this.txtAbonoTotal.getText().toString()) || Double.parseDouble(this.txtCargoTotal.getText().toString()) < Double.parseDouble(this.txtAbonoTotal.getText().toString())) {
            JOptionPane.showMessageDialog(null, "Los montos Cargo y Abono no cuadran, favor de revisar", "ERROR!", 0);
            return;
        }
        if (this.banderaImprimir == 1) {
            JOptionPane.showMessageDialog(null, "partida N°" + this.txtNumeroPartida.getText().toString() + " ya fue guardada", "ALERTA!", 2);
            return;
        }
        final int partidaContable = this.consultaSql.obtenerSigIdPartidaContable();
        if (String.valueOf(partidaContable) == this.txtNumeroPartida.getText()) {
            resultado = this.contabilidad.partidaContable(partidaContable, this.tblDetalle, this.txtObservacion.getText(), this.txtFechaDocumento.getText(), this.txtFechaContable.getText(), "PCHK/", -1, "", this.txtNumeroPartida.getText());
        }
        else {
            this.txtNumeroPartida.setText(String.valueOf(partidaContable));
            JOptionPane.showMessageDialog(null, "La Partida N°" + this.txtNumeroPartida.getText().toString() + " ya fue utilizada por otro usuario, se cambio al Nº" + this.txtNumeroPartida.getText(), "ALERTA!", 2);
            resultado = this.contabilidad.partidaContable(partidaContable, this.tblDetalle, this.txtObservacion.getText(), this.txtFechaDocumento.getText(), this.txtFechaContable.getText(), "PCHK/", -1, "", this.txtNumeroPartida.getText());
        }
        if (resultado) {
            JOptionPane.showMessageDialog(null, "Partida N°" + this.txtNumeroPartida.getText().toString() + " guardada correctamente", "OK!", 1);
            this.banderaImprimir = 1;
            return;
        }
        JOptionPane.showMessageDialog(null, "Ingreso de partida erroneo -- " + Variables.error, "ERROR!", 0);
    }
}
