package profac.com.submodulo.contabilidad;

import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Imprimir;
import profac.com.herramientas.Variables;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;

public class ReportesContables extends JFrame{
    
	/**
	 * @author Frank Castro
	 */
	
	private static final long serialVersionUID = 1L;
	
    public Ajustes ajustes = new Ajustes();
    public Imprimir imprimir = new Imprimir();
    public consultasSQL_SERVER consultaSql = new consultasSQL_SERVER();
    
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JLabel chckBalanceGeneral;
    private JLabel lblIconoChck_01;
    private JLabel lblNombreChck_balanceGeneral;
    private JLabel lblOficina;
    private JComboBox<Object> cbxOficina;
    private JPanel jp_chckOficinas;
    private JLabel chckOficinas;
    private JLabel lblIconoChck_oficinas;
    private JLabel lblNombreChck_oficinas;
    private JLabel lblFechaInicio;
    private JTextField txtFechaInicio;
    private JLabel lblFechaFinal;
    private JTextField txtFechaFinal;
    private JLabel lblCuentaContable;
    private JPanel jp_chckCuentaContable;
    private JLabel chckCuentaContable;
    private JLabel lblIconoChck_cuentaContable;
    private JLabel lblNombreChck_cuentaContable;
    private JTextField txtCuentaContable;
    private JLabel lblFormatoDeDescarga;
    private JComboBox<Object> cbxFormatoReporte;
    private JLabel chckBalanceComprobacion;
    private JLabel lblIconoChck_02;
    private JLabel lblNombreChck_balanceComprobacion;
    private JLabel chckEstadoResultado;
    private JLabel lblIconoChck_03;
    private JLabel lblNombreChck_estadoSeleccion;
    private JLabel chckCambioPatrimonio;
    private JLabel lblIconoChck_04;
    private JLabel lblNombreChck_cambioPatrimonio;
    private JLabel chckFlujoEfectivo;
    private JLabel lblIconoChck_05;
    private JLabel lblNombreChck_flujoEfectivo;
    private JLabel chckDetalleAnticipos;
    private JLabel lblIconoChck_06;
    private JLabel lblNombreChck_auxiliar_3;
    private JLabel chckBalanceGeneral_3;
    private JLabel lblIconoChck_07;
    private JLabel lblNombreChck_balanceGeneral_3;
    private JLabel chckAuxiliar_4;
    private JLabel lblIconoChck_08;
    private JLabel lblNombreChck_auxiliar_4;
    private JLabel chckBalanceGeneral_4;
    private JLabel lblIconoChck_09;
    private JLabel lblNombreChck_balanceGeneral_4;
    private JLabel chckAuxiliar_5;
    private JLabel lblIconoChck_10;
    private JLabel lblNombreChck_auxiliar_5;
    private JLabel chckBalanceGeneral_5;
    private JLabel lblIconoChck_11;
    private JLabel lblNombreChck_balanceGeneral_5;
    private JLabel chckAuxiliar_6;
    private JLabel lblIconoChck_12;
    private JLabel lblNombreChck_auxiliar_6;
    private JLabel chckBalanceGeneral_6;
    private JLabel lblIconoChck_13;
    private JLabel lblNombreChck_balanceGeneral_6;
    private JLabel chckAuxiliar_7;
    private JLabel lblIconoChck_14;
    private JLabel lblNombreChck_auxiliar_7;
    private JLabel chckBalanceGeneral_7;
    private JLabel lblIconoChck_15;
    private JLabel lblNombreChck_balanceGeneral_7;
    private JLabel chckAuxiliar_8;
    private JLabel lblIconoChck_16;
    private JLabel lblNombreChck_auxiliar_8;
    private JLabel chckBalanceGeneral_8;
    private JLabel lblIconoChck_17;
    private JLabel lblNombreChck_balanceGeneral_8;
    private JLabel chckAuxiliar_9;
    private JLabel lblIconoChck_18;
    private JLabel lblNombreChck_auxiliar_9;
    private JLabel chckBalanceGeneral_9;
    private JLabel lblIconoChck_19;
    private JLabel lblNombreChck_balanceGeneral_9;
    private JLabel chckAuxiliar_10;
    private JLabel lblIconoChck_20;
    private JLabel lblNombreChck_auxiliar_10;
    private JLabel chckBalanceGeneral_10;
    private JLabel lblIconoChck_21;
    private JLabel lblNombreChck_balanceGeneral_10;
    private JLabel chckAuxiliar_11;
    private JLabel lblIconoChck_22;
    private JLabel lblNombreChck_auxiliar_11;
    private JLabel chckBalanceGeneral_11;
    private JLabel lblIconoChck_23;
    private JLabel lblNombreChck_balanceGeneral_11;
    private JLabel chckAuxiliar_12;
    private JLabel lblIconoChck_24;
    private JLabel lblNombreChck_auxiliar_12;
    private JLabel chckBalanceGeneral_12;
    private JLabel lblIconoChck_25;
    private JLabel lblNombreChck_balanceGeneral_12;
    private JComboBox<Object> cbxAnio;
    private JLabel lblIconoChck_00;
    
    public int bandera_reporte = 0, bandera_check_cuenta = 0;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    ReportesContables frame = new ReportesContables();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ReportesContables() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent arg0) {
                llenarCampos();
            }
        });
        setDefaultCloseOperation(3);
        setResizable(false);
        setUndecorated(true);
        setBounds(0, ajustes.calcularPuntoY(6.57), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(8.8));
        contentPane = new JPanel();
        contentPane.setBackground(Variables.color_tres);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, ajustes.ancho, ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        contentPane.add(jp_botones);
        
        jp_btnNuevaPartida = new JPanel();
        jp_btnNuevaPartida.setLayout(null);
        jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnNuevaPartida.setBackground(Variables.color_tres);
        jp_btnNuevaPartida.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnNuevaPartida);
        
        btnNuevaPartida = new JLabel("");
        btnNuevaPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnNuevaPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnNuevaPartida.add(btnNuevaPartida);
        
        lblIconoBtn_nuevaPartida = new JLabel("");
        lblIconoBtn_nuevaPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_nuevaPartida.setIcon(ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", lblIconoBtn_nuevaPartida));
        jp_btnNuevaPartida.add(lblIconoBtn_nuevaPartida);
        
        lblNombreBtn_nuevaPartida = new JLabel("Nueva");
        lblNombreBtn_nuevaPartida.setHorizontalAlignment(0);
        lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_nuevaPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnNuevaPartida.add(lblNombreBtn_nuevaPartida);
        
        jp_btnBuscarPartida = new JPanel();
        jp_btnBuscarPartida.setLayout(null);
        jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscarPartida.setBackground(Variables.color_tres);
        jp_btnBuscarPartida.setBounds(ajustes.calcularPuntoX(4.95), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnBuscarPartida);
        
        btnBuscarPartida = new JLabel("");
        btnBuscarPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnBuscarPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnBuscarPartida.add(btnBuscarPartida);
        
        lblIconoBtn_buscarPartida = new JLabel("");
        lblIconoBtn_buscarPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_buscarPartida.setIcon(ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", lblIconoBtn_buscarPartida));
        jp_btnBuscarPartida.add(lblIconoBtn_buscarPartida);
        
        lblNombreBtn_buscarPartida = new JLabel("Buscar");
        lblNombreBtn_buscarPartida.setHorizontalAlignment(0);
        lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_buscarPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnBuscarPartida.add(lblNombreBtn_buscarPartida);
        
        jp_btnGuardar = new JPanel();
        jp_btnGuardar.setLayout(null);
        jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnGuardar.setBackground(Variables.color_tres);
        jp_btnGuardar.setBounds(ajustes.calcularPuntoX(9.11), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnGuardar);
        
        (btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        btnGuardar.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        jp_btnGuardar.add(btnGuardar);
        
        lblIconoBtn_guardar = new JLabel("");
        lblIconoBtn_guardar.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_guardar.setIcon(ajustes.ajustarImagen("/botones_04_icono_guardar", lblIconoBtn_guardar, 50, 50, 50, 50));
        jp_btnGuardar.add(lblIconoBtn_guardar);
        
        lblNombreBtn_guardar = new JLabel("Guardar");
        lblNombreBtn_guardar.setHorizontalAlignment(0);
        lblNombreBtn_guardar.setForeground(Variables.color_uno);
        lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_guardar.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnGuardar.add(lblNombreBtn_guardar);
        
        jp_btnImprimir = new JPanel();
        jp_btnImprimir.setLayout(null);
        jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnImprimir.setBackground(Variables.color_tres);
        jp_btnImprimir.setBounds(ajustes.calcularPuntoX(13.28), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnImprimir);
        
        btnImprimir = new JLabel("");
        btnImprimir.setCursor(Cursor.getPredefinedCursor(12));
        btnImprimir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                imprimir();
            }
        });
        btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        jp_btnImprimir.add(btnImprimir);
        
        lblIconoBtn_imprimir = new JLabel("");
        lblIconoBtn_imprimir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_imprimir.setIcon(ajustes.ajustarImagen("/botones_05_icono_imprimir", lblIconoBtn_imprimir, 50, 50, 50, 50));
        jp_btnImprimir.add(lblIconoBtn_imprimir);
        
        lblNombreBtn_imprimir = new JLabel("Imprimir");
        lblNombreBtn_imprimir.setHorizontalAlignment(0);
        lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_imprimir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnImprimir.add(lblNombreBtn_imprimir);
        
        jp_btnSalir = new JPanel();
        jp_btnSalir.setBackground(Variables.color_tres);
        jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnSalir.setBounds(ajustes.calcularPuntoX(26.04), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnSalir);
        jp_btnSalir.setLayout(null);
        
        btnSalir = new JLabel("");
        btnSalir.setCursor(Cursor.getPredefinedCursor(12));
        btnSalir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
        });
        btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        jp_btnSalir.add(btnSalir);
        
        JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.43), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        jp_btnSalir.add(lblIconoBtn_salir);
        
        JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnSalir.add(lblNombreBtn_salir);
        
        JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, ajustes.calcularPuntoY(8.33), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(17.13));
        contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        
        lblnewlabel = new JLabel("Libros Contables");
        lblnewlabel.setForeground(Variables.color_uno);
        lblnewlabel.setHorizontalAlignment(0);
        lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, ajustes.calcularPuntoY(1.85)));
        lblnewlabel.setBounds(0, ajustes.calcularPuntoY(0.46), ajustes.ancho, ajustes.calcularPuntoY(2.31));
        jp_contenido.add(lblnewlabel);
        
        JSeparator separator = new JSeparator();
        separator.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(3.24), ajustes.ancho - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        
        JLabel lblTipoReporte = new JLabel("Reportes Contables:");
        lblTipoReporte.setHorizontalAlignment(0);
        lblTipoReporte.setForeground(Variables.color_uno);
        lblTipoReporte.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblTipoReporte.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(4.63), (ajustes.ancho - 25) / 10 * 5, ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblTipoReporte);
       
        JPanel jp_chckReporteAuxiliar = new JPanel();
        jp_chckReporteAuxiliar.setLayout(null);
        jp_chckReporteAuxiliar.setOpaque(false);
        jp_chckReporteAuxiliar.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(7.41), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckReporteAuxiliar);
        
        JLabel chckAuxiliar = new JLabel("");
        chckAuxiliar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
                bandera_reporte = 0;
                determinarReporte();
            }
        });
        chckAuxiliar.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckReporteAuxiliar.add(chckAuxiliar);
        
        lblIconoChck_00 = new JLabel("");
        lblIconoChck_00.setHorizontalAlignment(0);
        lblIconoChck_00.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_00.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_00));
        jp_chckReporteAuxiliar.add(lblIconoChck_00);
        
        JLabel lblNombreChck_auxiliar = new JLabel("Auxiliar de todas las cuentas");
        lblNombreChck_auxiliar.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckReporteAuxiliar.add(lblNombreChck_auxiliar);
        
        JPanel jp_chckBalanceGeneral = new JPanel();
        jp_chckBalanceGeneral.setLayout(null);
        jp_chckBalanceGeneral.setOpaque(false);
        jp_chckBalanceGeneral.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(7.41), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckBalanceGeneral);
        
        chckBalanceGeneral = new JLabel("");
        chckBalanceGeneral.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 1;
                determinarReporte();
            }
        });
        chckBalanceGeneral.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckBalanceGeneral.add(chckBalanceGeneral);
        
        lblIconoChck_01 = new JLabel("");
        lblIconoChck_01.setHorizontalAlignment(0);
        lblIconoChck_01.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_01.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_01));
        jp_chckBalanceGeneral.add(lblIconoChck_01);
        
        lblNombreChck_balanceGeneral = new JLabel("Balance General");
        lblNombreChck_balanceGeneral.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckBalanceGeneral.add(lblNombreChck_balanceGeneral);
        
        JPanel jp_chckBalanceComprobacion = new JPanel();
        jp_chckBalanceComprobacion.setLayout(null);
        jp_chckBalanceComprobacion.setOpaque(false);
        jp_chckBalanceComprobacion.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(11.57), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckBalanceComprobacion);
        
        chckBalanceComprobacion = new JLabel("");
        chckBalanceComprobacion.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceComprobacion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 2;
                determinarReporte();
            }
        });
        chckBalanceComprobacion.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckBalanceComprobacion.add(chckBalanceComprobacion);
        
        lblIconoChck_02 = new JLabel("");
        lblIconoChck_02.setHorizontalAlignment(0);
        lblIconoChck_02.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_02.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckBalanceComprobacion.add(lblIconoChck_02);
        
        lblNombreChck_balanceComprobacion = new JLabel("Balance de Comprobaci\u00f3n:");
        lblNombreChck_balanceComprobacion.setForeground(Variables.color_uno);
        lblNombreChck_balanceComprobacion.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceComprobacion.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckBalanceComprobacion.add(lblNombreChck_balanceComprobacion);
        
        JPanel jp_chckEstadoResultado = new JPanel();
        jp_chckEstadoResultado.setLayout(null);
        jp_chckEstadoResultado.setOpaque(false);
        jp_chckEstadoResultado.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(11.57), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckEstadoResultado);
        
        chckEstadoResultado = new JLabel("");
        chckEstadoResultado.setCursor(Cursor.getPredefinedCursor(12));
        chckEstadoResultado.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 3;
                determinarReporte();
            }
        });
        chckEstadoResultado.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckEstadoResultado.add(chckEstadoResultado);
        
        lblIconoChck_03 = new JLabel("");
        lblIconoChck_03.setHorizontalAlignment(0);
        lblIconoChck_03.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_03.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckEstadoResultado.add(lblIconoChck_03);
        
        lblNombreChck_estadoSeleccion = new JLabel("Estado de Resultados");
        lblNombreChck_estadoSeleccion.setForeground(Variables.color_uno);
        lblNombreChck_estadoSeleccion.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_estadoSeleccion.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckEstadoResultado.add(lblNombreChck_estadoSeleccion);
        
        JPanel jp_chckCambioPatrimonio = new JPanel();
        jp_chckCambioPatrimonio.setLayout(null);
        jp_chckCambioPatrimonio.setOpaque(false);
        jp_chckCambioPatrimonio.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(15.74), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckCambioPatrimonio);
        
        chckCambioPatrimonio = new JLabel("");
        chckCambioPatrimonio.setCursor(Cursor.getPredefinedCursor(12));
        chckCambioPatrimonio.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 4;
                determinarReporte();
            }
        });
        chckCambioPatrimonio.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckCambioPatrimonio.add(chckCambioPatrimonio);
        
        lblIconoChck_04 = new JLabel("");
        lblIconoChck_04.setHorizontalAlignment(0);
        lblIconoChck_04.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_04.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckCambioPatrimonio.add(lblIconoChck_04);
        
        lblNombreChck_cambioPatrimonio = new JLabel("Cambio de Patrimonio");
        lblNombreChck_cambioPatrimonio.setForeground(Variables.color_uno);
        lblNombreChck_cambioPatrimonio.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_cambioPatrimonio.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckCambioPatrimonio.add(lblNombreChck_cambioPatrimonio);
        
        JPanel jp_chckFlujoEfectivo = new JPanel();
        jp_chckFlujoEfectivo.setLayout(null);
        jp_chckFlujoEfectivo.setOpaque(false);
        jp_chckFlujoEfectivo.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(15.74), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckFlujoEfectivo);
        
        chckFlujoEfectivo = new JLabel("");
        chckFlujoEfectivo.setCursor(Cursor.getPredefinedCursor(12));
        chckFlujoEfectivo.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 5;
                determinarReporte();
            }
        });
        chckFlujoEfectivo.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckFlujoEfectivo.add(chckFlujoEfectivo);
        
        lblIconoChck_05 = new JLabel("");
        lblIconoChck_05.setHorizontalAlignment(0);
        lblIconoChck_05.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_05.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckFlujoEfectivo.add(lblIconoChck_05);
        
        lblNombreChck_flujoEfectivo = new JLabel("Flujo de Efectivo");
        lblNombreChck_flujoEfectivo.setForeground(Variables.color_uno);
        lblNombreChck_flujoEfectivo.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_flujoEfectivo.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckFlujoEfectivo.add(lblNombreChck_flujoEfectivo);
        
        JPanel jp_chckDetalleAnticipos = new JPanel();
        jp_chckDetalleAnticipos.setLayout(null);
        jp_chckDetalleAnticipos.setOpaque(false);
        jp_chckDetalleAnticipos.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(19.91), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckDetalleAnticipos);
        
        chckDetalleAnticipos = new JLabel("");
        chckDetalleAnticipos.setCursor(Cursor.getPredefinedCursor(12));
        chckDetalleAnticipos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 6;
                determinarReporte();
            }
        });
        chckDetalleAnticipos.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckDetalleAnticipos.add(chckDetalleAnticipos);
        
        lblIconoChck_06 = new JLabel("");
        lblIconoChck_06.setHorizontalAlignment(0);
        lblIconoChck_06.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_06.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckDetalleAnticipos.add(lblIconoChck_06);
        
        lblNombreChck_auxiliar_3 = new JLabel("Detalle de anticipos de clientes");
        lblNombreChck_auxiliar_3.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_3.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_3.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckDetalleAnticipos.add(lblNombreChck_auxiliar_3);
        
        JPanel jp_chckMovimientosDiarios = new JPanel();
        jp_chckMovimientosDiarios.setLayout(null);
        jp_chckMovimientosDiarios.setOpaque(false);
        jp_chckMovimientosDiarios.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(19.91), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckMovimientosDiarios);
        
        chckBalanceGeneral_3 = new JLabel("");
        chckBalanceGeneral_3.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 7;
                determinarReporte();
            }
        });
        chckBalanceGeneral_3.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckMovimientosDiarios.add(chckBalanceGeneral_3);
        
        lblIconoChck_07 = new JLabel("");
        lblIconoChck_07.setHorizontalAlignment(0);
        lblIconoChck_07.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_07.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckMovimientosDiarios.add(lblIconoChck_07);
        
        lblNombreChck_balanceGeneral_3 = new JLabel("IMD (informe de movimientos diarios)");
        lblNombreChck_balanceGeneral_3.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_3.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_3.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckMovimientosDiarios.add(lblNombreChck_balanceGeneral_3);
        
        JPanel jp_chckCuentasPagar = new JPanel();
        jp_chckCuentasPagar.setLayout(null);
        jp_chckCuentasPagar.setOpaque(false);
        jp_chckCuentasPagar.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(24.07), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckCuentasPagar);
        
        chckAuxiliar_4 = new JLabel("");
        chckAuxiliar_4.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 8;
                determinarReporte();
            }
        });
        chckAuxiliar_4.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckCuentasPagar.add(chckAuxiliar_4);
        
        lblIconoChck_08 = new JLabel("");
        lblIconoChck_08.setHorizontalAlignment(0);
        lblIconoChck_08.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_08.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckCuentasPagar.add(lblIconoChck_08);
        
        lblNombreChck_auxiliar_4 = new JLabel("Detalle de las cuentas por pagar");
        lblNombreChck_auxiliar_4.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_4.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_4.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckCuentasPagar.add(lblNombreChck_auxiliar_4);
        
        JPanel jp_chckCuentasCobrar = new JPanel();
        jp_chckCuentasCobrar.setLayout(null);
        jp_chckCuentasCobrar.setOpaque(false);
        jp_chckCuentasCobrar.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(24.07), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckCuentasCobrar);
        
        chckBalanceGeneral_4 = new JLabel("");
        chckBalanceGeneral_4.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 9;
                determinarReporte();
            }
        });
        chckBalanceGeneral_4.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckCuentasCobrar.add(chckBalanceGeneral_4);
        
        lblIconoChck_09 = new JLabel("");
        lblIconoChck_09.setHorizontalAlignment(0);
        lblIconoChck_09.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_09.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckCuentasCobrar.add(lblIconoChck_09);
        
        lblNombreChck_balanceGeneral_4 = new JLabel("Detalle de las cuentas por cobrar");
        lblNombreChck_balanceGeneral_4.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_4.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_4.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckCuentasCobrar.add(lblNombreChck_balanceGeneral_4);
        
        JPanel jp_chckDiarioMayor = new JPanel();
        jp_chckDiarioMayor.setLayout(null);
        jp_chckDiarioMayor.setOpaque(false);
        jp_chckDiarioMayor.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(28.24), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckDiarioMayor);
        
        chckAuxiliar_5 = new JLabel("");
        chckAuxiliar_5.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 10;
                determinarReporte();
            }
        });
        chckAuxiliar_5.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckDiarioMayor.add(chckAuxiliar_5);
        
        lblIconoChck_10 = new JLabel("");
        lblIconoChck_10.setHorizontalAlignment(0);
        lblIconoChck_10.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_10.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckDiarioMayor.add(lblIconoChck_10);
        
        lblNombreChck_auxiliar_5 = new JLabel("Diario mayor");
        lblNombreChck_auxiliar_5.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_5.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_5.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckDiarioMayor.add(lblNombreChck_auxiliar_5);
        
        JPanel jp_chckConciliacionBancaria = new JPanel();
        jp_chckConciliacionBancaria.setLayout(null);
        jp_chckConciliacionBancaria.setOpaque(false);
        jp_chckConciliacionBancaria.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(28.24), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckConciliacionBancaria);
        
        chckBalanceGeneral_5 = new JLabel("");
        chckBalanceGeneral_5.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 11;
                determinarReporte();
            }
        });
        chckBalanceGeneral_5.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckConciliacionBancaria.add(chckBalanceGeneral_5);
        
        lblIconoChck_11 = new JLabel("");
        lblIconoChck_11.setHorizontalAlignment(0);
        lblIconoChck_11.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_11.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckConciliacionBancaria.add(lblIconoChck_11);
        
        lblNombreChck_balanceGeneral_5 = new JLabel("Conciliaciones bancarias");
        lblNombreChck_balanceGeneral_5.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_5.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_5.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckConciliacionBancaria.add(lblNombreChck_balanceGeneral_5);
        
        JPanel jp_chckingresoDiario = new JPanel();
        jp_chckingresoDiario.setLayout(null);
        jp_chckingresoDiario.setOpaque(false);
        jp_chckingresoDiario.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(32.41), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckingresoDiario);
        
        chckAuxiliar_6 = new JLabel("");
        chckAuxiliar_6.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 12;
                determinarReporte();
            }
        });
        chckAuxiliar_6.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckingresoDiario.add(chckAuxiliar_6);
        
        lblIconoChck_12 = new JLabel("");
        lblIconoChck_12.setHorizontalAlignment(0);
        lblIconoChck_12.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_12.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckingresoDiario.add(lblIconoChck_12);
        
        lblNombreChck_auxiliar_6 = new JLabel("Informe de ingresos diarios");
        lblNombreChck_auxiliar_6.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_6.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_6.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckingresoDiario.add(lblNombreChck_auxiliar_6);
        
        JPanel jp_chckArqueoCaja = new JPanel();
        jp_chckArqueoCaja.setLayout(null);
        jp_chckArqueoCaja.setOpaque(false);
        jp_chckArqueoCaja.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(32.41), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckArqueoCaja);
        
        chckBalanceGeneral_6 = new JLabel("");
        chckBalanceGeneral_6.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 13;
                determinarReporte();
            }
        });
        chckBalanceGeneral_6.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckArqueoCaja.add(chckBalanceGeneral_6);
        
        lblIconoChck_13 = new JLabel("");
        lblIconoChck_13.setHorizontalAlignment(0);
        lblIconoChck_13.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_13.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckArqueoCaja.add(lblIconoChck_13);
        
        lblNombreChck_balanceGeneral_6 = new JLabel("Reporte de arqueo a caja diario");
        lblNombreChck_balanceGeneral_6.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_6.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_6.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckArqueoCaja.add(lblNombreChck_balanceGeneral_6);
        
        JPanel jp_chckEjecucionPresupuestaria = new JPanel();
        jp_chckEjecucionPresupuestaria.setLayout(null);
        jp_chckEjecucionPresupuestaria.setOpaque(false);
        jp_chckEjecucionPresupuestaria.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(36.57), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckEjecucionPresupuestaria);
        
        chckAuxiliar_7 = new JLabel("");
        chckAuxiliar_7.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 14;
                determinarReporte();
            }
        });
        chckAuxiliar_7.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckEjecucionPresupuestaria.add(chckAuxiliar_7);
        
        lblIconoChck_14 = new JLabel("");
        lblIconoChck_14.setHorizontalAlignment(0);
        lblIconoChck_14.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_14.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckEjecucionPresupuestaria.add(lblIconoChck_14);
        
        lblNombreChck_auxiliar_7 = new JLabel("Ejecuciones presupuestarias");
        lblNombreChck_auxiliar_7.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_7.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_7.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckEjecucionPresupuestaria.add(lblNombreChck_auxiliar_7);
        
        JPanel jp_chckPresupuesto = new JPanel();
        jp_chckPresupuesto.setLayout(null);
        jp_chckPresupuesto.setOpaque(false);
        jp_chckPresupuesto.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(36.57), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckPresupuesto);
        
        chckBalanceGeneral_7 = new JLabel("");
        chckBalanceGeneral_7.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 15;
                determinarReporte();
            }
        });
        chckBalanceGeneral_7.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckPresupuesto.add(chckBalanceGeneral_7);
        
        lblIconoChck_15 = new JLabel("");
        lblIconoChck_15.setHorizontalAlignment(0);
        lblIconoChck_15.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_15.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckPresupuesto.add(lblIconoChck_15);
        
        lblNombreChck_balanceGeneral_7 = new JLabel("Presupuestos");
        lblNombreChck_balanceGeneral_7.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_7.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_7.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckPresupuesto.add(lblNombreChck_balanceGeneral_7);
        
        JLabel lblReportesFiscales = new JLabel("Reportes Fiscales:");
        lblReportesFiscales.setHorizontalAlignment(0);
        lblReportesFiscales.setForeground(Variables.color_uno);
        lblReportesFiscales.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblReportesFiscales.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(42.13), (ajustes.ancho - 25) / 10 * 5, ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblReportesFiscales);
        
        JPanel jp_chckInforma989 = new JPanel();
        jp_chckInforma989.setLayout(null);
        jp_chckInforma989.setOpaque(false);
        jp_chckInforma989.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(44.91), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckInforma989);
        
        chckAuxiliar_8 = new JLabel("");
        chckAuxiliar_8.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_8.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 16;
                determinarReporte();
            }
        });
        chckAuxiliar_8.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckInforma989.add(chckAuxiliar_8);
        
        lblIconoChck_16 = new JLabel("");
        lblIconoChck_16.setHorizontalAlignment(0);
        lblIconoChck_16.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_16.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckInforma989.add(lblIconoChck_16);
        
        lblNombreChck_auxiliar_8 = new JLabel("Informe 989");
        lblNombreChck_auxiliar_8.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_8.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_8.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckInforma989.add(lblNombreChck_auxiliar_8);
        
        JPanel jp_chckF910Renta = new JPanel();
        jp_chckF910Renta.setLayout(null);
        jp_chckF910Renta.setOpaque(false);
        jp_chckF910Renta.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(44.91), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckF910Renta);
        
        chckBalanceGeneral_8 = new JLabel("");
        chckBalanceGeneral_8.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_8.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 17;
                determinarReporte();
            }
        });
        chckBalanceGeneral_8.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckF910Renta.add(chckBalanceGeneral_8);
        
        lblIconoChck_17 = new JLabel("");
        lblIconoChck_17.setHorizontalAlignment(0);
        lblIconoChck_17.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_17.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckF910Renta.add(lblIconoChck_17);
        
        lblNombreChck_balanceGeneral_8 = new JLabel("F910 informe de retenci\u00f3n renta");
        lblNombreChck_balanceGeneral_8.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_8.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_8.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckF910Renta.add(lblNombreChck_balanceGeneral_8);
        
        JPanel jp_chckIvaCompras = new JPanel();
        jp_chckIvaCompras.setLayout(null);
        jp_chckIvaCompras.setOpaque(false);
        jp_chckIvaCompras.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(49.07), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckIvaCompras);
        
        chckAuxiliar_9 = new JLabel("");
        chckAuxiliar_9.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_9.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 18;
                determinarReporte();
            }
        });
        chckAuxiliar_9.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckIvaCompras.add(chckAuxiliar_9);
        
        lblIconoChck_18 = new JLabel("");
        lblIconoChck_18.setHorizontalAlignment(0);
        lblIconoChck_18.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_18.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckIvaCompras.add(lblIconoChck_18);
        
        lblNombreChck_auxiliar_9 = new JLabel("Libros de iva compras ventas");
        lblNombreChck_auxiliar_9.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_9.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_9.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckIvaCompras.add(lblNombreChck_auxiliar_9);
        
        JPanel jp_chckproporcianalidadIva = new JPanel();
        jp_chckproporcianalidadIva.setLayout(null);
        jp_chckproporcianalidadIva.setOpaque(false);
        jp_chckproporcianalidadIva.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(49.07), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckproporcianalidadIva);
        
        chckBalanceGeneral_9 = new JLabel("");
        chckBalanceGeneral_9.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_9.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 19;
                determinarReporte();
            }
        });
        chckBalanceGeneral_9.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckproporcianalidadIva.add(chckBalanceGeneral_9);
        
        lblIconoChck_19 = new JLabel("");
        lblIconoChck_19.setHorizontalAlignment(0);
        lblIconoChck_19.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_19.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckproporcianalidadIva.add(lblIconoChck_19);
        
        lblNombreChck_balanceGeneral_9 = new JLabel("Cuadro de proporcionalidad iva");
        lblNombreChck_balanceGeneral_9.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_9.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_9.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckproporcianalidadIva.add(lblNombreChck_balanceGeneral_9);
        
        JPanel jp_chckProveedoresExlusivos = new JPanel();
        jp_chckProveedoresExlusivos.setLayout(null);
        jp_chckProveedoresExlusivos.setOpaque(false);
        jp_chckProveedoresExlusivos.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(53.24), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckProveedoresExlusivos);
        
        chckAuxiliar_10 = new JLabel("");
        chckAuxiliar_10.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_10.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 20;
                determinarReporte();
            }
        });
        chckAuxiliar_10.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckProveedoresExlusivos.add(chckAuxiliar_10);
        
        lblIconoChck_20 = new JLabel("");
        lblIconoChck_20.setHorizontalAlignment(0);
        lblIconoChck_20.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_20.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckProveedoresExlusivos.add(lblIconoChck_20);
        
        lblNombreChck_auxiliar_10 = new JLabel("Proveedores excluidos de iva");
        lblNombreChck_auxiliar_10.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_10.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_10.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckProveedoresExlusivos.add(lblNombreChck_auxiliar_10);
        
        JPanel jp_chckResumenVentas = new JPanel();
        jp_chckResumenVentas.setLayout(null);
        jp_chckResumenVentas.setOpaque(false);
        jp_chckResumenVentas.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(53.24), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckResumenVentas);
        
        chckBalanceGeneral_10 = new JLabel("");
        chckBalanceGeneral_10.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_10.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 21;
                determinarReporte();
            }
        });
        chckBalanceGeneral_10.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckResumenVentas.add(chckBalanceGeneral_10);
        
        lblIconoChck_21 = new JLabel("");
        lblIconoChck_21.setHorizontalAlignment(0);
        lblIconoChck_21.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_21.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckResumenVentas.add(lblIconoChck_21);
       
        lblNombreChck_balanceGeneral_10 = new JLabel("Resumen ventas");
        lblNombreChck_balanceGeneral_10.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_10.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_10.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckResumenVentas.add(lblNombreChck_balanceGeneral_10);
        
        JPanel jp_chckResumenCompras = new JPanel();
        jp_chckResumenCompras.setLayout(null);
        jp_chckResumenCompras.setOpaque(false);
        jp_chckResumenCompras.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(57.41), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckResumenCompras);
        
        chckAuxiliar_11 = new JLabel("");
        chckAuxiliar_11.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_11.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 22;
                determinarReporte();
            }
        });
        chckAuxiliar_11.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckResumenCompras.add(chckAuxiliar_11);
        
        lblIconoChck_22 = new JLabel("");
        lblIconoChck_22.setHorizontalAlignment(0);
        lblIconoChck_22.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_22.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckResumenCompras.add(lblIconoChck_22);
        
        lblNombreChck_auxiliar_11 = new JLabel("Resumen de compras");
        lblNombreChck_auxiliar_11.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_11.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_11.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckResumenCompras.add(lblNombreChck_auxiliar_11);
        
        JPanel jp_chckAplicacionFondos = new JPanel();
        jp_chckAplicacionFondos.setLayout(null);
        jp_chckAplicacionFondos.setOpaque(false);
        jp_chckAplicacionFondos.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(57.41), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckAplicacionFondos);
        
        chckBalanceGeneral_11 = new JLabel("");
        chckBalanceGeneral_11.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_11.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 23;
                determinarReporte();
            }
        });
        chckBalanceGeneral_11.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckAplicacionFondos.add(chckBalanceGeneral_11);
        
        lblIconoChck_23 = new JLabel("");
        lblIconoChck_23.setHorizontalAlignment(0);
        lblIconoChck_23.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_23.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckAplicacionFondos.add(lblIconoChck_23);
        
        lblNombreChck_balanceGeneral_11 = new JLabel("Origen y aplicaci�n de fondos");
        lblNombreChck_balanceGeneral_11.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_11.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_11.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckAplicacionFondos.add(lblNombreChck_balanceGeneral_11);
        
        JPanel jp_chckImpuestosRenta = new JPanel();
        jp_chckImpuestosRenta.setLayout(null);
        jp_chckImpuestosRenta.setOpaque(false);
        jp_chckImpuestosRenta.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(61.57), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckImpuestosRenta);
        
        chckAuxiliar_12 = new JLabel("");
        chckAuxiliar_12.setCursor(Cursor.getPredefinedCursor(12));
        chckAuxiliar_12.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 24;
                determinarReporte();
            }
        });
        chckAuxiliar_12.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckImpuestosRenta.add(chckAuxiliar_12);
        
        lblIconoChck_24 = new JLabel("");
        lblIconoChck_24.setHorizontalAlignment(0);
        lblIconoChck_24.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_24.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckImpuestosRenta.add(lblIconoChck_24);
        
        lblNombreChck_auxiliar_12 = new JLabel("Impuesto sobre la renta ");
        lblNombreChck_auxiliar_12.setForeground(Variables.color_uno);
        lblNombreChck_auxiliar_12.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_auxiliar_12.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckImpuestosRenta.add(lblNombreChck_auxiliar_12);
        
        JPanel jp_chckIngresosDonacion = new JPanel();
        jp_chckIngresosDonacion.setLayout(null);
        jp_chckIngresosDonacion.setOpaque(false);
        jp_chckIngresosDonacion.setBounds((int)((ajustes.ancho - 25) / 10 * 2.5) + ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(61.57), (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckIngresosDonacion);
        
        chckBalanceGeneral_12 = new JLabel("");
        chckBalanceGeneral_12.setCursor(Cursor.getPredefinedCursor(12));
        chckBalanceGeneral_12.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                bandera_reporte = 25;
                determinarReporte();
            }
        });
        chckBalanceGeneral_12.setBounds(0, 0, (int)((ajustes.ancho - 25) / 10 * 2.5), ajustes.calcularPuntoY(3.7));
        jp_chckIngresosDonacion.add(chckBalanceGeneral_12);
        
        lblIconoChck_25 = new JLabel("");
        lblIconoChck_25.setHorizontalAlignment(0);
        lblIconoChck_25.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_25.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        jp_chckIngresosDonacion.add(lblIconoChck_25);
        
        lblNombreChck_balanceGeneral_12 = new JLabel("Informe de ingresos por donaciones");
        lblNombreChck_balanceGeneral_12.setForeground(Variables.color_uno);
        lblNombreChck_balanceGeneral_12.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_balanceGeneral_12.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckIngresosDonacion.add(lblNombreChck_balanceGeneral_12);
        
        JLabel lblAnio = new JLabel("A\u00f1o:");
        lblAnio.setHorizontalAlignment(0);
        lblAnio.setForeground(Variables.color_uno);
        lblAnio.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblAnio.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63), (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblAnio);
        
        cbxAnio = new JComboBox<Object>();
        cbxAnio.setForeground(Variables.color_dos);
        cbxAnio.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(0, ajustes.calcularPuntoY(3.7))));
        cbxAnio.setBackground(Variables.color_uno);
        cbxAnio.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(7.41), (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(3.7));
        ((JLabel)cbxAnio.getRenderer()).setHorizontalAlignment(0);
        jp_contenido.add(cbxAnio);
        
        lblOficina = new JLabel("Oficina:");
        lblOficina.setHorizontalAlignment(0);
        lblOficina.setForeground(Variables.color_uno);
        lblOficina.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblOficina.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(12.04), (ajustes.ancho - 25) / 10 * 5 - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblOficina);
        
        cbxOficina = new JComboBox<Object>();
        cbxOficina.setForeground(Variables.color_dos);
        cbxOficina.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(0, ajustes.calcularPuntoY(2.78))));
        cbxOficina.setBackground(Variables.color_uno);
        cbxOficina.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(14.81), (ajustes.ancho - 25) / 10 * 4 - ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(2.78));
        jp_contenido.add(cbxOficina);
        
        jp_chckOficinas = new JPanel();
        jp_chckOficinas.setLayout(null);
        jp_chckOficinas.setOpaque(false);
        jp_chckOficinas.setBounds((ajustes.ancho - 25) / 10 * 9, ajustes.calcularPuntoY(14.35), (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckOficinas);
        
        chckOficinas = new JLabel("");
        chckOficinas.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        chckOficinas.setBounds(0, 0, (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(3.7));
        jp_chckOficinas.add(chckOficinas);
        
        lblIconoChck_oficinas = new JLabel("");
        lblIconoChck_oficinas.setHorizontalAlignment(0);
        lblIconoChck_oficinas.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_oficinas.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_oficinas));
        jp_chckOficinas.add(lblIconoChck_oficinas);
        
        lblNombreChck_oficinas = new JLabel("Todas");
        lblNombreChck_oficinas.setForeground(Variables.color_uno);
        lblNombreChck_oficinas.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_oficinas.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (ajustes.ancho - 25) / 10 - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckOficinas.add(lblNombreChck_oficinas);
        
        lblFechaInicio = new JLabel("Fecha Inicio:");
        lblFechaInicio.setHorizontalAlignment(0);
        lblFechaInicio.setForeground(Variables.color_uno);
        lblFechaInicio.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblFechaInicio.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(19.44), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoY(3.13), ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblFechaInicio);
        
        txtFechaInicio = new JTextField();
        txtFechaInicio.setHorizontalAlignment(0);
        txtFechaInicio.setForeground(Variables.color_dos);
        txtFechaInicio.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(0, ajustes.calcularPuntoY(2.78))));
        txtFechaInicio.setEditable(false);
        txtFechaInicio.setColumns(10);
        txtFechaInicio.setBackground(Variables.color_uno);
        txtFechaInicio.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(22.22), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoY(3.13), ajustes.calcularPuntoY(2.78));
        jp_contenido.add(txtFechaInicio);
        
        lblFechaFinal= new JLabel("Fecha Final:");
        lblFechaFinal.setHorizontalAlignment(0);
        lblFechaFinal.setForeground(Variables.color_uno);
        lblFechaFinal.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblFechaFinal.setBounds((int)((ajustes.ancho - 25) / 10 * 7.5 + ajustes.calcularPuntoX(1.82)), ajustes.calcularPuntoY(19.44), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoY(3.13), ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblFechaFinal);
        
        txtFechaFinal= new JTextField();
        txtFechaFinal.setHorizontalAlignment(0);
        txtFechaFinal.setForeground(Variables.color_dos);
        txtFechaFinal.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(0, ajustes.calcularPuntoY(2.78))));
        txtFechaFinal.setEditable(false);
        txtFechaFinal.setColumns(10);
        txtFechaFinal.setBackground(Variables.color_uno);
        txtFechaFinal.setBounds((int)((ajustes.ancho - 25) / 10 * 7.5 + ajustes.calcularPuntoX(1.82)), ajustes.calcularPuntoY(22.22), (int)((ajustes.ancho - 25) / 10 * 2.5) - ajustes.calcularPuntoY(3.13), ajustes.calcularPuntoY(2.78));
        jp_contenido.add(txtFechaFinal);
        
        lblCuentaContable = new JLabel("Cuenta Contable:");
        lblCuentaContable.setHorizontalAlignment(0);
        lblCuentaContable.setForeground(Variables.color_uno);
        lblCuentaContable.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblCuentaContable.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(26.85), (ajustes.ancho - 25) / 10 * 5 - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblCuentaContable);
        
        txtCuentaContable = new JTextField();
        txtCuentaContable.setHorizontalAlignment(0);
        txtCuentaContable.setForeground(Variables.color_dos);
        txtCuentaContable.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(0, ajustes.calcularPuntoY(2.78))));
        txtCuentaContable.setEditable(false);
        txtCuentaContable.setColumns(10);
        txtCuentaContable.setBackground(Variables.color_uno);
        txtCuentaContable.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(29.63), (ajustes.ancho - 25) / 10 * 4 - ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(2.78));
        jp_contenido.add(txtCuentaContable);
        
        jp_chckCuentaContable = new JPanel();
        jp_chckCuentaContable.setLayout(null);
        jp_chckCuentaContable.setOpaque(false);
        jp_chckCuentaContable.setBounds((ajustes.ancho - 25) / 10 * 9, ajustes.calcularPuntoY(29.17), (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckCuentaContable);
        
        chckCuentaContable = new JLabel("");
        chckCuentaContable.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        		lblIconoChck_cuentaContable.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_cuentaContable));
        		bandera_check_cuenta = 1;
        		txtCuentaContable.setEditable(false);
        	}
        });
        chckCuentaContable.setCursor(Cursor.getPredefinedCursor(12));
        chckCuentaContable.setBounds(0, 0, (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(3.7));
        jp_chckCuentaContable.add(chckCuentaContable);
        
        lblIconoChck_cuentaContable = new JLabel("");
        lblIconoChck_cuentaContable.setHorizontalAlignment(0);
        lblIconoChck_cuentaContable.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(2.78));
        lblIconoChck_cuentaContable.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_cuentaContable));
        jp_chckCuentaContable.add(lblIconoChck_cuentaContable);
        
        lblNombreChck_cuentaContable = new JLabel("Filtrar");
        lblNombreChck_cuentaContable.setForeground(Variables.color_uno);
        lblNombreChck_cuentaContable.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombreChck_cuentaContable.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.46), (ajustes.ancho - 25) / 10 - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(2.78));
        jp_chckCuentaContable.add(lblNombreChck_cuentaContable);
        
        lblFormatoDeDescarga = new JLabel("Formato de Descarga:");
        lblFormatoDeDescarga.setHorizontalAlignment(0);
        lblFormatoDeDescarga.setForeground(Variables.color_uno);
        lblFormatoDeDescarga.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblFormatoDeDescarga.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(34.26), (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblFormatoDeDescarga);
        
        cbxFormatoReporte = new JComboBox<Object>();
        cbxFormatoReporte.setModel(new DefaultComboBoxModel<Object>(new String[] { "PDF", "EXCEL" }));
        cbxFormatoReporte.setForeground(Variables.color_dos);
        cbxFormatoReporte.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(0, ajustes.calcularPuntoY(3.7))));
        cbxFormatoReporte.setBackground(Variables.color_uno);
        cbxFormatoReporte.setBounds((ajustes.ancho - 25) / 10 * 5 + ajustes.calcularPuntoX(2.6), 401, (ajustes.ancho - 25) / 10, ajustes.calcularPuntoY(3.7));
        ((JLabel)cbxFormatoReporte.getRenderer()).setHorizontalAlignment(0);
        jp_contenido.add(cbxFormatoReporte);
    }
    
    @Override
    public void dispose() {
        getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void llenarCampos() {
        cbxAnio.setModel(consultaSql.getDataComboBox("select anio from respaldos where oficina_idoficina = '" + Variables.idOficina + "'"));
        cbxAnio.setSelectedItem(Variables.fechaSistema.substring(6));
        cbxOficina.setModel(consultaSql.getDataComboBox("select CONCAT(idoficina, ' - ', nombre) from oficina"));
        cbxOficina.setSelectedItem(String.valueOf(Variables.idOficina) + " - " + Variables.nombreOficina);
        txtFechaFinal.setText(Variables.fechaActual);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(ParseFecha(Variables.fechaActual));
        calendar.add(2, -1);
        Date fechaInicio = new Date();
        fechaInicio = calendar.getTime();
        txtFechaInicio.setText(fechaInicio.toInstant().atOffset(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
    }
    
    public static Date ParseFecha(String fecha) {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaDate = null;
        try {
            fechaDate = formato.parse(fecha);
        }
        catch (ParseException ex) {
            System.out.println(ex);
        }
        return fechaDate;
    }
    
    public void determinarReporte() {
        desactivarReporte();
        if (bandera_reporte == 0) {
            lblIconoChck_00.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_00));
        }
        if (bandera_reporte == 1) {
            lblIconoChck_01.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_01));
        }
        if (bandera_reporte == 2) {
            lblIconoChck_02.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_02));
        }
        if (bandera_reporte == 3) {
            lblIconoChck_03.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_03));
        }
        if (bandera_reporte == 4) {
            lblIconoChck_04.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_04));
        }
        if (bandera_reporte == 5) {
            lblIconoChck_05.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_05));
        }
        if (bandera_reporte == 6) {
            lblIconoChck_06.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_06));
        }
        if (bandera_reporte == 7) {
            lblIconoChck_07.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_07));
        }
        if (bandera_reporte == 8) {
            lblIconoChck_08.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_08));
        }
        if (bandera_reporte == 9) {
            lblIconoChck_09.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_09));
        }
        if (bandera_reporte == 10) {
            lblIconoChck_10.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_10));
        }
        if (bandera_reporte == 11) {
            lblIconoChck_11.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_11));
        }
        if (bandera_reporte == 12) {
            lblIconoChck_12.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_12));
        }
        if (bandera_reporte == 13) {
            lblIconoChck_13.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_13));
        }
        if (bandera_reporte == 14) {
            lblIconoChck_14.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_14));
        }
        if (bandera_reporte == 15) {
            lblIconoChck_15.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_15));
        }
        if (bandera_reporte == 16) {
            lblIconoChck_16.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_16));
        }
        if (bandera_reporte == 17) {
            lblIconoChck_17.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_17));
        }
        if (bandera_reporte == 18) {
            lblIconoChck_18.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_18));
        }
        if (bandera_reporte == 19) {
            lblIconoChck_19.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_19));
        }
        if (bandera_reporte == 20) {
            lblIconoChck_20.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_20));
        }
        if (bandera_reporte == 21) {
            lblIconoChck_21.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_21));
        }
        if (bandera_reporte == 22) {
            lblIconoChck_22.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_22));
        }
        if (bandera_reporte == 23) {
            lblIconoChck_23.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_23));
        }
        if (bandera_reporte == 24) {
            lblIconoChck_24.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_24));
        }
        if (bandera_reporte == 25) {
            lblIconoChck_25.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", lblIconoChck_25));
        }
    }
    
    public void desactivarReporte() {
        lblIconoChck_00.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_00));
        lblIconoChck_01.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_01));
        lblIconoChck_02.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_02));
        lblIconoChck_03.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_03));
        lblIconoChck_04.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_04));
        lblIconoChck_05.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_05));
        lblIconoChck_06.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_06));
        lblIconoChck_07.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_07));
        lblIconoChck_08.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_08));
        lblIconoChck_09.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_09));
        lblIconoChck_10.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_10));
        lblIconoChck_11.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_11));
        lblIconoChck_12.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_12));
        lblIconoChck_13.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_13));
        lblIconoChck_14.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_14));
        lblIconoChck_15.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_15));
        lblIconoChck_16.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_16));
        lblIconoChck_17.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_17));
        lblIconoChck_18.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_18));
        lblIconoChck_19.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_19));
        lblIconoChck_20.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_20));
        lblIconoChck_21.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_21));
        lblIconoChck_22.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_22));
        lblIconoChck_23.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_23));
        lblIconoChck_24.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_24));
        lblIconoChck_25.setIcon(ajustes.ajustarImagen_("/images/general-21-icono-check.png", lblIconoChck_25));
    }
    
    public void imprimir() {
        switch (bandera_reporte) {
            case 0://Reporte Contable - Auxiliar por cuenta
                if(bandera_check_cuenta == 0) {
                	JOptionPane.showMessageDialog(null, "Debe seleccionar la cuenta contable", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                	return;
                }else {
                	if(txtCuentaContable.getText().length() == 0) {
                		JOptionPane.showMessageDialog(null, "Este campo no puede estar vacio", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                	}else {
                		imprimir.imprimirLibroContable_balanceComprobacion("rpt_libroAuxiliar.jasper", Variables.usuario, Variables.nombreOficina, txtFechaInicio.getText().toString(), txtFechaFinal.getText().toString());
                	}
                }
                break;
            case 1: 
            	JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 2://Reporte Contable - Balance de comprobacion
            	if(consultaSql.verificarBalanceComprobacion(txtFechaInicio.getText().toString(), txtFechaFinal.getText().toString(), Variables.usuario, Variables.idOficina) > 0) {
            		imprimir.imprimirLibroContable_balanceComprobacion("rpt_balanceComprobacion.jasper", Variables.usuario, Variables.nombreOficina, txtFechaInicio.getText().toString(), txtFechaFinal.getText().toString());
            	}
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 4:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 5:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 6:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 7:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 8:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 9:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 10://Reporte Contable - Diario Mayor
            	if(consultaSql.verificarBalanceComprobacion(txtFechaInicio.getText().toString(), txtFechaFinal.getText().toString(), Variables.usuario, Variables.idOficina) > 0) {
            		imprimir.imprimirLibroContable_balanceComprobacion("rpt_libroDiarioMayor.jasper", Variables.usuario, Variables.nombreOficina, txtFechaInicio.getText().toString(), txtFechaFinal.getText().toString());
            	}
                break;
            case 11:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 12:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 13:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 14:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 15:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 16:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 17:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 18:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 19:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 20:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 21:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 22:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 23:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 24:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
            case 25:
                JOptionPane.showMessageDialog(null, "Reporte en mantenimiento", "ALERTA!", JOptionPane.WARNING_MESSAGE);
                break;
        }
    }
}
