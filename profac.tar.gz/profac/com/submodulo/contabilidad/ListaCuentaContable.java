// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import javax.swing.table.TableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JScrollPane;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaCuentaContable extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaCuenta;
    private JLabel btnNueva;
    private JLabel lblIconoBtn_nueva;
    private JLabel lblNombreBtn_nueva;
    private JPanel jp_btnEditarCuenta;
    private JLabel btnEditar;
    private JLabel lblIconoBtn_Editar;
    private JLabel lblNombreBtn_editar;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblListadoCuentaContable;
    private JLabel lblCuenta;
    private JTextField txtCuenta;
    private JLabel lblDescripcion;
    private JTextField txtDescripcion;
    private JLabel lblFechaMod;
    private JTextField txtFechaMod;
    private JLabel lblUsuarioMod;
    private JTextField txtUsuarioMod;
    private JLabel lblBuscar;
    private JTextField txtBuscar;
    private JPanel jp_btnBuscar;
    private JLabel lblIconoBtn_buscar;
    private JLabel lblNombreBtn_buscar;
    private JLabel btnBuscar;
    private JPanel jp_presupuesto;
    private JLabel lblSaldo;
    private JTextField txtSaldo;
    private JLabel lblSignoDolar;
    private JLabel lblCargo;
    private JLabel lblSignoDolar_1;
    private JTextField txtCargo;
    private JLabel lblAbono;
    private JLabel lblSignoDolar_2;
    private JTextField txtAbono;
    private JLabel lblDisponible;
    private JLabel lblSignoDolar_3;
    private JTextField txtDisponible;
    private JLabel lblPresupuesto;
    private JLabel lblSignoDolar_4;
    private JTextField txtPresupuesto;
    private JPanel jp_tblCuentas;
    private JTable tblCuentas;
    public boolean banderaModificar;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaCuentaContable frame = new ListaCuentaContable();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaCuentaContable() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.banderaModificar = false;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaCuentaContable.this.buscarCuenta("%%");
                ListaCuentaContable.this.txtBuscar.requestFocus();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaCuenta = new JPanel()).setLayout(null);
        this.jp_btnNuevaCuenta.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaCuenta.setBackground(Variables.color_tres);
        this.jp_btnNuevaCuenta.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaCuenta);
        (this.btnNueva = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNueva.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNueva.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnNuevaCuenta.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                final NuevaCuentaContable ncc = new NuevaCuentaContable();
                ncc.setVisible(true);
            }
        });
        this.btnNueva.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnNuevaCuenta.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaCuenta.add(this.btnNueva);
        (this.lblIconoBtn_nueva = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nueva.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nueva));
        this.jp_btnNuevaCuenta.add(this.lblIconoBtn_nueva);
        (this.lblNombreBtn_nueva = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nueva.setForeground(Variables.color_uno);
        this.lblNombreBtn_nueva.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nueva.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaCuenta.add(this.lblNombreBtn_nueva);
        (this.jp_btnEditarCuenta = new JPanel()).setLayout(null);
        this.jp_btnEditarCuenta.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnEditarCuenta.setBackground(Variables.color_tres);
        this.jp_btnEditarCuenta.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnEditarCuenta);
        (this.btnEditar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnEditar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnEditar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnEditarCuenta.setBackground(Variables.color_tres);
            }
        });
        this.btnEditar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnEditarCuenta.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnEditarCuenta.add(this.btnEditar);
        (this.lblIconoBtn_Editar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_Editar.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-editarPartida.png", this.lblIconoBtn_Editar));
        this.jp_btnEditarCuenta.add(this.lblIconoBtn_Editar);
        (this.lblNombreBtn_editar = new JLabel("Editar")).setHorizontalAlignment(0);
        this.lblNombreBtn_editar.setForeground(Variables.color_uno);
        this.lblNombreBtn_editar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_editar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnEditarCuenta.add(this.lblNombreBtn_editar);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaCuentaContable.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblListadoCuentaContable = new JLabel("Listado de Cuentas Contables")).setForeground(Variables.color_uno);
        this.lblListadoCuentaContable.setHorizontalAlignment(0);
        this.lblListadoCuentaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblListadoCuentaContable.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblListadoCuentaContable);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        (this.lblCuenta = new JLabel("Cuenta:")).setForeground(Variables.color_uno);
        this.lblCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCuenta.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(5.09), (this.ajustes.ancho - 25) / this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblCuenta);
        (this.txtCuenta = new JTextField()).setEditable(false);
        this.txtCuenta.setBackground(Variables.color_uno);
        this.txtCuenta.setForeground(Variables.color_dos);
        this.txtCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuenta.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCuenta);
        this.txtCuenta.setColumns(10);
        (this.lblDescripcion = new JLabel("Descripci\u00f3n:")).setForeground(Variables.color_uno);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescripcion);
        (this.txtDescripcion = new JTextField()).setEditable(false);
        this.txtDescripcion.setBackground(Variables.color_uno);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setColumns(10);
        this.txtDescripcion.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(8.8), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcion);
        (this.lblFechaMod = new JLabel("Fecha Modificacion:")).setForeground(Variables.color_uno);
        this.lblFechaMod.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaMod.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(13.43), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaMod);
        (this.txtFechaMod = new JTextField()).setEditable(false);
        this.txtFechaMod.setBackground(Variables.color_uno);
        this.txtFechaMod.setForeground(Variables.color_dos);
        this.txtFechaMod.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaMod.setColumns(10);
        this.txtFechaMod.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(12.96), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaMod);
        (this.lblUsuarioMod = new JLabel("Usuario:")).setForeground(Variables.color_uno);
        this.lblUsuarioMod.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblUsuarioMod.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(17.59), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblUsuarioMod);
        (this.txtUsuarioMod = new JTextField()).setEditable(false);
        this.txtUsuarioMod.setBackground(Variables.color_uno);
        this.txtUsuarioMod.setForeground(Variables.color_dos);
        this.txtUsuarioMod.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtUsuarioMod.setColumns(10);
        this.txtUsuarioMod.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(17.13), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtUsuarioMod);
        (this.lblBuscar = new JLabel("Buscar Cuenta por Nombre:")).setHorizontalAlignment(0);
        this.lblBuscar.setForeground(Variables.color_uno);
        this.lblBuscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblBuscar.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(21.76), this.ajustes.calcularPuntoX(37.5), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblBuscar);
        (this.txtBuscar = new JTextField()).addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(final KeyEvent arg0) {
                switch (arg0.getKeyCode()) {
                    case 10: {
                        ListaCuentaContable.this.buscarCuenta("%" + ListaCuentaContable.this.txtBuscar.getText().toString() + "%");
                        break;
                    }
                }
            }
        });
        this.txtBuscar.setBackground(Variables.color_uno);
        this.txtBuscar.setForeground(Variables.color_dos);
        this.txtBuscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscar.setColumns(10);
        this.txtBuscar.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(25.93), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtBuscar);
        (this.jp_btnBuscar = new JPanel()).setBackground(Variables.color_uno);
        this.jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(21.76), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(6.94));
        jp_contenido.add(this.jp_btnBuscar);
        this.jp_btnBuscar.setLayout(null);
        (this.btnBuscar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnBuscar.setBackground(Variables.color_uno);
                ListaCuentaContable.this.lblIconoBtn_buscar.setIcon(ListaCuentaContable.this.ajustes.ajustarImagen("/botones_07_icono_buscar", ListaCuentaContable.this.lblIconoBtn_buscar, 50, 50, 50, 50));
                ListaCuentaContable.this.lblNombreBtn_buscar.setForeground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaCuentaContable.this.buscarCuenta("%" + ListaCuentaContable.this.txtBuscar.getText().toString() + "%");
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCuentaContable.this.jp_btnBuscar.setBackground(Variables.color_dos);
                ListaCuentaContable.this.lblIconoBtn_buscar.setIcon(ListaCuentaContable.this.ajustes.ajustarImagen("/botones_07_icono_buscar_select", ListaCuentaContable.this.lblIconoBtn_buscar, 50, 50, 50, 50));
                ListaCuentaContable.this.lblNombreBtn_buscar.setForeground(Variables.color_uno);
            }
        });
        this.btnBuscar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(6.94));
        this.jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoBtn_buscar.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(1.11), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen("/botones_07_icono_buscar", this.lblIconoBtn_buscar, 50, 50, 50, 50));
        this.jp_btnBuscar.add(this.lblIconoBtn_buscar);
        (this.lblNombreBtn_buscar = new JLabel("BUSCAR")).setForeground(Variables.color_dos);
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNombreBtn_buscar.setBounds(this.ajustes.calcularPuntoX(3.91), 0, (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(3.91), this.ajustes.calcularPuntoY(6.94));
        this.jp_btnBuscar.add(this.lblNombreBtn_buscar);
        (this.jp_presupuesto = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_presupuesto.setBackground(Variables.color_uno);
        this.jp_presupuesto.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(24.07));
        jp_contenido.add(this.jp_presupuesto);
        this.jp_presupuesto.setLayout(null);
        (this.lblSaldo = new JLabel("Saldo al Cierre: ")).setForeground(Variables.color_dos);
        this.lblSaldo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblSaldo.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_presupuesto.add(this.lblSaldo);
        (this.lblSignoDolar = new JLabel("$")).setForeground(Variables.color_dos);
        this.lblSignoDolar.setHorizontalAlignment(0);
        this.lblSignoDolar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
        this.lblSignoDolar.setBounds((this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.31), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.lblSignoDolar);
        (this.txtSaldo = new JTextField()).setBackground(Variables.color_uno);
        this.txtSaldo.setForeground(Variables.color_dos);
        this.txtSaldo.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtSaldo.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.31), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.txtSaldo);
        this.txtSaldo.setColumns(10);
        (this.lblCargo = new JLabel("Cargo:")).setForeground(Variables.color_dos);
        this.lblCargo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCargo.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_presupuesto.add(this.lblCargo);
        (this.lblSignoDolar_1 = new JLabel("$")).setHorizontalAlignment(0);
        this.lblSignoDolar_1.setForeground(Variables.color_dos);
        this.lblSignoDolar_1.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
        this.lblSignoDolar_1.setBounds((this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(6.48), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.lblSignoDolar_1);
        (this.txtCargo = new JTextField()).setForeground(Variables.color_dos);
        this.txtCargo.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCargo.setColumns(10);
        this.txtCargo.setBackground(Variables.color_uno);
        this.txtCargo.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.txtCargo);
        (this.lblAbono = new JLabel("Abono:")).setForeground(Variables.color_dos);
        this.lblAbono.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblAbono.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(11.11), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_presupuesto.add(this.lblAbono);
        (this.lblSignoDolar_2 = new JLabel("$")).setHorizontalAlignment(0);
        this.lblSignoDolar_2.setForeground(Variables.color_dos);
        this.lblSignoDolar_2.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
        this.lblSignoDolar_2.setBounds((this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(10.65), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.lblSignoDolar_2);
        (this.txtAbono = new JTextField()).setForeground(Variables.color_dos);
        this.txtAbono.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtAbono.setColumns(10);
        this.txtAbono.setBackground(Variables.color_uno);
        this.txtAbono.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(10.65), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.txtAbono);
        (this.lblDisponible = new JLabel("Disponibilidad:")).setForeground(Variables.color_dos);
        this.lblDisponible.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDisponible.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(15.28), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_presupuesto.add(this.lblDisponible);
        (this.lblSignoDolar_3 = new JLabel("$")).setHorizontalAlignment(0);
        this.lblSignoDolar_3.setForeground(Variables.color_dos);
        this.lblSignoDolar_3.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
        this.lblSignoDolar_3.setBounds((this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(14.81), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.lblSignoDolar_3);
        (this.txtDisponible = new JTextField()).setForeground(Variables.color_dos);
        this.txtDisponible.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDisponible.setColumns(10);
        this.txtDisponible.setBackground(Variables.color_uno);
        this.txtDisponible.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(14.81), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.txtDisponible);
        (this.lblPresupuesto = new JLabel("Presupuesto:")).setForeground(Variables.color_dos);
        this.lblPresupuesto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPresupuesto.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(19.44), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_presupuesto.add(this.lblPresupuesto);
        (this.lblSignoDolar_4 = new JLabel("$")).setHorizontalAlignment(0);
        this.lblSignoDolar_4.setForeground(Variables.color_dos);
        this.lblSignoDolar_4.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
        this.lblSignoDolar_4.setBounds((this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(18.98), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.lblSignoDolar_4);
        (this.txtPresupuesto = new JTextField()).setForeground(Variables.color_dos);
        this.txtPresupuesto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPresupuesto.setColumns(10);
        this.txtPresupuesto.setBackground(Variables.color_uno);
        this.txtPresupuesto.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(18.98), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_presupuesto.add(this.txtPresupuesto);
        (this.jp_tblCuentas = new JPanel()).setBackground(Variables.color_uno);
        this.jp_tblCuentas.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_tblCuentas.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(30.56), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(50.93));
        jp_contenido.add(this.jp_tblCuentas);
        this.jp_tblCuentas.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.ancho - this.ajustes.calcularPuntoX(3.65), this.ajustes.calcularPuntoY(49.07));
        this.jp_tblCuentas.add(scrollPane);
        (this.tblCuentas = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblCuentas.setForeground(Variables.color_dos);
        this.tblCuentas.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.tblCuentas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                ListaCuentaContable.this.seleccionarCuenta();
            }
        });
        scrollPane.setViewportView(this.tblCuentas);
        this.menuEmergente();
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        final TableColumnModel columnModel = this.tblCuentas.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = this.tblCuentas.getTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(500);
        columnModel.getColumn(2).setPreferredWidth(75);
        columnModel.getColumn(2).setCellRenderer(alinear);
        columnModel.getColumn(3).setPreferredWidth(75);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(75);
        columnModel.getColumn(4).setCellRenderer(alinear);
        columnModel.getColumn(5).setPreferredWidth(75);
        columnModel.getColumn(5).setCellRenderer(alinear);
        columnModel.getColumn(6).setPreferredWidth(100);
        columnModel.getColumn(6).setCellRenderer(alinear);
    }
    
    public void seleccionarCuenta() {
        this.banderaModificar = true;
        this.txtCuenta.setText((String)this.tblCuentas.getValueAt(this.tblCuentas.getSelectedRow(), 0));
        this.txtDescripcion.setText((String)this.tblCuentas.getValueAt(this.tblCuentas.getSelectedRow(), 1));
        this.txtFechaMod.setText((String)this.tblCuentas.getValueAt(this.tblCuentas.getSelectedRow(), 5));
        this.txtUsuarioMod.setText((String)this.tblCuentas.getValueAt(this.tblCuentas.getSelectedRow(), 6));
        this.txtDisponible.setText((String)this.tblCuentas.getValueAt(this.tblCuentas.getSelectedRow(), 4));
        this.txtPresupuesto.setText((String)this.tblCuentas.getValueAt(this.tblCuentas.getSelectedRow(), 3));
    }
    
    public void buscarCuenta(final String cadena) {
        this.tblCuentas.setModel(this.consultaSql.llenarTablaCuentasContables(cadena, Variables.idOficina, 0));
        this.configurarTabla();
    }
    
    public void menuEmergente() {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JMenuItem mntmEditar = new JMenuItem("Editar Cuenta Contable", new ImageIcon(this.getClass().getResource("/images/general-20-icono-editar.png")));
        mntmEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Este modulo se encuentra en mantenimiento", "ALERTA!", 2);
            }
        });
        popupMenu.add(mntmEditar);
        this.tblCuentas.setComponentPopupMenu(popupMenu);
    }
}
