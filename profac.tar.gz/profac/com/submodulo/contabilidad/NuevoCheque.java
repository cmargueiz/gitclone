// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.ComboBoxModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Contabilidad;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevoCheque extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Contabilidad contabilidad;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevoCheque;
    private JLabel btnNuevoCheque;
    private JLabel lblIconoBtn_nuevoCheque;
    private JLabel lblNombreBtn_nuevoCheque;
    private JPanel jp_btnBuscarCheque;
    private JLabel btnBuscarCheque;
    private JLabel lblIconoBtn_buscarCheque;
    private JLabel lblNombreBtn_buscarCheque;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblCrearNuevoCheque;
    private JLabel chckNuevaPartida;
    private JLabel chckBuscarNumeroPartida;
    private JLabel lblIconoChck_buscarNumeroPartida;
    private JLabel lblIconoChck_nuevaPartida;
    private JTextField txtBuscarCuenta;
    private JTable tblCuentas;
    private JTextField txtNumeroCheque;
    private JLabel lblFechaContable;
    private JTextField txtFechaContable;
    private JTextField txtFechaDocumento;
    private JTextField txtNombreCheque;
    private JComboBox<Object> cbxBanco;
    private JLabel lblNumeroCheque;
    private JPanel jp_partidaContable;
    private JLabel lblNumeroPartida;
    private JTextField txtNumeroPartida;
    private JLabel lblObservacion;
    private JTextField txtObservacion;
    private JLabel lblCuenta;
    private JLabel lblDescripcionCuenta;
    private JLabel lblCargo;
    private JLabel lblAbono;
    private JTextField txtCuenta;
    private JTextField txtDescripcion;
    private JTextField txtCargo;
    private JTextField txtAbono;
    private JLabel lblIconoBtn_agregar;
    private JLabel btnAgregar;
    private JPanel jp_btnAgregar;
    private JPanel jp_detalle;
    private JLabel lblTotal;
    private JTextField txtAbonoTotal;
    private JTextField txtCargoTotal;
    private JTable tblDetalle;
    private JPanel jp_partidasContables;
    private JLabel lblBuscarpartida;
    private JTextField txtBuscarPartida;
    private JPanel jp_btnBuscar_partida;
    private JLabel btnBuscar_partida;
    private JLabel lblIconoBtn_buscar_partida;
    private JLabel lblNombreBtn_buscar_partida;
    private JPanel jp_tblPartidasContables;
    private JScrollPane scrollPane_2;
    private JPanel jp_cuentasContables;
    private JScrollPane scrollPane_1;
    private JTable tblPartidasContables;
    private JLabel lblNombreCheque;
    public boolean chckbxNuevaPartida;
    public boolean chckbxBuscarNumeroOartida;
    public int banderaTablaNuevaPartida;
    public int banderaTablaCatalogoPartida;
    public int banderaGuardar;
    public int banderaImprimir;
    public int banderaBtnAgregar;
    public double montoCheque;
    DefaultTableModel modeloTblDetalle;
    public double montoCargo;
    public double montoAbono;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevoCheque frame = new NuevoCheque();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevoCheque() {
        this.ajustes = new Ajustes();
        this.contabilidad = new F_Contabilidad();
        this.consultaSql = new consultasSQL_SERVER();
        this.chckbxNuevaPartida = false;
        this.chckbxBuscarNumeroOartida = false;
        this.banderaTablaNuevaPartida = 0;
        this.banderaTablaCatalogoPartida = 0;
        this.banderaGuardar = 0;
        this.banderaImprimir = 0;
        this.banderaBtnAgregar = 0;
        this.montoCheque = 0.0;
        this.montoCargo = 0.0;
        this.montoAbono = 0.0;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevoCheque.this.banderaGuardar = 0;
                NuevoCheque.this.banderaTablaCatalogoPartida = 0;
                NuevoCheque.this.banderaTablaNuevaPartida = 1;
                NuevoCheque.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevoCheque = new JPanel()).setLayout(null);
        this.jp_btnNuevoCheque.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevoCheque.setBackground(Variables.color_tres);
        this.jp_btnNuevoCheque.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevoCheque);
        (this.btnNuevoCheque = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevoCheque.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevoCheque.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnNuevoCheque.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevoCheque.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnNuevoCheque.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevoCheque.add(this.btnNuevoCheque);
        (this.lblIconoBtn_nuevoCheque = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevoCheque.setIcon(this.ajustes.ajustarImagen_("/images/botones-10-icono-nuevoCheque.png", this.lblIconoBtn_nuevoCheque));
        this.jp_btnNuevoCheque.add(this.lblIconoBtn_nuevoCheque);
        (this.lblNombreBtn_nuevoCheque = new JLabel("Nuevo")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevoCheque.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevoCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevoCheque.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevoCheque.add(this.lblNombreBtn_nuevoCheque);
        (this.jp_btnBuscarCheque = new JPanel()).setLayout(null);
        this.jp_btnBuscarCheque.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarCheque.setBackground(Variables.color_tres);
        this.jp_btnBuscarCheque.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarCheque);
        (this.btnBuscarCheque = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarCheque.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarCheque.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnBuscarCheque.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                final ListaCheques lch = new ListaCheques();
                lch.setVisible(true);
            }
        });
        this.btnBuscarCheque.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnBuscarCheque.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarCheque.add(this.btnBuscarCheque);
        (this.lblIconoBtn_buscarCheque = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarCheque.setIcon(this.ajustes.ajustarImagen_("/images/botones-11-icono-listaCheques.png", this.lblIconoBtn_buscarCheque));
        this.jp_btnBuscarCheque.add(this.lblIconoBtn_buscarCheque);
        (this.lblNombreBtn_buscarCheque = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarCheque.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarCheque.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarCheque.add(this.lblNombreBtn_buscarCheque);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevoCheque.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoCheque.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblCrearNuevoCheque = new JLabel("Crear Nuevo Cheque")).setForeground(Variables.color_uno);
        this.lblCrearNuevoCheque.setHorizontalAlignment(0);
        this.lblCrearNuevoCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblCrearNuevoCheque.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblCrearNuevoCheque);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JPanel jp_chckNuevaPartida = new JPanel();
        jp_chckNuevaPartida.setOpaque(false);
        jp_chckNuevaPartida.setBounds((this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckNuevaPartida);
        jp_chckNuevaPartida.setLayout(null);
        (this.chckNuevaPartida = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevoCheque.this.chckbxNuevaPartida = true;
                NuevoCheque.this.chckbxBuscarNumeroOartida = false;
                NuevoCheque.this.banderaGuardar = 0;
                NuevoCheque.this.banderaTablaCatalogoPartida = 0;
                NuevoCheque.this.banderaTablaNuevaPartida = 1;
                NuevoCheque.this.verificarOpcion();
            }
        });
        this.chckNuevaPartida.setCursor(Cursor.getPredefinedCursor(12));
        this.chckNuevaPartida.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
        jp_chckNuevaPartida.add(this.chckNuevaPartida);
        (this.lblIconoChck_nuevaPartida = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_nuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.lblIconoChck_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lblIconoChck_nuevaPartida));
        jp_chckNuevaPartida.add(this.lblIconoChck_nuevaPartida);
        final JLabel lblNombreChck_nuevaPartida = new JLabel("Nueva Partida Contable");
        lblNombreChck_nuevaPartida.setForeground(Variables.color_uno);
        lblNombreChck_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreChck_nuevaPartida.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_chckNuevaPartida.add(lblNombreChck_nuevaPartida);
        final JPanel jp_chckBuscarNumeroPartida = new JPanel();
        jp_chckBuscarNumeroPartida.setLayout(null);
        jp_chckBuscarNumeroPartida.setOpaque(false);
        jp_chckBuscarNumeroPartida.setBounds((this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
        jp_contenido.add(jp_chckBuscarNumeroPartida);
        (this.chckBuscarNumeroPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.chckBuscarNumeroPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoCheque.this.chckbxNuevaPartida = false;
                NuevoCheque.this.chckbxBuscarNumeroOartida = true;
                NuevoCheque.this.verificarOpcion();
            }
        });
        this.chckBuscarNumeroPartida.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(3.7));
        jp_chckBuscarNumeroPartida.add(this.chckBuscarNumeroPartida);
        (this.lblIconoChck_buscarNumeroPartida = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_buscarNumeroPartida.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.lblIconoChck_buscarNumeroPartida.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lblIconoChck_buscarNumeroPartida));
        jp_chckBuscarNumeroPartida.add(this.lblIconoChck_buscarNumeroPartida);
        final JLabel lblNombreChck_buscarNumeroPartida = new JLabel("Asignar Numero de Partida");
        lblNombreChck_buscarNumeroPartida.setForeground(Variables.color_uno);
        lblNombreChck_buscarNumeroPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreChck_buscarNumeroPartida.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        jp_chckBuscarNumeroPartida.add(lblNombreChck_buscarNumeroPartida);
        (this.jp_partidasContables = new JPanel()).setVisible(false);
        this.jp_partidasContables.setLayout(null);
        this.jp_partidasContables.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_partidasContables.setBackground(Variables.color_uno);
        this.jp_partidasContables.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.alto - this.ajustes.calcularPuntoY(26.85));
        jp_contenido.add(this.jp_partidasContables);
        (this.lblBuscarpartida = new JLabel("Buscar Partida Contable")).setHorizontalAlignment(0);
        this.lblBuscarpartida.setForeground(Variables.color_dos);
        this.lblBuscarpartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBuscarpartida.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(28.49), this.ajustes.calcularPuntoY(1.85));
        this.jp_partidasContables.add(this.lblBuscarpartida);
        (this.txtBuscarPartida = new JTextField()).setForeground(Variables.color_dos);
        this.txtBuscarPartida.setColumns(10);
        this.txtBuscarPartida.setBackground(Color.WHITE);
        this.txtBuscarPartida.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscarPartida.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(3.24), this.ajustes.calcularPuntoX(28.49), this.ajustes.calcularPuntoY(2.78));
        this.jp_partidasContables.add(this.txtBuscarPartida);
        (this.jp_btnBuscar_partida = new JPanel()).setLayout(null);
        this.jp_btnBuscar_partida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscar_partida.setBackground(Variables.color_tres);
        this.jp_btnBuscar_partida.setBounds(this.ajustes.calcularPuntoX(24.32), this.ajustes.calcularPuntoY(3.24), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_partidasContables.add(this.jp_btnBuscar_partida);
        (this.btnBuscar_partida = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnBuscar_partida.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoCheque.this.buscarCuenta("%" + NuevoCheque.this.txtBuscarCuenta.getText().toString() + "%");
            }
        });
        this.btnBuscar_partida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnBuscar_partida.setBackground(Variables.color_dos);
            }
        });
        this.btnBuscar_partida.setBounds(0, 0, this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar_partida.add(this.btnBuscar_partida);
        (this.lblIconoBtn_buscar_partida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), 0, this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.lblIconoBtn_buscar_partida.setIcon(this.ajustes.ajustarImagen_("/images/general-16-icono-buscar.png", this.lblIconoBtn_buscar_partida));
        this.jp_btnBuscar_partida.add(this.lblIconoBtn_buscar_partida);
        (this.lblNombreBtn_buscar_partida = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscar_partida.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscar_partida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.8))));
        this.lblNombreBtn_buscar_partida.setBounds(this.ajustes.calcularPuntoX(1.56), 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar_partida.add(this.lblNombreBtn_buscar_partida);
        final JSeparator separator_2 = new JSeparator();
        separator_2.setBounds(this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(6.94), this.ajustes.calcularPuntoX(27.45), this.ajustes.calcularPuntoY(0.19));
        this.jp_partidasContables.add(separator_2);
        (this.jp_tblPartidasContables = new JPanel()).setLayout(null);
        this.jp_tblPartidasContables.setBorder(new BevelBorder(1, null, null, null, null));
        this.jp_tblPartidasContables.setBackground(Color.WHITE);
        this.jp_tblPartidasContables.setBounds(this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(7.87), this.ajustes.calcularPuntoX(27.45), this.ajustes.calcularPuntoY(64.35));
        this.jp_partidasContables.add(this.jp_tblPartidasContables);
        (this.scrollPane_2 = new JScrollPane()).setBackground(Color.WHITE);
        this.scrollPane_2.setBounds(0, 0, this.ajustes.calcularPuntoX(27.45), this.ajustes.calcularPuntoY(64.35));
        this.jp_tblPartidasContables.add(this.scrollPane_2);
        (this.tblPartidasContables = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblPartidasContables.setForeground(Variables.color_dos);
        this.tblPartidasContables.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.tblPartidasContables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevoCheque.this.seleccionarPartida();
            }
        });
        this.scrollPane_2.setViewportView(this.tblPartidasContables);
        (this.jp_cuentasContables = new JPanel()).setBackground(Variables.color_uno);
        this.jp_cuentasContables.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_cuentasContables.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.alto - this.ajustes.calcularPuntoY(26.85));
        jp_contenido.add(this.jp_cuentasContables);
        this.jp_cuentasContables.setLayout(null);
        final JLabel lblBuscarCuenta = new JLabel("Buscar Cuenta Contable");
        lblBuscarCuenta.setHorizontalAlignment(0);
        lblBuscarCuenta.setForeground(Variables.color_dos);
        lblBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.jp_cuentasContables.add(lblBuscarCuenta);
        (this.txtBuscarCuenta = new JTextField()).setForeground(Variables.color_dos);
        this.txtBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscarCuenta.setColumns(10);
        this.txtBuscarCuenta.setBackground(Color.WHITE);
        this.txtBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(3.24), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(6.25), this.ajustes.calcularPuntoY(2.78));
        this.jp_cuentasContables.add(this.txtBuscarCuenta);
        final JPanel jp_btnBuscar = new JPanel();
        jp_btnBuscar.setLayout(null);
        jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscar.setBackground(Variables.color_tres);
        jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(3.24), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_cuentasContables.add(jp_btnBuscar);
        final JLabel btnBuscar = new JLabel("");
        btnBuscar.setBounds(0, 0, this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        jp_btnBuscar.add(btnBuscar);
        final JLabel lblIconoBtn_buscar = new JLabel("");
        lblIconoBtn_buscar.setBounds(this.ajustes.calcularPuntoX(0.26), 0, this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/general-16-icono-buscar.png", lblIconoBtn_buscar));
        jp_btnBuscar.add(lblIconoBtn_buscar);
        final JLabel lblNombreBtn_buscar = new JLabel("Buscar");
        lblNombreBtn_buscar.setHorizontalAlignment(0);
        lblNombreBtn_buscar.setForeground(Variables.color_uno);
        lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.8))));
        lblNombreBtn_buscar.setBounds(this.ajustes.calcularPuntoX(1.56), 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(2.78));
        jp_btnBuscar.add(lblNombreBtn_buscar);
        final JSeparator separator_3 = new JSeparator();
        separator_3.setBounds(this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(0.19));
        this.jp_cuentasContables.add(separator_3);
        final JPanel jp_tblCuentas = new JPanel();
        jp_tblCuentas.setLayout(null);
        jp_tblCuentas.setBorder(new BevelBorder(1, null, null, null, null));
        jp_tblCuentas.setBackground(Color.WHITE);
        jp_tblCuentas.setBounds(this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(35.65));
        this.jp_cuentasContables.add(jp_tblCuentas);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBackground(Color.WHITE);
        scrollPane.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(35.65));
        jp_tblCuentas.add(scrollPane);
        (this.tblCuentas = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblCuentas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoCheque.this.seleccionarCuenta((String)NuevoCheque.this.tblCuentas.getValueAt(NuevoCheque.this.tblCuentas.getSelectedRow(), 0), (String)NuevoCheque.this.tblCuentas.getValueAt(NuevoCheque.this.tblCuentas.getSelectedRow(), 1));
            }
        });
        this.tblCuentas.setForeground(Variables.color_dos);
        this.tblCuentas.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        scrollPane.setViewportView(this.tblCuentas);
        final JPanel jp_infoCheque = new JPanel();
        jp_infoCheque.setOpaque(false);
        jp_infoCheque.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(12.96));
        jp_contenido.add(jp_infoCheque);
        jp_infoCheque.setLayout(null);
        (this.lblNumeroCheque = new JLabel("Nº de Cheque:")).setHorizontalAlignment(0);
        this.lblNumeroCheque.setForeground(Variables.color_uno);
        this.lblNumeroCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNumeroCheque.setBounds(0, this.ajustes.calcularPuntoY(0.93), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        jp_infoCheque.add(this.lblNumeroCheque);
        (this.txtNumeroCheque = new JTextField()).setEditable(false);
        this.txtNumeroCheque.setBackground(Variables.color_uno);
        this.txtNumeroCheque.setForeground(Variables.color_dos);
        this.txtNumeroCheque.setHorizontalAlignment(0);
        this.txtNumeroCheque.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNumeroCheque.setBounds(0, this.ajustes.calcularPuntoY(3.24), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_infoCheque.add(this.txtNumeroCheque);
        this.txtNumeroCheque.setColumns(10);
        (this.lblFechaContable = new JLabel("Fecha Contable:")).setHorizontalAlignment(0);
        this.lblFechaContable.setForeground(Variables.color_uno);
        this.lblFechaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaContable.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        jp_infoCheque.add(this.lblFechaContable);
        (this.txtFechaContable = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaContable.setForeground(Variables.color_dos);
        this.txtFechaContable.setEditable(false);
        this.txtFechaContable.setColumns(10);
        this.txtFechaContable.setBackground(Variables.color_uno);
        this.txtFechaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaContable.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(3.24), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_infoCheque.add(this.txtFechaContable);
        final JLabel lblFechaDocumento = new JLabel("Fecha de Documento:");
        lblFechaDocumento.setHorizontalAlignment(0);
        lblFechaDocumento.setForeground(Variables.color_uno);
        lblFechaDocumento.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(0.93), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        jp_infoCheque.add(lblFechaDocumento);
        (this.txtFechaDocumento = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaDocumento.setForeground(Variables.color_dos);
        this.txtFechaDocumento.setEditable(false);
        this.txtFechaDocumento.setColumns(10);
        this.txtFechaDocumento.setBackground(Variables.color_uno);
        this.txtFechaDocumento.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(3.24), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(2.78));
        jp_infoCheque.add(this.txtFechaDocumento);
        (this.lblNombreCheque = new JLabel("Nombre de Cheque:")).setHorizontalAlignment(0);
        this.lblNombreCheque.setForeground(Variables.color_uno);
        this.lblNombreCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreCheque.setBounds(0, this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        jp_infoCheque.add(this.lblNombreCheque);
        (this.txtNombreCheque = new JTextField()).setBackground(Variables.color_uno);
        this.txtNombreCheque.setForeground(Variables.color_dos);
        this.txtNombreCheque.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreCheque.setBounds(0, this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_infoCheque.add(this.txtNombreCheque);
        this.txtNombreCheque.setColumns(10);
        final JLabel lblBanco = new JLabel("Banco:");
        lblBanco.setForeground(Variables.color_uno);
        lblBanco.setHorizontalAlignment(0);
        lblBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblBanco.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_infoCheque.add(lblBanco);
        (this.cbxBanco = new JComboBox<Object>()).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                NuevoCheque.this.obtenerCorrelativoCheque(NuevoCheque.this.cbxBanco.getSelectedItem().toString());
            }
        });
        this.cbxBanco.setCursor(Cursor.getPredefinedCursor(12));
        this.cbxBanco.setBackground(Variables.color_uno);
        this.cbxBanco.setForeground(Variables.color_dos);
        this.cbxBanco.setModel(this.consultaSql.getDataComboBox("select bancos.nombreBanco\r\nfrom bancos \r\ninner join cuentaContable on bancos.cuentaContable_id=cuentaContable.id \r\nwhere cuentaContable.oficina_idoficina = '" + Variables.idOficina + "'"));
        this.cbxBanco.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxBanco.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_infoCheque.add(this.cbxBanco);
        (this.jp_partidaContable = new JPanel()).setOpaque(false);
        this.jp_partidaContable.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(23.15), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(12.96));
        jp_contenido.add(this.jp_partidaContable);
        this.jp_partidaContable.setLayout(null);
        (this.lblNumeroPartida = new JLabel("Nº de Partida:")).setHorizontalAlignment(0);
        this.lblNumeroPartida.setForeground(Variables.color_uno);
        this.lblNumeroPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNumeroPartida.setBounds(0, this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_partidaContable.add(this.lblNumeroPartida);
        (this.txtNumeroPartida = new JTextField()).setEditable(false);
        this.txtNumeroPartida.setBackground(Variables.color_uno);
        this.txtNumeroPartida.setForeground(Variables.color_dos);
        this.txtNumeroPartida.setHorizontalAlignment(0);
        this.txtNumeroPartida.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNumeroPartida.setBounds((this.ajustes.ancho - 25) / 10, 0, (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        this.jp_partidaContable.add(this.txtNumeroPartida);
        this.txtNumeroPartida.setColumns(10);
        (this.lblObservacion = new JLabel("Observaci\u00f3n:")).setHorizontalAlignment(0);
        this.lblObservacion.setForeground(Variables.color_uno);
        this.lblObservacion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblObservacion.setBounds(0, this.ajustes.calcularPuntoY(4.17), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_partidaContable.add(this.lblObservacion);
        (this.txtObservacion = new JTextField()).setHorizontalAlignment(0);
        this.txtObservacion.setForeground(Variables.color_dos);
        this.txtObservacion.setColumns(10);
        this.txtObservacion.setBackground(Variables.color_uno);
        this.txtObservacion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtObservacion.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(3.7), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(2.78));
        this.jp_partidaContable.add(this.txtObservacion);
        (this.lblCuenta = new JLabel("Cuenta:")).setForeground(Variables.color_uno);
        this.lblCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCuenta.setHorizontalAlignment(0);
        this.lblCuenta.setBounds(0, this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_partidaContable.add(this.lblCuenta);
        (this.txtCuenta = new JTextField()).setEditable(false);
        this.txtCuenta.setForeground(Variables.color_dos);
        this.txtCuenta.setHorizontalAlignment(0);
        this.txtCuenta.setBackground(Variables.color_uno);
        this.txtCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuenta.setBounds(0, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        this.jp_partidaContable.add(this.txtCuenta);
        this.txtCuenta.setColumns(10);
        (this.lblDescripcionCuenta = new JLabel("Descripci\u00f3n:")).setForeground(Variables.color_uno);
        this.lblDescripcionCuenta.setHorizontalAlignment(0);
        this.lblDescripcionCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcionCuenta.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        this.jp_partidaContable.add(this.lblDescripcionCuenta);
        (this.txtDescripcion = new JTextField()).setForeground(Variables.color_dos);
        this.txtDescripcion.setEditable(false);
        this.txtDescripcion.setBackground(Variables.color_uno);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(2.78));
        this.jp_partidaContable.add(this.txtDescripcion);
        this.txtDescripcion.setColumns(10);
        (this.lblCargo = new JLabel("Cargo:")).setForeground(Variables.color_uno);
        this.lblCargo.setHorizontalAlignment(0);
        this.lblCargo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCargo.setBounds((this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.jp_partidaContable.add(this.lblCargo);
        (this.txtCargo = new JTextField()).setForeground(Variables.color_dos);
        this.txtCargo.setHorizontalAlignment(0);
        this.txtCargo.setText("0.00");
        this.txtCargo.setBackground(Variables.color_uno);
        this.txtCargo.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCargo.setBounds((this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        this.jp_partidaContable.add(this.txtCargo);
        this.txtCargo.setColumns(10);
        (this.lblAbono = new JLabel("Abono:")).setForeground(Variables.color_uno);
        this.lblAbono.setHorizontalAlignment(0);
        this.lblAbono.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblAbono.setBounds((this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.jp_partidaContable.add(this.lblAbono);
        (this.txtAbono = new JTextField()).setForeground(Variables.color_dos);
        this.txtAbono.setHorizontalAlignment(0);
        this.txtAbono.setText("0.00");
        this.txtAbono.setBackground(Variables.color_uno);
        this.txtAbono.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtAbono.setBounds((this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        this.jp_partidaContable.add(this.txtAbono);
        this.txtAbono.setColumns(10);
        (this.jp_btnAgregar = new JPanel()).setBackground(Variables.color_uno);
        this.jp_btnAgregar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnAgregar.setBounds((this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoY(2.08), this.ajustes.calcularPuntoY(5.09));
        this.jp_partidaContable.add(this.jp_btnAgregar);
        this.jp_btnAgregar.setLayout(null);
        (this.btnAgregar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnAgregar.setBackground(Variables.color_uno);
                NuevoCheque.this.lblIconoBtn_agregar.setIcon(NuevoCheque.this.ajustes.ajustarImagen_("/images/general-22-icono-add.png", NuevoCheque.this.lblIconoBtn_agregar));
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevoCheque.this.banderaGuardar = 1;
                NuevoCheque.this.banderaTablaCatalogoPartida = 0;
                NuevoCheque.this.banderaTablaNuevaPartida = 1;
                if (NuevoCheque.this.txtCargo.getText().length() == 0) {
                    NuevoCheque.this.txtCargo.setText("0.00");
                }
                if (NuevoCheque.this.txtAbono.getText().length() == 0) {
                    NuevoCheque.this.txtAbono.setText("0.00");
                }
                NuevoCheque.this.llenarTabla();
            }
        });
        this.btnAgregar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoCheque.this.jp_btnAgregar.setBackground(Variables.color_dos);
                NuevoCheque.this.lblIconoBtn_agregar.setIcon(NuevoCheque.this.ajustes.ajustarImagen_("/images/general-22-icono-add-select.png", NuevoCheque.this.lblIconoBtn_agregar));
            }
        });
        this.btnAgregar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnAgregar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(5.09));
        this.jp_btnAgregar.add(this.btnAgregar);
        (this.lblIconoBtn_agregar = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoBtn_agregar.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(4.17));
        this.lblIconoBtn_agregar.setIcon(this.ajustes.ajustarImagen_("/images/general-22-icono-add.png", this.lblIconoBtn_agregar));
        this.jp_btnAgregar.add(this.lblIconoBtn_agregar);
        (this.jp_detalle = new JPanel()).setBackground(Variables.color_uno);
        this.jp_detalle.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_detalle.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(37.04), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(58.33));
        jp_contenido.add(this.jp_detalle);
        this.jp_detalle.setLayout(null);
        (this.scrollPane_1 = new JScrollPane()).setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(58.33));
        this.jp_detalle.add(this.scrollPane_1);
        (this.tblDetalle = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblDetalle.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.tblDetalle.setForeground(Variables.color_dos);
        (this.modeloTblDetalle = new DefaultTableModel()).addColumn("Cuenta");
        this.modeloTblDetalle.addColumn("Descripcion");
        this.modeloTblDetalle.addColumn("Concepto");
        this.modeloTblDetalle.addColumn("Cargo");
        this.modeloTblDetalle.addColumn("Abono");
        this.tblDetalle.setModel(this.modeloTblDetalle);
        this.configurarTabla(1);
        this.scrollPane_1.setViewportView(this.tblDetalle);
        (this.lblTotal = new JLabel("Total:")).setForeground(Variables.color_uno);
        this.lblTotal.setHorizontalAlignment(4);
        this.lblTotal.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblTotal.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(20.37), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblTotal);
        (this.txtCargoTotal = new JTextField()).setEditable(false);
        this.txtCargoTotal.setText("0.00");
        this.txtCargoTotal.setBackground(Variables.color_uno);
        this.txtCargoTotal.setForeground(Variables.color_dos);
        this.txtCargoTotal.setHorizontalAlignment(0);
        this.txtCargoTotal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCargoTotal.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.alto - this.ajustes.calcularPuntoY(20.37), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoY(1.04), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCargoTotal);
        this.txtCargoTotal.setColumns(10);
        (this.txtAbonoTotal = new JTextField()).setEditable(false);
        this.txtAbonoTotal.setText("0.00");
        this.txtAbonoTotal.setBackground(Variables.color_uno);
        this.txtAbonoTotal.setHorizontalAlignment(0);
        this.txtAbonoTotal.setForeground(Variables.color_dos);
        this.txtAbonoTotal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtAbonoTotal.setBounds((this.ajustes.ancho - 25) / 10 * 9 + this.ajustes.calcularPuntoX(1.04), this.ajustes.alto - this.ajustes.calcularPuntoY(20.37), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtAbonoTotal);
        this.txtAbonoTotal.setColumns(10);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void verificarOpcion() {
        if (this.chckbxNuevaPartida && !this.chckbxBuscarNumeroOartida) {
            this.lblIconoChck_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lblIconoChck_nuevaPartida));
            this.lblIconoChck_buscarNumeroPartida.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lblIconoChck_buscarNumeroPartida));
            this.jp_cuentasContables.setVisible(true);
            this.jp_partidasContables.setVisible(false);
            this.jp_partidaContable.setVisible(true);
            this.jp_detalle.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(37.04), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.04), this.ajustes.alto - this.ajustes.calcularPuntoY(58.33));
            this.scrollPane_1.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(58.33));
        }
        else if (!this.chckbxNuevaPartida && this.chckbxBuscarNumeroOartida) {
            this.lblIconoChck_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lblIconoChck_nuevaPartida));
            this.lblIconoChck_buscarNumeroPartida.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lblIconoChck_buscarNumeroPartida));
            this.jp_cuentasContables.setVisible(false);
            this.jp_partidasContables.setVisible(true);
            this.jp_partidaContable.setVisible(false);
            this.jp_detalle.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(23.15), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(44.44));
            this.scrollPane_1.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(44.44));
        }
    }
    
    public void configurarTabla(final int op) {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        switch (op) {
            case 0: {
                final TableColumnModel columnModel = this.tblCuentas.getColumnModel();
                header = this.tblCuentas.getTableHeader();
                header.setFont(fuente);
                header.setForeground(Variables.color_dos);
                alinear.setHorizontalAlignment(0);
                columnModel.getColumn(0).setPreferredWidth(90);
                columnModel.getColumn(0).setCellRenderer(alinear);
                columnModel.getColumn(1).setPreferredWidth(200);
                break;
            }
            case 1: {
                final TableColumnModel columnModel = this.tblDetalle.getColumnModel();
                header = this.tblDetalle.getTableHeader();
                header.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
                header.setForeground(Variables.color_dos);
                alinear.setHorizontalAlignment(0);
                columnModel.getColumn(0).setPreferredWidth(100);
                columnModel.getColumn(0).setCellRenderer(alinear);
                columnModel.getColumn(1).setPreferredWidth(170);
                columnModel.getColumn(2).setPreferredWidth(100);
                columnModel.getColumn(3).setPreferredWidth(40);
                columnModel.getColumn(3).setCellRenderer(alinear);
                columnModel.getColumn(4).setPreferredWidth(40);
                columnModel.getColumn(4).setCellRenderer(alinear);
                break;
            }
            case 2: {
                final TableColumnModel columnModel = this.tblPartidasContables.getColumnModel();
                header = this.tblPartidasContables.getTableHeader();
                header.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31))));
                header.setForeground(Variables.color_dos);
                alinear.setHorizontalAlignment(0);
                columnModel.getColumn(0).setPreferredWidth(20);
                columnModel.getColumn(0).setCellRenderer(alinear);
                columnModel.getColumn(1).setPreferredWidth(195);
                columnModel.getColumn(2).setPreferredWidth(75);
                columnModel.getColumn(2).setCellRenderer(alinear);
                break;
            }
        }
    }
    
    public void llenarCampos() {
        this.banderaTablaNuevaPartida = 1;
        this.banderaTablaCatalogoPartida = 0;
        this.txtObservacion.requestFocus();
        this.obtenerCorrelativoCheque(this.cbxBanco.getSelectedItem().toString());
        this.txtFechaContable.setText(Variables.fechaSistema);
        this.txtFechaDocumento.setText(Variables.fechaActual);
        this.txtNumeroPartida.setText(this.consultaSql.obtenerNumeroPartidaContable());
        this.tblCuentas.setModel(this.consultaSql.llenarTablaCuentasContables_nuevaPartida(this.consultaSql.obtenerIDOficina(Variables.nombreOficina)));
        this.configurarTabla(0);
        this.tblPartidasContables.setModel(this.consultaSql.llenarTablaPartidasContablesMontos(Variables.idOficina));
        this.configurarTabla(2);
    }
    
    public void buscarCuenta(final String nombreCuenta) {
        this.tblCuentas.setModel(this.consultaSql.llenarTablaCuentasContables_nombre(nombreCuenta, this.consultaSql.obtenerIDOficina(Variables.nombreOficina)));
        this.configurarTabla(0);
    }
    
    public void obtenerCorrelativoCheque(final String nombreBanco) {
        try {
            final int numeroCheque = Integer.parseInt(this.consultaSql.obtenerCorrelativoCheque(nombreBanco, Variables.idOficina)) + 1;
            this.txtNumeroCheque.setText(Integer.toString(numeroCheque));
            this.txtCuenta.setText(this.consultaSql.cuentaContableBanco);
            this.txtDescripcion.setText(this.consultaSql.nombreCuentaContableBanco);
            this.txtCargo.requestFocus();
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No hay bancos ingresado para la oficina " + Variables.nombreOficina + " -- " + e.toString(), "ERROR!", 0);
        }
    }
    
    public void seleccionarPartida() {
        this.txtNumeroPartida.setText(this.tblPartidasContables.getValueAt(this.tblPartidasContables.getSelectedRow(), 0).toString());
        this.tblDetalle.setModel(this.consultaSql.llenarTablaPartidaContableModificar(Integer.parseInt(this.tblPartidasContables.getValueAt(this.tblPartidasContables.getSelectedRow(), 0).toString()), Variables.idOficina));
        Double cargo = 0.0;
        Double abono = 0.0;
        for (int i = 0; i < this.tblDetalle.getRowCount(); ++i) {
            cargo += Double.parseDouble(this.tblDetalle.getValueAt(i, 3).toString());
            abono += Double.parseDouble(this.tblDetalle.getValueAt(i, 4).toString());
        }
        this.txtCargoTotal.setText(Double.toString(cargo));
        this.txtAbonoTotal.setText(Double.toString(abono));
        this.banderaGuardar = 1;
        this.banderaTablaCatalogoPartida = 1;
        this.banderaTablaNuevaPartida = 0;
        this.consultaSql.obtenerInfoPartidaCreada(Integer.parseInt(this.tblPartidasContables.getValueAt(this.tblPartidasContables.getSelectedRow(), 0).toString()), Variables.idOficina);
        this.montoCheque = this.consultaSql.monto;
        this.txtObservacion.setText(this.consultaSql.descripcionPartidaCreada);
    }
    
    public void guardar() {
        if (this.banderaGuardar == 0) {
            JOptionPane.showMessageDialog(null, "Debe trabajar la partida o seleccionar una", "ERROR!", 0);
            return;
        }
        if (Double.parseDouble(this.txtCargoTotal.getText().toString()) > Double.parseDouble(this.txtAbonoTotal.getText().toString()) || Double.parseDouble(this.txtCargoTotal.getText().toString()) < Double.parseDouble(this.txtAbonoTotal.getText().toString())) {
            JOptionPane.showMessageDialog(null, "Los montos Cargo y Abono no cuadran, favor de revisar", "ERROR!", 0);
            return;
        }
        if (this.banderaImprimir == 1) {
            JOptionPane.showMessageDialog(null, "Partida N°" + this.txtNumeroPartida.getText().toString() + " ya fue guardada", "ALERTA!", 2);
            return;
        }
        if (this.txtNombreCheque.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "No puede dejar el campo vacio.", "ERROR!", 0);
            this.lblNombreCheque.setForeground(Color.RED);
            this.txtNombreCheque.requestFocus();
            return;
        }
        if (this.banderaTablaNuevaPartida == 1 && this.banderaTablaCatalogoPartida == 0) {
            boolean resultado = false;
            final int idBanco = Integer.parseInt(this.consultaSql.obtenerIdBanco(Variables.idOficina, this.cbxBanco.getSelectedItem().toString()));
            final int partidaContable = this.consultaSql.obtenerSigIdPartidaContable();
            if (String.valueOf(partidaContable) == this.txtNumeroPartida.getText()) {
                resultado = this.contabilidad.partidaContable(partidaContable, this.tblDetalle, this.txtObservacion.getText(), this.txtFechaDocumento.getText(), this.txtFechaContable.getText(), "", idBanco, this.txtNombreCheque.getText(), this.txtNumeroCheque.getText());
            }
            else {
                this.txtNumeroPartida.setText(String.valueOf(partidaContable));
                JOptionPane.showMessageDialog(null, "La Partida N°" + this.txtNumeroPartida.getText().toString() + " ya fue utilizada por otro usuario, se cambio al Nº" + this.txtNumeroPartida.getText(), "ALERTA!", 2);
                resultado = this.contabilidad.partidaContable(partidaContable, this.tblDetalle, this.txtObservacion.getText(), this.txtFechaDocumento.getText(), this.txtFechaContable.getText(), "", idBanco, this.txtNombreCheque.getText(), this.txtNumeroCheque.getText());
            }
            if (!resultado) {
                JOptionPane.showMessageDialog(null, "Ingreso de partida erroneo -- " + Variables.error, "ERROR!", 0);
                return;
            }
            if (this.contabilidad.modificarCorrelativo(this.txtNumeroCheque.getText(), idBanco)) {
                if (!this.contabilidad.insertarCheque(Integer.parseInt(this.txtNumeroPartida.getText()), idBanco, this.txtNumeroCheque.getText(), this.txtNombreCheque.getText(), this.montoCheque, Variables.fechaActual, this.txtObservacion.getText())) {
                    JOptionPane.showMessageDialog(null, "Al momento de ingresar el cheque", "ERROR!", 0);
                    return;
                }
                JOptionPane.showMessageDialog(null, "Cheque N°" + this.txtNumeroCheque.getText().toString() + " a nombre de " + this.txtNombreCheque.getText() + " guardado correctamente.", "OK!", 1);
                this.banderaImprimir = 1;
            }
        }
        if (this.banderaTablaNuevaPartida == 0 && this.banderaTablaCatalogoPartida == 1) {
            if (!this.contabilidad.agregarComprobante_madificarPartida(this.txtNumeroCheque.getText(), this.txtFechaDocumento.getText(), Integer.parseInt(this.txtNumeroPartida.getText()), Variables.idOficina, this.tblDetalle, Integer.parseInt(this.consultaSql.obtenerIdBanco(Variables.idOficina, this.cbxBanco.getSelectedItem().toString())), this.txtNombreCheque.getText(), this.cbxBanco.getSelectedItem().toString(), this.montoCheque, this.txtObservacion.getText())) {
                JOptionPane.showMessageDialog(null, "Al momento de ingresar el cheque", "ERROR!", 0);
                return;
            }
            JOptionPane.showMessageDialog(null, "Cheque N°" + this.txtNumeroCheque.getText().toString() + " a nombre de " + this.txtNombreCheque.getText() + " guardado correctamente.", "OK!", 1);
            this.banderaImprimir = 1;
        }
    }
    
    public void llenarTabla() {
        final Object[] object = { this.txtCuenta.getText(), this.txtDescripcion.getText(), "", this.txtCargo.getText(), this.txtAbono.getText() };
        this.modeloTblDetalle.addRow(object);
        final double cargo = Double.parseDouble(this.txtCargo.getText().toString());
        final double abono = Double.parseDouble(this.txtAbono.getText().toString());
        this.montoCargo += cargo;
        this.montoAbono += abono;
        this.txtCargoTotal.setText(Double.toString(this.montoCargo));
        this.txtAbonoTotal.setText(Double.toString(this.montoAbono));
        this.txtCuenta.requestFocus();
        this.txtCuenta.setEditable(true);
        this.txtCuenta.setText("");
        this.txtDescripcion.setEditable(true);
        this.txtDescripcion.setText("");
        this.txtDescripcion.setText("");
        this.txtCargo.setText("0.00");
        this.txtAbono.setText("0.00");
    }
    
    public void seleccionarCuenta(final String cuenta, final String descrip) {
        final int resultado = this.consultaSql.verificarCuentaContable(cuenta);
        if (resultado > 0) {
            JOptionPane.showMessageDialog(null, "La Cuenta '" + cuenta + " - " + descrip + " Tiene Sub-Cuentas", "ERROR!", 0);
            return;
        }
        this.txtCuenta.setText(cuenta);
        this.txtDescripcion.setText(descrip);
        this.txtCargo.requestFocus();
        this.txtCargo.setText("");
    }
}
