// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Contabilidad;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevoBanco extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Contabilidad contabilidad;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaBanco;
    private JLabel btnNuevaBanco;
    private JLabel lblIconoBtn_nuevaBanco;
    private JLabel lblNombreBtn_nuevaBanco;
    private JPanel jp_btnBuscarBanco;
    private JLabel btnBuscarBanco;
    private JLabel lblIconoBtn_buscarBanco;
    private JLabel lblNombreBtn_buscarBanco;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblNuevoBanco;
    private JPanel jp_infoBanco;
    private JTextField txtOficina;
    private JTextField txtFechaContable;
    private JTextField txtFechaDocumento;
    private JLabel lblNombreBanco;
    private JTextField txtNombreBanco;
    private JLabel lblTipoCuenta;
    private JLabel lblCuentaBancaria;
    private JTextField txtCuentaBancaria;
    private JLabel lblCuentaContable;
    private JTextField txtCuentaContable;
    private JLabel lblDescripcion;
    private JTextField txtDescripcion;
    private JLabel lblBuscarCuenta;
    private JTextField txtBuscar;
    private JPanel jp_btnBuscar;
    private JLabel btnBuscar;
    private JLabel lblIconoBtn_buscar;
    private JLabel lblNombreBtn_buscar;
    private JPanel jp_tblCuentas;
    private JScrollPane scrollPane;
    private JTable tblCuentas;
    private JLabel lblCorrelativoCheque;
    private JTextField txtCorrelativoCheque;
    private JComboBox<Object> cbxTipoCuenta;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevoBanco frame = new NuevoBanco();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevoBanco() {
        this.ajustes = new Ajustes();
        this.contabilidad = new F_Contabilidad();
        this.consultaSql = new consultasSQL_SERVER();
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevoBanco.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaBanco = new JPanel()).setLayout(null);
        this.jp_btnNuevaBanco.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaBanco.setBackground(Variables.color_tres);
        this.jp_btnNuevaBanco.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaBanco);
        (this.btnNuevaBanco = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaBanco.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaBanco.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnNuevaBanco.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaBanco.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnNuevaBanco.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaBanco.add(this.btnNuevaBanco);
        (this.lblIconoBtn_nuevaBanco = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaBanco.setIcon(this.ajustes.ajustarImagen_("/images/botones-12-icono-nuevoBanco.png", this.lblIconoBtn_nuevaBanco));
        this.jp_btnNuevaBanco.add(this.lblIconoBtn_nuevaBanco);
        (this.lblNombreBtn_nuevaBanco = new JLabel("Nuevo")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaBanco.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaBanco.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaBanco.add(this.lblNombreBtn_nuevaBanco);
        (this.jp_btnBuscarBanco = new JPanel()).setLayout(null);
        this.jp_btnBuscarBanco.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarBanco.setBackground(Variables.color_tres);
        this.jp_btnBuscarBanco.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarBanco);
        (this.btnBuscarBanco = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarBanco.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarBanco.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnBuscarBanco.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarBanco.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnBuscarBanco.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarBanco.add(this.btnBuscarBanco);
        (this.lblIconoBtn_buscarBanco = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarBanco.setIcon(this.ajustes.ajustarImagen_("/images/botones-13-icono-buscarBanco.png", this.lblIconoBtn_buscarBanco));
        this.jp_btnBuscarBanco.add(this.lblIconoBtn_buscarBanco);
        (this.lblNombreBtn_buscarBanco = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarBanco.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarBanco.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarBanco.add(this.lblNombreBtn_buscarBanco);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoBanco.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoBanco.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblNuevoBanco = new JLabel("Ingreso de Nuevo Banco")).setForeground(Variables.color_uno);
        this.lblNuevoBanco.setHorizontalAlignment(0);
        this.lblNuevoBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNuevoBanco.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblNuevoBanco);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JPanel jp_cuentas = new JPanel();
        jp_cuentas.setBackground(Variables.color_uno);
        jp_cuentas.setBorder(new BevelBorder(0, null, null, null, null));
        jp_cuentas.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.alto - this.ajustes.calcularPuntoY(21.76));
        jp_contenido.add(jp_cuentas);
        jp_cuentas.setLayout(null);
        (this.lblBuscarCuenta = new JLabel("Buscar Cuenta Contable")).setHorizontalAlignment(0);
        this.lblBuscarCuenta.setForeground(Variables.color_dos);
        this.lblBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        jp_cuentas.add(this.lblBuscarCuenta);
        (this.txtBuscar = new JTextField()).setForeground(Variables.color_dos);
        this.txtBuscar.setColumns(10);
        this.txtBuscar.setBackground(Color.WHITE);
        this.txtBuscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscar.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(3.43), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(6.25), this.ajustes.calcularPuntoY(2.78));
        jp_cuentas.add(this.txtBuscar);
        (this.jp_btnBuscar = new JPanel()).setLayout(null);
        this.jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscar.setBackground(Variables.color_tres);
        this.jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(3.43), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        jp_cuentas.add(this.jp_btnBuscar);
        (this.btnBuscar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnBuscar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoBanco.this.buscarCuenta("%" + NuevoBanco.this.txtBuscar.getText().toString() + "%");
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoBanco.this.jp_btnBuscar.setBackground(Variables.color_dos);
            }
        });
        this.btnBuscar.setBounds(0, 0, this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), 0, this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/general-16-icono-buscar.png", this.lblIconoBtn_buscar));
        this.jp_btnBuscar.add(this.lblIconoBtn_buscar);
        (this.lblNombreBtn_buscar = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscar.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.8))));
        this.lblNombreBtn_buscar.setBounds(this.ajustes.calcularPuntoX(1.58), 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar.add(this.lblNombreBtn_buscar);
        final JSeparator separator_1 = new JSeparator();
        separator_1.setBounds(this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(7.13), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(0.19));
        jp_cuentas.add(separator_1);
        (this.jp_tblCuentas = new JPanel()).setLayout(null);
        this.jp_tblCuentas.setBorder(new BevelBorder(1, null, null, null, null));
        this.jp_tblCuentas.setBackground(Color.WHITE);
        this.jp_tblCuentas.setBounds(this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(8.06), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(31.48));
        jp_cuentas.add(this.jp_tblCuentas);
        (this.scrollPane = new JScrollPane()).setBackground(Color.WHITE);
        this.scrollPane.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.08), this.ajustes.alto - this.ajustes.calcularPuntoY(31.48));
        this.jp_tblCuentas.add(this.scrollPane);
        (this.tblCuentas = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblCuentas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevoBanco.this.seleccionarCuenta((String)NuevoBanco.this.tblCuentas.getValueAt(NuevoBanco.this.tblCuentas.getSelectedRow(), 0), (String)NuevoBanco.this.tblCuentas.getValueAt(NuevoBanco.this.tblCuentas.getSelectedRow(), 1));
            }
        });
        this.tblCuentas.setForeground(Variables.color_dos);
        this.tblCuentas.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.scrollPane.setViewportView(this.tblCuentas);
        (this.jp_infoBanco = new JPanel()).setOpaque(false);
        this.jp_infoBanco.setBounds((this.ajustes.ancho - 25) / 10 * 4 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.alto - this.ajustes.calcularPuntoY(21.76));
        jp_contenido.add(this.jp_infoBanco);
        this.jp_infoBanco.setLayout(null);
        final JLabel lblOficina = new JLabel("Nombre de Oficina:");
        lblOficina.setForeground(Variables.color_uno);
        lblOficina.setHorizontalAlignment(0);
        lblOficina.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblOficina.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(lblOficina);
        (this.txtOficina = new JTextField()).setEditable(false);
        this.txtOficina.setBackground(Variables.color_uno);
        this.txtOficina.setForeground(Variables.color_dos);
        this.txtOficina.setHorizontalAlignment(0);
        this.txtOficina.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtOficina.setBounds(0, this.ajustes.calcularPuntoY(1.85), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtOficina);
        this.txtOficina.setColumns(10);
        final JLabel lblFechaContable = new JLabel("Fecha Contable:");
        lblFechaContable.setHorizontalAlignment(0);
        lblFechaContable.setForeground(Variables.color_uno);
        lblFechaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaContable.setBounds(0, this.ajustes.calcularPuntoY(5.09), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.72), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(lblFechaContable);
        (this.txtFechaContable = new JTextField()).setEditable(false);
        this.txtFechaContable.setBackground(Variables.color_uno);
        this.txtFechaContable.setForeground(Variables.color_dos);
        this.txtFechaContable.setHorizontalAlignment(0);
        this.txtFechaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaContable.setBounds(0, this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.72), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtFechaContable);
        this.txtFechaContable.setColumns(10);
        final JLabel lblFechaDocumento = new JLabel("Fecha Documento:");
        lblFechaDocumento.setHorizontalAlignment(0);
        lblFechaDocumento.setForeground(Variables.color_uno);
        lblFechaDocumento.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.63), this.ajustes.calcularPuntoY(5.09), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.72), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(lblFechaDocumento);
        (this.txtFechaDocumento = new JTextField()).setEditable(false);
        this.txtFechaDocumento.setBackground(Variables.color_uno);
        this.txtFechaDocumento.setHorizontalAlignment(0);
        this.txtFechaDocumento.setForeground(Variables.color_dos);
        this.txtFechaDocumento.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.63), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.72), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtFechaDocumento);
        this.txtFechaDocumento.setColumns(10);
        (this.lblNombreBanco = new JLabel("Nombre de Banco:")).setHorizontalAlignment(0);
        this.lblNombreBanco.setForeground(Variables.color_uno);
        this.lblNombreBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBanco.setBounds(0, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(this.lblNombreBanco);
        (this.txtNombreBanco = new JTextField()).setHorizontalAlignment(0);
        this.txtNombreBanco.setForeground(Variables.color_dos);
        this.txtNombreBanco.setColumns(10);
        this.txtNombreBanco.setBackground(Variables.color_uno);
        this.txtNombreBanco.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreBanco.setBounds(0, this.ajustes.calcularPuntoY(12.5), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtNombreBanco);
        (this.lblTipoCuenta = new JLabel("Tipo de Cuenta:")).setHorizontalAlignment(0);
        this.lblTipoCuenta.setForeground(Variables.color_uno);
        this.lblTipoCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblTipoCuenta.setBounds(0, this.ajustes.calcularPuntoY(15.74), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.lblTipoCuenta);
        (this.cbxTipoCuenta = new JComboBox<Object>()).setCursor(Cursor.getPredefinedCursor(12));
        this.cbxTipoCuenta.setModel(new DefaultComboBoxModel<Object>(new String[] { "CORRIENTE", "AHORROS" }));
        this.cbxTipoCuenta.setBackground(Variables.color_uno);
        this.cbxTipoCuenta.setForeground(Variables.color_dos);
        this.cbxTipoCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxTipoCuenta.setBounds(0, this.ajustes.calcularPuntoY(18.06), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.72), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.cbxTipoCuenta);
        (this.lblCorrelativoCheque = new JLabel("Correlativo de Cheques:")).setHorizontalAlignment(0);
        this.lblCorrelativoCheque.setForeground(Variables.color_uno);
        this.lblCorrelativoCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCorrelativoCheque.setBounds((this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.63), this.ajustes.calcularPuntoY(16.2), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.72), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(this.lblCorrelativoCheque);
        (this.txtCorrelativoCheque = new JTextField()).setText("0");
        this.txtCorrelativoCheque.setHorizontalAlignment(0);
        this.txtCorrelativoCheque.setForeground(Variables.color_dos);
        this.txtCorrelativoCheque.setEditable(false);
        this.txtCorrelativoCheque.setColumns(10);
        this.txtCorrelativoCheque.setBackground(Variables.color_uno);
        this.txtCorrelativoCheque.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCorrelativoCheque.setBounds((this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(0.63), this.ajustes.calcularPuntoY(18.06), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(1.72), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtCorrelativoCheque);
        (this.lblCuentaBancaria = new JLabel("Cuenta Bancaria:")).setHorizontalAlignment(0);
        this.lblCuentaBancaria.setForeground(Variables.color_uno);
        this.lblCuentaBancaria.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCuentaBancaria.setBounds(0, this.ajustes.calcularPuntoY(21.3), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(this.lblCuentaBancaria);
        (this.txtCuentaBancaria = new JTextField()).setHorizontalAlignment(0);
        this.txtCuentaBancaria.setForeground(Variables.color_dos);
        this.txtCuentaBancaria.setColumns(10);
        this.txtCuentaBancaria.setBackground(Variables.color_uno);
        this.txtCuentaBancaria.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuentaBancaria.setBounds(0, this.ajustes.calcularPuntoY(23.61), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtCuentaBancaria);
        (this.lblCuentaContable = new JLabel("Cuenta Contable:")).setHorizontalAlignment(0);
        this.lblCuentaContable.setForeground(Variables.color_uno);
        this.lblCuentaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCuentaContable.setBounds(0, this.ajustes.calcularPuntoY(26.85), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(this.lblCuentaContable);
        (this.txtCuentaContable = new JTextField()).setHorizontalAlignment(0);
        this.txtCuentaContable.setForeground(Variables.color_dos);
        this.txtCuentaContable.setColumns(10);
        this.txtCuentaContable.setBackground(Variables.color_uno);
        this.txtCuentaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuentaContable.setBounds(0, this.ajustes.calcularPuntoY(28.7), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtCuentaContable);
        (this.lblDescripcion = new JLabel("Descripcion:")).setHorizontalAlignment(0);
        this.lblDescripcion.setForeground(Variables.color_uno);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds(0, this.ajustes.calcularPuntoY(31.94), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(1.85));
        this.jp_infoBanco.add(this.lblDescripcion);
        (this.txtDescripcion = new JTextField()).setHorizontalAlignment(0);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setColumns(10);
        this.txtDescripcion.setBackground(Variables.color_uno);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setBounds(0, this.ajustes.calcularPuntoY(33.8), (this.ajustes.ancho - 25) / 10 * 6 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(2.78));
        this.jp_infoBanco.add(this.txtDescripcion);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void llenarCampos() {
        this.txtOficina.setText(Variables.nombreOficina);
        this.txtFechaContable.setText(Variables.fechaSistema);
        this.txtFechaDocumento.setText(Variables.fechaActual);
        this.tblCuentas.setModel(this.consultaSql.llenarTablaCuentasContables_nuevaPartida(this.consultaSql.obtenerIDOficina(Variables.nombreOficina)));
        this.configurarTabla();
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        final TableColumnModel columnModel = this.tblCuentas.getColumnModel();
        header = this.tblCuentas.getTableHeader();
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(90);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(500);
    }
    
    public void seleccionarCuenta(final String cuenta, final String descripcion) {
        final int resultado = this.consultaSql.verificarCuentaContable(cuenta);
        if (resultado > 0) {
            JOptionPane.showMessageDialog(null, "La Cuenta '" + cuenta + " - " + descripcion + " Tiene Sub-Cuentas", "ERROR!", 0);
            return;
        }
        this.txtCuentaContable.setText(cuenta);
        this.txtDescripcion.setText(descripcion);
    }
    
    public void buscarCuenta(final String nombreCuenta) {
        this.tblCuentas.setModel(this.consultaSql.llenarTablaCuentasContables_nombre(nombreCuenta, this.consultaSql.obtenerIDOficina(Variables.nombreOficina)));
        this.configurarTabla();
    }
    
    public void guardar() {
        int banderaError = 0;
        if (this.txtNombreBanco.getText().length() == 0) {
            this.lblNombreBanco.setForeground(Color.RED);
            ++banderaError;
        }
        if (this.txtCuentaBancaria.getText().length() == 0) {
            this.lblCuentaBancaria.setForeground(Color.RED);
            ++banderaError;
        }
        if (this.txtCuentaContable.getText().length() == 0) {
            this.lblCuentaContable.setForeground(Color.RED);
            ++banderaError;
        }
        if (this.txtDescripcion.getText().length() == 0) {
            this.lblDescripcion.setForeground(Color.RED);
            ++banderaError;
        }
        if (banderaError > 0) {
            JOptionPane.showMessageDialog(null, "Estos campos no pueden estar vacio.", "ERROR!", 0);
            return;
        }
        if (this.contabilidad.insertarBanco(1, this.txtNombreBanco.getText(), this.cbxTipoCuenta.getSelectedItem().toString(), this.txtCuentaBancaria.getText(), this.consultaSql.obtenerIdCuentaContable(this.txtCuentaContable.getText(), Variables.idOficina), this.txtCuentaContable.getText(), 0, Integer.parseInt(this.txtCorrelativoCheque.getText()), Variables.idUsuario, Variables.fechaActual)) {
            JOptionPane.showMessageDialog(null, "Banco '" + this.txtNombreBanco.getText() + "' guardado correctamente.", "OK!", 1);
            return;
        }
        JOptionPane.showMessageDialog(null, "Banco '" + this.txtNombreBanco.getText() + "' no se pudo guardar -- " + Variables.error, "ERROR!", 0);
    }
}
