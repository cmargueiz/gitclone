// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.updateSQL_SERVER;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ModificarPartidaContable extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultasSql;
    public updateSQL_SERVER updateSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JTextField txtNumeroPartida;
    private JTextField txtDescripcionPartida;
    private JTextField txtFechaContablePartida;
    private JTextField txtNombreUsuario;
    private JPanel jp_tblDetallePartida;
    private JTextField txtAbonoTotal;
    private JTextField txtCargoTotal;
    private JPanel jp_tblCuentasContables;
    private JLabel lblBuscarCuenta;
    private JTextField txtBuscarCuenta;
    private JSeparator separator_2;
    private JPanel jp_tblCuentas;
    private JScrollPane scrollPane;
    private JLabel lblCuentaContable;
    private JTextField txtCuentaContable;
    private JLabel lblDescripcionCuenta;
    private JTextField txtDescripcionCuenta;
    private JLabel lblFechaContable;
    private JTextField txtFechaContable;
    private JLabel lblCargo;
    private JTextField txtCargo;
    private JLabel lblAbono;
    private JTextField txtAbono;
    private JPanel jp_btnAplicar;
    private JLabel lblIconoBtn_aplicar;
    private JLabel lblNombreBtn_aplicar;
    private JLabel btnAplicar;
    private JTable tblDetallePartida;
    public int filaSeleccionada;
    public int banderaModificada;
    public int banderaImprimir;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ModificarPartidaContable frame = new ModificarPartidaContable();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ModificarPartidaContable() {
        this.ajustes = new Ajustes();
        this.consultasSql = new consultasSQL_SERVER();
        this.updateSql = new updateSQL_SERVER();
        this.filaSeleccionada = 0;
        this.banderaModificada = 0;
        this.banderaImprimir = 0;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ModificarPartidaContable.this.cargarDetallePartida();
                ModificarPartidaContable.this.jp_tblCuentasContables.setVisible(false);
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaPartida = new JPanel()).setLayout(null);
        this.jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
        this.jp_btnNuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaPartida);
        (this.btnNuevaPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaPartida.add(this.btnNuevaPartida);
        (this.lblIconoBtn_nuevaPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaPartida));
        this.jp_btnNuevaPartida.add(this.lblIconoBtn_nuevaPartida);
        (this.lblNombreBtn_nuevaPartida = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaPartida.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaPartida.add(this.lblNombreBtn_nuevaPartida);
        (this.jp_btnBuscarPartida = new JPanel()).setLayout(null);
        this.jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
        this.jp_btnBuscarPartida.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarPartida);
        (this.btnBuscarPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarPartida.add(this.btnBuscarPartida);
        (this.lblIconoBtn_buscarPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarPartida));
        this.jp_btnBuscarPartida.add(this.lblIconoBtn_buscarPartida);
        (this.lblNombreBtn_buscarPartida = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarPartida.add(this.lblNombreBtn_buscarPartida);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ModificarPartidaContable.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ModificarPartidaContable.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        final JLabel lblModificarCuentaContable = new JLabel("Modificar Cuenta Contable");
        lblModificarCuentaContable.setForeground(Variables.color_uno);
        lblModificarCuentaContable.setHorizontalAlignment(0);
        lblModificarCuentaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        lblModificarCuentaContable.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(lblModificarCuentaContable);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JLabel lblPartidaSeleccionada = new JLabel("Numero de Partida:");
        lblPartidaSeleccionada.setForeground(Variables.color_uno);
        lblPartidaSeleccionada.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblPartidaSeleccionada.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(5.56), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblPartidaSeleccionada);
        (this.txtNumeroPartida = new JTextField()).setHorizontalAlignment(0);
        this.txtNumeroPartida.setForeground(Variables.color_dos);
        this.txtNumeroPartida.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNumeroPartida.setEditable(false);
        this.txtNumeroPartida.setColumns(10);
        this.txtNumeroPartida.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(5.09), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNumeroPartida);
        final JLabel lblDescripcion = new JLabel("Descripci\u00f3n:");
        lblDescripcion.setHorizontalAlignment(0);
        lblDescripcion.setForeground(Variables.color_uno);
        lblDescripcion.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblDescripcion.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(5.56), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblDescripcion);
        (this.txtDescripcionPartida = new JTextField()).setForeground(Variables.color_dos);
        this.txtDescripcionPartida.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcionPartida.setEditable(false);
        this.txtDescripcionPartida.setColumns(10);
        this.txtDescripcionPartida.setBounds((this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(5.09), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcionPartida);
        final JLabel lblFechaPartidaSeleccinada = new JLabel("Fecha Contable:");
        lblFechaPartidaSeleccinada.setHorizontalAlignment(0);
        lblFechaPartidaSeleccinada.setForeground(Variables.color_uno);
        lblFechaPartidaSeleccinada.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaPartidaSeleccinada.setBounds((this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(5.56), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblFechaPartidaSeleccinada);
        (this.txtFechaContablePartida = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaContablePartida.setForeground(Variables.color_dos);
        this.txtFechaContablePartida.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaContablePartida.setEditable(false);
        this.txtFechaContablePartida.setColumns(10);
        this.txtFechaContablePartida.setBounds((this.ajustes.ancho - 25) / 10 * 7, this.ajustes.calcularPuntoY(5.09), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaContablePartida);
        final JLabel lblNombreUsuarioPartidaSeleccionada = new JLabel("Nombre de Usuario:");
        lblNombreUsuarioPartidaSeleccionada.setHorizontalAlignment(0);
        lblNombreUsuarioPartidaSeleccionada.setForeground(Variables.color_uno);
        lblNombreUsuarioPartidaSeleccionada.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreUsuarioPartidaSeleccionada.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(5.56), this.ajustes.ancho / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNombreUsuarioPartidaSeleccionada);
        (this.txtNombreUsuario = new JTextField()).setHorizontalAlignment(0);
        this.txtNombreUsuario.setForeground(Variables.color_dos);
        this.txtNombreUsuario.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreUsuario.setEditable(false);
        this.txtNombreUsuario.setColumns(10);
        this.txtNombreUsuario.setBounds((this.ajustes.ancho - 25) / 10 * 9, this.ajustes.calcularPuntoY(5.09), this.ajustes.ancho / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreUsuario);
        (this.jp_tblDetallePartida = new JPanel()).setBackground(Variables.color_uno);
        this.jp_tblDetallePartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_tblDetallePartida.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(68.06));
        jp_contenido.add(this.jp_tblDetallePartida);
        this.jp_tblDetallePartida.setLayout(null);
        final JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(66.2));
        this.jp_tblDetallePartida.add(scrollPane_1);
        (this.tblDetallePartida = new JTable()).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                ModificarPartidaContable.this.seleccionarMovimiento();
            }
        });
        this.tblDetallePartida.setBackground(Variables.color_uno);
        this.tblDetallePartida.setForeground(Variables.color_dos);
        this.tblDetallePartida.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        scrollPane_1.setViewportView(this.tblDetallePartida);
        final JLabel lblTotal = new JLabel("TOTAL");
        lblTotal.setHorizontalAlignment(4);
        lblTotal.setForeground(Variables.color_uno);
        lblTotal.setFont(new Font("Book Antiqua", 1, 20));
        lblTotal.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(78.7), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblTotal);
        (this.txtCargoTotal = new JTextField()).setEditable(false);
        this.txtCargoTotal.setHorizontalAlignment(0);
        this.txtCargoTotal.setForeground(Variables.color_dos);
        this.txtCargoTotal.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCargoTotal.setBounds(this.ajustes.ancho / 10 * 2, this.ajustes.calcularPuntoY(78.7), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCargoTotal);
        this.txtCargoTotal.setColumns(10);
        (this.txtAbonoTotal = new JTextField()).setEditable(false);
        this.txtAbonoTotal.setHorizontalAlignment(0);
        this.txtAbonoTotal.setForeground(Variables.color_dos);
        this.txtAbonoTotal.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtAbonoTotal.setBounds(this.ajustes.ancho / 10 * 3, this.ajustes.calcularPuntoY(78.7), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtAbonoTotal);
        this.txtAbonoTotal.setColumns(10);
        final JLabel lblInformacionDetalle = new JLabel("Informaci\u00f3n del Movimiento Contable");
        lblInformacionDetalle.setHorizontalAlignment(0);
        lblInformacionDetalle.setForeground(Variables.color_uno);
        lblInformacionDetalle.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(2.78))));
        lblInformacionDetalle.setBounds((this.ajustes.ancho + 40) / 10 * 4, this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 40) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(lblInformacionDetalle);
        final JSeparator separator_1 = new JSeparator();
        separator_1.setBounds((this.ajustes.ancho + 60) / 10 * 4, this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 60) / 10 * 3, this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator_1);
        (this.lblCuentaContable = new JLabel("Cuenta Contable")).setHorizontalAlignment(0);
        this.lblCuentaContable.setForeground(Variables.color_uno);
        this.lblCuentaContable.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCuentaContable.setBounds((this.ajustes.ancho + 40) / 10 * 4, this.ajustes.calcularPuntoY(14.35), (this.ajustes.ancho - 40) / 10 * 3, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblCuentaContable);
        (this.txtCuentaContable = new JTextField()).setHorizontalAlignment(0);
        this.txtCuentaContable.setEditable(false);
        this.txtCuentaContable.setForeground(Variables.color_dos);
        this.txtCuentaContable.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuentaContable.setBounds((this.ajustes.ancho + 60) / 10 * 4, this.ajustes.calcularPuntoY(16.67), (this.ajustes.ancho - 60) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCuentaContable);
        this.txtCuentaContable.setColumns(10);
        (this.lblDescripcionCuenta = new JLabel("Descripci\u00f3n de Cuenta Contable")).setHorizontalAlignment(0);
        this.lblDescripcionCuenta.setForeground(Variables.color_uno);
        this.lblDescripcionCuenta.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcionCuenta.setBounds((this.ajustes.ancho + 40) / 10 * 4, this.ajustes.calcularPuntoY(20.37), (this.ajustes.ancho - 40) / 10 * 3, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescripcionCuenta);
        (this.txtDescripcionCuenta = new JTextField()).setForeground(Variables.color_dos);
        this.txtDescripcionCuenta.setFont(new Font("Book Antiqua", 0, this.ajustes.calcularPuntoY(2.78)));
        this.txtDescripcionCuenta.setEditable(false);
        this.txtDescripcionCuenta.setColumns(10);
        this.txtDescripcionCuenta.setBounds((this.ajustes.ancho + 60) / 10 * 4, this.ajustes.calcularPuntoY(22.69), (this.ajustes.ancho - 60) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcionCuenta);
        (this.lblFechaContable = new JLabel("Fecha Contable")).setHorizontalAlignment(0);
        this.lblFechaContable.setForeground(Variables.color_uno);
        this.lblFechaContable.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaContable.setBounds((this.ajustes.ancho + 40) / 10 * 4, this.ajustes.calcularPuntoY(26.39), (this.ajustes.ancho - 40) / 10 * 3, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaContable);
        (this.txtFechaContable = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaContable.setForeground(Variables.color_dos);
        this.txtFechaContable.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaContable.setEditable(false);
        this.txtFechaContable.setColumns(10);
        this.txtFechaContable.setBounds((this.ajustes.ancho + 60) / 10 * 4, this.ajustes.calcularPuntoY(28.7), (this.ajustes.ancho - 60) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaContable);
        (this.lblCargo = new JLabel("Cargo")).setHorizontalAlignment(0);
        this.lblCargo.setForeground(Variables.color_uno);
        this.lblCargo.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85)))));
        this.lblCargo.setBounds((this.ajustes.ancho + 40) / 10 * 4, this.ajustes.calcularPuntoY(32.41), (this.ajustes.ancho - 40) / 10 * 3 / 2, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblCargo);
        (this.txtCargo = new JTextField()).setHorizontalAlignment(0);
        this.txtCargo.setForeground(Variables.color_dos);
        this.txtCargo.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCargo.setColumns(10);
        this.txtCargo.setBounds((this.ajustes.ancho + 60) / 10 * 4, this.ajustes.calcularPuntoY(34.72), (this.ajustes.ancho - 60) / 10 * 3 / 2, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCargo);
        (this.lblAbono = new JLabel("Abono")).setHorizontalAlignment(0);
        this.lblAbono.setForeground(Variables.color_uno);
        this.lblAbono.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblAbono.setBounds((this.ajustes.ancho + 40) / 10 * 4 + (this.ajustes.ancho - 40) / 10 * 3 / 2, this.ajustes.calcularPuntoY(32.41), (this.ajustes.ancho - 40) / 10 * 3 / 2, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblAbono);
        (this.txtAbono = new JTextField()).setHorizontalAlignment(0);
        this.txtAbono.setForeground(Variables.color_dos);
        this.txtAbono.setFont(new Font("Book Antiqua", 0, 20));
        this.txtAbono.setColumns(10);
        this.txtAbono.setBounds((this.ajustes.ancho + 60) / 10 * 4 + (this.ajustes.ancho - 60) / 10 * 3 / 2 + this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(34.72), (this.ajustes.ancho - 60) / 10 * 3 / 2 - this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtAbono);
        (this.jp_btnAplicar = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnAplicar.setBounds((this.ajustes.ancho + 60) / 10 * 4, this.ajustes.calcularPuntoY(40.74), (this.ajustes.ancho - 60) / 10 * 3, this.ajustes.calcularPuntoY(8.8));
        jp_contenido.add(this.jp_btnAplicar);
        this.jp_btnAplicar.setLayout(null);
        (this.btnAplicar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnAplicar.setBackground(Variables.color_uno);
                ModificarPartidaContable.this.lblNombreBtn_aplicar.setForeground(Variables.color_dos);
                ModificarPartidaContable.this.lblIconoBtn_aplicar.setIcon(ModificarPartidaContable.this.ajustes.ajustarImagen_("/images/botones-09-icono-aplicar.png", ModificarPartidaContable.this.lblIconoBtn_aplicar));
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ModificarPartidaContable.this.modificarMovimiento();
            }
        });
        this.btnAplicar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ModificarPartidaContable.this.jp_btnAplicar.setBackground(Variables.color_dos);
                ModificarPartidaContable.this.lblNombreBtn_aplicar.setForeground(Variables.color_uno);
                ModificarPartidaContable.this.lblIconoBtn_aplicar.setIcon(ModificarPartidaContable.this.ajustes.ajustarImagen_("/images/botones-09-icono-aplicar-select.png", ModificarPartidaContable.this.lblIconoBtn_aplicar));
            }
        });
        this.btnAplicar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnAplicar.setBounds(0, 0, (this.ajustes.ancho - 60) / 10 * 3, this.ajustes.calcularPuntoY(8.8));
        this.jp_btnAplicar.add(this.btnAplicar);
        (this.lblIconoBtn_aplicar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(3.96), this.ajustes.calcularPuntoY(7.04));
        this.lblIconoBtn_aplicar.setIcon(this.ajustes.ajustarImagen_("/images/botones-09-icono-aplicar.png", this.lblIconoBtn_aplicar));
        this.jp_btnAplicar.add(this.lblIconoBtn_aplicar);
        (this.lblNombreBtn_aplicar = new JLabel("APLICAR CAMBIOS")).setForeground(Variables.color_dos);
        this.lblNombreBtn_aplicar.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
        this.lblNombreBtn_aplicar.setHorizontalAlignment(0);
        this.lblNombreBtn_aplicar.setBounds(this.ajustes.calcularPuntoX(4.43), 0, (this.ajustes.ancho - 60) / 10 * 3 - this.ajustes.calcularPuntoX(4.43), this.ajustes.calcularPuntoY(8.8));
        this.jp_btnAplicar.add(this.lblNombreBtn_aplicar);
        (this.jp_tblCuentasContables = new JPanel()).setBackground(Variables.color_uno);
        this.jp_tblCuentasContables.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_tblCuentasContables.setBounds(this.ajustes.ancho / 10 * 7 + this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoY(3.7), this.ajustes.calcularPuntoY(72.22));
        jp_contenido.add(this.jp_tblCuentasContables);
        this.jp_tblCuentasContables.setLayout(null);
        (this.lblBuscarCuenta = new JLabel("Buscar Cuenta Contable")).setHorizontalAlignment(0);
        this.lblBuscarCuenta.setForeground(Variables.color_dos);
        this.lblBuscarCuenta.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBuscarCuenta.setBounds(0, this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        this.jp_tblCuentasContables.add(this.lblBuscarCuenta);
        (this.txtBuscarCuenta = new JTextField()).setForeground(Variables.color_dos);
        this.txtBuscarCuenta.setFont(new Font("Book Antiqua", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscarCuenta.setColumns(10);
        this.txtBuscarCuenta.setBackground(Color.WHITE);
        this.txtBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(2.78));
        this.jp_tblCuentasContables.add(this.txtBuscarCuenta);
        (this.separator_2 = new JSeparator()).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.19));
        this.jp_tblCuentasContables.add(this.separator_2);
        (this.jp_tblCuentas = new JPanel()).setLayout(null);
        this.jp_tblCuentas.setBorder(new BevelBorder(1, null, null, null, null));
        this.jp_tblCuentas.setBackground(Color.WHITE);
        this.jp_tblCuentas.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(7.41), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(63.89));
        this.jp_tblCuentasContables.add(this.jp_tblCuentas);
        (this.scrollPane = new JScrollPane()).setBackground(Color.WHITE);
        this.scrollPane.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(63.89));
        this.jp_tblCuentas.add(this.scrollPane);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void cargarDetallePartida() {
        this.txtNumeroPartida.setText(Variables.numeroPartidaSeleccionada);
        this.txtDescripcionPartida.setText(Variables.descripcionPartidaSeleccionada);
        this.txtFechaContablePartida.setText(Variables.fechaContablePartidaSeleccionada);
        this.txtNombreUsuario.setText(Variables.usuarioPartidaContable);
        this.tblDetallePartida.setModel(this.consultasSql.llenarTablaPartidaContableModificar(Integer.parseInt(Variables.numeroPartidaSeleccionada), this.consultasSql.obtenerIDOficina(Variables.nombreOficina)));
        this.configurarTabla();
        Double totalCargo = 0.0;
        Double totalAbono = 0.0;
        for (int i = 0; i < this.tblDetallePartida.getRowCount(); ++i) {
            totalCargo += Double.parseDouble(this.tblDetallePartida.getValueAt(i, 3).toString());
            totalAbono += Double.parseDouble(this.tblDetallePartida.getValueAt(i, 4).toString());
        }
        this.txtCargoTotal.setText(Double.toString(totalCargo));
        this.txtAbonoTotal.setText(Double.toString(totalAbono));
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        final TableColumnModel columnModel = this.tblDetallePartida.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = this.tblDetallePartida.getTableHeader();
        final Font fuente = new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(150);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(300);
        columnModel.getColumn(2).setPreferredWidth(100);
        columnModel.getColumn(2).setCellRenderer(alinear);
        columnModel.getColumn(3).setPreferredWidth(75);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(75);
        columnModel.getColumn(4).setCellRenderer(alinear);
    }
    
    public void seleccionarMovimiento() {
        this.filaSeleccionada = this.tblDetallePartida.getSelectedRow();
        this.txtCuentaContable.setText((String)this.tblDetallePartida.getValueAt(this.tblDetallePartida.getSelectedRow(), 0));
        this.txtDescripcionCuenta.setText((String)this.tblDetallePartida.getValueAt(this.tblDetallePartida.getSelectedRow(), 1));
        this.txtFechaContable.setText((String)this.tblDetallePartida.getValueAt(this.tblDetallePartida.getSelectedRow(), 2));
        this.txtCargo.setText((String)this.tblDetallePartida.getValueAt(this.tblDetallePartida.getSelectedRow(), 3));
        this.txtAbono.setText((String)this.tblDetallePartida.getValueAt(this.tblDetallePartida.getSelectedRow(), 4));
        this.txtCargo.requestFocus();
    }
    
    public void modificarMovimiento() {
        this.tblDetallePartida.setValueAt(this.txtCargo.getText().toString(), this.filaSeleccionada, 3);
        this.tblDetallePartida.setValueAt(this.txtAbono.getText().toString(), this.filaSeleccionada, 4);
        this.txtCuentaContable.setText("");
        this.txtDescripcionCuenta.setText("");
        this.txtFechaContable.setText("");
        this.txtCargo.setText("");
        this.txtAbono.setText("");
        Double montoCargoModificado = 0.0;
        Double montoAbonoModificado = 0.0;
        for (int i = 0; i < this.tblDetallePartida.getRowCount(); ++i) {
            montoCargoModificado += Double.parseDouble(this.tblDetallePartida.getValueAt(i, 3).toString());
            montoAbonoModificado += Double.parseDouble(this.tblDetallePartida.getValueAt(i, 4).toString());
        }
        this.txtCargoTotal.setText(Double.toString(montoCargoModificado));
        this.txtAbonoTotal.setText(Double.toString(montoAbonoModificado));
        this.banderaModificada = 1;
    }
    
    public void guardar() {
        if (Double.parseDouble(this.txtCargoTotal.getText().toString()) > Double.parseDouble(this.txtAbonoTotal.getText().toString()) || Double.parseDouble(this.txtCargoTotal.getText().toString()) < Double.parseDouble(this.txtAbonoTotal.getText().toString())) {
            JOptionPane.showMessageDialog(null, "Los montos Cargo y Abono no cuadran, favor de revisar", "ERROR!", 0);
            return;
        }
        if (this.banderaModificada == 0) {
            JOptionPane.showMessageDialog(null, "Partida no ha sido modificada.", "ALERTA!", 2);
            return;
        }
        for (int i = 0; i < this.tblDetallePartida.getRowCount(); ++i) {
            if (Double.compare(this.consultasSql.obtenerCargoMovimientoContable(Integer.parseInt(Variables.numeroPartidaSeleccionada), this.tblDetallePartida.getValueAt(i, 0).toString()), Double.parseDouble(this.tblDetallePartida.getValueAt(i, 3).toString())) != 0) {
                final int resultado = this.updateSql.modificarCargoPartidaContable(Integer.parseInt(Variables.numeroPartidaSeleccionada), this.consultasSql.obtenerIdCuentaContable(this.tblDetallePartida.getValueAt(i, 0).toString(), this.consultasSql.obtenerIDOficina(Variables.nombreOficina)), Double.parseDouble(this.tblDetallePartida.getValueAt(i, 3).toString()), Variables.fechaActual);
                if (resultado != 1) {
                    JOptionPane.showMessageDialog(null, "Al modificar el cargo -- " + this.updateSql.error, "ERROR!", 0);
                    return;
                }
            }
            else if (Double.compare(this.consultasSql.obtenerAbonoMovimientoContable(Integer.parseInt(Variables.numeroPartidaSeleccionada), this.tblDetallePartida.getValueAt(i, 0).toString()), Double.parseDouble(this.tblDetallePartida.getValueAt(i, 4).toString())) != 0) {
                final int resultado = this.updateSql.modificarAbonoPartidaContable(Integer.parseInt(Variables.numeroPartidaSeleccionada), this.consultasSql.obtenerIdCuentaContable(this.tblDetallePartida.getValueAt(i, 0).toString(), this.consultasSql.obtenerIDOficina(Variables.nombreOficina)), Double.parseDouble(this.tblDetallePartida.getValueAt(i, 4).toString()), Variables.fechaActual);
                if (resultado != 1) {
                    JOptionPane.showMessageDialog(null, "Al modificar el abono -- " + this.updateSql.error, "ERROR!", 0);
                    return;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Partida N°" + Variables.numeroPartidaSeleccionada + " guardar exitosamente.", "OK!", 1);
        this.banderaImprimir = 1;
    }
}
