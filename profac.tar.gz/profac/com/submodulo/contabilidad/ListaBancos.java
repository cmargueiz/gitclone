// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaBancos extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevoBanco;
    private JLabel btnNuevoBanco;
    private JLabel lblIconoBtn_nuevoBanco;
    private JLabel lblNombreBtn_nuevoBanco;
    private JPanel jp_btnBuscarBanco;
    private JLabel btnBuscarBanco;
    private JLabel lblIconoBtn_buscarBanco;
    private JLabel lblNombreBtn_buscarBanco;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JTextField txtIdBanco;
    private JLabel lblNombreBanco;
    private JTextField txtNombreBanco;
    private JTable tblBancos;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaBancos frame = new ListaBancos();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaBancos() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaBancos.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevoBanco = new JPanel()).setLayout(null);
        this.jp_btnNuevoBanco.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevoBanco.setBackground(Variables.color_tres);
        this.jp_btnNuevoBanco.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevoBanco);
        (this.btnNuevoBanco = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevoBanco.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevoBanco.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBancos.this.jp_btnNuevoBanco.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevoBanco.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBancos.this.jp_btnNuevoBanco.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevoBanco.add(this.btnNuevoBanco);
        (this.lblIconoBtn_nuevoBanco = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevoBanco.setIcon(this.ajustes.ajustarImagen_("/images/botones-12-icono-nuevoBanco.png", this.lblIconoBtn_nuevoBanco));
        this.jp_btnNuevoBanco.add(this.lblIconoBtn_nuevoBanco);
        (this.lblNombreBtn_nuevoBanco = new JLabel("Nuevo")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevoBanco.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevoBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevoBanco.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevoBanco.add(this.lblNombreBtn_nuevoBanco);
        (this.jp_btnBuscarBanco = new JPanel()).setLayout(null);
        this.jp_btnBuscarBanco.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarBanco.setBackground(Variables.color_tres);
        this.jp_btnBuscarBanco.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarBanco);
        (this.btnBuscarBanco = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarBanco.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarBanco.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBancos.this.jp_btnBuscarBanco.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarBanco.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBancos.this.jp_btnBuscarBanco.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarBanco.add(this.btnBuscarBanco);
        (this.lblIconoBtn_buscarBanco = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarBanco.setIcon(this.ajustes.ajustarImagen_("/images/botones-13-icono-buscarBanco.png", this.lblIconoBtn_buscarBanco));
        this.jp_btnBuscarBanco.add(this.lblIconoBtn_buscarBanco);
        (this.lblNombreBtn_buscarBanco = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarBanco.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarBanco.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarBanco.add(this.lblNombreBtn_buscarBanco);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBancos.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBancos.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBancos.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBancos.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBancos.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaBancos.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBancos.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblnewlabel = new JLabel("Catalogo de Bancos")).setForeground(Variables.color_uno);
        this.lblnewlabel.setHorizontalAlignment(0);
        this.lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblnewlabel.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblnewlabel);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JLabel lblIdoBanco = new JLabel("ID Banco:");
        lblIdoBanco.setHorizontalAlignment(0);
        lblIdoBanco.setForeground(Variables.color_uno);
        lblIdoBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblIdoBanco.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblIdoBanco);
        (this.txtIdBanco = new JTextField()).setEditable(false);
        this.txtIdBanco.setBackground(Variables.color_uno);
        this.txtIdBanco.setHorizontalAlignment(0);
        this.txtIdBanco.setForeground(Variables.color_dos);
        this.txtIdBanco.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtIdBanco.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtIdBanco);
        this.txtIdBanco.setColumns(10);
        (this.lblNombreBanco = new JLabel("Nombre de Banco:")).setHorizontalAlignment(0);
        this.lblNombreBanco.setForeground(Variables.color_uno);
        this.lblNombreBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBanco.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNombreBanco);
        (this.txtNombreBanco = new JTextField()).setEditable(false);
        this.txtNombreBanco.setBackground(Variables.color_uno);
        this.txtNombreBanco.setForeground(Variables.color_dos);
        this.txtNombreBanco.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreBanco.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreBanco);
        this.txtNombreBanco.setColumns(10);
        final JPanel jp_tblBancos = new JPanel();
        jp_tblBancos.setBorder(new BevelBorder(0, null, null, null, null));
        jp_tblBancos.setBackground(Variables.color_uno);
        jp_tblBancos.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(10.19), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.alto - this.ajustes.calcularPuntoY(27.78));
        jp_contenido.add(jp_tblBancos);
        jp_tblBancos.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.ancho - this.ajustes.calcularPuntoX(3.65), this.ajustes.alto - this.ajustes.calcularPuntoY(29.63));
        jp_tblBancos.add(scrollPane);
        (this.tblBancos = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblBancos.setBackground(Variables.color_uno);
        this.tblBancos.setForeground(Variables.color_dos);
        this.tblBancos.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        scrollPane.setViewportView(this.tblBancos);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void llenarCampos() {
        this.tblBancos.setModel(this.consultaSql.llenarTablaCatalogoBancos(Variables.idOficina));
        this.configurarTabla();
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(2.31)));
        final TableColumnModel columnModel = this.tblBancos.getColumnModel();
        header = this.tblBancos.getTableHeader();
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(500);
        columnModel.getColumn(2).setPreferredWidth(150);
        columnModel.getColumn(3).setPreferredWidth(150);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(150);
        columnModel.getColumn(4).setCellRenderer(alinear);
        columnModel.getColumn(5).setPreferredWidth(100);
        columnModel.getColumn(5).setCellRenderer(alinear);
        columnModel.getColumn(6).setPreferredWidth(100);
    }
}
