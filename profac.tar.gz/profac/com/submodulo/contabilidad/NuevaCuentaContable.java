// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.insertSQL_SERVER;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Contabilidad;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevaCuentaContable extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Contabilidad contabilidad;
    public consultasSQL_SERVER consultaSql;
    public insertSQL_SERVER insertSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblNuevaCunetaContable;
    private JPanel jp_cuentasContables;
    private JLabel lblBuscarCuenta;
    private JTextField txtBuscarCuenta;
    private JPanel jp_btnBuscar;
    private JLabel btnBuscar;
    private JLabel lblIconoBtn_buscar;
    private JLabel lblNombreBtn_buscar;
    private JSeparator separator_1;
    private JPanel jp_tblCuentas;
    private JScrollPane scrollPane;
    private JTable tblCuentas;
    private JPanel jp_infoCuenta;
    private JComboBox<Object> cbxTipoCuenta;
    private JLabel lblCuentaSup;
    private JTextField txtCuentaSup;
    private JLabel lblCuenta;
    private JTextField txtCuenta;
    private JLabel lblPresupuesto;
    private JTextField txtPresupuesto;
    private JLabel lblDescripcion;
    private JTextField txtDescripcion;
    public int nivel;
    public int clase;
    public int tipoCuenta_;
    public String cuenta;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevaCuentaContable frame = new NuevaCuentaContable();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevaCuentaContable() {
        this.ajustes = new Ajustes();
        this.contabilidad = new F_Contabilidad();
        this.consultaSql = new consultasSQL_SERVER();
        this.insertSql = new insertSQL_SERVER();
        this.nivel = 0;
        this.clase = 0;
        this.tipoCuenta_ = 0;
        this.cuenta = "";
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevaCuentaContable.this.buscarCuenta("%%");
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaPartida = new JPanel()).setLayout(null);
        this.jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
        this.jp_btnNuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaPartida);
        (this.btnNuevaPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaPartida.add(this.btnNuevaPartida);
        (this.lblIconoBtn_nuevaPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaPartida));
        this.jp_btnNuevaPartida.add(this.lblIconoBtn_nuevaPartida);
        (this.lblNombreBtn_nuevaPartida = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaPartida.add(this.lblNombreBtn_nuevaPartida);
        (this.jp_btnBuscarPartida = new JPanel()).setLayout(null);
        this.jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
        this.jp_btnBuscarPartida.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarPartida);
        (this.btnBuscarPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarPartida.add(this.btnBuscarPartida);
        (this.lblIconoBtn_buscarPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarPartida));
        this.jp_btnBuscarPartida.add(this.lblIconoBtn_buscarPartida);
        (this.lblNombreBtn_buscarPartida = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarPartida.add(this.lblNombreBtn_buscarPartida);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaCuentaContable.this.guardarCuentaContable();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaCuentaContable.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblNuevaCunetaContable = new JLabel("Ingresar Nueva Cuenta Contable")).setForeground(Variables.color_uno);
        this.lblNuevaCunetaContable.setHorizontalAlignment(0);
        this.lblNuevaCunetaContable.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNuevaCunetaContable.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblNuevaCunetaContable);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        (this.jp_cuentasContables = new JPanel()).setLayout(null);
        this.jp_cuentasContables.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_cuentasContables.setBackground(Variables.color_uno);
        this.jp_cuentasContables.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(75.93));
        jp_contenido.add(this.jp_cuentasContables);
        (this.lblBuscarCuenta = new JLabel("Buscar Cuenta Contable")).setHorizontalAlignment(0);
        this.lblBuscarCuenta.setForeground(Variables.color_dos);
        this.lblBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBuscarCuenta.setBounds(0, this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(1.85));
        this.jp_cuentasContables.add(this.lblBuscarCuenta);
        (this.txtBuscarCuenta = new JTextField()).setForeground(Variables.color_dos);
        this.txtBuscarCuenta.setColumns(10);
        this.txtBuscarCuenta.setBackground(Color.WHITE);
        this.txtBuscarCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscarCuenta.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(6.25), this.ajustes.calcularPuntoY(2.78));
        this.jp_cuentasContables.add(this.txtBuscarCuenta);
        (this.jp_btnBuscar = new JPanel()).setLayout(null);
        this.jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscar.setBackground(Variables.color_tres);
        this.jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(5.21), this.ajustes.calcularPuntoY(2.78), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_cuentasContables.add(this.jp_btnBuscar);
        (this.btnBuscar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnBuscar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaCuentaContable.this.buscarCuenta("%" + NuevaCuentaContable.this.txtBuscarCuenta.getText().toString() + "%");
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaCuentaContable.this.jp_btnBuscar.setBackground(Variables.color_dos);
            }
        });
        this.btnBuscar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.setBounds(0, 0, this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), 0, this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/general-16-icono-buscar.png", this.lblIconoBtn_buscar));
        this.jp_btnBuscar.add(this.lblIconoBtn_buscar);
        (this.lblNombreBtn_buscar = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscar.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_buscar.setBounds(this.ajustes.calcularPuntoX(1.56), 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(2.78));
        this.jp_btnBuscar.add(this.lblNombreBtn_buscar);
        (this.separator_1 = new JSeparator()).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(0.19));
        this.jp_cuentasContables.add(this.separator_1);
        (this.jp_tblCuentas = new JPanel()).setLayout(null);
        this.jp_tblCuentas.setBorder(new BevelBorder(1, null, null, null, null));
        this.jp_tblCuentas.setBackground(Color.WHITE);
        this.jp_tblCuentas.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(7.41), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(67.59));
        this.jp_cuentasContables.add(this.jp_tblCuentas);
        (this.scrollPane = new JScrollPane()).setBackground(Color.WHITE);
        this.scrollPane.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(67.59));
        this.jp_tblCuentas.add(this.scrollPane);
        (this.tblCuentas = new JTable()).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaCuentaContable.this.llenarCampos();
                NuevaCuentaContable.this.calcularCuenta();
            }
        });
        this.tblCuentas.setForeground(Variables.color_dos);
        this.tblCuentas.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.scrollPane.setViewportView(this.tblCuentas);
        (this.jp_infoCuenta = new JPanel()).setOpaque(false);
        this.jp_infoCuenta.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(46.3));
        jp_contenido.add(this.jp_infoCuenta);
        this.jp_infoCuenta.setLayout(null);
        final JLabel lblNewLabel = new JLabel("Tipo de Cuenta");
        lblNewLabel.setForeground(Variables.color_uno);
        lblNewLabel.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel.setHorizontalAlignment(0);
        lblNewLabel.setBounds((this.ajustes.ancho - 25) / 10, 0, (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(1.85));
        this.jp_infoCuenta.add(lblNewLabel);
        (this.cbxTipoCuenta = new JComboBox<Object>()).setBackground(Variables.color_uno);
        this.cbxTipoCuenta.setForeground(Variables.color_dos);
        this.cbxTipoCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxTipoCuenta.setModel(new DefaultComboBoxModel<Object>(new String[] { "01 - Cuenta de Resumen", "02 - Cuenta de Detalle" }));
        this.cbxTipoCuenta.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        this.jp_infoCuenta.add(this.cbxTipoCuenta);
        final JSeparator separator_2 = new JSeparator();
        separator_2.setBounds((this.ajustes.ancho - 25) / 20, this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 20 * 8, this.ajustes.calcularPuntoY(0.19));
        this.jp_infoCuenta.add(separator_2);
        (this.lblCuentaSup = new JLabel("Cuenta Contable Superior:")).setForeground(Variables.color_uno);
        this.lblCuentaSup.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCuentaSup.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(9.26), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_infoCuenta.add(this.lblCuentaSup);
        (this.txtCuentaSup = new JTextField()).setHorizontalAlignment(0);
        this.txtCuentaSup.setForeground(Variables.color_dos);
        this.txtCuentaSup.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuentaSup.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(8.8), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_infoCuenta.add(this.txtCuentaSup);
        this.txtCuentaSup.setColumns(10);
        (this.lblCuenta = new JLabel("Cuenta Contable:")).setForeground(Variables.color_uno);
        this.lblCuenta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCuenta.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(14.35), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_infoCuenta.add(this.lblCuenta);
        (this.txtCuenta = new JTextField()).setHorizontalAlignment(0);
        this.txtCuenta.setForeground(Variables.color_dos);
        this.txtCuenta.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCuenta.setColumns(10);
        this.txtCuenta.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(13.89), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_infoCuenta.add(this.txtCuenta);
        (this.lblPresupuesto = new JLabel("Monto Presupuestado ($):")).setForeground(Variables.color_uno);
        this.lblPresupuesto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPresupuesto.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(19.44), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_infoCuenta.add(this.lblPresupuesto);
        (this.txtPresupuesto = new JTextField()).setHorizontalAlignment(0);
        this.txtPresupuesto.setForeground(Variables.color_dos);
        this.txtPresupuesto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPresupuesto.setColumns(10);
        this.txtPresupuesto.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(18.98), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_infoCuenta.add(this.txtPresupuesto);
        (this.lblDescripcion = new JLabel("Descripci\u00f3n:")).setForeground(Variables.color_uno);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(24.54), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        this.jp_infoCuenta.add(this.lblDescripcion);
        (this.txtDescripcion = new JTextField()).setHorizontalAlignment(0);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setColumns(10);
        this.txtDescripcion.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(24.07), (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(2.78));
        this.jp_infoCuenta.add(this.txtDescripcion);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        final TableColumnModel columnModel = this.tblCuentas.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = this.tblCuentas.getTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(400);
        columnModel.getColumn(2).setPreferredWidth(75);
        columnModel.getColumn(2).setCellRenderer(alinear);
    }
    
    public void buscarCuenta(final String nombreCuenta) {
        this.tblCuentas.setModel(this.consultaSql.llenarTablaCuentasContables(nombreCuenta, Variables.idOficina, 1));
        this.configurarTabla();
    }
    
    public void llenarCampos() {
        this.txtCuentaSup.setText((String)this.tblCuentas.getValueAt(this.tblCuentas.getSelectedRow(), 0));
        this.txtPresupuesto.setText("0.00");
    }
    
    public void calcularCuenta() {
        int contador = 1;
        int bandera = 0;
        String cuentaNueva = "";
        final String substring;
        switch (substring = this.cbxTipoCuenta.getSelectedItem().toString().substring(0, 2)) {
            case "01": {
                this.cuenta = "RE";
                break;
            }
            case "02": {
                this.cuenta = "DE";
                break;
            }
            default:
                break;
        }
        final int nivelCuenta = this.consultaSql.obtenerNivelCuenta(this.txtCuentaSup.getText().toString(), Variables.idOficina);
        this.clase = Integer.parseInt(this.txtCuentaSup.getText().toString().substring(0, 1));
        if (nivelCuenta == 1) {
            while (bandera == 0) {
                cuentaNueva = String.valueOf(this.txtCuentaSup.getText().toString().substring(0, nivelCuenta)) + String.valueOf(contador);
                this.nivel = cuentaNueva.length();
                for (int cont = 1, longCuentaNueva = cuentaNueva.length(); cont <= 14 - longCuentaNueva; ++cont) {
                    cuentaNueva = String.valueOf(cuentaNueva) + "0";
                }
                if (this.consultaSql.obtenerNivelCuenta(cuentaNueva, Variables.idOficina) == 0) {
                    bandera = 1;
                    this.txtCuenta.setText(cuentaNueva);
                }
                else {
                    ++contador;
                }
            }
        }
        else {
            while (bandera == 0) {
                if (contador >= 1 && contador <= 9) {
                    cuentaNueva = String.valueOf(this.txtCuentaSup.getText().toString().substring(0, nivelCuenta)) + "0" + String.valueOf(contador);
                    this.nivel = cuentaNueva.length();
                }
                else {
                    cuentaNueva = String.valueOf(this.txtCuentaSup.getText().toString().substring(0, nivelCuenta)) + String.valueOf(contador);
                    this.nivel = cuentaNueva.length();
                }
                for (int cont = 1, longCuentaNueva = cuentaNueva.length(); cont <= 14 - longCuentaNueva; ++cont) {
                    cuentaNueva = String.valueOf(cuentaNueva) + "0";
                }
                if (this.consultaSql.obtenerNivelCuenta(cuentaNueva, Variables.idOficina) == 0) {
                    bandera = 1;
                    this.txtCuenta.setText(cuentaNueva);
                }
                else {
                    ++contador;
                }
            }
        }
    }
    
    public void guardarCuentaContable() {
        if (this.txtCuenta.getText().length() == 0 || this.txtDescripcion.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "Se deben completar todos los campos", "ERROR!", 0);
            return;
        }
        final String correlativo = String.valueOf(Integer.parseInt(this.consultaSql.obtenerCorrelativoCuentaContable(Variables.idOficina)) + 1);
        String id = "";
        for (int i = 0; i < 9 - correlativo.length(); ++i) {
            id = String.valueOf(id) + "0";
        }
        id = String.valueOf(Variables.idOficina) + id + correlativo;
        if (this.contabilidad.cuentaContable(id, this.txtCuenta.getText(), this.txtCuentaSup.getText(), this.clase, this.nivel, this.clase, this.txtDescripcion.getText(), Variables.fechaActual, Variables.idUsuario, this.cuenta, 0.0, 0.0, Variables.idOficina, Double.parseDouble(this.txtPresupuesto.getText()), 0.0)) {
            this.buscarCuenta("%%");
            this.txtCuenta.setText("");
            this.txtCuentaSup.setText("");
            this.txtPresupuesto.setText("");
            this.txtDescripcion.setText("");
            JOptionPane.showMessageDialog(null, "Cuenta Nº " + this.txtCuenta.getText() + " agregada correctamente.", "OK!", 1);
            return;
        }
        JOptionPane.showMessageDialog(null, "Al momento de ingresar la cuenta contable -- " + Variables.error, "ERROR!", 0);
    }
}
