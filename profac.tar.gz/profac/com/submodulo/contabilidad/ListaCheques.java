// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.contabilidad;

import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.JScrollPane;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import javax.swing.text.Document;
import javax.swing.ComboBoxModel;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.WindowListener;
import profac.com.herramientas.Variables;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaCheques extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevoCheque;
    private JLabel btnNuevoCheque;
    private JLabel lblIconoBtn_nuevoCheque;
    private JLabel lblNombreBtn_nuevoCheque;
    private JPanel jp_btnBuscarCheque;
    private JLabel btnBuscarCheque;
    private JLabel lblIconoBtn_buscarCheque;
    private JLabel lblNombreBtn_buscarCheque;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblListaCheques;
    private JLabel lblBanco;
    private JTextField txtBuscar;
    private JLabel lblFechaInicio;
    private JTextField txtFechaInicio;
    private JLabel lblFechaFin;
    private JTextField txtFechaFin;
    private JPanel jp_btnBuscar;
    private JLabel lblIconoBtn_buscar;
    private JLabel lblNombreBtn_buscar;
    private JLabel btnBuscar;
    private JPanel jp_tblCheques;
    private JTable tblCheques;
    private JComboBox<Object> cbxBanco;
    public int contadorFecha;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaCheques frame = new ListaCheques();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaCheques() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.contadorFecha = 0;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaCheques.this.txtFechaInicio.setText(Variables.fechaSistema);
                ListaCheques.this.txtFechaFin.setText(Variables.fechaActual);
                ListaCheques.this.buscarCheques("%%", "%" + ListaCheques.this.cbxBanco.getSelectedItem().toString() + "%", "", "", 0);
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(new Color(57, 81, 115));
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(new Color(227, 227, 227));
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevoCheque = new JPanel()).setLayout(null);
        this.jp_btnNuevoCheque.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevoCheque.setBackground(new Color(57, 81, 115));
        this.jp_btnNuevoCheque.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevoCheque);
        (this.btnNuevoCheque = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevoCheque.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevoCheque.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCheques.this.jp_btnNuevoCheque.setBackground(new Color(57, 81, 115));
            }
        });
        this.btnNuevoCheque.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCheques.this.jp_btnNuevoCheque.setBackground(new Color(0, 38, 77));
            }
        });
        this.jp_btnNuevoCheque.add(this.btnNuevoCheque);
        (this.lblIconoBtn_nuevoCheque = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevoCheque.setIcon(this.ajustes.ajustarImagen_("/images/botones-10-icono-nuevoCheque.png", this.lblIconoBtn_nuevoCheque));
        this.jp_btnNuevoCheque.add(this.lblIconoBtn_nuevoCheque);
        (this.lblNombreBtn_nuevoCheque = new JLabel("Nuevo")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevoCheque.setForeground(new Color(227, 227, 227));
        this.lblNombreBtn_nuevoCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevoCheque.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevoCheque.add(this.lblNombreBtn_nuevoCheque);
        (this.jp_btnBuscarCheque = new JPanel()).setLayout(null);
        this.jp_btnBuscarCheque.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarCheque.setBackground(new Color(57, 81, 115));
        this.jp_btnBuscarCheque.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarCheque);
        (this.btnBuscarCheque = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarCheque.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarCheque.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCheques.this.jp_btnBuscarCheque.setBackground(new Color(57, 81, 115));
            }
        });
        this.btnBuscarCheque.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCheques.this.jp_btnBuscarCheque.setBackground(new Color(0, 38, 77));
            }
        });
        this.jp_btnBuscarCheque.add(this.btnBuscarCheque);
        (this.lblIconoBtn_buscarCheque = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarCheque.setIcon(this.ajustes.ajustarImagen_("/images/botones-11-icono-listaCheques.png", this.lblIconoBtn_buscarCheque));
        this.jp_btnBuscarCheque.add(this.lblIconoBtn_buscarCheque);
        (this.lblNombreBtn_buscarCheque = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarCheque.setForeground(new Color(227, 227, 227));
        this.lblNombreBtn_buscarCheque.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarCheque.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarCheque.add(this.lblNombreBtn_buscarCheque);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(new Color(57, 81, 115));
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCheques.this.jp_btnGuardar.setBackground(new Color(57, 81, 115));
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCheques.this.jp_btnGuardar.setBackground(new Color(0, 38, 77));
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(new Color(227, 227, 227));
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(new Color(57, 81, 115));
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCheques.this.jp_btnImprimir.setBackground(new Color(57, 81, 115));
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCheques.this.jp_btnImprimir.setBackground(new Color(0, 38, 77));
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(new Color(227, 227, 227));
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(new Color(57, 81, 115));
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCheques.this.jp_btnSalir.setBackground(new Color(57, 81, 115));
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaCheques.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCheques.this.jp_btnSalir.setBackground(new Color(0, 38, 77));
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(new Color(227, 227, 227));
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblListaCheques = new JLabel("Lista de Cheques Emitidos")).setForeground(new Color(227, 227, 227));
        this.lblListaCheques.setHorizontalAlignment(0);
        this.lblListaCheques.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblListaCheques.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblListaCheques);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JPanel jp_infoBuscar = new JPanel();
        jp_infoBuscar.setOpaque(false);
        jp_infoBuscar.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(10.65));
        jp_contenido.add(jp_infoBuscar);
        jp_infoBuscar.setLayout(null);
        final JLabel lblBuscar = new JLabel("Buscar por Descripci\u00f3n:");
        lblBuscar.setForeground(new Color(227, 227, 227));
        lblBuscar.setHorizontalAlignment(0);
        lblBuscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblBuscar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        jp_infoBuscar.add(lblBuscar);
        (this.txtBuscar = new JTextField()).setForeground(new Color(0, 38, 77));
        this.txtBuscar.setBackground(new Color(227, 227, 227));
        this.txtBuscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtBuscar.setBounds(0, this.ajustes.calcularPuntoY(2.31), (this.ajustes.ancho - 25) / 10 * 5 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_infoBuscar.add(this.txtBuscar);
        this.txtBuscar.setColumns(10);
        (this.lblBanco = new JLabel("Buscar por Nombre de Banco:")).setHorizontalAlignment(0);
        this.lblBanco.setForeground(new Color(227, 227, 227));
        this.lblBanco.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBanco.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(0.52), 0, (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        jp_infoBuscar.add(this.lblBanco);
        (this.cbxBanco = new JComboBox<Object>()).setForeground(new Color(0, 38, 77));
        this.cbxBanco.setBackground(new Color(227, 227, 227));
        this.cbxBanco.setModel(this.consultaSql.getDataComboBox("select bancos.nombreBanco\r\nfrom bancos \r\ninner join cuentaContable on bancos.cuentaContable_id=cuentaContable.id \r\nwhere cuentaContable.oficina_idoficina = '" + Variables.idOficina + "'"));
        this.cbxBanco.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxBanco.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.31), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_infoBuscar.add(this.cbxBanco);
        (this.lblFechaInicio = new JLabel("Desde:")).setHorizontalAlignment(0);
        this.lblFechaInicio.setForeground(new Color(227, 227, 227));
        this.lblFechaInicio.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaInicio.setBounds(0, this.ajustes.calcularPuntoY(5.56), (this.ajustes.ancho - 25) / 10 * 5 / 2 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85));
        jp_infoBuscar.add(this.lblFechaInicio);
        (this.txtFechaInicio = new JTextField()).setDocument(new LimitadorCaracteres(this.txtFechaInicio, 10));
        this.txtFechaInicio.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(final FocusEvent arg0) {
                ListaCheques.this.contadorFecha = 0;
            }
        });
        this.txtFechaInicio.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(final KeyEvent arg0) {
                final int k = arg0.getKeyChar();
                if (k >= 48 && k <= 57) {
                    if (ListaCheques.this.contadorFecha == 2 || ListaCheques.this.contadorFecha == 4) {
                        ListaCheques.this.txtFechaInicio.setText(String.valueOf(ListaCheques.this.txtFechaInicio.getText()) + "/");
                    }
                    final ListaCheques this$0 = ListaCheques.this;
                    ++this$0.contadorFecha;
                }
                else {
                    arg0.setKeyChar('\f');
                }
            }
        });
        this.txtFechaInicio.setHorizontalAlignment(0);
        this.txtFechaInicio.setForeground(new Color(0, 38, 77));
        this.txtFechaInicio.setColumns(10);
        this.txtFechaInicio.setBackground(new Color(227, 227, 227));
        this.txtFechaInicio.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaInicio.setBounds(0, this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 * 5 / 2 - this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(2.78));
        jp_infoBuscar.add(this.txtFechaInicio);
        (this.lblFechaFin = new JLabel("Hasta:")).setHorizontalAlignment(0);
        this.lblFechaFin.setForeground(new Color(227, 227, 227));
        this.lblFechaFin.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaFin.setBounds((this.ajustes.ancho - 25) / 10 * 5 / 2 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(5.56), (this.ajustes.ancho - 25) / 10 * 5 / 2 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        jp_infoBuscar.add(this.lblFechaFin);
        (this.txtFechaFin = new JTextField()).setDocument(new LimitadorCaracteres(this.txtFechaFin, 10));
        this.txtFechaFin.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(final FocusEvent arg0) {
                ListaCheques.this.contadorFecha = 0;
            }
        });
        this.txtFechaFin.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(final KeyEvent arg0) {
                final int k = arg0.getKeyChar();
                if (k >= 48 && k <= 57) {
                    if (ListaCheques.this.contadorFecha == 2 || ListaCheques.this.contadorFecha == 4) {
                        ListaCheques.this.txtFechaFin.setText(String.valueOf(ListaCheques.this.txtFechaFin.getText()) + "/");
                    }
                    final ListaCheques this$0 = ListaCheques.this;
                    ++this$0.contadorFecha;
                }
                else {
                    arg0.setKeyChar('\f');
                }
            }
        });
        this.txtFechaFin.setHorizontalAlignment(0);
        this.txtFechaFin.setForeground(new Color(0, 38, 77));
        this.txtFechaFin.setColumns(10);
        this.txtFechaFin.setBackground(new Color(227, 227, 227));
        this.txtFechaFin.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaFin.setBounds((this.ajustes.ancho - 25) / 10 * 5 / 2 + this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(7.87), (this.ajustes.ancho - 25) / 10 * 5 / 2 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        jp_infoBuscar.add(this.txtFechaFin);
        (this.jp_btnBuscar = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscar.setBackground(new Color(227, 227, 227));
        this.jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 9 + this.ajustes.calcularPuntoX(0.52), 0, (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(10.65));
        this.jp_btnBuscar.setLayout(null);
        jp_infoBuscar.add(this.jp_btnBuscar);
        (this.btnBuscar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaCheques.this.jp_btnBuscar.setBackground(new Color(227, 227, 227));
                ListaCheques.this.lblIconoBtn_buscar.setIcon(ListaCheques.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", ListaCheques.this.lblIconoBtn_buscar));
                ListaCheques.this.lblNombreBtn_buscar.setForeground(new Color(0, 38, 77));
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaCheques.this.buscarCheques("%" + ListaCheques.this.txtBuscar.getText() + "%", "%" + ListaCheques.this.cbxBanco.getSelectedItem().toString() + "%", ListaCheques.this.txtFechaInicio.getText(), ListaCheques.this.txtFechaFin.getText(), 1);
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaCheques.this.jp_btnBuscar.setBackground(new Color(0, 38, 77));
                ListaCheques.this.lblIconoBtn_buscar.setIcon(ListaCheques.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar-select.png", ListaCheques.this.lblIconoBtn_buscar));
                ListaCheques.this.lblNombreBtn_buscar.setForeground(new Color(227, 227, 227));
            }
        });
        this.btnBuscar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(10.65));
        this.jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoBtn_buscar.setBounds(((this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56) - this.ajustes.calcularPuntoX(2.66)) / 2, this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(2.66), this.ajustes.calcularPuntoY(4.72));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", this.lblIconoBtn_buscar));
        this.jp_btnBuscar.add(this.lblIconoBtn_buscar);
        (this.lblNombreBtn_buscar = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscar.setForeground(new Color(0, 38, 77));
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(2.78))));
        this.lblNombreBtn_buscar.setBounds(0, this.ajustes.calcularPuntoY(6.02), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(4.63));
        this.jp_btnBuscar.add(this.lblNombreBtn_buscar);
        (this.jp_tblCheques = new JPanel()).setBackground(new Color(227, 227, 227));
        this.jp_tblCheques.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_tblCheques.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(16.2), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.alto - this.ajustes.calcularPuntoY(33.33));
        jp_contenido.add(this.jp_tblCheques);
        this.jp_tblCheques.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.ancho - this.ajustes.calcularPuntoX(3.65), this.ajustes.alto - this.ajustes.calcularPuntoY(35.19));
        this.jp_tblCheques.add(scrollPane);
        (this.tblCheques = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblCheques.setForeground(new Color(0, 38, 77));
        this.tblCheques.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        scrollPane.setViewportView(this.tblCheques);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void buscarCheques(final String descripcion, final String banco, final String fechaInicio, final String fechaFin, final int op) {
        this.tblCheques.setModel(this.consultaSql.llenarTablaCatalogoCheques(descripcion, banco, Variables.idOficina, fechaInicio, fechaFin, op));
        this.configurarTabla();
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(2.31)));
        final TableColumnModel columnModel = this.tblCheques.getColumnModel();
        header = this.tblCheques.getTableHeader();
        header.setFont(fuente);
        header.setForeground(new Color(0, 38, 77));
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(40);
        columnModel.getColumn(1).setCellRenderer(alinear);
        columnModel.getColumn(2).setPreferredWidth(200);
        columnModel.getColumn(3).setPreferredWidth(500);
        columnModel.getColumn(4).setPreferredWidth(100);
        columnModel.getColumn(4).setCellRenderer(alinear);
        columnModel.getColumn(5).setPreferredWidth(75);
        columnModel.getColumn(5).setCellRenderer(alinear);
        columnModel.getColumn(6).setPreferredWidth(75);
        columnModel.getColumn(6).setCellRenderer(alinear);
        columnModel.getColumn(7).setPreferredWidth(150);
        columnModel.getColumn(7).setCellRenderer(alinear);
    }
}
