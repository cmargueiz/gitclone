// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.usuarios;

import javax.swing.JOptionPane;
import org.apache.commons.codec.digest.DigestUtils;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import java.awt.EventQueue;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JPanel;
import profac.com.database.updateSQL_SERVER;
import profac.com.database.consultasSQL_SERVER;
import javax.swing.JFrame;

public class ControlUsuarios_cambioContra extends JFrame
{
    private static final long serialVersionUID = 1L;
    public consultasSQL_SERVER consultasSql;
    public updateSQL_SERVER updateSql;
    private JPanel contentPane;
    private JPasswordField passwordAnterior;
    private JPasswordField passwordNueva1;
    private JPasswordField passwordNueva2;
    public JLabel lblCambioDeContrasea;
    public String usuario;
    public String fechaSistema;
    public String fechaActual;
    public String nombreOficina;
    public String nombreUsuario;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ControlUsuarios_cambioContra frame = new ControlUsuarios_cambioContra();
                    frame.setVisible(true);
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ControlUsuarios_cambioContra() {
        this.consultasSql = new consultasSQL_SERVER();
        this.updateSql = new updateSQL_SERVER();
        this.lblCambioDeContrasea = new JLabel("");
        this.setUndecorated(true);
        this.setResizable(false);
        this.setDefaultCloseOperation(0);
        this.setBounds(100, 100, 450, 165);
        (this.contentPane = new JPanel()).setBorder(new EtchedBorder(0, null, null));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        this.lblCambioDeContrasea.setHorizontalAlignment(0);
        this.lblCambioDeContrasea.setFont(new Font("Tahoma", 1, 15));
        this.lblCambioDeContrasea.setBounds(10, 10, 430, 20);
        this.contentPane.add(this.lblCambioDeContrasea);
        final JLabel lblContraseaAntigua = new JLabel("Contrase\u00f1a Antigua:");
        lblContraseaAntigua.setBounds(10, 40, 110, 20);
        this.contentPane.add(lblContraseaAntigua);
        (this.passwordAnterior = new JPasswordField()).setBounds(120, 40, 320, 20);
        this.contentPane.add(this.passwordAnterior);
        final JLabel lblNuevaContrasea = new JLabel("Nueva Contrase\u00f1a:");
        lblNuevaContrasea.setForeground(Color.BLACK);
        lblNuevaContrasea.setBounds(10, 70, 110, 20);
        this.contentPane.add(lblNuevaContrasea);
        (this.passwordNueva1 = new JPasswordField()).setBounds(120, 70, 320, 20);
        this.contentPane.add(this.passwordNueva1);
        final JLabel lblConfirmarContrasea = new JLabel("Confirmar Contrase\u00f1a:");
        lblConfirmarContrasea.setBounds(10, 100, 110, 20);
        this.contentPane.add(lblConfirmarContrasea);
        (this.passwordNueva2 = new JPasswordField()).setBounds(120, 100, 320, 20);
        this.contentPane.add(this.passwordNueva2);
        final JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final String passAntigua = DigestUtils.md5Hex(ControlUsuarios_cambioContra.this.passwordAnterior.getText());
                final String passNueva1 = DigestUtils.md5Hex(ControlUsuarios_cambioContra.this.passwordNueva1.getText());
                final String passNueva2 = DigestUtils.md5Hex(ControlUsuarios_cambioContra.this.passwordNueva2.getText());
                if (ControlUsuarios_cambioContra.this.consultasSql.login(ControlUsuarios_cambioContra.this.usuario, passAntigua) <= 0) {
                    JOptionPane.showMessageDialog(null, "La contrase\u00f1a no es igual a la registrada", "ERROR!", 0);
                    ControlUsuarios_cambioContra.this.passwordNueva1.setText("");
                    ControlUsuarios_cambioContra.this.passwordNueva2.setText("");
                    ControlUsuarios_cambioContra.this.passwordAnterior.requestFocus();
                    lblContraseaAntigua.setForeground(Color.RED);
                    return;
                }
                if (!passNueva1.equals(passNueva2)) {
                    JOptionPane.showMessageDialog(null, "Las contrase\u00f1as no coiciden", "ERROR!", 0);
                    ControlUsuarios_cambioContra.this.passwordNueva1.setText("");
                    ControlUsuarios_cambioContra.this.passwordNueva2.setText("");
                    ControlUsuarios_cambioContra.this.passwordNueva1.requestFocus();
                    lblNuevaContrasea.setForeground(Color.RED);
                    lblConfirmarContrasea.setForeground(Color.RED);
                    lblContraseaAntigua.setForeground(Color.BLACK);
                    return;
                }
                if (passNueva1.equals(passAntigua)) {
                    JOptionPane.showMessageDialog(null, "No pueden ser iguales las contrase\u00f1as", "ERROR!", 0);
                    ControlUsuarios_cambioContra.this.passwordNueva1.setText("");
                    ControlUsuarios_cambioContra.this.passwordNueva2.setText("");
                    ControlUsuarios_cambioContra.this.passwordNueva1.requestFocus();
                    lblNuevaContrasea.setForeground(Color.RED);
                    lblContraseaAntigua.setForeground(Color.RED);
                    lblConfirmarContrasea.setForeground(Color.BLACK);
                    return;
                }
                final int resultado = ControlUsuarios_cambioContra.this.updateSql.modificarPassword(ControlUsuarios_cambioContra.this.usuario, passNueva1);
                if (resultado == 1) {
                    JOptionPane.showMessageDialog(null, "contrase\u00f1a modificada correctamente", "OK!", 1);
                    ControlUsuarios_cambioContra.this.dispose();
                }
            }
        });
        btnGuardar.setFont(new Font("Tahoma", 1, 11));
        btnGuardar.setBounds(125, 130, 90, 25);
        this.contentPane.add(btnGuardar);
        final JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                ControlUsuarios_cambioContra.this.dispose();
            }
        });
        btnCancelar.setFont(new Font("Tahoma", 1, 11));
        btnCancelar.setBounds(235, 131, 90, 25);
        this.contentPane.add(btnCancelar);
        this.setLocationRelativeTo(null);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
}
