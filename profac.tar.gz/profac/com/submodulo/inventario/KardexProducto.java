package profac.com.submodulo.inventario;

import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;

import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Variables;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JTable;

public class KardexProducto extends JFrame{
    
	/**
	 * @author Frank Castro 
	 */
	
	private static final long serialVersionUID = 1L;
	
	public Ajustes ajustes = new Ajustes();
    public consultasSQL_SERVER consultaSql = new consultasSQL_SERVER();
    
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

	private JLabel lblIconoBtn_buscar;

	private JLabel lblNombreBtn_buscar;

	private JLabel btnBuscar;
	private JTable tblKardexProducto;

	private JPanel jp_tblIKardexProductos;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    KardexProducto frame = new KardexProducto();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public KardexProducto() {
        setDefaultCloseOperation(3);
        setResizable(false);
        setUndecorated(true);
        setBounds(0, ajustes.calcularPuntoY(6.57), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(8.8));
        contentPane = new JPanel();
        contentPane.setBackground(Variables.color_tres);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, ajustes.ancho, ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        contentPane.add(jp_botones);
        
        jp_btnNuevaPartida = new JPanel();
        jp_btnNuevaPartida.setLayout(null);
        jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnNuevaPartida.setBackground(Variables.color_tres);
        jp_btnNuevaPartida.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnNuevaPartida);
        
        btnNuevaPartida = new JLabel("");
        btnNuevaPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnNuevaPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnNuevaPartida.add(btnNuevaPartida);
        
        lblIconoBtn_nuevaPartida = new JLabel("");
        lblIconoBtn_nuevaPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_nuevaPartida.setIcon(ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", lblIconoBtn_nuevaPartida));
        jp_btnNuevaPartida.add(lblIconoBtn_nuevaPartida);
        
        lblNombreBtn_nuevaPartida = new JLabel("Nueva");
        lblNombreBtn_nuevaPartida.setHorizontalAlignment(0);
        lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_nuevaPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnNuevaPartida.add(lblNombreBtn_nuevaPartida);
        
        jp_btnBuscarPartida = new JPanel();
        jp_btnBuscarPartida.setLayout(null);
        jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscarPartida.setBackground(Variables.color_tres);
        jp_btnBuscarPartida.setBounds(ajustes.calcularPuntoX(4.95), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnBuscarPartida);
        
        btnBuscarPartida = new JLabel("");
        btnBuscarPartida.setCursor(Cursor.getPredefinedCursor(12));
        btnBuscarPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        jp_btnBuscarPartida.add(btnBuscarPartida);
        
        lblIconoBtn_buscarPartida = new JLabel("");
        lblIconoBtn_buscarPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_buscarPartida.setIcon(ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", lblIconoBtn_buscarPartida));
        jp_btnBuscarPartida.add(lblIconoBtn_buscarPartida);
        
        lblNombreBtn_buscarPartida = new JLabel("Buscar");
        lblNombreBtn_buscarPartida.setHorizontalAlignment(0);
        lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_buscarPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnBuscarPartida.add(lblNombreBtn_buscarPartida);
        
        jp_btnGuardar = new JPanel();
        jp_btnGuardar.setLayout(null);
        jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnGuardar.setBackground(Variables.color_tres);
        jp_btnGuardar.setBounds(ajustes.calcularPuntoX(9.11), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnGuardar);
        
        btnGuardar = new JLabel("");
        btnGuardar.setCursor(Cursor.getPredefinedCursor(12));
        btnGuardar.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        jp_btnGuardar.add(btnGuardar);
        
        lblIconoBtn_guardar = new JLabel("");
        lblIconoBtn_guardar.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_guardar.setIcon(ajustes.ajustarImagen("/botones_04_icono_guardar", lblIconoBtn_guardar, 50, 50, 50, 50));
        jp_btnGuardar.add(lblIconoBtn_guardar);
        
        lblNombreBtn_guardar = new JLabel("Guardar");
        lblNombreBtn_guardar.setHorizontalAlignment(0);
        lblNombreBtn_guardar.setForeground(Variables.color_uno);
        lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_guardar.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnGuardar.add(lblNombreBtn_guardar);
        
        jp_btnImprimir = new JPanel();
        jp_btnImprimir.setLayout(null);
        jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnImprimir.setBackground(Variables.color_tres);
        jp_btnImprimir.setBounds(ajustes.calcularPuntoX(13.28), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnImprimir);
        
        btnImprimir = new JLabel("");
        btnImprimir.setCursor(Cursor.getPredefinedCursor(12));
        btnImprimir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        jp_btnImprimir.add(btnImprimir);
        
        lblIconoBtn_imprimir = new JLabel("");
        lblIconoBtn_imprimir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_imprimir.setIcon(ajustes.ajustarImagen("/botones_05_icono_imprimir", lblIconoBtn_imprimir, 50, 50, 50, 50));
        jp_btnImprimir.add(lblIconoBtn_imprimir);
        
        lblNombreBtn_imprimir = new JLabel("Imprimir");
        lblNombreBtn_imprimir.setHorizontalAlignment(0);
        lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_imprimir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnImprimir.add(lblNombreBtn_imprimir);
        
        jp_btnSalir = new JPanel();
        jp_btnSalir.setBackground(Variables.color_tres);
        jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnSalir.setBounds(ajustes.calcularPuntoX(26.04), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        jp_botones.add(jp_btnSalir);
        jp_btnSalir.setLayout(null);
        
        btnSalir = new JLabel("");
        btnSalir.setCursor(Cursor.getPredefinedCursor(12));
        btnSalir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
        btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
        });
        btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        jp_btnSalir.add(btnSalir);
        
        JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.43), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        jp_btnSalir.add(lblIconoBtn_salir);
        
        JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(1.85));
        jp_btnSalir.add(lblNombreBtn_salir);
        
        JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, ajustes.calcularPuntoY(8.33), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(17.13));
        contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        
        lblnewlabel = new JLabel("Kardex de Producto");
        lblnewlabel.setForeground(Variables.color_uno);
        lblnewlabel.setHorizontalAlignment(0);
        lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, ajustes.calcularPuntoY(1.85)));
        lblnewlabel.setBounds(0, ajustes.calcularPuntoY(0.46), ajustes.ancho, ajustes.calcularPuntoY(2.31));
        jp_contenido.add(lblnewlabel);
        JSeparator separator = new JSeparator();
        separator.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(3.24), ajustes.ancho - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        
        final JLabel lblNombreDeProducto = new JLabel("Nombre de Producto");
        lblNombreDeProducto.setForeground(Variables.color_uno);
        lblNombreDeProducto.setHorizontalAlignment(0);
        lblNombreDeProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreDeProducto.setBounds(this.ajustes.calcularPuntoX(2.05),this.ajustes.calcularPuntoY(4.42), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNombreDeProducto);
        
        (this.textField = new JTextField()).setBackground(Variables.color_uno);
        this.textField.setHorizontalAlignment(0);
        this.textField.setForeground(Variables.color_dos);
        this.textField.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this. textField.setBounds(this.ajustes.calcularPuntoX(2.05),this.ajustes.calcularPuntoY(6.77),this.ajustes.calcularPuntoX(29.33),this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.textField);
        
        JLabel lblNewLabel_1 = new JLabel("Fecha de Inicio");
        lblNewLabel_1.setHorizontalAlignment(0);
        lblNewLabel_1.setForeground(Variables.color_uno);
        lblNewLabel_1.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_1.setBounds(this.ajustes.calcularPuntoX(33.52), this.ajustes.calcularPuntoY(4.42), (this.ajustes.ancho - 25) / 10 * 1, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNewLabel_1);
        
        (this.textField_1 = new JTextField()).setBackground(Variables.color_uno);
        this.textField_1.setHorizontalAlignment(0);
        this.textField_1.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.textField_1.setBounds(this.ajustes.calcularPuntoX(33.52),this.ajustes.calcularPuntoY(6.77), (this.ajustes.ancho - 25) / 10 * 1, this.ajustes.calcularPuntoY(2.78));
        this.textField.setColumns(10);
        jp_contenido.add(this.textField_1);
        
        JLabel lblNewLabel_3 = new JLabel("Fecha Final");
        lblNewLabel_3.setHorizontalAlignment(0);
        lblNewLabel_3.setForeground(Variables.color_uno);;
        lblNewLabel_3.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNewLabel_3.setBounds(this.ajustes.calcularPuntoX(45.66), this.ajustes.calcularPuntoY(4.42), (this.ajustes.ancho - 25) / 10 * 1, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNewLabel_3);
        
        (this.textField_2 = new JTextField()).setBackground(Variables.color_uno);;
        this.textField_2.setHorizontalAlignment(0);
        this.textField_2.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.textField_2.setBounds(this.ajustes.calcularPuntoX(45.66),this.ajustes.calcularPuntoY(6.77), (this.ajustes.ancho - 25) / 10 * 1, this.ajustes.calcularPuntoY(2.78));
        this.textField.setColumns(10);
        jp_contenido.add(this.textField_2);
        
        final JPanel jp_btnBuscar = new JPanel();
        jp_btnBuscar.setLayout(null);
        jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscar.setBackground(Variables.color_uno);
        jp_btnBuscar.setBounds(788, 37, (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(4.63));
        jp_contenido.add(jp_btnBuscar);
        jp_btnBuscar.setLayout(null);
        
        (this.btnBuscar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.addMouseListener(new MouseAdapter() {
            private Object tblKardexProducto;
			private Object consultaSql;
			@Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_uno);
                KardexProducto.this.lblIconoBtn_buscar.setIcon(KardexProducto.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", KardexProducto.this.lblIconoBtn_buscar));
                KardexProducto.this.lblNombreBtn_buscar.setForeground(Variables.color_dos);
            }
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		String idIngresoProducto =  textField.getText();
				String fechaIni =  textField_1.getText();
        		String fechaFin = textField_2.getText();
        		
        		
        	}
			public void llenarTablaIngresoProducto(String nombreProducto,String fechaIni,String fechaFin) {
		    	
		    	fechaIni = (fechaIni==null) ? fechaIni=Variables.fechaActual : fechaIni ;
		    	fechaFin = (fechaFin==null) ? fechaFin=Variables.fechaActual : fechaFin ;
		    	
		    	
				
			}
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_dos);
                KardexProducto.this.lblIconoBtn_buscar.setIcon(KardexProducto.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar-select.png", KardexProducto.this.lblIconoBtn_buscar));
                KardexProducto.this.lblNombreBtn_buscar.setForeground(Variables.color_uno);
            }
        });
        this.btnBuscar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(4.63));
        jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.7));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", this.lblIconoBtn_buscar));
        jp_btnBuscar.add(this.lblIconoBtn_buscar);
        
        (this.lblNombreBtn_buscar = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscar.setForeground(Variables.color_dos);
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.7))));
        lblNombreBtn_buscar.setBounds(this.ajustes.calcularPuntoX(2.86), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(6.51), this.ajustes.calcularPuntoY(3.7));
        jp_btnBuscar.add(this.lblNombreBtn_buscar);
        
        (this.jp_tblIKardexProductos = new JPanel()).setBackground(Variables.color_uno);
        jp_tblIKardexProductos.setLayout(null);
        jp_tblIKardexProductos.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(10.65), this.ajustes.calcularPuntoX(97.4), this.ajustes.calcularPuntoY(71.3));;
        jp_contenido.add(this.jp_tblIKardexProductos);
        
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBackground(Variables.color_uno);
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.calcularPuntoX(96.35), this.ajustes.calcularPuntoY(69.44));
        this.jp_tblIKardexProductos.add(scrollPane);
        jp_tblIKardexProductos.add(scrollPane);
        
        (this.tblKardexProducto = new JTable()).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                KardexProducto.this.seleccionarProducto();
            }
        });
        this.tblKardexProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        scrollPane.setViewportView(this.tblKardexProducto);
    }
    
    public void seleccionarProducto() {
		// TODO Auto-generated method stub
		
	}
    public void configurarTabla() {
    	 final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
         JTableHeader header = new JTableHeader();
         final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
         final TableColumnModel columnModel = this.tblKardexProducto.getColumnModel();
         header = this.tblKardexProducto.getTableHeader();
         header.setFont(fuente);
         header.setForeground(Variables.color_dos);
         alinear.setHorizontalAlignment(0);
         columnModel.getColumn(0).setPreferredWidth(35);
         columnModel.getColumn(0).setCellRenderer(alinear);
         columnModel.getColumn(1).setPreferredWidth(500);
         columnModel.getColumn(2).setPreferredWidth(50);
         columnModel.getColumn(2).setCellRenderer(alinear);
         columnModel.getColumn(3).setPreferredWidth(50);
         columnModel.getColumn(3).setCellRenderer(alinear);
         columnModel.getColumn(4).setPreferredWidth(50);
         columnModel.getColumn(4).setCellRenderer(alinear);
         columnModel.getColumn(5).setPreferredWidth(50);
         columnModel.getColumn(5).setCellRenderer(alinear);
         columnModel.getColumn(6).setPreferredWidth(50);
         columnModel.getColumn(6).setCellRenderer(alinear);
         columnModel.getColumn(7).setPreferredWidth(75);
         columnModel.getColumn(7).setCellRenderer(alinear);
         columnModel.getColumn(8).setPreferredWidth(150);
    }

	@Override
    public void dispose() {
        getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
}
