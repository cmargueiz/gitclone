// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.inventario;

import javax.swing.JOptionPane;
import javax.swing.ComboBoxModel;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Inventario;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevaBodega extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Inventario inventario;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaBodega;
    private JLabel lblIconoBtn_nuevaBodega;
    private JLabel lblNombreBtn_nuevaBodega;
    private JPanel jp_btnBuscarBodega;
    private JLabel btnBuscarBodega;
    private JLabel lblIconoBtn_buscarBodega;
    private JLabel lblNombreBtn_buscarBodega;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblNuevaBodega;
    private JLabel btnNuevaBodega;
    private JTextField txtIdBodega;
    private JLabel lblNombreBodega;
    private JTextField txtNombreBodega;
    private JLabel lblFechaDocumento;
    private JTextField txtFechaDocumento;
    private JLabel lblOficina;
    private JTextField txtOficina;
    private JLabel lblDireccion;
    private JTextField txtDireccion;
    private JLabel lblCiudad;
    private JTextField txtCiudad;
    private JLabel lblTelefono;
    private JTextField txtTelefono;
    private JLabel lblUsuario;
    private JComboBox<Object> cbxUsuarios;
    private JLabel lblDescripcion;
    private JTextArea txtDescripcion;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevaBodega frame = new NuevaBodega();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevaBodega() {
        this.ajustes = new Ajustes();
        this.inventario = new F_Inventario();
        this.consultaSql = new consultasSQL_SERVER();
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevaBodega.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaBodega = new JPanel()).setLayout(null);
        this.jp_btnNuevaBodega.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaBodega.setBackground(Variables.color_tres);
        this.jp_btnNuevaBodega.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaBodega);
        (this.btnNuevaBodega = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaBodega.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaBodega.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnNuevaBodega.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                Variables.ventana_nuevaBodega = true;
                Variables.ventana_editarBodega = false;
                NuevaBodega.this.llenarCampos();
            }
        });
        this.btnNuevaBodega.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnNuevaBodega.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaBodega.add(this.btnNuevaBodega);
        (this.lblIconoBtn_nuevaBodega = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaBodega.setIcon(this.ajustes.ajustarImagen_("/images/botones-14-icono-nuevaBodega.png", this.lblIconoBtn_nuevaBodega));
        this.jp_btnNuevaBodega.add(this.lblIconoBtn_nuevaBodega);
        (this.lblNombreBtn_nuevaBodega = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaBodega.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaBodega.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaBodega.add(this.lblNombreBtn_nuevaBodega);
        (this.jp_btnBuscarBodega = new JPanel()).setLayout(null);
        this.jp_btnBuscarBodega.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarBodega.setBackground(Variables.color_tres);
        this.jp_btnBuscarBodega.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarBodega);
        (this.btnBuscarBodega = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarBodega.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarBodega.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnBuscarBodega.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                final ListaBodegas lbd = new ListaBodegas();
                lbd.setVisible(true);
            }
        });
        this.btnBuscarBodega.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnBuscarBodega.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarBodega.add(this.btnBuscarBodega);
        (this.lblIconoBtn_buscarBodega = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarBodega.setIcon(this.ajustes.ajustarImagen_("/images/botones-15-icono-buscarBodega.png", this.lblIconoBtn_buscarBodega));
        this.jp_btnBuscarBodega.add(this.lblIconoBtn_buscarBodega);
        (this.lblNombreBtn_buscarBodega = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarBodega.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarBodega.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarBodega.add(this.lblNombreBtn_buscarBodega);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevaBodega.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevaBodega.this.cerrar();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevaBodega.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblNuevaBodega = new JLabel("Crear Nueva Bodega")).setForeground(Variables.color_uno);
        this.lblNuevaBodega.setHorizontalAlignment(0);
        this.lblNuevaBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNuevaBodega.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblNuevaBodega);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JLabel lblIdBodega = new JLabel("ID Bodega:");
        lblIdBodega.setForeground(Variables.color_uno);
        lblIdBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblIdBodega.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblIdBodega);
        (this.txtIdBodega = new JTextField()).setEditable(false);
        this.txtIdBodega.setBackground(Variables.color_uno);
        this.txtIdBodega.setForeground(Variables.color_dos);
        this.txtIdBodega.setHorizontalAlignment(0);
        this.txtIdBodega.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtIdBodega.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtIdBodega);
        this.txtIdBodega.setColumns(10);
        (this.lblFechaDocumento = new JLabel("Fecha Documento:")).setForeground(Variables.color_uno);
        this.lblFechaDocumento.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaDocumento);
        (this.txtFechaDocumento = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaDocumento.setForeground(Variables.color_dos);
        this.txtFechaDocumento.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaDocumento.setEditable(false);
        this.txtFechaDocumento.setColumns(10);
        this.txtFechaDocumento.setBackground(Variables.color_uno);
        this.txtFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaDocumento);
        (this.lblNombreBodega = new JLabel("Nombre de Bodega:")).setForeground(Variables.color_uno);
        this.lblNombreBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBodega.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNombreBodega);
        (this.txtNombreBodega = new JTextField()).setForeground(Variables.color_dos);
        this.txtNombreBodega.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreBodega.setColumns(10);
        this.txtNombreBodega.setBackground(Variables.color_uno);
        this.txtNombreBodega.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreBodega);
        (this.lblOficina = new JLabel("Oficina:")).setForeground(Variables.color_uno);
        this.lblOficina.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblOficina.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(15.74), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblOficina);
        (this.txtOficina = new JTextField()).setEditable(false);
        this.txtOficina.setForeground(Variables.color_dos);
        this.txtOficina.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtOficina.setColumns(10);
        this.txtOficina.setBackground(Variables.color_uno);
        this.txtOficina.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(17.59), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtOficina);
        (this.lblDireccion = new JLabel("Direccion:")).setForeground(Variables.color_uno);
        this.lblDireccion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDireccion.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(21.3), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDireccion);
        (this.txtDireccion = new JTextField()).setForeground(Variables.color_dos);
        this.txtDireccion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDireccion.setColumns(10);
        this.txtDireccion.setBackground(Variables.color_uno);
        this.txtDireccion.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(23.15), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDireccion);
        (this.lblCiudad = new JLabel("Ciudad:")).setForeground(Variables.color_uno);
        this.lblCiudad.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCiudad.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(26.85), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblCiudad);
        (this.txtCiudad = new JTextField()).setForeground(Variables.color_dos);
        this.txtCiudad.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCiudad.setColumns(10);
        this.txtCiudad.setBackground(Variables.color_uno);
        this.txtCiudad.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(28.7), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCiudad);
        (this.lblTelefono = new JLabel("Telefono:")).setForeground(Variables.color_uno);
        this.lblTelefono.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblTelefono.setBounds((this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(26.85), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblTelefono);
        (this.txtTelefono = new JTextField()).setForeground(Variables.color_dos);
        this.txtTelefono.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtTelefono.setColumns(10);
        this.txtTelefono.setBackground(Variables.color_uno);
        this.txtTelefono.setBounds((this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(28.7), (this.ajustes.ancho - 25) / 10 * 3, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtTelefono);
        (this.lblUsuario = new JLabel("Encargado de Bodega:")).setForeground(Variables.color_uno);
        this.lblUsuario.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblUsuario.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(32.41), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblUsuario);
        (this.cbxUsuarios = new JComboBox<Object>()).setCursor(Cursor.getPredefinedCursor(12));
        this.cbxUsuarios.setBackground(Variables.color_uno);
        this.cbxUsuarios.setForeground(Variables.color_dos);
        this.cbxUsuarios.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxUsuarios.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(34.26), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxUsuarios);
        (this.lblDescripcion = new JLabel("Descripci\u00f3n:")).setForeground(Variables.color_uno);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(37.95), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescripcion);
        (this.txtDescripcion = new JTextArea()).setBackground(Variables.color_uno);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setBounds((this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(39.81), (this.ajustes.ancho - 25) / 10 * 8, this.ajustes.alto - this.ajustes.calcularPuntoY(57.41));
        jp_contenido.add(this.txtDescripcion);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void cerrar() {
        if (Variables.ventana_editarBodega) {
            final ListaBodegas lbo = new ListaBodegas();
            Variables.ventana_nuevaBodega = false;
            Variables.ventana_editarBodega = false;
            lbo.setVisible(true);
            this.dispose();
        }
        else {
            this.dispose();
        }
    }
    
    public void llenarCampos() {
        if (Variables.ventana_nuevaBodega && !Variables.ventana_editarBodega) {
            this.lblNuevaBodega.setText("Crear Nueva Bodega");
            this.txtFechaDocumento.setText(Variables.fechaActual);
            this.txtNombreBodega.setText("");
            this.txtNombreBodega.requestFocus();
            this.txtIdBodega.setText(Integer.toString(this.consultaSql.obtenerSigIdBodega(Variables.idOficina)));
            this.txtOficina.setText(Variables.nombreOficina);
            this.cbxUsuarios.setModel(this.consultaSql.getDataComboBox("select nombre\r\nfrom usuario\r\nwhere oficina_idoficina = '" + Variables.idOficina + "' \r\n" + "order by nombre asc"));
            this.consultaSql.obtenerInfoOficina(this.txtOficina.getText(), Variables.idOficina);
            this.txtDireccion.setText(this.consultaSql.direccion_bodega);
            this.txtCiudad.setText(this.consultaSql.ciudad_bodega);
            this.txtTelefono.setText(this.consultaSql.telefono_bodega);
            this.txtDescripcion.setText("");
        }
        else if (!Variables.ventana_nuevaBodega && Variables.ventana_editarBodega) {
            this.lblNuevaBodega.setText("Editar Bodega");
            this.txtFechaDocumento.setText(Variables.fechaMod);
            this.txtIdBodega.setText(Variables.idBodega);
            this.txtNombreBodega.setText(Variables.nombreBodega);
            this.txtOficina.setText(Variables.nombreOficina);
            this.cbxUsuarios.setModel(this.consultaSql.getDataComboBox("select nombre\r\nfrom usuario\r\nwhere oficina_idoficina = '" + Variables.idOficina + "' \r\n" + "order by nombre asc"));
            this.cbxUsuarios.setSelectedItem(Variables.encargadoBodega);
            this.txtDireccion.setText(Variables.direccionBodega);
            this.txtCiudad.setText(Variables.ciudadBodega);
            this.txtTelefono.setText(Variables.telefonoBodega);
            this.txtDescripcion.setText(Variables.descripcionBodega);
        }
    }
    
    public void guardar() {
        if (this.verificarEspaciosVacios() > 0) {
            JOptionPane.showMessageDialog(null, "No puede quedar espacios vacios", "ERROR!", 0);
            return;
        }
        if (Variables.ventana_nuevaBodega && !Variables.ventana_editarBodega) {
            this.ingresoNuevaBodega();
        }
        else if (!Variables.ventana_nuevaBodega && Variables.ventana_editarBodega) {
            this.modificarBodega();
        }
    }
    
    public int verificarEspaciosVacios() {
        int resultado = 0;
        if (this.txtNombreBodega.getText().length() == 0) {
            this.lblNombreBodega.setForeground(Color.red);
            this.txtNombreBodega.requestFocus();
            ++resultado;
        }
        if (this.txtDireccion.getText().length() == 0) {
            this.lblDireccion.setForeground(Color.red);
            this.txtDireccion.requestFocus();
            ++resultado;
        }
        if (this.txtCiudad.getText().length() == 0) {
            this.lblCiudad.setForeground(Color.red);
            this.txtCiudad.requestFocus();
            ++resultado;
        }
        if (this.txtTelefono.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "El campo Telefono, no puede quedar vacio", "ERROR!", 0);
            this.lblTelefono.setForeground(Color.red);
            this.txtTelefono.requestFocus();
            ++resultado;
        }
        if (this.txtDescripcion.getText().length() == 0) {
            this.lblDescripcion.setForeground(Color.red);
            this.txtDescripcion.requestFocus();
            ++resultado;
        }
        return resultado;
    }
    
    public void ingresoNuevaBodega() {
        if (this.inventario.nuevaBodega(Integer.parseInt(this.txtIdBodega.getText()), this.txtNombreBodega.getText(), Variables.idOficina, this.cbxUsuarios.getSelectedItem().toString(), this.txtDescripcion.getText(), this.txtDireccion.getText(), this.txtCiudad.getText(), this.txtTelefono.getText(), Variables.fechaActual, Variables.idUsuario)) {
            JOptionPane.showMessageDialog(null, "Bodega '" + this.txtNombreBodega.getText() + "' guardada correctamente.", "OK!", 1);
            this.txtNombreBodega.setText("");
            this.txtDescripcion.setText("");
            this.txtIdBodega.setText(Integer.toString(this.consultaSql.obtenerSigIdBodega(Variables.idOficina)));
            return;
        }
        JOptionPane.showMessageDialog(null, "Al guardar la nueva bodega -- " + Variables.error, "ERROR!", 0);
    }
    
    public void modificarBodega() {
        if (this.inventario.modificarBodega(Integer.parseInt(this.txtIdBodega.getText()), this.txtNombreBodega.getText(), Variables.idOficina, this.cbxUsuarios.getSelectedItem().toString(), this.txtDescripcion.getText(), this.txtDireccion.getText(), this.txtCiudad.getText(), this.txtTelefono.getText(), Variables.fechaActual, Variables.idUsuario)) {
            JOptionPane.showMessageDialog(null, "Bodega '" + this.txtNombreBodega.getText() + "' modificada correctamente.", "OK!", 1);
            final ListaBodegas lbo = new ListaBodegas();
            Variables.ventana_nuevaBodega = false;
            Variables.ventana_editarBodega = false;
            lbo.setVisible(true);
            this.dispose();
            return;
        }
        JOptionPane.showMessageDialog(null, "Al guardar la nueva bodega -- " + Variables.error, "ERROR!", 0);
    }
}
