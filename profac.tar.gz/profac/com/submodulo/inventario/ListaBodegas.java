// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.inventario;

import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaBodegas extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaBodega;
    private JLabel btnNuevaBodega;
    private JLabel lblIconoBtn_nuevaBodega;
    private JLabel lblNombreBtn_nuevaBodega;
    private JPanel jp_btnEditarBodega;
    private JLabel btnEditarBodega;
    private JLabel lblIconoBtn_EditarBodega;
    private JLabel lblNombreBtn_EditarBodega;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblBodegas;
    private JTextField txtIdBodega;
    private JTextField txtNombreBodega;
    private JTextField txtFechaMod;
    private JTextField txtUsuarioMod;
    private JTextField txtCiudad;
    private JLabel lblDireccion;
    private JTextField txtDireccion;
    private JLabel lblDescripcion;
    private JTextField txtDescripcion;
    private JTable tblBodega;
    private JTextField txtEncargado;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaBodegas frame = new ListaBodegas();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaBodegas() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaBodegas.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaBodega = new JPanel()).setLayout(null);
        this.jp_btnNuevaBodega.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaBodega.setBackground(Variables.color_tres);
        this.jp_btnNuevaBodega.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaBodega);
        (this.btnNuevaBodega = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaBodega.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaBodega.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnNuevaBodega.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaBodega.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnNuevaBodega.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaBodega.add(this.btnNuevaBodega);
        (this.lblIconoBtn_nuevaBodega = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaBodega.setIcon(this.ajustes.ajustarImagen_("/images/botones-14-icono-nuevaBodega.png", this.lblIconoBtn_nuevaBodega));
        this.jp_btnNuevaBodega.add(this.lblIconoBtn_nuevaBodega);
        (this.lblNombreBtn_nuevaBodega = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaBodega.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaBodega.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaBodega.add(this.lblNombreBtn_nuevaBodega);
        (this.jp_btnEditarBodega = new JPanel()).setLayout(null);
        this.jp_btnEditarBodega.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnEditarBodega.setBackground(Variables.color_tres);
        this.jp_btnEditarBodega.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnEditarBodega);
        (this.btnEditarBodega = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnEditarBodega.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnEditarBodega.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnEditarBodega.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                ListaBodegas.this.editar();
            }
        });
        this.btnEditarBodega.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnEditarBodega.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnEditarBodega.add(this.btnEditarBodega);
        (this.lblIconoBtn_EditarBodega = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_EditarBodega.setIcon(this.ajustes.ajustarImagen_("/images/botones-16-icono-editarBodega.png", this.lblIconoBtn_EditarBodega));
        this.jp_btnEditarBodega.add(this.lblIconoBtn_EditarBodega);
        (this.lblNombreBtn_EditarBodega = new JLabel("Editar")).setHorizontalAlignment(0);
        this.lblNombreBtn_EditarBodega.setForeground(Variables.color_uno);
        this.lblNombreBtn_EditarBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_EditarBodega.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnEditarBodega.add(this.lblNombreBtn_EditarBodega);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaBodegas.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaBodegas.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblBodegas = new JLabel("Listado de Bodegas")).setForeground(Variables.color_uno);
        this.lblBodegas.setHorizontalAlignment(0);
        this.lblBodegas.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblBodegas.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblBodegas);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JLabel lblIdBodega = new JLabel("ID Bodega:");
        lblIdBodega.setHorizontalAlignment(0);
        lblIdBodega.setForeground(Variables.color_uno);
        lblIdBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblIdBodega.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblIdBodega);
        (this.txtIdBodega = new JTextField()).setEditable(false);
        this.txtIdBodega.setHorizontalAlignment(0);
        this.txtIdBodega.setForeground(Variables.color_dos);
        this.txtIdBodega.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtIdBodega.setBackground(Variables.color_uno);
        this.txtIdBodega.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtIdBodega);
        this.txtIdBodega.setColumns(10);
        final JLabel lblNombreBodega = new JLabel("Nombre de Bodega:");
        lblNombreBodega.setHorizontalAlignment(0);
        lblNombreBodega.setForeground(Variables.color_uno);
        lblNombreBodega.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBodega.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNombreBodega);
        (this.txtNombreBodega = new JTextField()).setEditable(false);
        this.txtNombreBodega.setHorizontalAlignment(0);
        this.txtNombreBodega.setForeground(Variables.color_dos);
        this.txtNombreBodega.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreBodega.setColumns(10);
        this.txtNombreBodega.setBackground(Variables.color_uno);
        this.txtNombreBodega.setBounds((this.ajustes.ancho - 25) / 10 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreBodega);
        final JLabel lblCiudad = new JLabel("Ciudad:");
        lblCiudad.setHorizontalAlignment(0);
        lblCiudad.setForeground(Variables.color_uno);
        lblCiudad.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblCiudad.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblCiudad);
        (this.txtCiudad = new JTextField()).setEditable(false);
        this.txtCiudad.setHorizontalAlignment(0);
        this.txtCiudad.setForeground(Variables.color_dos);
        this.txtCiudad.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCiudad.setColumns(10);
        this.txtCiudad.setBackground(Variables.color_uno);
        this.txtCiudad.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCiudad);
        final JLabel lblFechaMod = new JLabel("Fecha Mod:");
        lblFechaMod.setHorizontalAlignment(0);
        lblFechaMod.setForeground(Variables.color_uno);
        lblFechaMod.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaMod.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblFechaMod);
        (this.txtFechaMod = new JTextField()).setEditable(false);
        this.txtFechaMod.setHorizontalAlignment(0);
        this.txtFechaMod.setForeground(Variables.color_dos);
        this.txtFechaMod.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaMod.setColumns(10);
        this.txtFechaMod.setBackground(Variables.color_uno);
        this.txtFechaMod.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaMod);
        final JLabel lblUsuarioMod = new JLabel("Usuario:");
        lblUsuarioMod.setHorizontalAlignment(0);
        lblUsuarioMod.setForeground(Variables.color_uno);
        lblUsuarioMod.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblUsuarioMod.setBounds((this.ajustes.ancho - 25) / 10 * 8 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblUsuarioMod);
        (this.txtUsuarioMod = new JTextField()).setEditable(false);
        this.txtUsuarioMod.setHorizontalAlignment(0);
        this.txtUsuarioMod.setForeground(Variables.color_dos);
        this.txtUsuarioMod.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtUsuarioMod.setColumns(10);
        this.txtUsuarioMod.setBackground(Variables.color_uno);
        this.txtUsuarioMod.setBounds(this.ajustes.calcularPuntoX(80.83), this.ajustes.calcularPuntoY(6.48), this.ajustes.calcularPuntoX(17.86), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtUsuarioMod);
        final JLabel lblEncargado = new JLabel("Encargado:");
        lblEncargado.setHorizontalAlignment(0);
        lblEncargado.setForeground(Variables.color_uno);
        lblEncargado.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblEncargado.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblEncargado);
        (this.txtEncargado = new JTextField()).setHorizontalAlignment(0);
        this.txtEncargado.setForeground(Variables.color_dos);
        this.txtEncargado.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtEncargado.setEditable(false);
        this.txtEncargado.setColumns(10);
        this.txtEncargado.setBackground(Variables.color_uno);
        this.txtEncargado.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 25) / 10 * 3 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtEncargado);
        (this.lblDireccion = new JLabel("Direcci\u00f3n:")).setHorizontalAlignment(0);
        this.lblDireccion.setForeground(Variables.color_uno);
        this.lblDireccion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDireccion.setBounds((this.ajustes.ancho - 25) / 10 * 3 + this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 7 - this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDireccion);
        (this.txtDireccion = new JTextField()).setHorizontalAlignment(0);
        this.txtDireccion.setForeground(Variables.color_dos);
        this.txtDireccion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDireccion.setEditable(false);
        this.txtDireccion.setColumns(10);
        this.txtDireccion.setBackground(Variables.color_uno);
        this.txtDireccion.setBounds(this.ajustes.calcularPuntoX(31.61), this.ajustes.calcularPuntoY(12.04), this.ajustes.calcularPuntoX(67.08), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDireccion);
        (this.lblDescripcion = new JLabel("Descripci\u00f3n:")).setHorizontalAlignment(0);
        this.lblDescripcion.setForeground(Variables.color_uno);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(15.74), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescripcion);
        (this.txtDescripcion = new JTextField()).setHorizontalAlignment(0);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setEditable(false);
        this.txtDescripcion.setColumns(10);
        this.txtDescripcion.setBackground(Variables.color_uno);
        this.txtDescripcion.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(17.59), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescripcion);
        final JPanel jp_tblBodega = new JPanel();
        jp_tblBodega.setBorder(new BevelBorder(0, null, null, null, null));
        jp_tblBodega.setBackground(Variables.color_uno);
        jp_tblBodega.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(21.3), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.alto - this.ajustes.calcularPuntoY(38.43));
        jp_contenido.add(jp_tblBodega);
        jp_tblBodega.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.ancho - this.ajustes.calcularPuntoX(3.65), this.ajustes.alto - this.ajustes.calcularPuntoY(40.28));
        jp_tblBodega.add(scrollPane);
        (this.tblBodega = new JTable()).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                ListaBodegas.this.seleccionarBodega(ListaBodegas.this.tblBodega);
            }
        });
        this.tblBodega.setCursor(Cursor.getPredefinedCursor(12));
        this.tblBodega.setForeground(Variables.color_dos);
        this.tblBodega.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        this.tblBodega.setBackground(Variables.color_uno);
        scrollPane.setViewportView(this.tblBodega);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void llenarCampos() {
        this.tblBodega.setModel(this.consultaSql.llenarTablaListaBodegas(Variables.idOficina));
        this.configurarTabla();
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        final TableColumnModel columnModel = this.tblBodega.getColumnModel();
        header = this.tblBodega.getTableHeader();
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(400);
        columnModel.getColumn(2).setPreferredWidth(400);
        columnModel.getColumn(3).setPreferredWidth(75);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(150);
    }
    
    public void seleccionarBodega(final JTable tbl) {
        this.txtIdBodega.setText((String)tbl.getValueAt(tbl.getSelectedRow(), 0));
        Variables.idBodega = this.txtIdBodega.getText();
        this.txtNombreBodega.setText((String)tbl.getValueAt(tbl.getSelectedRow(), 1));
        Variables.nombreBodega = this.txtNombreBodega.getText();
        this.txtEncargado.setText((String)tbl.getValueAt(tbl.getSelectedRow(), 2));
        Variables.encargadoBodega = this.txtEncargado.getText();
        this.txtFechaMod.setText((String)tbl.getValueAt(tbl.getSelectedRow(), 3));
        Variables.fechaMod = this.txtFechaMod.getText();
        this.txtUsuarioMod.setText((String)tbl.getValueAt(tbl.getSelectedRow(), 4));
        this.consultaSql.obtenerInfoBodega(Integer.parseInt(this.txtIdBodega.getText()), Variables.idOficina);
        this.txtCiudad.setText(Variables.ciudadBodega);
        this.txtDescripcion.setText(Variables.descripcionBodega);
        this.txtDireccion.setText(Variables.direccionBodega);
    }
    
    public void editar() {
        if (this.txtIdBodega.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "Primero selecciona una bodega", "ALERTA!", 2);
            return;
        }
        final NuevaBodega nbo = new NuevaBodega();
        nbo.setVisible(Variables.ventana_editarBodega = true);
        this.dispose();
    }
}
