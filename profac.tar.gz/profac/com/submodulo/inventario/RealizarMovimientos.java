package profac.com.submodulo.inventario;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import profac.com.database.consultasSQL_SERVER;
import profac.com.database.insertSQL_SERVER;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Variables;
import profac.com.herramientas.Texto;
import profac.com.herramientas.Fechas;
import profac.com.submodulo.contabilidad.VicularCuentasContables;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListDataListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ListSelectionModel;
import javax.swing.JRadioButton;
import javax.swing.JButton;

public class RealizarMovimientos extends JFrame {

	/**
	 * @author Frank Castro
	 */

	private static final long serialVersionUID = 1L;

	public Ajustes ajustes = new Ajustes();
	public consultasSQL_SERVER consultaSql = new consultasSQL_SERVER();
	public insertSQL_SERVER insertSql = new insertSQL_SERVER();

	private JPanel contentPane;
	private JPanel jp_btnSalir;
	private JLabel btnSalir;
	private JPanel jp_btnNuevaPartida;
	private JLabel btnNuevaPartida;
	private JLabel lblIconoBtn_nuevaPartida;
	private JLabel lblNombreBtn_nuevaPartida;
	private JPanel jp_btnBuscarPartida;
	private JLabel btnBuscarPartida;
	private JLabel lblIconoBtn_buscarPartida;
	private JLabel lblNombreBtn_buscarPartida;
	private JPanel jp_btnGuardar;
	private JLabel btnGuardar;
	private JLabel lblIconoBtn_guardar;
	private JLabel lblNombreBtn_guardar;
	private JPanel jp_btnImprimir;
	private JLabel btnImprimir;
	private JLabel lblIconoBtn_imprimir;
	private JLabel lblNombreBtn_imprimir;
	private JLabel lblnewlabel;
	private JTextField txtBuscarProducto;
	private JTextField txtNumDoc;
	private JTextField txtCantMov;
	private JTextField txtFechamod;

	private JLabel lblCodMov;

	private JLabel lblNumDoc;

	private JLabel lblCantMov;

	private JLabel lblFechamod;

	private JLabel lblTipoMov;

	private JLabel lblOficina;

	private JLabel lblOficinaDestino;
	private JLabel lblBodegaDestino;
	private JScrollPane scrollPane;

	private JPanel jp_listaproductos;
	private JTable tblProductos;
	private JScrollPane scrollPane_1;

	private JPanel jp_kardex;

	private JPanel jp_btnAplicar;

	private JLabel btnAplicar;

	private JLabel lblIconoBtn_aplicar;

	private JLabel lblNombreBtn_aplicar;

	private JComboBox cbxTipoMov;

	private JComboBox cbxOficina;

	private JComboBox cbxOficinaDestino;
	
	private JComboBox cbxBodegaOrigen;

	private JComboBox cbxBodegaDestino;

	public DefaultTableModel modeloProductos = new DefaultTableModel();
	public DefaultTableModel modeloKardex = new DefaultTableModel();
	public ArrayList<String[]> listaIngresar = new ArrayList<String[]>();
	public ArrayList<String[]> listaIngresarTraslado = new ArrayList<String[]>();
	public boolean traslado = false;
	public String[] lastMov;
	public Fechas fechasHandler = new Fechas();

	private JTable tblkardex;
	private JLabel lblBodega;
	private JComboBox cbxBodega;
	private JLabel lblBodegaDestin;
	private JComboBox cbxBodegaDestin;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					RealizarMovimientos frame = new RealizarMovimientos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public RealizarMovimientos() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				iniciarTablaKardex();
				llenarListaProductos();
				setLasMov();
				llenarCmbOficina();
				llenarCmbBodegas();
				llenarCmbTipoMovimiento();
				configurarTablas();
				controlesTraslado(false);
				txtFechamod.setText(Variables.fechaActual);
				txtNumDoc.setText(getNumDoc());
			}
		});
		setDefaultCloseOperation(3);
		setResizable(false);
		setUndecorated(true);
		setBounds(0, ajustes.calcularPuntoY(6.57), ajustes.ancho, ajustes.alto - ajustes.calcularPuntoY(8.8));
		contentPane = new JPanel();
		contentPane.setBackground(Variables.color_tres);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel jp_botones = new JPanel();
		jp_botones.setBackground(Variables.color_uno);
		jp_botones.setBorder(null);
		jp_botones.setBounds(0, 0, ajustes.ancho, ajustes.calcularPuntoY(8.33));
		jp_botones.setLayout(null);
		contentPane.add(jp_botones);

		jp_btnNuevaPartida = new JPanel();
		jp_btnNuevaPartida.setLayout(null);
		jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnNuevaPartida.setBackground(Variables.color_tres);
		jp_btnNuevaPartida.setBounds(ajustes.calcularPuntoX(0.78), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnNuevaPartida);

		btnNuevaPartida = new JLabel("");
		btnNuevaPartida.setCursor(Cursor.getPredefinedCursor(12));
		btnNuevaPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnNuevaPartida.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnNuevaPartida.setBackground(Variables.color_tres);
			}
		});
		btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnNuevaPartida.setBackground(Variables.color_dos);
			}
		});
		jp_btnNuevaPartida.add(btnNuevaPartida);

		lblIconoBtn_nuevaPartida = new JLabel("");
		lblIconoBtn_nuevaPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_nuevaPartida
				.setIcon(ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", lblIconoBtn_nuevaPartida));
		jp_btnNuevaPartida.add(lblIconoBtn_nuevaPartida);

		lblNombreBtn_nuevaPartida = new JLabel("Nueva");
		lblNombreBtn_nuevaPartida.setHorizontalAlignment(0);
		lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
		lblNombreBtn_nuevaPartida
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_nuevaPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnNuevaPartida.add(lblNombreBtn_nuevaPartida);

		jp_btnBuscarPartida = new JPanel();
		jp_btnBuscarPartida.setLayout(null);
		jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnBuscarPartida.setBackground(Variables.color_tres);
		jp_btnBuscarPartida.setBounds(ajustes.calcularPuntoX(4.95), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnBuscarPartida);

		btnBuscarPartida = new JLabel("");
		btnBuscarPartida.setCursor(Cursor.getPredefinedCursor(12));
		btnBuscarPartida.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnBuscarPartida.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnBuscarPartida.setBackground(Variables.color_tres);
			}
		});
		btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnBuscarPartida.setBackground(Variables.color_dos);
			}
		});
		jp_btnBuscarPartida.add(btnBuscarPartida);

		lblIconoBtn_buscarPartida = new JLabel("");
		lblIconoBtn_buscarPartida.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_buscarPartida.setIcon(
				ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", lblIconoBtn_buscarPartida));
		jp_btnBuscarPartida.add(lblIconoBtn_buscarPartida);

		lblNombreBtn_buscarPartida = new JLabel("Buscar");
		lblNombreBtn_buscarPartida.setHorizontalAlignment(0);
		lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
		lblNombreBtn_buscarPartida
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_buscarPartida.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnBuscarPartida.add(lblNombreBtn_buscarPartida);

		jp_btnGuardar = new JPanel();
		jp_btnGuardar.setLayout(null);
		jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnGuardar.setBackground(Variables.color_tres);
		jp_btnGuardar.setBounds(ajustes.calcularPuntoX(9.11), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnGuardar);

		btnGuardar = new JLabel("");
		btnGuardar.setCursor(Cursor.getPredefinedCursor(12));
		btnGuardar.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnGuardar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnGuardar.setBackground(Variables.color_tres);
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				insertarRegistro();
			}
		});
		btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnGuardar.setBackground(Variables.color_dos);
			}
		});
		jp_btnGuardar.add(btnGuardar);

		lblIconoBtn_guardar = new JLabel("");
		lblIconoBtn_guardar.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_guardar
				.setIcon(ajustes.ajustarImagen("/botones_04_icono_guardar", lblIconoBtn_guardar, 50, 50, 50, 50));
		jp_btnGuardar.add(lblIconoBtn_guardar);

		lblNombreBtn_guardar = new JLabel("Guardar");
		lblNombreBtn_guardar.setHorizontalAlignment(0);
		lblNombreBtn_guardar.setForeground(Variables.color_uno);
		lblNombreBtn_guardar
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_guardar.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnGuardar.add(lblNombreBtn_guardar);

		jp_btnImprimir = new JPanel();
		jp_btnImprimir.setLayout(null);
		jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnImprimir.setBackground(Variables.color_tres);
		jp_btnImprimir.setBounds(ajustes.calcularPuntoX(13.28), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnImprimir);

		btnImprimir = new JLabel("");
		btnImprimir.setCursor(Cursor.getPredefinedCursor(12));
		btnImprimir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnImprimir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnImprimir.setBackground(Variables.color_tres);
			}
		});
		btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnImprimir.setBackground(Variables.color_dos);
			}
		});
		jp_btnImprimir.add(btnImprimir);

		lblIconoBtn_imprimir = new JLabel("");
		lblIconoBtn_imprimir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.46),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_imprimir
				.setIcon(ajustes.ajustarImagen("/botones_05_icono_imprimir", lblIconoBtn_imprimir, 50, 50, 50, 50));
		jp_btnImprimir.add(lblIconoBtn_imprimir);

		lblNombreBtn_imprimir = new JLabel("Imprimir");
		lblNombreBtn_imprimir.setHorizontalAlignment(0);
		lblNombreBtn_imprimir.setForeground(Variables.color_uno);
		lblNombreBtn_imprimir
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_imprimir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnImprimir.add(lblNombreBtn_imprimir);

		jp_btnSalir = new JPanel();
		jp_btnSalir.setBackground(Variables.color_tres);
		jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
		jp_btnSalir.setBounds(ajustes.calcularPuntoX(26.04), ajustes.calcularPuntoY(0.46), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(7.41));
		jp_botones.add(jp_btnSalir);
		jp_btnSalir.setLayout(null);

		btnSalir = new JLabel("");
		btnSalir.setCursor(Cursor.getPredefinedCursor(12));
		btnSalir.setBounds(0, 0, ajustes.calcularPuntoX(3.13), ajustes.calcularPuntoY(7.41));
		btnSalir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent arg0) {
				jp_btnSalir.setBackground(Variables.color_tres);
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				jp_btnSalir.setBackground(Variables.color_dos);
			}
		});
		jp_btnSalir.add(btnSalir);

		JLabel lblIconoBtn_salir = new JLabel("");
		lblIconoBtn_salir.setBounds(ajustes.calcularPuntoX(0.26), ajustes.calcularPuntoY(0.43),
				ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(4.63));
		lblIconoBtn_salir.setIcon(ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
		jp_btnSalir.add(lblIconoBtn_salir);

		JLabel lblNombreBtn_salir = new JLabel("Salir");
		lblNombreBtn_salir.setForeground(Variables.color_uno);
		lblNombreBtn_salir.setHorizontalAlignment(0);
		lblNombreBtn_salir
				.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.39))));
		lblNombreBtn_salir.setBounds(0, ajustes.calcularPuntoY(5.56), ajustes.calcularPuntoX(3.13),
				ajustes.calcularPuntoY(1.85));
		jp_btnSalir.add(lblNombreBtn_salir);

		JPanel jp_contenido = new JPanel();
		jp_contenido.setOpaque(false);
		jp_contenido.setBounds(0, ajustes.calcularPuntoY(8.33), ajustes.ancho,
				ajustes.alto - ajustes.calcularPuntoY(17.13));
		contentPane.add(jp_contenido);
		jp_contenido.setLayout(null);

		lblnewlabel = new JLabel("Realizar Movimientos");
		lblnewlabel.setForeground(Variables.color_uno);
		lblnewlabel.setHorizontalAlignment(0);
		lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, ajustes.calcularPuntoY(1.85)));
		lblnewlabel.setBounds(0, ajustes.calcularPuntoY(0.46), ajustes.ancho, ajustes.calcularPuntoY(2.31));
		jp_contenido.add(lblnewlabel);
		JSeparator separator = new JSeparator();
		separator.setBounds(ajustes.calcularPuntoX(1.3), ajustes.calcularPuntoY(3.24),
				ajustes.ancho - ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(0.19));
		jp_contenido.add(separator);

		(this.jp_listaproductos = new JPanel()).setBackground(Variables.color_uno);
		this.jp_listaproductos.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)),
				"Lista de Productos", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
		this.jp_listaproductos.setForeground(Color.BLACK);
		this.jp_listaproductos.setOpaque(false);
		this.jp_listaproductos.setBounds(this.ajustes.calcularPuntoX(1.32), this.ajustes.calcularPuntoY(6.90),
				this.ajustes.calcularPuntoX(39.33), this.ajustes.calcularPuntoY(74.34));
		jp_contenido.add(this.jp_listaproductos);
		this.jp_listaproductos.setLayout(null);

		final JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		scrollPane.setBackground(Variables.color_uno);
		scrollPane.setBounds(this.ajustes.calcularPuntoX(0.88), this.ajustes.calcularPuntoY(2.86),
				this.ajustes.calcularPuntoX(37.57), this.ajustes.calcularPuntoY(69.92));
		jp_listaproductos.add(scrollPane);

		(this.tblProductos = new JTable()).addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(final MouseEvent e) {
				RealizarMovimientos.this.seleccionarProducto();
			}
		});
		tblProductos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setLasMov();
				llenarCmbBodegas();
				llenarCmbOficina();
				
			}
		});
		this.tblProductos.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		scrollPane.setViewportView(this.tblProductos);

		(this.jp_kardex = new JPanel()).setBackground(Variables.color_uno);
		this.jp_kardex.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Informacion de Kardex",
				TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
		this.jp_kardex.setForeground(Color.BLACK);
		this.jp_kardex.setOpaque(false);
		this.jp_kardex.setBounds(this.ajustes.calcularPuntoX(41.54), this.ajustes.calcularPuntoY(37.63),
				this.ajustes.calcularPuntoX(57.20), this.ajustes.calcularPuntoY(43.61));
		jp_contenido.add(this.jp_kardex);
		this.jp_kardex.setLayout(null);

		final JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBackground(Variables.color_uno);
		scrollPane_2.setBounds(this.ajustes.calcularPuntoX(0.88), this.ajustes.calcularPuntoY(2.86),
				this.ajustes.calcularPuntoX(55.44), this.ajustes.calcularPuntoY(39.19));
		this.jp_kardex.add(scrollPane_2);

		tblkardex = new JTable();
		tblkardex.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPane_2.setViewportView(tblkardex);

		(this.lblCodMov = new JLabel("Buscar Producto")).setHorizontalAlignment(0);
		this.lblCodMov.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblCodMov.setForeground(Variables.color_uno);
		this.lblCodMov.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		this.lblCodMov.setBounds(1139, 53,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lblCodMov);

		(this.txtBuscarProducto = new JTextField()).setBackground(Variables.color_uno);
		txtBuscarProducto.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				llenarListaProductos(txtBuscarProducto.getText());
			}
		});
		this.txtBuscarProducto.setHorizontalAlignment(0);
		this.txtBuscarProducto.setForeground(Variables.color_dos);
		this.txtBuscarProducto.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		txtBuscarProducto.setBounds(1139, 79,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.txtBuscarProducto);
		txtBuscarProducto.setColumns(10);

		(this.lblNumDoc = new JLabel("Numero de documento")).setHorizontalAlignment(0);
		this.lblNumDoc.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblNumDoc.setForeground(Variables.color_uno);
		this.lblNumDoc.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblNumDoc.setBounds(this.ajustes.calcularPuntoX(65.14), this.ajustes.calcularPuntoY(6.90),
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lblNumDoc);

		(this.txtNumDoc = new JTextField()).setBackground(Variables.color_uno);
		txtNumDoc.setEditable(false);
		this.txtNumDoc.setHorizontalAlignment(0);
		this.txtNumDoc.setForeground(Variables.color_dos);
		this.txtNumDoc.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.txtNumDoc.setBounds(this.ajustes.calcularPuntoX(65.14), this.ajustes.calcularPuntoY(10.28),
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.txtNumDoc);
		txtNumDoc.setColumns(10);

		(this.lblCantMov = new JLabel("Cantidad de Movimiento")).setHorizontalAlignment(0);
		this.lblCantMov.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblCantMov.setForeground(Variables.color_uno);
		this.lblCantMov.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		this.lblCantMov.setBounds(this.ajustes.calcularPuntoX(44.41), this.ajustes.calcularPuntoY(14.58),
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(lblCantMov);

		(this.txtCantMov = new JTextField()).setBackground(Variables.color_uno);
		this.txtCantMov.setHorizontalAlignment(0);
		this.txtCantMov.setForeground(Variables.color_dos);
		this.txtCantMov.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.txtCantMov.setBounds(this.ajustes.calcularPuntoX(44.41), this.ajustes.calcularPuntoY(17.96),
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.txtCantMov);
		txtCantMov.setColumns(10);

		(this.lblFechamod = new JLabel("Fecha Modificacion")).setHorizontalAlignment(0);
		this.lblFechamod.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblFechamod.setForeground(Variables.color_uno);
		this.lblFechamod.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		this.lblFechamod.setBounds(this.ajustes.calcularPuntoX(65.14), this.ajustes.calcularPuntoY(14.58),
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lblFechamod);

		(this.txtFechamod = new JTextField()).setBackground(Variables.color_uno);
		this.txtFechamod.setHorizontalAlignment(0);
		this.txtFechamod.setForeground(Variables.color_dos);
		this.txtFechamod.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.txtFechamod.setBounds(this.ajustes.calcularPuntoX(65.14), this.ajustes.calcularPuntoY(17.96),
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.txtFechamod);

		(this.lblTipoMov = new JLabel("Tipo de Movimiento")).setHorizontalAlignment(0);
		this.lblTipoMov.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblTipoMov.setForeground(Variables.color_uno);
		this.lblTipoMov.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblTipoMov.setBounds(604, 53,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(this.lblTipoMov);

		(this.lblOficina = new JLabel("Oficina Origen")).setHorizontalAlignment(0);
		this.lblOficina.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblOficina.setForeground(Variables.color_uno);
		this.lblOficina.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblOficina.setBounds(604, 171,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(lblOficina);

		(this.lblOficinaDestino = new JLabel("Oficina Destino")).setHorizontalAlignment(0);
		this.lblOficinaDestino.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblOficinaDestino.setForeground(Variables.color_uno);
		this.lblOficinaDestino.setFont(
				new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
		lblOficinaDestino.setBounds(604, 230,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(1.85));
		jp_contenido.add(lblOficinaDestino);

		(this.cbxTipoMov = new JComboBox()).setForeground(Variables.color_dos);
		cbxTipoMov.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (cbxTipoMov.getSelectedItem().toString().equals("OUT03 - TRASLADO")) {
					setLasMov();
					controlesTraslado(true);
					traslado=true;
					llenarCmbOficina();
					llenarCmbBodegas();
					iniciarTablaKardex();
					listaIngresar = new ArrayList<String[]>(); 
				}else {
					listaIngresarTraslado =  new ArrayList<String[]>(); 
					llenarCmbOficina();
					llenarCmbBodegas();
					controlesTraslado(false);
					traslado=false;
					iniciarTablaKardex();
				}
				txtNumDoc.setText(getNumDoc());
			}
		});
		this.cbxTipoMov.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.cbxTipoMov.setBounds(604, 79,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.cbxTipoMov);

		(this.cbxOficina = new JComboBox()).setForeground(Variables.color_dos);
		this.cbxOficina.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.cbxOficina.setBounds(604, 197,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.cbxOficina);

		(this.cbxOficinaDestino = new JComboBox()).setForeground(Variables.color_dos);
		this.cbxOficinaDestino.setFont(
				new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
		this.cbxOficinaDestino.setBounds(604, 256,
				this.ajustes.calcularPuntoX(17.27), this.ajustes.calcularPuntoY(2.78));
		jp_contenido.add(this.cbxOficinaDestino);

		(this.jp_btnAplicar = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
		this.jp_btnAplicar.setBounds(this.ajustes.calcularPuntoX(84.33), this.ajustes.calcularPuntoY(16.14),
				this.ajustes.calcularPuntoX(14.70), this.ajustes.calcularPuntoY(7.42));
		jp_contenido.add(this.jp_btnAplicar);
		this.jp_btnAplicar.setLayout(null);

		(this.btnAplicar = new JLabel("")).addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(final MouseEvent arg0) {
				RealizarMovimientos.this.jp_btnAplicar.setBackground(Variables.color_uno);
				RealizarMovimientos.this.lblNombreBtn_aplicar.setForeground(Variables.color_dos);
				RealizarMovimientos.this.lblIconoBtn_aplicar.setIcon(RealizarMovimientos.this.ajustes.ajustarImagen_(
						"/images/botones-09-icono-aplicar.png", RealizarMovimientos.this.lblIconoBtn_aplicar));
			}

			@Override
			public void mouseClicked(final MouseEvent e) {
				RealizarMovimientos.this.modificarCuentas(); // Hay realizar al boton aplicar este va realizar la
																// vinculacion de la cuentas mostrando en la tabla
																// principal , que esta abajo
			}
		});
		btnAplicar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (!traslado) {
					actualizarTablaKardex();
				}else {
					actualizarTablaKardexTraslado();
				}
				
				agregarListaIngreso();
				System.out.println("Lista ingreso "+listaIngresar.size());
				System.out.println("Lista traslado "+listaIngresarTraslado.size());
			}
		});
		this.btnAplicar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(final MouseEvent arg0) {
				RealizarMovimientos.this.jp_btnAplicar.setBackground(Variables.color_dos);
				RealizarMovimientos.this.lblNombreBtn_aplicar.setForeground(Variables.color_uno);
				RealizarMovimientos.this.lblIconoBtn_aplicar.setIcon(RealizarMovimientos.this.ajustes.ajustarImagen_(
						"/images/botones-09-icono-aplicar-select.png", RealizarMovimientos.this.lblIconoBtn_aplicar));
			}
		});
		this.btnAplicar.setCursor(Cursor.getPredefinedCursor(12));
		this.btnAplicar.setBounds(0, 0, this.ajustes.calcularPuntoX(14.70), this.ajustes.calcularPuntoY(7.42));
		this.jp_btnAplicar.add(this.btnAplicar);

		(this.lblIconoBtn_aplicar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(1.90),
				this.ajustes.calcularPuntoY(0.80), this.ajustes.calcularPuntoX(2.70), this.ajustes.calcularPuntoY(5.0));
		this.lblIconoBtn_aplicar.setIcon(
				new ImageIcon(VicularCuentasContables.class.getResource("/images/botones-11-icono-aplicar.png")));
		this.jp_btnAplicar.add(this.lblIconoBtn_aplicar);

		(this.lblNombreBtn_aplicar = new JLabel(" AGREGAR")).setForeground(Variables.color_dos);
		lblNombreBtn_aplicar.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblNombreBtn_aplicar
				.setFont(new Font("Book Antiqua", 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(3.24))));
		this.lblNombreBtn_aplicar.setBounds(0, 0, this.ajustes.calcularPuntoX(14.70),
				this.ajustes.calcularPuntoY(7.42));
		this.jp_btnAplicar.add(this.lblNombreBtn_aplicar);
		
		lblBodega = new JLabel("BodegaOrigen");
		lblBodega.setBounds(914, 171, 126, 14);
		jp_contenido.add(lblBodega);
		
		cbxBodega = new JComboBox();
		cbxBodega.setBounds(886, 195, 200, 23);
		jp_contenido.add(cbxBodega);
		
		lblBodegaDestin = new JLabel("lblBodegaDestin");
		lblBodegaDestin.setBounds(954, 230, 55, 14);
		jp_contenido.add(lblBodegaDestin);
		
		cbxBodegaDestin = new JComboBox();
		cbxBodegaDestin.setBounds(886, 254, 200, 23);
		jp_contenido.add(cbxBodegaDestin);
	}

	protected void seleccionarProducto() {
		// TODO Auto-generated method stub

	}

	protected void modificarCuentas() {
		// TODO Auto-generated method stub

	}

	public void iniciarTablaKardex() {
		this.modeloKardex = new DefaultTableModel();
		
		if (!traslado) {
			this.modeloKardex.addColumn("Cod Producto");
			this.modeloKardex.addColumn("Cantidad Movimiento");
			this.modeloKardex.addColumn("Tipo Movimiento");
			this.modeloKardex.addColumn("Oficina");
			this.modeloKardex.addColumn("Bodega");
		} else {
			this.modeloKardex.addColumn("Cod Producto");
			this.modeloKardex.addColumn("Cantidad Movimiento");
			this.modeloKardex.addColumn("Tipo Movimiento");
			this.modeloKardex.addColumn("Oficina Origen");
			this.modeloKardex.addColumn("Oficina Destino");
			this.modeloKardex.addColumn("Bodega Origen");
			this.modeloKardex.addColumn("Bodega Destino");
		}
		this.tblkardex.setModel(modeloKardex);
	}

	public void configurarTablas() {
		
		final int[] tamanosProducto = {0,25,100,20,20,15,15,80};
		this.tblProductos = this.ajustes.configurarTabla(tblProductos,tamanosProducto);
		
		int[] tamanosKardex;
		if (!traslado) {
			final int[] tamanoNormal = { 20, 20, 100, 30 ,30};
			tamanosKardex = tamanoNormal;
		} else {
			final int[] tamanoTraslado = { 20, 20, 100, 30, 30 };
			tamanosKardex = tamanoTraslado;
		}
		this.tblkardex = this.ajustes.configurarTabla(this.tblkardex, tamanosKardex);
	}

	public void llenarListaProductos() {
		
		this.modeloProductos = this.consultaSql.obtenerDatosProductos(null);
		this.tblProductos.setModel(modeloProductos);
		configurarTablas();
	}

	
	public void llenarListaProductos(final String producto) {
		this.modeloProductos = this.consultaSql.obtenerDatosProductos(producto);
		this.tblProductos.setModel(modeloProductos);
		configurarTablas();
	}
	
	public void llenarCmbTipoMovimiento() {
		final String consulta = ""
				+ "select CONCAT(tipoMovimiento.idtipoMovimiento,' - ',tipoMovimiento.descripcion) from tipoMovimiento \n"
				+ "where tipoMovimiento.idtipoMovimiento LIKE 'OUT%' or tipoMovimiento.idtipoMovimiento LIKE 'IN%'";
		this.cbxTipoMov.setModel(this.consultaSql.getDataComboBox(consulta));
	}

	public void llenarCmbOficina() {
		
		final String consulta = "SELECT CONCAT(o.idoficina,' - ',o.nombre) from oficina o ;";
		if (!traslado) {
			this.cbxOficina.setModel(this.consultaSql.getDataComboBox(consulta));
			cbxOficina.setEnabled(true);
		}else {
			final DefaultComboBoxModel<Object> md = new DefaultComboBoxModel<>();
			
			md.addElement(this.lastMov[1]);
			cbxOficina.setModel(md);
			
		}
		this.cbxOficinaDestino.setModel(this.consultaSql.getDataComboBox(consulta));
	}

	
	public void llenarCmbBodegas() {
		final String consulta = "SELECT CONCAT(b.idbodega,' - ',b.nombreBodega) from bodega b;";
		if (!traslado) {
			this.cbxBodega.setModel(this.consultaSql.getDataComboBox(consulta));
			this.cbxBodega.setEnabled(true);
		}else {
			final DefaultComboBoxModel<Object> md = new DefaultComboBoxModel<>();
			md.addElement(this.lastMov[0]);
			cbxBodega.setModel(md);

		}
			
		this.cbxBodegaDestin.setModel(this.consultaSql.getDataComboBox(consulta));
	}
	
	public boolean oficinaDistinta() {
		if (this.cbxOficina.getSelectedItem()!=this.cbxOficinaDestino.getSelectedItem()) {
			return true;
		}
		return false;
	}

	public String getBodegaOficina(final String idOficina) {
		final String consulta = "SELECT * from bodega b WHERE oficina_idoficina='" + idOficina + "'";
		return this.consultaSql.getDataComboBox(consulta).toString().split(" ")[0];
	}
	
	public String[] getlastMovbyProducto(final String codProducto) throws SQLException {
		final String consulta = "SELECT top 1\n"
				+ "	CONCAT(b.idbodega,' - ',b.nombreBodega) as bodega,\n"
				+ "	CONCAT(o.idoficina,' - ',o.nombre ) as oficina,\n"
				+ "	p.codigo ,\n"
				+ "	kp.idMov \n"
				+ "FROM producto p\n"
				+ "inner join kardexProducto kp \n"
				+ "on p.idproducto = kp.producto_idproducto \n"
				+ "inner join bodega b \n"
				+ "on kp.bodega_idbodega = b.idbodega \n"
				+ "inner join oficina o \n"
				+ "on b.oficina_idoficina = o.idoficina \n"
				+ "where p.codigo ='"+codProducto+"'\n"
				+ "order by kp.idMov desc;\n"
				+ "";
		final ResultSet rs = this.consultaSql.obtenerResultSetConsultas(consulta);
		
		while(rs.next()) {
			final String data[] = {rs.getString(1),rs.getString(2)};
			return data;
		}
		return null;
		
	}

	public void setLasMov() {
		final int filaSeleccionada = (tblProductos.getSelectedRow()>-1) ? tblProductos.getSelectedRow():0;
		final String codProdcu =  tblProductos.getValueAt(filaSeleccionada, 1).toString();
		try {
			lastMov = getlastMovbyProducto(codProdcu);			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public String getNumDoc() {
		final String tipoMovimiento = Texto.getIdCombos(this.cbxTipoMov.getSelectedItem().toString())[0];
		final int cantRegistroKardex = this.consultaSql.contarRegistrosKardex();

		return tipoMovimiento + cantRegistroKardex;
	}
	
	public void controlesTraslado(final boolean setBoolean) {
		lblOficinaDestino.setVisible(setBoolean);
		cbxOficinaDestino.setVisible(setBoolean);
		lblBodegaDestin.setVisible(setBoolean);
		cbxBodegaDestin.setVisible(setBoolean);
	}

	public void actualizarTablaKardex() {
		final int filaSeleccionadaProducto =this.tblProductos.getSelectedRow();
		final String codProducto = modeloProductos.getValueAt(filaSeleccionadaProducto, 1).toString();
		final String cantMovimiento = this.txtCantMov.getText();
		final String[] tipoMovimientoArray = Texto.getIdCombos(this.cbxTipoMov.getSelectedItem().toString());
		String tipoMovimiento = "";
		for (int i = 2; i < tipoMovimientoArray.length; i++) {
			tipoMovimiento += tipoMovimientoArray[i] + " ";
		}
		final String[] oficinaArray = Texto.getIdCombos(this.cbxOficina.getSelectedItem().toString());
		String oficina = "";
		for (int i = 2; i < oficinaArray.length; i++) {
			oficina += oficinaArray[i] + " ";
		}
		
		final String[] bodegaArray =  Texto.getIdCombos(this.cbxBodega.getSelectedItem().toString());
		String bodega = "";
		for (int i = 0; i < bodegaArray.length; i++) {
			bodega+=bodegaArray[i]+" ";
		}
		
		String[] row = { codProducto, cantMovimiento, tipoMovimiento, oficina ,bodega};
		this.modeloKardex.addRow(row);
		this.tblkardex.setModel(modeloKardex);
	}
	
	public void actualizarTablaKardexTraslado() {
		final int filaSeleccionadaProducto = (this.tblProductos.getSelectedRow() > 0)
				? this.tblProductos.getSelectedRow()
				: null;
		final String codProducto = modeloProductos.getValueAt(filaSeleccionadaProducto, 1).toString();
		final String cantMovimiento = this.txtCantMov.getText();
		final String[] tipoMovimientoArray = Texto.getIdCombos(this.cbxTipoMov.getSelectedItem().toString());
		String tipoMovimiento = "";
		for (int i = 2; i < tipoMovimientoArray.length; i++) {
			tipoMovimiento += tipoMovimientoArray[i] + " ";
		}
		final String[] oficinaOrigenArray = Texto.getIdCombos(this.cbxOficina.getSelectedItem().toString());
		String oficina = "";
		for (int i = 2; i < oficinaOrigenArray.length; i++) {
			oficina += oficinaOrigenArray[i] + " ";
		}
		
		final String[] oficinaDestinoArray = Texto.getIdCombos(this.cbxOficinaDestino.getSelectedItem().toString());
		String oficinaDestino = "";
		for (int i = 2; i < oficinaDestinoArray.length; i++) {
			oficinaDestino+= oficinaDestinoArray[i] + " ";
		}
		
		final String[] bodegaOrigenArray = Texto.getIdCombos(this.cbxBodega.getSelectedItem().toString());
		String bodegaOrigen = "";
		for (int i = 2; i < bodegaOrigenArray.length; i++) {
			bodegaOrigen+= bodegaOrigenArray[i] + " ";
		}
		
		final String[] bodegaDestinoArray = Texto.getIdCombos(this.cbxBodegaDestin.getSelectedItem().toString());
		String bodegaDestino = "";
		for (int i = 2; i < bodegaDestinoArray.length; i++) {
			bodegaDestino+= bodegaDestinoArray[i] + " ";
		}
		
		String[] row = { codProducto, cantMovimiento, tipoMovimiento, oficina ,oficinaDestino,bodegaOrigen,bodegaDestino};
		this.modeloKardex.addRow(row);
		this.tblkardex.setModel(modeloKardex);
	}
	
	public void agregarListaIngreso() {

		try {
			final int filaSeleccionadaProducto = (this.tblProductos.getSelectedRow() > 0)
					? this.tblProductos.getSelectedRow()
					: null;
			final String codProducto = modeloProductos.getValueAt(filaSeleccionadaProducto, 0).toString();
			final String tipoMovimientoId = Texto.getIdCombos(this.cbxTipoMov.getSelectedItem().toString())[0];
			final String oficinaId = Texto.getIdCombos(this.cbxOficina.getSelectedItem().toString())[0];
			final String oficinaDestinoId = Texto.getIdCombos(this.cbxOficinaDestino.getSelectedItem().toString())[0];
			final String bodegaId = Texto.getIdCombos(this.cbxBodega.getSelectedItem().toString())[0];
			final String bodegaDestinoId = Texto.getIdCombos(this.cbxBodegaDestin.getSelectedItem().toString())[0];
			final String numeroDoc = this.getNumDoc();
			final String cantMov = this.txtCantMov.getText();
			final String fechaReg = this.fechasHandler.fechaParaSistema(Variables.fechaActual);
			final String fechaMod = fechaReg;
			final String usuarioId = String.valueOf(Variables.idUsuario);
			String[] filaIngresada;
			if (Texto.comparacioRegexp("^IN.*", tipoMovimientoId)) {
				final String[] fila = { codProducto, tipoMovimientoId, bodegaId, numeroDoc, cantMov, fechaReg, fechaMod,usuarioId, oficinaId };
				filaIngresada = fila;
			}else {
				final String[] fila = { codProducto, tipoMovimientoId, bodegaId, numeroDoc, "-"+cantMov, fechaReg, fechaMod,usuarioId, oficinaId };
				filaIngresada = fila;
			}
			
			if (!traslado) {
				listaIngresar.add(filaIngresada);				
			}else {
				final String[] filaATrasladar = { codProducto, tipoMovimientoId, bodegaId, numeroDoc, "-"+cantMov, fechaReg, fechaMod,usuarioId, oficinaId }; 
				listaIngresarTraslado.add(filaATrasladar);
				final String[] filaIngresadaTraslado =  { codProducto, tipoMovimientoId, bodegaDestinoId, numeroDoc, cantMov, fechaReg, fechaMod,usuarioId, oficinaDestinoId };
				listaIngresarTraslado.add(filaIngresadaTraslado);
			}
		} catch (NullPointerException e) {
			JOptionPane.showMessageDialog(contentPane, "Asegurese de agregar la infomacion solicitada", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void eliminarFilaListaIngreso() {
		int filaEliminar = this.tblkardex.getSelectedRow();
		this.modeloKardex.removeRow(filaEliminar);
		this.tblkardex.setModel(modeloKardex);
		this.listaIngresar.remove(filaEliminar);
		if (traslado) {
			filaEliminar++;
			this.listaIngresarTraslado.remove(filaEliminar-1);
			this.listaIngresarTraslado.remove(filaEliminar);
		}
	}

	public void insertarRegistro() {
		int result = 0;

		if (!traslado) {
			for (String[] kardex : listaIngresar) {
				if (this.insertSql.insertKardexProducto(kardex[0], kardex[1], kardex[2], kardex[3], kardex[4], kardex[5],
						kardex[6], kardex[7], kardex[8]) > 0) {
					result++;
				}
			}
		}else {
			for (String[] kardex : listaIngresarTraslado) {
				if (this.insertSql.insertKardexProducto(kardex[0], kardex[1], kardex[2], kardex[3], kardex[4], kardex[5],
						kardex[6], kardex[7], kardex[8]) > 0) {
					result++;
				}
			}
		}


		if (result > 0) {
			JOptionPane.showMessageDialog(contentPane, "Registro Almacenado correctamente");
			iniciarTablaKardex();
		} else {
			iniciarTablaKardex();
			JOptionPane.showMessageDialog(contentPane, "Registro NO almacenado correctamente", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	public void dispose() {
		getFrame().setVisible(true);
		super.dispose();
	}

	private JFrame getFrame() {
		return this;
	}
}
