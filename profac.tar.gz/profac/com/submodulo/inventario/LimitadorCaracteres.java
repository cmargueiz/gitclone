// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.inventario;

import javax.swing.text.BadLocationException;
import javax.swing.text.AttributeSet;
import javax.swing.JTextField;
import javax.swing.text.PlainDocument;

class LimitadorCaracteres extends PlainDocument
{
    private static final long serialVersionUID = 1L;
    private JTextField editor;
    private int numeroMaximoCaracteres;
    
    public LimitadorCaracteres(final JTextField editor, final int numeroMaximoCaracteres) {
        this.editor = editor;
        this.numeroMaximoCaracteres = numeroMaximoCaracteres;
    }
    
    @Override
    public void insertString(final int arg0, final String arg1, final AttributeSet arg2) throws BadLocationException {
        if (this.editor.getText().length() + arg1.length() > this.numeroMaximoCaracteres) {
            return;
        }
        super.insertString(arg0, arg1, arg2);
    }
}
