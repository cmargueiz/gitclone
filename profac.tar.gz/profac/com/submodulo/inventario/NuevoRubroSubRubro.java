// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.inventario;

import javax.swing.JOptionPane;
import javax.swing.ComboBoxModel;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Inventario;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevoRubroSubRubro extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Inventario inventario;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevoRubroSubrubro;
    private JLabel lblIconoBtn_nuevoRubroSubrubro;
    private JLabel lblNombreBtn_nuevoRubroSubrubro;
    private JPanel jp_btnBuscarRubroSubrubro;
    private JLabel btnBuscarRubroSubrubro;
    private JLabel lblIconoBtn_buscarRubroSubrubro;
    private JLabel lblNombreBtn_buscarRubroSubrubro;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblNuevoRubroSubrubro;
    private JPanel jp_chckRubro;
    private JLabel chckRubro;
    private JLabel lblIconoChck_rubro;
    private JLabel lblNombreChck_rubro;
    private JPanel jp_chckSubrubro;
    private JLabel chckSubrubro;
    private JLabel lblIconoChck_subrubro;
    private JLabel lblNombreChck_subrubro;
    private JTextField txtId;
    private JTextField txtFechaDoc;
    private JComboBox<Object> cbxRubroSup;
    private JTextField txtNombreRubro;
    public boolean chckbxRubro;
    public boolean chckbxSubrubro;
    private JTextArea txtDescripcion;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevoRubroSubRubro frame = new NuevoRubroSubRubro();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevoRubroSubRubro() {
        this.ajustes = new Ajustes();
        this.inventario = new F_Inventario();
        this.consultaSql = new consultasSQL_SERVER();
        this.chckbxRubro = true;
        this.chckbxSubrubro = false;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevoRubroSubRubro.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevoRubroSubrubro = new JPanel()).setLayout(null);
        this.jp_btnNuevoRubroSubrubro.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevoRubroSubrubro.setBackground(Variables.color_tres);
        this.jp_btnNuevoRubroSubrubro.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevoRubroSubrubro);
        final JLabel btnNuevoRubroSubrubro = new JLabel("");
        btnNuevoRubroSubrubro.setCursor(Cursor.getPredefinedCursor(12));
        btnNuevoRubroSubrubro.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        btnNuevoRubroSubrubro.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnNuevoRubroSubrubro.setBackground(Variables.color_tres);
            }
        });
        btnNuevoRubroSubrubro.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnNuevoRubroSubrubro.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevoRubroSubrubro.add(btnNuevoRubroSubrubro);
        (this.lblIconoBtn_nuevoRubroSubrubro = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevoRubroSubrubro.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevoRubroSubrubro));
        this.jp_btnNuevoRubroSubrubro.add(this.lblIconoBtn_nuevoRubroSubrubro);
        (this.lblNombreBtn_nuevoRubroSubrubro = new JLabel("Nuevo")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevoRubroSubrubro.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevoRubroSubrubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevoRubroSubrubro.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevoRubroSubrubro.add(this.lblNombreBtn_nuevoRubroSubrubro);
        (this.jp_btnBuscarRubroSubrubro = new JPanel()).setLayout(null);
        this.jp_btnBuscarRubroSubrubro.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarRubroSubrubro.setBackground(Variables.color_tres);
        this.jp_btnBuscarRubroSubrubro.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarRubroSubrubro);
        (this.btnBuscarRubroSubrubro = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarRubroSubrubro.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarRubroSubrubro.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnBuscarRubroSubrubro.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarRubroSubrubro.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnBuscarRubroSubrubro.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarRubroSubrubro.add(this.btnBuscarRubroSubrubro);
        (this.lblIconoBtn_buscarRubroSubrubro = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarRubroSubrubro.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarRubroSubrubro));
        this.jp_btnBuscarRubroSubrubro.add(this.lblIconoBtn_buscarRubroSubrubro);
        (this.lblNombreBtn_buscarRubroSubrubro = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarRubroSubrubro.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarRubroSubrubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarRubroSubrubro.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarRubroSubrubro.add(this.lblNombreBtn_buscarRubroSubrubro);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoRubroSubRubro.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblNuevoRubroSubrubro = new JLabel("Crear Nuevo Rubro o Sub-Rubro")).setForeground(Variables.color_uno);
        this.lblNuevoRubroSubrubro.setHorizontalAlignment(0);
        this.lblNuevoRubroSubrubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNuevoRubroSubrubro.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblNuevoRubroSubrubro);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JLabel lblTipoEstructura = new JLabel("Tipo de Estructura:");
        lblTipoEstructura.setHorizontalAlignment(0);
        lblTipoEstructura.setForeground(Variables.color_uno);
        lblTipoEstructura.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblTipoEstructura.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblTipoEstructura);
        (this.jp_chckRubro = new JPanel()).setLayout(null);
        this.jp_chckRubro.setOpaque(false);
        this.jp_chckRubro.setBounds((this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(7.41), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(3.7));
        jp_contenido.add(this.jp_chckRubro);
        (this.chckRubro = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                NuevoRubroSubRubro.this.txtId.setText(Integer.toString(NuevoRubroSubRubro.this.consultaSql.obtenerSigIdRubro(Variables.idOficina)));
                NuevoRubroSubRubro.this.chckbxRubro = true;
                NuevoRubroSubRubro.this.chckbxSubrubro = false;
                NuevoRubroSubRubro.this.cbxRubroSup.setEnabled(false);
                NuevoRubroSubRubro.this.verificarOpcion();
            }
        });
        this.chckRubro.setCursor(Cursor.getPredefinedCursor(12));
        this.chckRubro.setBounds(0, 0, (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(3.7));
        this.jp_chckRubro.add(this.chckRubro);
        (this.lblIconoChck_rubro = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_rubro.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.lblIconoChck_rubro.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lblIconoChck_rubro));
        this.jp_chckRubro.add(this.lblIconoChck_rubro);
        (this.lblNombreChck_rubro = new JLabel("Rubro")).setForeground(Variables.color_uno);
        this.lblNombreChck_rubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNombreChck_rubro.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        this.jp_chckRubro.add(this.lblNombreChck_rubro);
        (this.jp_chckSubrubro = new JPanel()).setLayout(null);
        this.jp_chckSubrubro.setOpaque(false);
        this.jp_chckSubrubro.setBounds((this.ajustes.ancho - 25) / 10 * 5 + this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(7.41), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(3.7));
        jp_contenido.add(this.jp_chckSubrubro);
        (this.chckSubrubro = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoRubroSubRubro.this.txtId.setText(Integer.toString(NuevoRubroSubRubro.this.consultaSql.obtenerSigIdSubrubro(Variables.idOficina)));
                NuevoRubroSubRubro.this.chckbxRubro = false;
                NuevoRubroSubRubro.this.chckbxSubrubro = true;
                NuevoRubroSubRubro.this.cbxRubroSup.setEnabled(true);
                NuevoRubroSubRubro.this.verificarOpcion();
            }
        });
        this.chckSubrubro.setCursor(Cursor.getPredefinedCursor(12));
        this.chckSubrubro.setBounds(0, 0, (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(3.7));
        this.jp_chckSubrubro.add(this.chckSubrubro);
        (this.lblIconoChck_subrubro = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_subrubro.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(2.78));
        this.lblIconoChck_subrubro.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lblIconoChck_subrubro));
        this.jp_chckSubrubro.add(this.lblIconoChck_subrubro);
        (this.lblNombreChck_subrubro = new JLabel("Sub-Rubro")).setForeground(Variables.color_uno);
        this.lblNombreChck_subrubro.setFont(new Font(Variables.fuenteLetra, 1, 15));
        this.lblNombreChck_subrubro.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        this.jp_chckSubrubro.add(this.lblNombreChck_subrubro);
        final JLabel lblId = new JLabel("ID:");
        lblId.setHorizontalAlignment(0);
        lblId.setForeground(Variables.color_uno);
        lblId.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblId.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblId);
        (this.txtId = new JTextField()).setEditable(false);
        this.txtId.setHorizontalAlignment(0);
        this.txtId.setForeground(Variables.color_dos);
        this.txtId.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtId.setBackground(Variables.color_uno);
        this.txtId.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(13.89), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtId);
        this.txtId.setColumns(10);
        final JLabel lblFechaDoc = new JLabel("Fecha Doc:");
        lblFechaDoc.setHorizontalAlignment(0);
        lblFechaDoc.setForeground(Variables.color_uno);
        lblFechaDoc.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblFechaDoc.setBounds((this.ajustes.ancho - 25) / 10 * 7, this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblFechaDoc);
        (this.txtFechaDoc = new JTextField()).setEditable(false);
        this.txtFechaDoc.setHorizontalAlignment(0);
        this.txtFechaDoc.setForeground(Variables.color_dos);
        this.txtFechaDoc.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaDoc.setColumns(10);
        this.txtFechaDoc.setBackground(Variables.color_uno);
        this.txtFechaDoc.setBounds((this.ajustes.ancho - 25) / 10 * 7, this.ajustes.calcularPuntoY(13.89), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaDoc);
        final JLabel lblRubroSuperior = new JLabel("Rubro Superior:");
        lblRubroSuperior.setHorizontalAlignment(0);
        lblRubroSuperior.setForeground(Variables.color_uno);
        lblRubroSuperior.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblRubroSuperior.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(17.59), (this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblRubroSuperior);
        (this.cbxRubroSup = new JComboBox<Object>()).setCursor(Cursor.getPredefinedCursor(12));
        this.cbxRubroSup.setForeground(Variables.color_dos);
        this.cbxRubroSup.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxRubroSup.setBackground(Variables.color_uno);
        this.cbxRubroSup.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(19.44), (this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxRubroSup);
        final JLabel lblNombreRubro = new JLabel("Nombre de Rubro o Sub-Rubro:");
        lblNombreRubro.setHorizontalAlignment(0);
        lblNombreRubro.setForeground(Variables.color_uno);
        lblNombreRubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreRubro.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(23.15), (this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNombreRubro);
        (this.txtNombreRubro = new JTextField()).setForeground(Variables.color_dos);
        this.txtNombreRubro.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreRubro.setColumns(10);
        this.txtNombreRubro.setBackground(Variables.color_uno);
        this.txtNombreRubro.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(25.0), (this.ajustes.ancho - 25) / 10 * 6, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreRubro);
        final JLabel lblDescripcion = new JLabel("Descripcion:");
        lblDescripcion.setHorizontalAlignment(0);
        lblDescripcion.setForeground(Variables.color_uno);
        lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblDescripcion.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(28.7), this.ajustes.calcularPuntoX(59.11), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblDescripcion);
        (this.txtDescripcion = new JTextArea()).setBackground(Variables.color_uno);
        this.txtDescripcion.setForeground(Variables.color_dos);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(30.56), (this.ajustes.ancho - 25) / 10 * 6, this.ajustes.alto - this.ajustes.calcularPuntoY(49.07));
        jp_contenido.add(this.txtDescripcion);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void verificarOpcion() {
        if (this.chckbxRubro && !this.chckbxSubrubro) {
            this.lblIconoChck_rubro.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lblIconoChck_rubro));
            this.lblIconoChck_subrubro.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lblIconoChck_subrubro));
        }
        else if (!this.chckbxRubro && this.chckbxSubrubro) {
            this.lblIconoChck_rubro.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check.png", this.lblIconoChck_rubro));
            this.lblIconoChck_subrubro.setIcon(this.ajustes.ajustarImagen_("/images/general-21-icono-check-select.png", this.lblIconoChck_subrubro));
        }
    }
    
    public void llenarCampos() {
        this.cbxRubroSup.setModel(this.consultaSql.getDataComboBox("select nombre from categoria where idcategoriaPadre = -1 order by nombre asc"));
        this.cbxRubroSup.setEnabled(false);
        this.txtId.setText(Integer.toString(this.consultaSql.obtenerSigIdRubro(Variables.idOficina)));
        this.txtFechaDoc.setText(Variables.fechaActual);
    }
    
    public void guardar() {
        if ((Variables.ventana_NuevoRubroSubrubro || !Variables.ventana_EditarRubroSubrubro) && Variables.ventana_NuevoRubroSubrubro && !Variables.ventana_EditarRubroSubrubro) {
            this.guardarRubroSubRubro();
        }
    }
    
    public void guardarRubroSubRubro() {
        if (this.consultaSql.obtenerIdRubro(this.txtNombreRubro.getText(), Variables.idOficina) > 0) {
            JOptionPane.showMessageDialog(null, "Ya existe un Rubro o Sub-Rubro con este nombre, favor cambiar nombre antes de guardar", "ALERTA!", 2);
            return;
        }
        if (this.chckbxRubro && !this.chckbxSubrubro) {
            if (!this.inventario.nuevoRubro(Integer.parseInt(this.txtId.getText()), -1, this.txtNombreRubro.getText(), Variables.fechaActual, Variables.idUsuario, this.txtDescripcion.getText(), Variables.idOficina)) {
                JOptionPane.showMessageDialog(null, "Rubro '" + this.txtNombreRubro.getText() + "' no se pudo guardar -- " + Variables.error, "ERROR!", 0);
                return;
            }
            JOptionPane.showMessageDialog(null, "Rubro '" + this.txtNombreRubro.getText() + "' guardado correctamente", "COMPLETADO!", 1);
        }
        else if (!this.chckbxRubro && this.chckbxSubrubro) {
            if (!this.inventario.nuevoSubrubro(Integer.parseInt(this.txtId.getText()), this.consultaSql.obtenerIdRubro(this.cbxRubroSup.getSelectedItem().toString(), Variables.idOficina), this.txtNombreRubro.getText(), Variables.fechaActual, Variables.idUsuario, this.txtDescripcion.getText(), Variables.idOficina)) {
                JOptionPane.showMessageDialog(null, "Sub-Rubro '" + this.txtNombreRubro.getText() + "' no se pudo guardar -- " + Variables.error, "ERROR!", 0);
                return;
            }
            JOptionPane.showMessageDialog(null, "Sub-Rubro '" + this.txtNombreRubro.getText() + "' guardado correctamente", "COMPLETADO!", 1);
        }
        this.cbxRubroSup.setModel(this.consultaSql.getDataComboBox("select nombre from categoria where idcategoriaPadre = -1 order by nombre asc"));
        this.txtId.setText(Integer.toString(this.consultaSql.obtenerSigIdRubro(Variables.idOficina)));
        this.txtNombreRubro.setText("");
        this.txtDescripcion.setText("");
    }
}
