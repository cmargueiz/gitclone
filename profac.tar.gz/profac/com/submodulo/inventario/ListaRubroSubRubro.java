// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.inventario;

import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.JScrollPane;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaRubroSubRubro extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevoRubroSubrubro;
    private JLabel btnNuevoRubroSubrubro;
    private JLabel lblIconoBtn_nuevoRubroSubrubro;
    private JLabel lblNombreBtn_nuevoRubroSubrubro;
    private JPanel jp_btnBuscarRubroSubrubro;
    private JLabel btnBuscarRubroSubrubro;
    private JLabel lblIconoBtn_buscarRubroSubrubro;
    private JLabel lblNombreBtn_buscarRubroSubrubro;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JTextField txtNombreRubro;
    private JComboBox<Object> cbxOpcionBusqueda;
    private JLabel lblRubrosSubrubros;
    private JLabel lblIconoBtn_buscar;
    private JLabel lblNombreBtn_buscar;
    private JLabel btnBuscar;
    private JPanel jp_tblRubros;
    private JTable tblRubros;
    private JTextField txtRubroSeleccionado;
    private JTextField txtIdRubroSeleccionado;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaRubroSubRubro frame = new ListaRubroSubRubro();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaRubroSubRubro() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaRubroSubRubro.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevoRubroSubrubro = new JPanel()).setLayout(null);
        this.jp_btnNuevoRubroSubrubro.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevoRubroSubrubro.setBackground(Variables.color_tres);
        this.jp_btnNuevoRubroSubrubro.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevoRubroSubrubro);
        (this.btnNuevoRubroSubrubro = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevoRubroSubrubro.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevoRubroSubrubro.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnNuevoRubroSubrubro.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevoRubroSubrubro.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnNuevoRubroSubrubro.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevoRubroSubrubro.add(this.btnNuevoRubroSubrubro);
        (this.lblIconoBtn_nuevoRubroSubrubro = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevoRubroSubrubro.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevoRubroSubrubro));
        this.jp_btnNuevoRubroSubrubro.add(this.lblIconoBtn_nuevoRubroSubrubro);
        (this.lblNombreBtn_nuevoRubroSubrubro = new JLabel("Nuevo")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevoRubroSubrubro.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevoRubroSubrubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevoRubroSubrubro.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevoRubroSubrubro.add(this.lblNombreBtn_nuevoRubroSubrubro);
        (this.jp_btnBuscarRubroSubrubro = new JPanel()).setLayout(null);
        this.jp_btnBuscarRubroSubrubro.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarRubroSubrubro.setBackground(Variables.color_tres);
        this.jp_btnBuscarRubroSubrubro.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarRubroSubrubro);
        (this.btnBuscarRubroSubrubro = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarRubroSubrubro.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarRubroSubrubro.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnBuscarRubroSubrubro.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarRubroSubrubro.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnBuscarRubroSubrubro.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarRubroSubrubro.add(this.btnBuscarRubroSubrubro);
        (this.lblIconoBtn_buscarRubroSubrubro = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarRubroSubrubro.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarRubroSubrubro));
        this.jp_btnBuscarRubroSubrubro.add(this.lblIconoBtn_buscarRubroSubrubro);
        (this.lblNombreBtn_buscarRubroSubrubro = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarRubroSubrubro.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarRubroSubrubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarRubroSubrubro.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarRubroSubrubro.add(this.lblNombreBtn_buscarRubroSubrubro);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaRubroSubRubro.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaRubroSubRubro.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblRubrosSubrubros = new JLabel("Lista de Rubros y Sub-Rubros")).setForeground(Variables.color_uno);
        this.lblRubrosSubrubros.setHorizontalAlignment(0);
        this.lblRubrosSubrubros.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblRubrosSubrubros.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblRubrosSubrubros);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        final JLabel lblNombreRubro = new JLabel("Nombre de Rubro o Sub-Rubro:");
        lblNombreRubro.setForeground(Variables.color_uno);
        lblNombreRubro.setHorizontalAlignment(0);
        lblNombreRubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreRubro.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblNombreRubro);
        (this.txtNombreRubro = new JTextField()).setForeground(Variables.color_dos);
        this.txtNombreRubro.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreRubro.setBackground(Variables.color_uno);
        this.txtNombreRubro.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreRubro);
        this.txtNombreRubro.setColumns(10);
        final JLabel lblTipo = new JLabel("Buscar por:");
        lblTipo.setHorizontalAlignment(0);
        lblTipo.setForeground(Variables.color_uno);
        lblTipo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblTipo.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblTipo);
        (this.cbxOpcionBusqueda = new JComboBox<Object>()).setModel(new DefaultComboBoxModel<Object>(new String[] { "TODO", "RUBRO", "SUB-RUBRO" }));
        this.cbxOpcionBusqueda.setForeground(Variables.color_dos);
        this.cbxOpcionBusqueda.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxOpcionBusqueda.setBackground(Variables.color_uno);
        this.cbxOpcionBusqueda.setBounds((this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 25) / 10 * 5, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxOpcionBusqueda);
        final JPanel jp_btnBuscar = new JPanel();
        jp_btnBuscar.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnBuscar.setBackground(Variables.color_uno);
        jp_btnBuscar.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(10.19));
        jp_contenido.add(jp_btnBuscar);
        jp_btnBuscar.setLayout(null);
        (this.btnBuscar = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_uno);
                ListaRubroSubRubro.this.lblIconoBtn_buscar.setIcon(ListaRubroSubRubro.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", ListaRubroSubRubro.this.lblIconoBtn_buscar));
                ListaRubroSubRubro.this.lblNombreBtn_buscar.setForeground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaRubroSubRubro.this.buscar();
            }
        });
        this.btnBuscar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnBuscar.setBackground(Variables.color_dos);
                ListaRubroSubRubro.this.lblIconoBtn_buscar.setIcon(ListaRubroSubRubro.this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar-select.png", ListaRubroSubRubro.this.lblIconoBtn_buscar));
                ListaRubroSubRubro.this.lblNombreBtn_buscar.setForeground(Variables.color_uno);
            }
        });
        this.btnBuscar.setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscar.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(10.19));
        jp_btnBuscar.add(this.btnBuscar);
        (this.lblIconoBtn_buscar = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoBtn_buscar.setBounds(this.ajustes.calcularPuntoX(2.86), this.ajustes.calcularPuntoY(1.85), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscar.setIcon(this.ajustes.ajustarImagen_("/images/botones-07-icono-buscar.png", this.lblIconoBtn_buscar));
        jp_btnBuscar.add(this.lblIconoBtn_buscar);
        (this.lblNombreBtn_buscar = new JLabel("Buscar")).setForeground(Variables.color_dos);
        this.lblNombreBtn_buscar.setHorizontalAlignment(0);
        this.lblNombreBtn_buscar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.9))));
        this.lblNombreBtn_buscar.setBounds(0, this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(3.7));
        jp_btnBuscar.add(this.lblNombreBtn_buscar);
        (this.jp_tblRubros = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_tblRubros.setBackground(Variables.color_uno);
        this.jp_tblRubros.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(17.59), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.alto - this.ajustes.calcularPuntoY(41.67));
        jp_contenido.add(this.jp_tblRubros);
        this.jp_tblRubros.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), this.ajustes.ancho - this.ajustes.calcularPuntoX(3.65), this.ajustes.alto - this.ajustes.calcularPuntoY(43.52));
        this.jp_tblRubros.add(scrollPane);
        (this.tblRubros = new JTable()).setCursor(Cursor.getPredefinedCursor(12));
        this.tblRubros.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaRubroSubRubro.this.txtIdRubroSeleccionado.setText(ListaRubroSubRubro.this.tblRubros.getValueAt(ListaRubroSubRubro.this.tblRubros.getSelectedRow(), 0).toString());
                ListaRubroSubRubro.this.txtRubroSeleccionado.setText(ListaRubroSubRubro.this.tblRubros.getValueAt(ListaRubroSubRubro.this.tblRubros.getSelectedRow(), 1).toString());
            }
        });
        this.tblRubros.setBackground(Variables.color_uno);
        this.tblRubros.setForeground(Variables.color_dos);
        this.tblRubros.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.4))));
        scrollPane.setViewportView(this.tblRubros);
        final JLabel lblIdRubroSeleccionado = new JLabel("ID:");
        lblIdRubroSeleccionado.setHorizontalAlignment(0);
        lblIdRubroSeleccionado.setForeground(Variables.color_uno);
        lblIdRubroSeleccionado.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblIdRubroSeleccionado.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.alto - this.ajustes.calcularPuntoY(23.15), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblIdRubroSeleccionado);
        (this.txtIdRubroSeleccionado = new JTextField()).setEditable(false);
        this.txtIdRubroSeleccionado.setHorizontalAlignment(0);
        this.txtIdRubroSeleccionado.setForeground(Variables.color_dos);
        this.txtIdRubroSeleccionado.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtIdRubroSeleccionado.setColumns(10);
        this.txtIdRubroSeleccionado.setBackground(Variables.color_uno);
        this.txtIdRubroSeleccionado.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.alto - this.ajustes.calcularPuntoY(21.3), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtIdRubroSeleccionado);
        final JLabel lblRubroSeleccionado = new JLabel("Nombre de Rubro:");
        lblRubroSeleccionado.setHorizontalAlignment(0);
        lblRubroSeleccionado.setForeground(Variables.color_uno);
        lblRubroSeleccionado.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblRubroSeleccionado.setBounds((this.ajustes.ancho - this.ajustes.calcularPuntoX(1.3)) / 10 + this.ajustes.calcularPuntoX(0.26), this.ajustes.alto - this.ajustes.calcularPuntoY(23.15), (this.ajustes.ancho - this.ajustes.calcularPuntoX(1.3)) / 10 * 9, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblRubroSeleccionado);
        (this.txtRubroSeleccionado = new JTextField()).setEditable(false);
        this.txtRubroSeleccionado.setForeground(Variables.color_dos);
        this.txtRubroSeleccionado.setHorizontalAlignment(0);
        this.txtRubroSeleccionado.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtRubroSeleccionado.setBackground(Variables.color_uno);
        this.txtRubroSeleccionado.setBounds((this.ajustes.ancho - this.ajustes.calcularPuntoX(1.3)) / 10 + this.ajustes.calcularPuntoX(0.26), this.ajustes.alto - this.ajustes.calcularPuntoY(21.3), (this.ajustes.ancho - this.ajustes.calcularPuntoX(1.3)) / 10 * 9, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtRubroSeleccionado);
        this.txtRubroSeleccionado.setColumns(10);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void llenarCampos() {
        this.txtNombreRubro.requestFocus();
        this.tblRubros.setModel(this.consultaSql.llenarTablaListaRubroSubRubro("%%", Variables.idOficina, this.cbxOpcionBusqueda.getSelectedIndex()));
        this.configurarTabla();
    }
    
    public void buscar() {
        this.tblRubros.setModel(this.consultaSql.llenarTablaListaRubroSubRubro("%" + this.txtNombreRubro.getText() + "%", Variables.idOficina, this.cbxOpcionBusqueda.getSelectedIndex()));
        this.configurarTabla();
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.31)));
        final TableColumnModel columnModel = this.tblRubros.getColumnModel();
        header = this.tblRubros.getTableHeader();
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(500);
        columnModel.getColumn(2).setPreferredWidth(200);
        columnModel.getColumn(3).setPreferredWidth(100);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(200);
    }
}
