// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.submodulo.inventario;

import javax.swing.ComboBoxModel;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.F_Inventario;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class NuevoProducto extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public F_Inventario inventario;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevoProducto;
    private JLabel btnNuevoProducto;
    private JLabel lblIconoBtn_nuevoProducto;
    private JLabel lblNombreBtn_nuevoProducto;
    private JPanel jp_btnBuscarProducto;
    private JLabel btnBuscarProducto;
    private JLabel lblIconoBtn_buscarProducto;
    private JLabel lblNombreBtn_buscarProducto;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblNuevoProducto;
    private JLabel lblIdProducto;
    private JTextField txtIdProducto;
    private JTextField txtCodigoProducto;
    private JLabel lblFechaDocumento;
    private JTextField txtFechaDocumento;
    private JLabel imgProducto;
    private JTextField txtNombreProducto;
    private JLabel lblProveedor;
    private JLabel lblRubro;
    private JComboBox<Object> cbxRubro;
    private JLabel lblDescripcion;
    private JLabel lblPeso;
    private JTextField txtPeso;
    private JLabel lblUnidadMedida;
    private JTextField txtUnidadMedida;
    private JLabel lblStockMinimo;
    private JTextField txtStockMinimo;
    private JLabel lblStockMaximo;
    private JTextField txtStockMaximo;
    private JLabel lblCosto;
    private JTextField txtCosto;
    private JLabel lblPrecio;
    private JTextField txtPrecio;
    private JLabel lblDescuento_01;
    private JTextField txtDescuento_01;
    private JLabel lblDescuento_02;
    private JTextField txtDescuento_02;
    private JLabel lblDescuento_03;
    private JTextField txtDescuento_03;
    private JPanel jp_chckVenta;
    private JLabel chckVenta;
    private JLabel lblIconoChck_venta;
    private JLabel lblNombreChck_venta;
    private JPanel jp_chckConsumo;
    private JLabel chckConsumo;
    private JLabel lblIconoChck_consumo;
    private JLabel lblNombreChck_consumo;
    private JPanel jp_chckActivo;
    private JLabel chckActivo;
    private JLabel lblIconoChck_activo;
    private JLabel lblNombreChck_activo;
    private JPanel jp_chckInactivo;
    private JLabel chckInactivo;
    private JLabel lblIconoChck_inactivo;
    private JLabel lblNombreChck_inactivo;
    private JLabel lblRutaImagen;
    private JPanel jp_btnBuscarImagen;
    private JLabel btnBuscarImagen;
    private JLabel lblIconoBtn_buscarImagen;
    private JLabel lblNombreBtn_buscarImagen;
    public boolean chckbxVenta;
    public boolean chckbxConsumo;
    public boolean chckbxActivo;
    public boolean chckbxInactivo;
    public String rutaImg;
    private JComboBox<Object> cbxProveedor;
    private JLabel lblNombreProducto;
    private JTextPane txtDescripcion;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final NuevoProducto frame = new NuevoProducto();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public NuevoProducto() {
        this.ajustes = new Ajustes();
        this.inventario = new F_Inventario();
        this.consultaSql = new consultasSQL_SERVER();
        this.chckbxVenta = true;
        this.chckbxConsumo = false;
        this.chckbxActivo = true;
        this.chckbxInactivo = false;
        this.rutaImg = "";
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                NuevoProducto.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevoProducto = new JPanel()).setLayout(null);
        this.jp_btnNuevoProducto.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevoProducto.setBackground(Variables.color_tres);
        this.jp_btnNuevoProducto.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevoProducto);
        (this.btnNuevoProducto = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevoProducto.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevoProducto.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnNuevoProducto.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevoProducto.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnNuevoProducto.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevoProducto.add(this.btnNuevoProducto);
        (this.lblIconoBtn_nuevoProducto = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevoProducto.setIcon(this.ajustes.ajustarImagen("/botones_17_icono_nuevoProducto", this.lblIconoBtn_nuevoProducto, 50, 50, 50, 50));
        this.jp_btnNuevoProducto.add(this.lblIconoBtn_nuevoProducto);
        (this.lblNombreBtn_nuevoProducto = new JLabel("Nuevo")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevoProducto.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevoProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(2, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_nuevoProducto.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevoProducto.add(this.lblNombreBtn_nuevoProducto);
        (this.jp_btnBuscarProducto = new JPanel()).setLayout(null);
        this.jp_btnBuscarProducto.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarProducto.setBackground(Variables.color_tres);
        this.jp_btnBuscarProducto.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarProducto);
        (this.btnBuscarProducto = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarProducto.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarProducto.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnBuscarProducto.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarProducto.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnBuscarProducto.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarProducto.add(this.btnBuscarProducto);
        (this.lblIconoBtn_buscarProducto = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarProducto.setIcon(this.ajustes.ajustarImagen("/botones_18_icono_buscarProducto", this.lblIconoBtn_buscarProducto, 50, 50, 50, 50));
        this.jp_btnBuscarProducto.add(this.lblIconoBtn_buscarProducto);
        (this.lblNombreBtn_buscarProducto = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarProducto.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(2, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_buscarProducto.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarProducto.add(this.lblNombreBtn_buscarProducto);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoProducto.this.guardar();
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(2, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.26), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(2, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoProducto.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(2, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - 185);
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblNuevoProducto = new JLabel("Ingresar Nuevo Producto")).setForeground(Variables.color_uno);
        this.lblNuevoProducto.setHorizontalAlignment(0);
        this.lblNuevoProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.lblNuevoProducto.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.lblNuevoProducto);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - 50, this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        (this.lblIdProducto = new JLabel("ID:")).setHorizontalAlignment(0);
        this.lblIdProducto.setForeground(Variables.color_uno);
        this.lblIdProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblIdProducto.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblIdProducto);
        (this.txtIdProducto = new JTextField()).setEditable(false);
        this.txtIdProducto.setBackground(Variables.color_uno);
        this.txtIdProducto.setHorizontalAlignment(0);
        this.txtIdProducto.setForeground(Variables.color_dos);
        this.txtIdProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtIdProducto.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtIdProducto);
        this.txtIdProducto.setColumns(10);
        final JLabel lblCodigoProducto = new JLabel("Codigo:");
        lblCodigoProducto.setHorizontalAlignment(0);
        lblCodigoProducto.setForeground(Variables.color_uno);
        lblCodigoProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblCodigoProducto.setBounds((this.ajustes.ancho - 25) / 10 + 50, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 3 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(lblCodigoProducto);
        (this.txtCodigoProducto = new JTextField()).setHorizontalAlignment(0);
        this.txtCodigoProducto.setForeground(Variables.color_dos);
        this.txtCodigoProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCodigoProducto.setColumns(10);
        this.txtCodigoProducto.setBackground(Variables.color_uno);
        this.txtCodigoProducto.setBounds((this.ajustes.ancho - 25) / 10 + 50, this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10 * 3 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCodigoProducto);
        (this.lblFechaDocumento = new JLabel("Fecha:")).setHorizontalAlignment(0);
        this.lblFechaDocumento.setForeground(Variables.color_uno);
        this.lblFechaDocumento.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 9, this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaDocumento);
        (this.txtFechaDocumento = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaDocumento.setForeground(Variables.color_dos);
        this.txtFechaDocumento.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaDocumento.setEditable(false);
        this.txtFechaDocumento.setColumns(10);
        this.txtFechaDocumento.setBackground(Variables.color_uno);
        this.txtFechaDocumento.setBounds((this.ajustes.ancho - 25) / 10 * 9, this.ajustes.calcularPuntoY(6.48), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaDocumento);
        final JPanel jp_imgProducto = new JPanel();
        jp_imgProducto.setBorder(new BevelBorder(1, null, null, null, null));
        jp_imgProducto.setBackground(Variables.color_uno);
        jp_imgProducto.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 2, (this.ajustes.ancho - 25) / 10 * 2);
        jp_contenido.add(jp_imgProducto);
        jp_imgProducto.setLayout(null);
        (this.imgProducto = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.93), (this.ajustes.ancho - 25) / 10 * 2 - 20, (this.ajustes.ancho - 25) / 10 * 2 - 20);
        jp_imgProducto.add(this.imgProducto);
        (this.lblRutaImagen = new JLabel("")).setForeground(Variables.color_uno);
        this.lblRutaImagen.setFont(new Font(Variables.fuenteLetra, 0, 10));
        this.lblRutaImagen.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(10.19) + (this.ajustes.ancho - 25) / 10 * 2, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(0.93));
        jp_contenido.add(this.lblRutaImagen);
        (this.jp_btnBuscarImagen = new JPanel()).setBackground(Variables.color_uno);
        this.jp_btnBuscarImagen.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarImagen.setBounds((this.ajustes.ancho - 25) / 10 * 8, this.ajustes.calcularPuntoY(11.11) + (this.ajustes.ancho - 25) / 10 * 2, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(5.56));
        jp_contenido.add(this.jp_btnBuscarImagen);
        this.jp_btnBuscarImagen.setLayout(null);
        (this.btnBuscarImagen = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnBuscarImagen.setBackground(Variables.color_uno);
                NuevoProducto.this.lblIconoBtn_buscarImagen.setIcon(NuevoProducto.this.ajustes.ajustarImagen("/botones_07_icono_buscar", NuevoProducto.this.lblIconoBtn_buscarImagen, 50, 50, 50, 50));
                NuevoProducto.this.lblNombreBtn_buscarImagen.setForeground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoProducto.this.buscarImg();
            }
        });
        this.btnBuscarImagen.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                NuevoProducto.this.jp_btnBuscarImagen.setBackground(Variables.color_dos);
                NuevoProducto.this.lblIconoBtn_buscarImagen.setIcon(NuevoProducto.this.ajustes.ajustarImagen("/botones_07_icono_buscar_select", NuevoProducto.this.lblIconoBtn_buscarImagen, 50, 50, 50, 50));
                NuevoProducto.this.lblNombreBtn_buscarImagen.setForeground(Variables.color_uno);
            }
        });
        this.btnBuscarImagen.setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarImagen.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2, this.ajustes.calcularPuntoY(5.56));
        this.jp_btnBuscarImagen.add(this.btnBuscarImagen);
        (this.lblIconoBtn_buscarImagen = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarImagen.setIcon(this.ajustes.ajustarImagen("/botones_07_icono_buscar", this.lblIconoBtn_buscarImagen, 50, 50, 50, 50));
        this.jp_btnBuscarImagen.add(this.lblIconoBtn_buscarImagen);
        (this.lblNombreBtn_buscarImagen = new JLabel("Buscar Imagen")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarImagen.setForeground(Variables.color_dos);
        this.lblNombreBtn_buscarImagen.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, 25)));
        this.lblNombreBtn_buscarImagen.setBounds(this.ajustes.calcularPuntoX(4.17), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 2 - 80, this.ajustes.calcularPuntoY(4.63));
        this.jp_btnBuscarImagen.add(this.lblNombreBtn_buscarImagen);
        (this.lblProveedor = new JLabel("Proveedor:")).setHorizontalAlignment(0);
        this.lblProveedor.setForeground(Variables.color_uno);
        this.lblProveedor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblProveedor.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblProveedor);
        (this.cbxProveedor = new JComboBox<Object>()).setForeground(Variables.color_dos);
        this.cbxProveedor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxProveedor.setBackground(Variables.color_uno);
        this.cbxProveedor.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 25) / 10 * 4, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxProveedor);
        (this.lblRubro = new JLabel("Rubro:")).setHorizontalAlignment(0);
        this.lblRubro.setForeground(Variables.color_uno);
        this.lblRubro.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblRubro.setBounds((this.ajustes.ancho - 25) / 10 * 4 + 50, this.ajustes.calcularPuntoY(10.19), (this.ajustes.ancho - 25) / 10 * 4 - 70, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblRubro);
        (this.cbxRubro = new JComboBox<Object>()).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                NuevoProducto.this.txtCodigoProducto.setText(NuevoProducto.this.obtenerCodigoProducto(NuevoProducto.this.cbxRubro.getSelectedItem().toString()));
            }
        });
        this.cbxRubro.setForeground(Variables.color_dos);
        this.cbxRubro.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxRubro.setBackground(Variables.color_uno);
        this.cbxRubro.setBounds((this.ajustes.ancho - 25) / 10 * 4 + 50, this.ajustes.calcularPuntoY(12.04), (this.ajustes.ancho - 25) / 10 * 4 - 70, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxRubro);
        (this.lblNombreProducto = new JLabel("Nombre de Producto:")).setHorizontalAlignment(0);
        this.lblNombreProducto.setForeground(Variables.color_uno);
        this.lblNombreProducto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreProducto.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(15.74), (this.ajustes.ancho - 25) / 10 * 8 - 50, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNombreProducto);
        (this.txtNombreProducto = new JTextField()).setHorizontalAlignment(0);
        this.txtNombreProducto.setForeground(Variables.color_dos);
        this.txtNombreProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreProducto.setColumns(10);
        this.txtNombreProducto.setBackground(Variables.color_uno);
        this.txtNombreProducto.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(17.59), (this.ajustes.ancho - 25) / 10 * 8 - 50, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreProducto);
        (this.lblDescripcion = new JLabel("Descripcion:")).setHorizontalAlignment(0);
        this.lblDescripcion.setForeground(Variables.color_uno);
        this.lblDescripcion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescripcion.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(21.3), (this.ajustes.ancho - 25) / 10 * 8 - 50, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescripcion);
        (this.txtDescripcion = new JTextPane()).setForeground(Variables.color_dos);
        this.txtDescripcion.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescripcion.setBackground(Variables.color_uno);
        this.txtDescripcion.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(23.15), (this.ajustes.ancho - 25) / 10 * 8 - 50, this.ajustes.calcularPuntoY(8.33));
        jp_contenido.add(this.txtDescripcion);
        (this.lblPeso = new JLabel("Peso del Producto:")).setHorizontalAlignment(0);
        this.lblPeso.setForeground(Variables.color_uno);
        this.lblPeso.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPeso.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(32.41), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblPeso);
        (this.txtPeso = new JTextField()).setText("0.00");
        this.txtPeso.setHorizontalAlignment(0);
        this.txtPeso.setForeground(Variables.color_dos);
        this.txtPeso.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPeso.setColumns(10);
        this.txtPeso.setBackground(Variables.color_uno);
        this.txtPeso.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(34.26), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtPeso);
        (this.lblUnidadMedida = new JLabel("Unidad de Medida:")).setHorizontalAlignment(0);
        this.lblUnidadMedida.setForeground(Variables.color_uno);
        this.lblUnidadMedida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblUnidadMedida.setBounds((this.ajustes.ancho - 25) / 10 * 2 + 25, this.ajustes.calcularPuntoY(32.41), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblUnidadMedida);
        (this.txtUnidadMedida = new JTextField()).setText("C/U");
        this.txtUnidadMedida.setHorizontalAlignment(0);
        this.txtUnidadMedida.setForeground(Variables.color_dos);
        this.txtUnidadMedida.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtUnidadMedida.setColumns(10);
        this.txtUnidadMedida.setBackground(Variables.color_uno);
        this.txtUnidadMedida.setBounds((this.ajustes.ancho - 25) / 10 * 2 + 25, this.ajustes.calcularPuntoY(34.26), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtUnidadMedida);
        (this.lblStockMinimo = new JLabel("Stock Minimo:")).setHorizontalAlignment(0);
        this.lblStockMinimo.setForeground(Variables.color_uno);
        this.lblStockMinimo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblStockMinimo.setBounds((this.ajustes.ancho - 25) / 10 * 4 + 25, this.ajustes.calcularPuntoY(32.41), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblStockMinimo);
        (this.txtStockMinimo = new JTextField()).setText("0.00");
        this.txtStockMinimo.setHorizontalAlignment(0);
        this.txtStockMinimo.setForeground(Variables.color_dos);
        this.txtStockMinimo.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtStockMinimo.setColumns(10);
        this.txtStockMinimo.setBackground(Variables.color_uno);
        this.txtStockMinimo.setBounds((this.ajustes.ancho - 25) / 10 * 4 + 25, this.ajustes.calcularPuntoY(34.26), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtStockMinimo);
        (this.lblStockMaximo = new JLabel("Stock Maximo:")).setHorizontalAlignment(0);
        this.lblStockMaximo.setForeground(Variables.color_uno);
        this.lblStockMaximo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblStockMaximo.setBounds((this.ajustes.ancho - 25) / 10 * 6 + 25, this.ajustes.calcularPuntoY(32.41), (this.ajustes.ancho - 25) / 10 * 2 - 50, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblStockMaximo);
        (this.txtStockMaximo = new JTextField()).setText("0.00");
        this.txtStockMaximo.setHorizontalAlignment(0);
        this.txtStockMaximo.setForeground(Variables.color_dos);
        this.txtStockMaximo.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtStockMaximo.setColumns(10);
        this.txtStockMaximo.setBackground(Variables.color_uno);
        this.txtStockMaximo.setBounds((this.ajustes.ancho - 25) / 10 * 6 + 25, this.ajustes.calcularPuntoY(34.26), (this.ajustes.ancho - 25) / 10 * 2 - 50, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtStockMaximo);
        (this.lblCosto = new JLabel("Costo ($)")).setHorizontalAlignment(0);
        this.lblCosto.setForeground(Variables.color_uno);
        this.lblCosto.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCosto.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(37.96), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblCosto);
        (this.txtCosto = new JTextField()).setText("0.00");
        this.txtCosto.setHorizontalAlignment(0);
        this.txtCosto.setForeground(Variables.color_dos);
        this.txtCosto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtCosto.setColumns(10);
        this.txtCosto.setBackground(Variables.color_uno);
        this.txtCosto.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(39.81), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtCosto);
        (this.lblPrecio = new JLabel("Precio ($)")).setHorizontalAlignment(0);
        this.lblPrecio.setForeground(Variables.color_uno);
        this.lblPrecio.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblPrecio.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(43.52), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblPrecio);
        (this.txtPrecio = new JTextField()).setText("0.00");
        this.txtPrecio.setHorizontalAlignment(0);
        this.txtPrecio.setForeground(Variables.color_dos);
        this.txtPrecio.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtPrecio.setColumns(10);
        this.txtPrecio.setBackground(Variables.color_uno);
        this.txtPrecio.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(45.37), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtPrecio);
        (this.lblDescuento_01 = new JLabel("Descuento 1 (%):")).setHorizontalAlignment(0);
        this.lblDescuento_01.setForeground(Variables.color_uno);
        this.lblDescuento_01.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescuento_01.setBounds((this.ajustes.ancho - 25) / 10 * 2 + 25, this.ajustes.calcularPuntoY(43.52), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescuento_01);
        (this.txtDescuento_01 = new JTextField()).setText("0.00");
        this.txtDescuento_01.setHorizontalAlignment(0);
        this.txtDescuento_01.setForeground(Variables.color_dos);
        this.txtDescuento_01.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescuento_01.setColumns(10);
        this.txtDescuento_01.setBackground(Variables.color_uno);
        this.txtDescuento_01.setBounds((this.ajustes.ancho - 25) / 10 * 2 + 25, this.ajustes.calcularPuntoY(45.37), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescuento_01);
        (this.lblDescuento_02 = new JLabel("Descuento 2 (%):")).setHorizontalAlignment(0);
        this.lblDescuento_02.setForeground(Variables.color_uno);
        this.lblDescuento_02.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescuento_02.setBounds((this.ajustes.ancho - 25) / 10 * 4 + 25, this.ajustes.calcularPuntoY(43.52), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescuento_02);
        (this.txtDescuento_02 = new JTextField()).setText("0.00");
        this.txtDescuento_02.setHorizontalAlignment(0);
        this.txtDescuento_02.setForeground(Variables.color_dos);
        this.txtDescuento_02.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescuento_02.setColumns(10);
        this.txtDescuento_02.setBackground(Variables.color_uno);
        this.txtDescuento_02.setBounds((this.ajustes.ancho - 25) / 10 * 4 + 25, this.ajustes.calcularPuntoY(45.37), (this.ajustes.ancho - 25) / 10 * 2 - 25, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescuento_02);
        (this.lblDescuento_03 = new JLabel("Descuento 3 (%):")).setHorizontalAlignment(0);
        this.lblDescuento_03.setForeground(Variables.color_uno);
        this.lblDescuento_03.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblDescuento_03.setBounds((this.ajustes.ancho - 25) / 10 * 6 + 25, this.ajustes.calcularPuntoY(43.52), (this.ajustes.ancho - 25) / 10 * 2 - 50, this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblDescuento_03);
        (this.txtDescuento_03 = new JTextField()).setText("0.00");
        this.txtDescuento_03.setHorizontalAlignment(0);
        this.txtDescuento_03.setForeground(Variables.color_dos);
        this.txtDescuento_03.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtDescuento_03.setColumns(10);
        this.txtDescuento_03.setBackground(Variables.color_uno);
        this.txtDescuento_03.setBounds((this.ajustes.ancho - 25) / 10 * 6 + 25, this.ajustes.calcularPuntoY(45.37), (this.ajustes.ancho - 25) / 10 * 2 - 50, this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtDescuento_03);
        final JPanel jp_tipoProducto = new JPanel();
        jp_tipoProducto.setOpaque(false);
        jp_tipoProducto.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Tipo de Producto", 4, 2, null, Variables.color_uno));
        jp_tipoProducto.setBounds(25, this.ajustes.calcularPuntoY(49.07), (this.ajustes.ancho - 25) / 10 * 2 - 30, this.ajustes.calcularPuntoY(12.04));
        jp_contenido.add(jp_tipoProducto);
        jp_tipoProducto.setLayout(null);
        (this.jp_chckVenta = new JPanel()).setLayout(null);
        this.jp_chckVenta.setOpaque(false);
        this.jp_chckVenta.setBounds(10, this.ajustes.calcularPuntoY(1.85), (this.ajustes.ancho - 25) / 10 * 2 - 45, this.ajustes.calcularPuntoY(3.7));
        jp_tipoProducto.add(this.jp_chckVenta);
        (this.chckVenta = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoProducto.this.chckbxVenta = true;
                NuevoProducto.this.chckbxConsumo = false;
                NuevoProducto.this.verificarOpcion();
            }
        });
        this.chckVenta.setCursor(Cursor.getPredefinedCursor(12));
        this.chckVenta.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2 - 45, this.ajustes.calcularPuntoY(3.7));
        this.jp_chckVenta.add(this.chckVenta);
        (this.lblIconoChck_venta = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_venta.setBounds(0, 0, this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.7));
        this.lblIconoChck_venta.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check_select", this.lblIconoChck_venta, 40, 40, 30, 30));
        this.jp_chckVenta.add(this.lblIconoChck_venta);
        (this.lblNombreChck_venta = new JLabel("Venta")).setForeground(Variables.color_uno);
        this.lblNombreChck_venta.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreChck_venta.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 2 - 95, this.ajustes.calcularPuntoY(2.78));
        this.jp_chckVenta.add(this.lblNombreChck_venta);
        (this.jp_chckConsumo = new JPanel()).setLayout(null);
        this.jp_chckConsumo.setOpaque(false);
        this.jp_chckConsumo.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(6.48), this.ajustes.calcularPuntoX(17.45), this.ajustes.calcularPuntoY(3.7));
        jp_tipoProducto.add(this.jp_chckConsumo);
        (this.chckConsumo = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoProducto.this.chckbxVenta = false;
                NuevoProducto.this.chckbxConsumo = true;
                NuevoProducto.this.verificarOpcion();
            }
        });
        this.chckConsumo.setCursor(Cursor.getPredefinedCursor(12));
        this.chckConsumo.setBounds(0, 0, (this.ajustes.ancho - 25) / 10 * 2 - 45, this.ajustes.calcularPuntoY(3.7));
        this.jp_chckConsumo.add(this.chckConsumo);
        (this.lblIconoChck_consumo = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_consumo.setBounds(0, 0, this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.7));
        this.lblIconoChck_consumo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check", this.lblIconoChck_consumo, 40, 40, 30, 30));
        this.jp_chckConsumo.add(this.lblIconoChck_consumo);
        (this.lblNombreChck_consumo = new JLabel("Consumo")).setForeground(Variables.color_uno);
        this.lblNombreChck_consumo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreChck_consumo.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 2 - 95, this.ajustes.calcularPuntoY(2.78));
        this.jp_chckConsumo.add(this.lblNombreChck_consumo);
        final JPanel jp_estadoProducto = new JPanel();
        jp_estadoProducto.setLayout(null);
        jp_estadoProducto.setOpaque(false);
        jp_estadoProducto.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Estado del Producto", 4, 2, null, Variables.color_uno));
        jp_estadoProducto.setBounds((this.ajustes.ancho - 25) / 10 * 2 + 30, this.ajustes.calcularPuntoY(49.07), (this.ajustes.ancho - 25) / 10 * 2 - 30, this.ajustes.calcularPuntoY(12.04));
        jp_contenido.add(jp_estadoProducto);
        (this.jp_chckActivo = new JPanel()).setLayout(null);
        this.jp_chckActivo.setOpaque(false);
        this.jp_chckActivo.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(1.85), (this.ajustes.ancho - 25) / 10 * 2 - 40, this.ajustes.calcularPuntoY(3.7));
        jp_estadoProducto.add(this.jp_chckActivo);
        (this.chckActivo = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoProducto.this.chckbxActivo = true;
                NuevoProducto.this.chckbxInactivo = false;
                NuevoProducto.this.verificarOpcion();
            }
        });
        this.chckActivo.setCursor(Cursor.getPredefinedCursor(12));
        this.chckActivo.setBounds(0, 0, this.ajustes.calcularPuntoX(17.45), this.ajustes.calcularPuntoY(3.7));
        this.jp_chckActivo.add(this.chckActivo);
        (this.lblIconoChck_activo = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_activo.setBounds(0, 0, this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.7));
        this.lblIconoChck_activo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check_select", this.lblIconoChck_activo, 40, 40, 30, 30));
        this.jp_chckActivo.add(this.lblIconoChck_activo);
        (this.lblNombreChck_activo = new JLabel("Activo")).setForeground(Variables.color_uno);
        this.lblNombreChck_activo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreChck_activo.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 2 - 95, this.ajustes.calcularPuntoY(2.78));
        this.jp_chckActivo.add(this.lblNombreChck_activo);
        (this.jp_chckInactivo = new JPanel()).setLayout(null);
        this.jp_chckInactivo.setOpaque(false);
        this.jp_chckInactivo.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(6.48), this.ajustes.calcularPuntoX(17.45), this.ajustes.calcularPuntoY(3.7));
        jp_estadoProducto.add(this.jp_chckInactivo);
        (this.chckInactivo = new JLabel("")).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                NuevoProducto.this.chckbxActivo = false;
                NuevoProducto.this.chckbxInactivo = true;
                NuevoProducto.this.verificarOpcion();
            }
        });
        this.chckInactivo.setCursor(Cursor.getPredefinedCursor(12));
        this.chckInactivo.setBounds(0, 0, this.ajustes.calcularPuntoX(17.45), this.ajustes.calcularPuntoY(3.7));
        this.jp_chckInactivo.add(this.chckInactivo);
        (this.lblIconoChck_inactivo = new JLabel("")).setHorizontalAlignment(0);
        this.lblIconoChck_inactivo.setBounds(0, 0, this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.7));
        this.lblIconoChck_inactivo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check", this.lblIconoChck_inactivo, 40, 40, 30, 30));
        this.jp_chckInactivo.add(this.lblIconoChck_inactivo);
        (this.lblNombreChck_inactivo = new JLabel("Inactivo")).setForeground(Variables.color_uno);
        this.lblNombreChck_inactivo.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreChck_inactivo.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.46), (this.ajustes.ancho - 25) / 10 * 2 - 95, this.ajustes.calcularPuntoY(2.78));
        this.jp_chckInactivo.add(this.lblNombreChck_inactivo);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void verificarOpcion() {
        if (this.chckbxVenta && !this.chckbxConsumo) {
            this.lblIconoChck_venta.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check_select", this.lblIconoChck_venta, 40, 40, 30, 30));
            this.lblIconoChck_consumo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check", this.lblIconoChck_consumo, 40, 40, 30, 30));
        }
        else if (!this.chckbxVenta && this.chckbxConsumo) {
            this.lblIconoChck_venta.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check", this.lblIconoChck_venta, 40, 40, 30, 30));
            this.lblIconoChck_consumo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check_select", this.lblIconoChck_consumo, 40, 40, 30, 30));
        }
        if (this.chckbxActivo && !this.chckbxInactivo) {
            this.lblIconoChck_activo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check_select", this.lblIconoChck_activo, 40, 40, 30, 30));
            this.lblIconoChck_inactivo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check", this.lblIconoChck_inactivo, 40, 40, 30, 30));
        }
        else if (!this.chckbxActivo && this.chckbxInactivo) {
            this.lblIconoChck_activo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check", this.lblIconoChck_activo, 40, 40, 30, 30));
            this.lblIconoChck_inactivo.setIcon(this.ajustes.ajustarImagen("/general_21_icono_check_select", this.lblIconoChck_inactivo, 40, 40, 30, 30));
        }
    }
    
    public void buscarImg() {
        final JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        jfc.setDialogTitle("Select an image");
        jfc.setAcceptAllFileFilterUsed(false);
        final FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG and JPG images", new String[] { "png", "jpg" });
        jfc.addChoosableFileFilter(filter);
        final int returnValue = jfc.showOpenDialog(null);
        if (returnValue == 0) {
            this.lblRutaImagen.setText(jfc.getSelectedFile().getPath());
            try {
                final ImageIcon imgOriginal = new ImageIcon(this.lblRutaImagen.getText());
                final Icon icono = new ImageIcon(imgOriginal.getImage().getScaledInstance(this.imgProducto.getWidth(), this.imgProducto.getHeight(), 1));
                this.imgProducto.setText(null);
                this.imgProducto.setIcon(icono);
                this.rutaImg = this.lblRutaImagen.getText();
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "al buscar la imagen " + ex.toString(), "ERROR!", 0);
            }
        }
    }
    
    public void llenarCampos() {
        this.cbxRubro.setModel(this.consultaSql.getDataComboBox("select nombre from subcategoria order by idSubcategoria asc"));
        this.cbxProveedor.setModel(this.consultaSql.getDataComboBox("select nombre from proveedor order by nombre asc"));
        this.txtIdProducto.setText(String.valueOf(this.consultaSql.obtenerSigIdProducto()));
        this.txtCodigoProducto.setText(this.obtenerCodigoProducto(this.cbxRubro.getSelectedItem().toString()));
        this.txtFechaDocumento.setText(Variables.fechaActual);
    }
    
    public String obtenerCodigoProducto(final String nombreRubro) {
        String resultado = "";
        this.consultaSql.obtenerIdSubrubro(nombreRubro, Variables.idOficina);
        if (Variables.idRubro.length() == 1) {
            Variables.idRubro = "0" + Variables.idRubro;
        }
        else if (Variables.idRubro.length() > 2) {
            Variables.idRubro = Variables.idRubro.substring(0, 2);
        }
        final int idSubRubroAux = Integer.parseInt(Variables.idSubrubro);
        if (Variables.idSubrubro.length() == 1) {
            Variables.idSubrubro = "0" + Variables.idSubrubro;
        }
        else if (Variables.idSubrubro.length() > 2) {
            Variables.idSubrubro = Variables.idSubrubro.substring(0, 2);
        }
        final String numProducto = String.valueOf(this.consultaSql.obtenerSigProducto(idSubRubroAux));
        String aux = "";
        for (int i = 0; i < 5 - numProducto.length(); ++i) {
            aux = String.valueOf(aux) + "0";
        }
        resultado = String.valueOf(Variables.idOficina) + Variables.idRubro + Variables.idSubrubro + aux + numProducto;
        return resultado;
    }
    
    public void guardar() {
        if (this.txtNombreProducto.getText().length() == 0) {
            JOptionPane.showMessageDialog(null, "No se puede dejar campos vacios", "ERROR!", 0);
            this.lblNombreProducto.setForeground(Color.red);
            this.txtNombreProducto.requestFocus();
            return;
        }
        String tipoProducto = "";
        if (this.chckbxVenta && !this.chckbxConsumo) {
            tipoProducto = "VEN";
        }
        else if (!this.chckbxVenta && this.chckbxConsumo) {
            tipoProducto = "CON";
        }
        int estadoProducto = 0;
        if (this.chckbxActivo && !this.chckbxInactivo) {
            estadoProducto = 1;
        }
        else if (!this.chckbxActivo && this.chckbxInactivo) {
            estadoProducto = 0;
        }
        if (this.inventario.nuevoProducto(this.txtCodigoProducto.getText().toString(), this.consultaSql.obtenerIdProveedor(this.cbxProveedor.getSelectedItem().toString()), this.txtNombreProducto.getText().toString(), this.txtDescripcion.getText().toString(), Variables.fechaActual, Variables.idUsuario, Double.valueOf(this.txtPeso.getText().toString()), this.txtUnidadMedida.getText().toString(), Double.valueOf(this.txtStockMinimo.getText().toString()), Double.valueOf(this.txtStockMaximo.getText().toString()), Double.valueOf(this.txtCosto.getText().toString()), Double.valueOf(this.txtPrecio.getText().toString()), Double.valueOf(this.txtDescuento_01.getText().toString()), Double.valueOf(this.txtDescuento_02.getText().toString()), Double.valueOf(this.txtDescuento_03.getText().toString()), this.lblRutaImagen.getText().toString(), tipoProducto, estadoProducto, Integer.parseInt(Variables.idSubrubro_))) {
            JOptionPane.showMessageDialog(null, "Producto " + this.txtNombreProducto.getText() + "guardado correctamente.", "OK!", 1);
            return;
        }
        JOptionPane.showMessageDialog(null, "Producto " + this.txtNombreProducto.getText() + "no se pudo guardar -- " + Variables.error, "ERROR!", 0);
    }
}
