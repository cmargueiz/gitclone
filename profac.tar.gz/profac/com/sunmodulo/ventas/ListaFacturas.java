// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.sunmodulo.ventas;

import javax.swing.table.TableModel;
import java.time.format.DateTimeFormatter;
import java.time.ZoneOffset;
import java.util.Calendar;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Cursor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import profac.com.herramientas.Variables;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class ListaFacturas extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    public consultasSQL_SERVER consultaSql;
    private JPanel contentPane;
    private JPanel jp_btnSalir;
    private JLabel btnSalir;
    private JPanel jp_btnNuevaPartida;
    private JLabel btnNuevaPartida;
    private JLabel lblIconoBtn_nuevaPartida;
    private JLabel lblNombreBtn_nuevaPartida;
    private JPanel jp_btnBuscarPartida;
    private JLabel btnBuscarPartida;
    private JLabel lblIconoBtn_buscarPartida;
    private JLabel lblNombreBtn_buscarPartida;
    private JPanel jp_btnGuardar;
    private JLabel btnGuardar;
    private JLabel lblIconoBtn_guardar;
    private JLabel lblNombreBtn_guardar;
    private JPanel jp_btnImprimir;
    private JLabel btnImprimir;
    private JLabel lblIconoBtn_imprimir;
    private JLabel lblNombreBtn_imprimir;
    private JLabel lblnewlabel;
    private JLabel lblNombreCliente;
    private JTextField txtNombreCliente;
    private JLabel lblFechaInicio;
    private JTextField txtFechaInicio;
    private JLabel lblFechaFinal;
    private JTextField txtFechaFinal;
    private JPanel jp_btnBuscarFactura;
    private JLabel lblBuscarPor;
    private JComboBox<Object> cbxBuscarPor;
    private JLabel lblIconoBtn_buscarFactura;
    private JLabel lblNombreBtn_buscarFactura;
    private JLabel btnBuscarFactura;
    private JPanel jp_tblFacturas;
    private JScrollPane scrollPane;
    private JTable tblFacturas;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final ListaFacturas frame = new ListaFacturas();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public ListaFacturas() {
        this.ajustes = new Ajustes();
        this.consultaSql = new consultasSQL_SERVER();
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                ListaFacturas.this.llenarCampos();
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JPanel jp_botones = new JPanel();
        jp_botones.setBackground(Variables.color_uno);
        jp_botones.setBorder(null);
        jp_botones.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(8.33));
        jp_botones.setLayout(null);
        this.contentPane.add(jp_botones);
        (this.jp_btnNuevaPartida = new JPanel()).setLayout(null);
        this.jp_btnNuevaPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
        this.jp_btnNuevaPartida.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnNuevaPartida);
        (this.btnNuevaPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnNuevaPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnNuevaPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnNuevaPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnNuevaPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnNuevaPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnNuevaPartida.add(this.btnNuevaPartida);
        (this.lblIconoBtn_nuevaPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_nuevaPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-02-icono-nuevaPartida.png", this.lblIconoBtn_nuevaPartida));
        this.jp_btnNuevaPartida.add(this.lblIconoBtn_nuevaPartida);
        (this.lblNombreBtn_nuevaPartida = new JLabel("Nueva")).setHorizontalAlignment(0);
        this.lblNombreBtn_nuevaPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_nuevaPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_nuevaPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnNuevaPartida.add(this.lblNombreBtn_nuevaPartida);
        (this.jp_btnBuscarPartida = new JPanel()).setLayout(null);
        this.jp_btnBuscarPartida.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
        this.jp_btnBuscarPartida.setBounds(this.ajustes.calcularPuntoX(4.95), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnBuscarPartida);
        (this.btnBuscarPartida = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarPartida.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnBuscarPartida.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnBuscarPartida.setBackground(Variables.color_tres);
            }
        });
        this.btnBuscarPartida.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnBuscarPartida.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnBuscarPartida.add(this.btnBuscarPartida);
        (this.lblIconoBtn_buscarPartida = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_buscarPartida.setIcon(this.ajustes.ajustarImagen_("/images/botones-03-icono-buscarPartida.png", this.lblIconoBtn_buscarPartida));
        this.jp_btnBuscarPartida.add(this.lblIconoBtn_buscarPartida);
        (this.lblNombreBtn_buscarPartida = new JLabel("Buscar")).setHorizontalAlignment(0);
        this.lblNombreBtn_buscarPartida.setForeground(Variables.color_uno);
        this.lblNombreBtn_buscarPartida.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_buscarPartida.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnBuscarPartida.add(this.lblNombreBtn_buscarPartida);
        (this.jp_btnGuardar = new JPanel()).setLayout(null);
        this.jp_btnGuardar.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnGuardar.setBackground(Variables.color_tres);
        this.jp_btnGuardar.setBounds(this.ajustes.calcularPuntoX(9.11), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnGuardar);
        (this.btnGuardar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnGuardar.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        this.btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnGuardar.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnGuardar.add(this.btnGuardar);
        (this.lblIconoBtn_guardar = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_guardar.setIcon(this.ajustes.ajustarImagen("/botones_04_icono_guardar", this.lblIconoBtn_guardar, 50, 50, 50, 50));
        this.jp_btnGuardar.add(this.lblIconoBtn_guardar);
        (this.lblNombreBtn_guardar = new JLabel("Guardar")).setHorizontalAlignment(0);
        this.lblNombreBtn_guardar.setForeground(Variables.color_uno);
        this.lblNombreBtn_guardar.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_guardar.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnGuardar.add(this.lblNombreBtn_guardar);
        (this.jp_btnImprimir = new JPanel()).setLayout(null);
        this.jp_btnImprimir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnImprimir.setBackground(Variables.color_tres);
        this.jp_btnImprimir.setBounds(this.ajustes.calcularPuntoX(13.28), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnImprimir);
        (this.btnImprimir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnImprimir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnImprimir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnImprimir.setBackground(Variables.color_tres);
            }
        });
        this.btnImprimir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnImprimir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnImprimir.add(this.btnImprimir);
        (this.lblIconoBtn_imprimir = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        this.lblIconoBtn_imprimir.setIcon(this.ajustes.ajustarImagen("/botones_05_icono_imprimir", this.lblIconoBtn_imprimir, 50, 50, 50, 50));
        this.jp_btnImprimir.add(this.lblIconoBtn_imprimir);
        (this.lblNombreBtn_imprimir = new JLabel("Imprimir")).setHorizontalAlignment(0);
        this.lblNombreBtn_imprimir.setForeground(Variables.color_uno);
        this.lblNombreBtn_imprimir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        this.lblNombreBtn_imprimir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnImprimir.add(this.lblNombreBtn_imprimir);
        (this.jp_btnSalir = new JPanel()).setBackground(Variables.color_tres);
        this.jp_btnSalir.setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnSalir.setBounds(this.ajustes.calcularPuntoX(26.04), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        jp_botones.add(this.jp_btnSalir);
        this.jp_btnSalir.setLayout(null);
        (this.btnSalir = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnSalir.setBounds(0, 0, this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(7.41));
        this.btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnSalir.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                ListaFacturas.this.dispose();
            }
        });
        this.btnSalir.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                ListaFacturas.this.jp_btnSalir.setBackground(Variables.color_dos);
            }
        });
        this.jp_btnSalir.add(this.btnSalir);
        final JLabel lblIconoBtn_salir = new JLabel("");
        lblIconoBtn_salir.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.43), this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(4.63));
        lblIconoBtn_salir.setIcon(this.ajustes.ajustarImagen("/botones_01_icono_salir", lblIconoBtn_salir, 50, 50, 50, 50));
        this.jp_btnSalir.add(lblIconoBtn_salir);
        final JLabel lblNombreBtn_salir = new JLabel("Salir");
        lblNombreBtn_salir.setForeground(Variables.color_uno);
        lblNombreBtn_salir.setHorizontalAlignment(0);
        lblNombreBtn_salir.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.39))));
        lblNombreBtn_salir.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(1.85));
        this.jp_btnSalir.add(lblNombreBtn_salir);
        final JPanel jp_contenido = new JPanel();
        jp_contenido.setOpaque(false);
        jp_contenido.setBounds(0, this.ajustes.calcularPuntoY(8.33), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(17.13));
        this.contentPane.add(jp_contenido);
        jp_contenido.setLayout(null);
        (this.lblnewlabel = new JLabel("Lista de Facturas Emitidas")).setForeground(Variables.color_uno);
        this.lblnewlabel.setHorizontalAlignment(0);
        this.lblnewlabel.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.calcularPuntoY(1.85)));
        this.lblnewlabel.setBounds(0, this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho, this.ajustes.calcularPuntoY(2.31));
        jp_contenido.add(this.lblnewlabel);
        final JSeparator separator = new JSeparator();
        separator.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(3.24), this.ajustes.ancho - this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(0.19));
        jp_contenido.add(separator);
        (this.lblBuscarPor = new JLabel("Buscar Por:")).setHorizontalAlignment(0);
        this.lblBuscarPor.setForeground(Variables.color_uno);
        this.lblBuscarPor.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblBuscarPor.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblBuscarPor);
        (this.cbxBuscarPor = new JComboBox<Object>()).setModel(new DefaultComboBoxModel<Object>(new String[] { "OP01 - Nombre del Cliente", "OP02 - Numero de Factura" }));
        this.cbxBuscarPor.setForeground(Variables.color_dos);
        this.cbxBuscarPor.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.cbxBuscarPor.setBackground(Variables.color_uno);
        this.cbxBuscarPor.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 2 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.cbxBuscarPor);
        (this.lblNombreCliente = new JLabel("Nombre del Cliente:")).setHorizontalAlignment(0);
        this.lblNombreCliente.setForeground(Variables.color_uno);
        this.lblNombreCliente.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreCliente.setBounds((this.ajustes.ancho - 25) / 10 * 2 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblNombreCliente);
        (this.txtNombreCliente = new JTextField()).setForeground(Variables.color_dos);
        this.txtNombreCliente.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtNombreCliente.setColumns(10);
        this.txtNombreCliente.setBackground(Variables.color_uno);
        this.txtNombreCliente.setBounds((this.ajustes.ancho - 25) / 10 * 2 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 * 4 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtNombreCliente);
        (this.lblFechaInicio = new JLabel("Fecha Inicio:")).setHorizontalAlignment(0);
        this.lblFechaInicio.setForeground(Variables.color_uno);
        this.lblFechaInicio.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaInicio.setBounds((this.ajustes.ancho - 25) / 10 * 6 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaInicio);
        (this.txtFechaInicio = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaInicio.setForeground(Variables.color_dos);
        this.txtFechaInicio.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaInicio.setColumns(10);
        this.txtFechaInicio.setBackground(Variables.color_uno);
        this.txtFechaInicio.setBounds((this.ajustes.ancho - 25) / 10 * 6 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaInicio);
        (this.lblFechaFinal = new JLabel("Fecha Final:")).setHorizontalAlignment(0);
        this.lblFechaFinal.setForeground(Variables.color_uno);
        this.lblFechaFinal.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaFinal.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        jp_contenido.add(this.lblFechaFinal);
        (this.txtFechaFinal = new JTextField()).setHorizontalAlignment(0);
        this.txtFechaFinal.setForeground(Variables.color_dos);
        this.txtFechaFinal.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(2.78))));
        this.txtFechaFinal.setColumns(10);
        this.txtFechaFinal.setBackground(Variables.color_uno);
        this.txtFechaFinal.setBounds((this.ajustes.ancho - 25) / 10 * 7 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(6.94), (this.ajustes.ancho - 25) / 10 - this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.78));
        jp_contenido.add(this.txtFechaFinal);
        (this.jp_btnBuscarFactura = new JPanel()).setBorder(new BevelBorder(0, null, null, null, null));
        this.jp_btnBuscarFactura.setBackground(Variables.color_uno);
        this.jp_btnBuscarFactura.setBounds((this.ajustes.ancho - 50) / 10 * 9 + this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(4.63), (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(5.09));
        jp_contenido.add(this.jp_btnBuscarFactura);
        this.jp_btnBuscarFactura.setLayout(null);
        (this.btnBuscarFactura = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnBuscarFactura.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent e) {
                ListaFacturas.this.jp_btnBuscarFactura.setBackground(Variables.color_uno);
                ListaFacturas.this.lblIconoBtn_buscarFactura.setIcon(ListaFacturas.this.ajustes.ajustarImagen("/botones_07_icono_buscar/", ListaFacturas.this.lblIconoBtn_buscarFactura, 45, 45, 45, 45));
                ListaFacturas.this.lblNombreBtn_buscarFactura.setForeground(Variables.color_dos);
            }
        });
        this.btnBuscarFactura.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent e) {
                ListaFacturas.this.jp_btnBuscarFactura.setBackground(Variables.color_dos);
                ListaFacturas.this.lblIconoBtn_buscarFactura.setIcon(ListaFacturas.this.ajustes.ajustarImagen("/botones_07_icono_buscar_select/", ListaFacturas.this.lblIconoBtn_buscarFactura, 45, 45, 45, 45));
                ListaFacturas.this.lblNombreBtn_buscarFactura.setForeground(Variables.color_uno);
            }
        });
        this.btnBuscarFactura.setBounds(0, 0, (this.ajustes.ancho - 25) / 10, this.ajustes.calcularPuntoY(5.09));
        this.jp_btnBuscarFactura.add(this.btnBuscarFactura);
        (this.lblIconoBtn_buscarFactura = new JLabel("")).setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.34), this.ajustes.calcularPuntoY(4.17));
        this.lblIconoBtn_buscarFactura.setIcon(this.ajustes.ajustarImagen("/botones_07_icono_buscar/", this.lblIconoBtn_buscarFactura, 45, 45, 45, 45));
        this.jp_btnBuscarFactura.add(this.lblIconoBtn_buscarFactura);
        (this.lblNombreBtn_buscarFactura = new JLabel("Buscar")).setForeground(Variables.color_dos);
        this.lblNombreBtn_buscarFactura.setHorizontalAlignment(0);
        this.lblNombreBtn_buscarFactura.setFont(new Font("Tahoma", 0, this.ajustes.ajustarTexto(0, this.ajustes.calcularPuntoY(4.17))));
        this.lblNombreBtn_buscarFactura.setBounds(this.ajustes.calcularPuntoX(3.39), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(5.99), this.ajustes.calcularPuntoY(4.17));
        this.jp_btnBuscarFactura.add(this.lblNombreBtn_buscarFactura);
        (this.jp_tblFacturas = new JPanel()).setBackground(Variables.color_uno);
        this.jp_tblFacturas.setBounds(this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(10.65), this.ajustes.ancho - 50, this.ajustes.calcularPuntoY(71.3));
        jp_contenido.add(this.jp_tblFacturas);
        this.jp_tblFacturas.setLayout(null);
        (this.scrollPane = new JScrollPane()).setBounds(0, 0, this.ajustes.ancho - 50, this.ajustes.calcularPuntoY(71.3));
        this.jp_tblFacturas.add(this.scrollPane);
        (this.tblFacturas = new JTable()).setForeground(Variables.color_dos);
        this.tblFacturas.setFont(new Font(Variables.fuenteLetra, 0, Variables.tamContenidoTabla));
        this.scrollPane.setViewportView(this.tblFacturas);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public static Date ParseFecha(final String fecha) {
        final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaDate = null;
        try {
            fechaDate = formato.parse(fecha);
        }
        catch (ParseException ex) {
            System.out.println(ex);
        }
        return fechaDate;
    }
    
    public void configurarTabla() {
        final DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        JTableHeader header = new JTableHeader();
        final Font fuente = new Font(Variables.fuenteLetra, 1, Variables.tamTituloTabla);
        final TableColumnModel columnModel = this.tblFacturas.getColumnModel();
        header = this.tblFacturas.getTableHeader();
        header.setFont(fuente);
        header.setForeground(Variables.color_dos);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(600);
        columnModel.getColumn(2).setPreferredWidth(75);
        columnModel.getColumn(2).setCellRenderer(alinear);
        columnModel.getColumn(3).setPreferredWidth(75);
        columnModel.getColumn(3).setCellRenderer(alinear);
        columnModel.getColumn(4).setPreferredWidth(75);
        columnModel.getColumn(4).setCellRenderer(alinear);
        columnModel.getColumn(5).setPreferredWidth(75);
        columnModel.getColumn(5).setCellRenderer(alinear);
    }
    
    public void llenarCampos() {
        this.txtFechaFinal.setText(Variables.fechaActual);
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(ParseFecha(Variables.fechaActual));
        calendar.add(2, -1);
        Date fechaInicio = new Date();
        fechaInicio = calendar.getTime();
        this.txtFechaInicio.setText(fechaInicio.toInstant().atOffset(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        this.tblFacturas.setModel(this.consultaSql.obtenerListaFacturas());
        this.configurarTabla();
    }
}
