// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.modulos;

import profac.com.login.Login;
import javax.swing.JComponent;
import Animacion.Animacion;
import profac.com.submodulo.contabilidad.ReportesContables;
import profac.com.submodulo.contabilidad.VicularCuentasContables;
import profac.com.submodulo.contabilidad.ListaBancos;
import profac.com.submodulo.contabilidad.NuevoBanco;
import profac.com.submodulo.contabilidad.ListaCuentaContable;
import profac.com.submodulo.contabilidad.NuevaCuentaContable;
import profac.com.submodulo.contabilidad.ListaCheques;
import profac.com.submodulo.contabilidad.NuevoCheque;
import profac.com.submodulo.contabilidad.ListaPartidaContable;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import profac.com.submodulo.contabilidad.NuevaPartidaContable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.Cursor;
import javax.swing.border.BevelBorder;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.WindowListener;
import profac.com.herramientas.Variables;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class Contabilidad extends JFrame
{
    private static final long serialVersionUID = 1L;
	public Ajustes ajustes;
    private JPanel contentPane;
    private JLabel btnMinimizar;
    private JLabel btnCerrar;
    public JLabel lblNombreOficina;
    public JLabel lblFechaSistema;
    private JPanel jp_menuLateral;
    public JLabel lblUsuarioLateral;
    public JLabel lblNombreUsuarioLateral;
    public JLabel lblCargoUsuarioLateral;
    public boolean bandera_menuLateral;
    private JLabel btnMenuPricipal;
    private JLabel btnConfiguracion;
    private JLabel btnCerrarSesion;
    private JMenu mnPartidasContables;
    private JMenu mnCheques;
    private JMenu mnCatalogoDeCuentas;
    private JMenu mnBancos;
    private JMenuBar mnBar;
    private JMenuItem mntmNuevaPartidaContable;
    private JMenuItem mntmListaDePartidas;
    private JMenuItem mntmNuevoCheque;
    private JMenuItem mntmListaDeCheques;
    private JMenuItem mntmNuevaCuentaContable;
    private JMenuItem mntmCatalogoDeCuentas;
    private JMenuItem mntmVincularCuentasContables;
    private JMenuItem mntmNuevoBanco;
    private JMenuItem mntmListaDeBancos;
    private JMenu mnReportes;
    private JMenuItem mntmAuxiliarContable;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final Contabilidad frame = new Contabilidad();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public Contabilidad() {
        this.ajustes = new Ajustes();
        this.bandera_menuLateral = false;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                Contabilidad.this.lblNombreUsuarioLateral.setText(Variables.nombreUsuario);
                Contabilidad.this.lblCargoUsuarioLateral.setText(Variables.cargoUsuario);
                Contabilidad.this.lblNombreOficina.setText(Variables.nombreOficina);
                Contabilidad.this.lblFechaSistema.setText(Variables.fechaSistema);
                Contabilidad.this.lblUsuarioLateral.setText(Variables.usuario);
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, 0, this.ajustes.ancho, this.ajustes.alto);
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        (this.jp_menuLateral = new JPanel()).setBackground(Variables.color_uno);
        this.jp_menuLateral.setBounds(this.ajustes.calcularPuntoX(15.63) * -1, this.ajustes.calcularPuntoY(6.57), this.ajustes.calcularPuntoX(15.63), this.ajustes.alto - this.ajustes.calcularPuntoY(6.57));
        this.contentPane.add(this.jp_menuLateral);
        this.jp_menuLateral.setLayout(null);
        final JLabel lblLogo = new JLabel("");
        lblLogo.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.39), this.ajustes.calcularPuntoX(10.52), this.ajustes.calcularPuntoY(18.7));
        lblLogo.setIcon(this.ajustes.ajustarImagen("/general_07_icono_logo", lblLogo, 202, 202, 202, 202));
        this.jp_menuLateral.add(lblLogo);
        (this.lblNombreUsuarioLateral = new JLabel("Nombre de Usuario")).setForeground(Variables.color_dos);
        this.lblNombreUsuarioLateral.setHorizontalAlignment(0);
        this.lblNombreUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreUsuarioLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(21.76), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(1.85));
        this.jp_menuLateral.add(this.lblNombreUsuarioLateral);
        (this.lblCargoUsuarioLateral = new JLabel("Cargo de Usuario")).setForeground(Variables.color_dos);
        this.lblCargoUsuarioLateral.setHorizontalAlignment(0);
        this.lblCargoUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCargoUsuarioLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(25.46), this.ajustes.calcularPuntoX(14.32), this.ajustes.calcularPuntoY(2.31));
        this.jp_menuLateral.add(this.lblCargoUsuarioLateral);
        final JSeparator s1 = new JSeparator();
        s1.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(28.24), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(0.28));
        this.jp_menuLateral.add(s1);
        final JPanel jp_opcionesMenuLateral = new JPanel();
        jp_opcionesMenuLateral.setOpaque(false);
        jp_opcionesMenuLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(29.17), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(59.72));
        this.jp_menuLateral.add(jp_opcionesMenuLateral);
        jp_opcionesMenuLateral.setLayout(null);
        final JPanel jp_btnMenuPrincipal = new JPanel();
        jp_btnMenuPrincipal.setBackground(Variables.color_tres);
        jp_btnMenuPrincipal.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnMenuPrincipal.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnMenuPrincipal);
        jp_btnMenuPrincipal.setLayout(null);
        (this.btnMenuPricipal = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnMenuPricipal.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnMenuPricipal.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_dos);
            }
        });
        this.btnMenuPricipal.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Contabilidad.this.boton(4);
            }
        });
        jp_btnMenuPrincipal.add(this.btnMenuPricipal);
        final JLabel lblIconoBtn_menuPrincipal = new JLabel("");
        lblIconoBtn_menuPrincipal.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_menuPrincipal.setIcon(this.ajustes.ajustarImagen("/general_08_icono_menuprincipal", lblIconoBtn_menuPrincipal, 40, 35, 40, 35));
        jp_btnMenuPrincipal.add(lblIconoBtn_menuPrincipal);
        final JLabel lblNombreBtn_menuPrincipal = new JLabel("Menu Principal");
        lblNombreBtn_menuPrincipal.setForeground(Variables.color_uno);
        lblNombreBtn_menuPrincipal.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_menuPrincipal.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnMenuPrincipal.add(lblNombreBtn_menuPrincipal);
        final JPanel jp_btnConfiguracion = new JPanel();
        jp_btnConfiguracion.setLayout(null);
        jp_btnConfiguracion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnConfiguracion.setBackground(Variables.color_tres);
        jp_btnConfiguracion.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnConfiguracion);
        (this.btnConfiguracion = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnConfiguracion.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnConfiguracion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_dos);
            }
        });
        this.btnConfiguracion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Modulo en Mantenimiento", "ALERTA!", 2);
            }
        });
        jp_btnConfiguracion.add(this.btnConfiguracion);
        final JLabel lblIconoBtn_configuracion = new JLabel("");
        lblIconoBtn_configuracion.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_configuracion.setIcon(this.ajustes.ajustarImagen("/general_09_icono_configuracion", lblIconoBtn_configuracion, 40, 35, 40, 35));
        jp_btnConfiguracion.add(lblIconoBtn_configuracion);
        final JLabel lblNombreBtn_configuracion = new JLabel("Configuraci\u00f3n");
        lblNombreBtn_configuracion.setForeground(Variables.color_uno);
        lblNombreBtn_configuracion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_configuracion.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnConfiguracion.add(lblNombreBtn_configuracion);
        final JPanel jp_btnCerrarSesion = new JPanel();
        jp_btnCerrarSesion.setLayout(null);
        jp_btnCerrarSesion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnCerrarSesion.setBackground(Variables.color_tres);
        jp_btnCerrarSesion.setBounds(0, this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnCerrarSesion);
        (this.btnCerrarSesion = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnCerrarSesion.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnCerrarSesion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_dos);
            }
        });
        this.btnCerrarSesion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                Contabilidad.this.boton(3);
            }
        });
        jp_btnCerrarSesion.add(this.btnCerrarSesion);
        final JLabel lblIconoBtn_cerrarSesion = new JLabel("");
        lblIconoBtn_cerrarSesion.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_cerrarSesion.setIcon(this.ajustes.ajustarImagen("/general_10_icono_cerrarSesion", lblIconoBtn_cerrarSesion, 35, 35, 35, 35));
        jp_btnCerrarSesion.add(lblIconoBtn_cerrarSesion);
        final JLabel lblNombreBtn_cerrarSesion = new JLabel("Cerrar Sesi\u00f3n");
        lblNombreBtn_cerrarSesion.setForeground(Variables.color_uno);
        lblNombreBtn_cerrarSesion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_cerrarSesion.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnCerrarSesion.add(lblNombreBtn_cerrarSesion);
        final JSeparator s2 = new JSeparator();
        s2.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.alto - this.ajustes.calcularPuntoY(9.72), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(0.28));
        this.jp_menuLateral.add(s2);
        (this.lblUsuarioLateral = new JLabel("usuario")).setForeground(Variables.color_tres);
        this.lblUsuarioLateral.setHorizontalAlignment(0);
        this.lblUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblUsuarioLateral.setBounds(0, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8), this.ajustes.calcularPuntoX(15.63), this.ajustes.calcularPuntoY(1.85));
        this.jp_menuLateral.add(this.lblUsuarioLateral);
        final JPanel jp_info = new JPanel();
        jp_info.setBackground(Variables.color_uno);
        jp_info.setBorder(new BevelBorder(0, null, null, null, null));
        jp_info.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_info.setLayout(null);
        this.contentPane.add(jp_info);
        (this.btnMinimizar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnMinimizar.setBounds(this.ajustes.ancho - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.65), this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.btnMinimizar.setIcon(this.ajustes.ajustarImagen("/general_03_icono_minimizar", this.btnMinimizar, 20, 20, 20, 20));
        this.btnMinimizar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.cambioImage(Contabilidad.this.btnMinimizar, "/general_03_icono_minimizar_select", 20);
            }
        });
        this.btnMinimizar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.cambioImage(Contabilidad.this.btnMinimizar, "/general_03_icono_minimizar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Contabilidad.this.boton(1);
            }
        });
        jp_info.add(this.btnMinimizar);
        (this.btnCerrar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnCerrar.setBackground(Variables.color_uno);
        this.btnCerrar.setBounds(this.ajustes.ancho - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.btnCerrar.setIcon(this.ajustes.ajustarImagen("/general_04_icono_cerrar", this.btnCerrar, 20, 20, 20, 20));
        this.btnCerrar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.cambioImage(Contabilidad.this.btnCerrar, "/general_04_icono_cerrar_select", 20);
            }
        });
        this.btnCerrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.cambioImage(Contabilidad.this.btnCerrar, "/general_04_icono_cerrar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Contabilidad.this.boton(3);
            }
        });
        jp_info.add(this.btnCerrar);
        final JLabel lblNombreVentana = new JLabel("Contabilidad");
        lblNombreVentana.setForeground(Variables.color_dos);
        lblNombreVentana.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreVentana.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3, this.ajustes.calcularPuntoY(1.85));
        jp_info.add(lblNombreVentana);
        (this.lblNombreOficina = new JLabel("Nombre de Oficina")).setForeground(Variables.color_dos);
        this.lblNombreOficina.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreOficina.setBounds(this.ajustes.ancho / 3 + this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3, this.ajustes.calcularPuntoY(1.85));
        jp_info.add(this.lblNombreOficina);
        (this.lblFechaSistema = new JLabel("Fecha del Sistema")).setForeground(Variables.color_dos);
        this.lblFechaSistema.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaSistema.setBounds(this.ajustes.ancho / 3 + this.ajustes.ancho / 3 + this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3 - this.ajustes.calcularPuntoX(4.43), this.ajustes.calcularPuntoY(1.85));
        jp_info.add(this.lblFechaSistema);
        final JPanel jp_menu = new JPanel();
        jp_menu.setBackground(Variables.color_dos);
        jp_menu.setBorder(new LineBorder(Variables.color_dos));
        jp_menu.setBounds(0, this.ajustes.calcularPuntoY(2.78), this.ajustes.ancho, this.ajustes.calcularPuntoY(3.8));
        jp_menu.setLayout(null);
        this.contentPane.add(jp_menu);
        final JLabel btnMenuLateral = new JLabel("");
        btnMenuLateral.setCursor(Cursor.getPredefinedCursor(12));
        btnMenuLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.98), this.ajustes.calcularPuntoY(2.87));
        btnMenuLateral.setIcon(this.ajustes.ajustarImagen("/general_05_icono_menulateral", btnMenuLateral, 38, 31, 38, 31));
        btnMenuLateral.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.cambioImage(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
        });
        btnMenuLateral.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.cambioImage(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                Contabilidad.this.boton(2);
            }
        });
        final JPanel panel = new JPanel();
        panel.setBackground(Variables.color_dos);
        panel.setBounds(this.ajustes.calcularPuntoX(39.58), 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(3.8));
        jp_menu.add(panel);
        jp_menu.add(btnMenuLateral);
        (this.mnBar = new JMenuBar()).setBorder(null);
        this.mnBar.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
        this.mnBar.setBorderPainted(false);
        this.mnBar.setBounds(this.ajustes.calcularPuntoX(3.39), 0, this.ajustes.calcularPuntoX(36.46), this.ajustes.calcularPuntoY(3.8));
        jp_menu.add(this.mnBar);
        (this.mnPartidasContables = new JMenu("Partidas Contables")).setOpaque(true);
        this.mnPartidasContables.setHideActionText(true);
        this.mnPartidasContables.setBorder(null);
        this.mnPartidasContables.setIcon(this.ajustes.ajustarImagen_menu("/general_11_icono_partidaDiario", 25, 25, this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.31)));
        this.mnPartidasContables.setBackground(Variables.color_dos);
        this.mnPartidasContables.setCursor(Cursor.getPredefinedCursor(12));
        this.mnPartidasContables.setForeground(Variables.color_uno);
        this.mnPartidasContables.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnPartidasContables.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.mnPartidasContables.setBackground(Variables.color_dos);
            }
        });
        this.mnPartidasContables.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.mnPartidasContables.setBackground(Variables.color_tres);
            }
        });
        this.mnBar.add(this.mnPartidasContables);
        (this.mntmNuevaPartidaContable = new JMenuItem("Nueva Partida Contable")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final NuevaPartidaContable npc = new NuevaPartidaContable();
                npc.setVisible(true);
            }
        });
        this.mntmNuevaPartidaContable.setBorderPainted(true);
        this.mntmNuevaPartidaContable.setOpaque(true);
        this.mntmNuevaPartidaContable.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmNuevaPartidaContable.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        this.mntmNuevaPartidaContable.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmNuevaPartidaContable.setBackground(Variables.color_tres);
        this.mntmNuevaPartidaContable.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmNuevaPartidaContable.setForeground(Variables.color_uno);
        this.mntmNuevaPartidaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnPartidasContables.add(this.mntmNuevaPartidaContable);
        (this.mntmListaDePartidas = new JMenuItem("Lista de Partidas Contables")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaPartidaContable lpc = new ListaPartidaContable();
                lpc.setVisible(true);
            }
        });
        this.mntmListaDePartidas.setBorderPainted(true);
        this.mntmListaDePartidas.setOpaque(true);
        this.mntmListaDePartidas.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmListaDePartidas.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-17-icono-lista.png")));
        this.mntmListaDePartidas.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmListaDePartidas.setBackground(Variables.color_tres);
        this.mntmListaDePartidas.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmListaDePartidas.setForeground(Variables.color_uno);
        this.mntmListaDePartidas.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnPartidasContables.add(this.mntmListaDePartidas);
        (this.mnCheques = new JMenu("Cheques")).setIcon(this.ajustes.ajustarImagen_menu("/general_13_icono_cheques", 35, 26, this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(2.41)));
        this.mnCheques.setBorder(null);
        this.mnCheques.setBackground(Variables.color_dos);
        this.mnCheques.setOpaque(true);
        this.mnCheques.setCursor(Cursor.getPredefinedCursor(12));
        this.mnCheques.setForeground(Variables.color_uno);
        this.mnCheques.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnCheques.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.mnCheques.setBackground(Variables.color_dos);
            }
        });
        this.mnCheques.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.mnCheques.setBackground(Variables.color_tres);
            }
        });
        this.mnBar.add(this.mnCheques);
        (this.mntmNuevoCheque = new JMenuItem("Crear Cheque")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final NuevoCheque nch = new NuevoCheque();
                nch.setVisible(true);
            }
        });
        this.mntmNuevoCheque.setOpaque(true);
        this.mntmNuevoCheque.setBorderPainted(true);
        this.mntmNuevoCheque.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmNuevoCheque.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        this.mntmNuevoCheque.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmNuevoCheque.setBackground(Variables.color_tres);
        this.mntmNuevoCheque.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmNuevoCheque.setForeground(Variables.color_uno);
        this.mntmNuevoCheque.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnCheques.add(this.mntmNuevoCheque);
        (this.mntmListaDeCheques = new JMenuItem("Lista de Cheques")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaCheques lch = new ListaCheques();
                lch.setVisible(true);
            }
        });
        this.mntmListaDeCheques.setOpaque(true);
        this.mntmListaDeCheques.setBorderPainted(true);
        this.mntmListaDeCheques.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmListaDeCheques.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-17-icono-lista.png")));
        this.mntmListaDeCheques.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmListaDeCheques.setBackground(Variables.color_tres);
        this.mntmListaDeCheques.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmListaDeCheques.setForeground(Variables.color_uno);
        this.mntmListaDeCheques.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnCheques.add(this.mntmListaDeCheques);
        (this.mnCatalogoDeCuentas = new JMenu("Catalogo de Cuentas")).setIcon(this.ajustes.ajustarImagen_menu("/general_14_icono_catalogoCuentas", 20, 26, this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(2.41)));
        this.mnCatalogoDeCuentas.setForeground(Variables.color_uno);
        this.mnCatalogoDeCuentas.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnCatalogoDeCuentas.setCursor(Cursor.getPredefinedCursor(12));
        this.mnCatalogoDeCuentas.setBorder(null);
        this.mnCatalogoDeCuentas.setOpaque(true);
        this.mnCatalogoDeCuentas.setBackground(Variables.color_dos);
        this.mnCatalogoDeCuentas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.mnCatalogoDeCuentas.setBackground(Variables.color_dos);
            }
        });
        this.mnCatalogoDeCuentas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.mnCatalogoDeCuentas.setBackground(Variables.color_tres);
            }
        });
        this.mnBar.add(this.mnCatalogoDeCuentas);
        (this.mntmNuevaCuentaContable = new JMenuItem("Nueva Cuenta Contable")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final NuevaCuentaContable ncc = new NuevaCuentaContable();
                ncc.setVisible(true);
            }
        });
        this.mntmNuevaCuentaContable.setBorderPainted(true);
        this.mntmNuevaCuentaContable.setOpaque(true);
        this.mntmNuevaCuentaContable.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmNuevaCuentaContable.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        this.mntmNuevaCuentaContable.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmNuevaCuentaContable.setBackground(Variables.color_tres);
        this.mntmNuevaCuentaContable.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmNuevaCuentaContable.setForeground(Variables.color_uno);
        this.mntmNuevaCuentaContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnCatalogoDeCuentas.add(this.mntmNuevaCuentaContable);
        (this.mntmCatalogoDeCuentas = new JMenuItem("Catalogo de Cuentas")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaCuentaContable lcc = new ListaCuentaContable();
                lcc.setVisible(true);
            }
        });
        this.mntmCatalogoDeCuentas.setBorderPainted(true);
        this.mntmCatalogoDeCuentas.setOpaque(true);
        this.mntmCatalogoDeCuentas.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmCatalogoDeCuentas.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-17-icono-lista.png")));
        this.mntmCatalogoDeCuentas.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmCatalogoDeCuentas.setBackground(Variables.color_tres);
        this.mntmCatalogoDeCuentas.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmCatalogoDeCuentas.setForeground(Variables.color_uno);
        this.mntmCatalogoDeCuentas.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnCatalogoDeCuentas.add(this.mntmCatalogoDeCuentas);
        (this.mntmVincularCuentasContables = new JMenuItem("Vincular Cuentas Contables")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final VicularCuentasContables vcc= new VicularCuentasContables();
                vcc.setVisible(true);
            }
        });
        this.mntmVincularCuentasContables.setBorderPainted(true);
        this.mntmVincularCuentasContables.setOpaque(true);
        this.mntmVincularCuentasContables.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmVincularCuentasContables.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-18-icono-vincular.png")));
        this.mntmVincularCuentasContables.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmVincularCuentasContables.setBackground(Variables.color_tres);
        this.mntmVincularCuentasContables.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmVincularCuentasContables.setForeground(Variables.color_uno);
        this.mntmVincularCuentasContables.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnCatalogoDeCuentas.add(this.mntmVincularCuentasContables);
        (this.mnBancos = new JMenu("Bancos")).setOpaque(true);
        this.mnBancos.setForeground(Variables.color_uno);
        this.mnBancos.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnBancos.setCursor(Cursor.getPredefinedCursor(12));
        this.mnBancos.setBorder(null);
        this.mnBancos.setBackground(Variables.color_dos);
        this.mnBancos.setIcon(this.ajustes.ajustarImagen_menu("/general_15_icono_bancos", 26, 26, this.ajustes.calcularPuntoX(1.35), this.ajustes.calcularPuntoY(2.41)));
        this.mnBancos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.mnBancos.setBackground(Variables.color_dos);
            }
        });
        this.mnBancos.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.mnBancos.setBackground(Variables.color_tres);
            }
        });
        this.mnBar.add(this.mnBancos);
        (this.mntmNuevoBanco = new JMenuItem("Nuevo Banco")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final NuevoBanco nbk = new NuevoBanco();
                nbk.setVisible(true);
            }
        });
        this.mntmNuevoBanco.setOpaque(true);
        this.mntmNuevoBanco.setBorderPainted(true);
        this.mntmNuevoBanco.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmNuevoBanco.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        this.mntmNuevoBanco.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmNuevoBanco.setBackground(Variables.color_tres);
        this.mntmNuevoBanco.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmNuevoBanco.setForeground(Variables.color_uno);
        this.mntmNuevoBanco.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnBancos.add(this.mntmNuevoBanco);
        (this.mntmListaDeBancos = new JMenuItem("Lista de Bancos")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaBancos lbk = new ListaBancos();
                lbk.setVisible(true);
            }
        });
        this.mntmListaDeBancos.setOpaque(true);
        this.mntmListaDeBancos.setBorderPainted(true);
        this.mntmListaDeBancos.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        this.mntmListaDeBancos.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-17-icono-lista.png")));
        this.mntmListaDeBancos.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmListaDeBancos.setBackground(Variables.color_tres);
        this.mntmListaDeBancos.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmListaDeBancos.setForeground(Variables.color_uno);
        this.mntmListaDeBancos.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnBancos.add(this.mntmListaDeBancos);
        (this.mnReportes = new JMenu("Reportes")).setCursor(Cursor.getPredefinedCursor(12));
        this.mnReportes.setOpaque(true);
        this.mnReportes.setForeground(Variables.color_uno);
        this.mnReportes.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mnReportes.setBorder(null);
        this.mnReportes.setBackground(Variables.color_dos);
        this.mnReportes.setIcon(this.ajustes.ajustarImagen_menu("/general_31_icono_reporte", 26, 26, this.ajustes.calcularPuntoX(1.35), this.ajustes.calcularPuntoY(2.41)));
        this.mnReportes.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Contabilidad.this.mnReportes.setBackground(Variables.color_dos);
            }
        });
        this.mnReportes.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Contabilidad.this.mnReportes.setBackground(Variables.color_tres);
            }
        });
        this.mnBar.add(this.mnReportes);
        (this.mntmAuxiliarContable = new JMenuItem("Reportes Contables y Fiscales")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                ReportesContables rcf = new ReportesContables();
                rcf.setVisible(true);
            }
        });
        this.mnReportes.add(this.mntmAuxiliarContable);
        this.mntmAuxiliarContable.setIcon(new ImageIcon(Contabilidad.class.getResource("/varios_10_icono_reportes/varios_10_icono_reporte_contable.png")));
        this.mntmAuxiliarContable.setCursor(Cursor.getPredefinedCursor(12));
        this.mntmAuxiliarContable.setOpaque(true);
        this.mntmAuxiliarContable.setForeground(Variables.color_uno);
        this.mntmAuxiliarContable.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.mntmAuxiliarContable.setBounds(new Rectangle(0, 0, 0, 30));
        this.mntmAuxiliarContable.setBorderPainted(true);
        this.mntmAuxiliarContable.setBorder(new BevelBorder(0, null, null, null, null));
        this.mntmAuxiliarContable.setBackground(Variables.color_tres);
        final JPanel jp_contenedor = new JPanel();
        jp_contenedor.setOpaque(false);
        jp_contenedor.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        jp_contenedor.setLayout(null);
        this.contentPane.add(jp_contenedor);
        final JPanel jp_copyright = new JPanel();
        jp_copyright.setLayout(null);
        jp_copyright.setOpaque(false);
        jp_copyright.setBounds(this.ajustes.calcularPuntoX(47.66), this.ajustes.calcularPuntoY(98.15), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(1.3));
        this.contentPane.add(jp_copyright);
        final JLabel lblIconoCopyRight = new JLabel("");
        lblIconoCopyRight.setBounds(0, 0, this.ajustes.calcularPuntoX(0.73), this.ajustes.calcularPuntoY(1.3));
        lblIconoCopyRight.setIcon(this.ajustes.ajustarImagen("/general_00_icono_copyright_gris", lblIconoCopyRight, 14, 14, 14, 14));
        jp_copyright.add(lblIconoCopyRight);
        final JLabel lblNombreCopyRight = new JLabel(Variables.copyRight);
        lblNombreCopyRight.setForeground(Variables.color_uno);
        lblNombreCopyRight.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.3))));
        lblNombreCopyRight.setBounds(this.ajustes.calcularPuntoX(1.04), 0, this.ajustes.calcularPuntoX(3.65), this.ajustes.calcularPuntoY(1.3));
        jp_copyright.add(lblNombreCopyRight);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void cambioImage(final JLabel lblImg, final String cadenaImagen, final int tamImg) {
        lblImg.setIcon(this.ajustes.ajustarImagen(cadenaImagen, lblImg, tamImg, tamImg, tamImg, tamImg));
    }
    
    public void boton(final int op) {
        switch (op) {
            case 0: {
                System.exit(2);
                break;
            }
            case 1: {
                this.setExtendedState(1);
                break;
            }
            case 2: {
                if (!this.bandera_menuLateral) {
                    Animacion.mover_derecha(-300, 0, 5L, 5, this.jp_menuLateral);
                    this.bandera_menuLateral = true;
                    break;
                }
                Animacion.mover_izquierda(0, -300, 5L, 5, this.jp_menuLateral);
                this.bandera_menuLateral = false;
                break;
            }
            case 3: {
                if (JOptionPane.showConfirmDialog(this.rootPane, "¿Desea Cerrar Sesi\u00f3n?", "Cerrar Sesi\u00f3n", 0) == 0) {
                    final Login login = new Login();
                    login.setVisible(true);
                    this.dispose();
                    break;
                }
                break;
            }
            case 4: {
                final Principal pri = new Principal();
                pri.setVisible(true);
                this.dispose();
                break;
            }
        }
    }
    
    public void habilitarBtn(final boolean estado) {
        this.btnMenuPricipal.setEnabled(false);
    }
}
