// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.modulos;

import profac.com.login.Login;
import javax.swing.JComponent;
import Animacion.Animacion;
import profac.com.submodulo.compras.IngresoProducto;
import profac.com.submodulo.compras.ListaOrdenCompra;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import profac.com.submodulo.compras.NuevaOrdenCompra;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import java.awt.SystemColor;
import javax.swing.JOptionPane;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.Cursor;
import javax.swing.border.BevelBorder;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.WindowListener;
import profac.com.herramientas.Variables;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;

public class Compras extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    private JPanel contentPane;
    private JLabel btnMinimizar;
    private JLabel btnCerrar;
    public JLabel lblNombreOficina;
    public JLabel lblFechaSistema;
    private JPanel jp_menuLateral;
    public JLabel lblUsuarioLateral;
    public JLabel lblNombreUsuarioLateral;
    public JLabel lblCargoUsuarioLateral;
    public boolean bandera_menuLateral;
    private JLabel btnMenuPricipal;
    private JLabel btnConfiguracion;
    private JLabel btnCerrarSesion;
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final Compras frame = new Compras();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public Compras() {
        this.ajustes = new Ajustes();
        this.bandera_menuLateral = false;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                Compras.this.lblNombreUsuarioLateral.setText(Variables.nombreUsuario);
                Compras.this.lblCargoUsuarioLateral.setText(Variables.cargoUsuario);
                Compras.this.lblNombreOficina.setText(Variables.nombreOficina);
                Compras.this.lblFechaSistema.setText(Variables.fechaSistema);
                Compras.this.lblUsuarioLateral.setText(Variables.usuario);
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, 0, this.ajustes.ancho, this.ajustes.alto);
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        (this.jp_menuLateral = new JPanel()).setBackground(Variables.color_uno);
        this.jp_menuLateral.setBounds(this.ajustes.calcularPuntoX(15.63) * -1, this.ajustes.calcularPuntoY(6.57), this.ajustes.calcularPuntoX(15.63), this.ajustes.alto - this.ajustes.calcularPuntoY(6.57));
        this.contentPane.add(this.jp_menuLateral);
        this.jp_menuLateral.setLayout(null);
        final JLabel lblLogo = new JLabel("");
        lblLogo.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.39), this.ajustes.calcularPuntoX(10.52), this.ajustes.calcularPuntoY(18.7));
        lblLogo.setIcon(this.ajustes.ajustarImagen("/general_07_icono_logo", lblLogo, 202, 202, 202, 202));
        this.jp_menuLateral.add(lblLogo);
        (this.lblNombreUsuarioLateral = new JLabel("Nombre de Usuario")).setForeground(Variables.color_dos);
        this.lblNombreUsuarioLateral.setHorizontalAlignment(0);
        this.lblNombreUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreUsuarioLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(21.76), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(1.85));
        this.jp_menuLateral.add(this.lblNombreUsuarioLateral);
        (this.lblCargoUsuarioLateral = new JLabel("Cargo de Usuario")).setForeground(Variables.color_dos);
        this.lblCargoUsuarioLateral.setHorizontalAlignment(0);
        this.lblCargoUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblCargoUsuarioLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(25.46), this.ajustes.calcularPuntoX(14.32), this.ajustes.calcularPuntoY(2.31));
        this.jp_menuLateral.add(this.lblCargoUsuarioLateral);
        final JSeparator s1 = new JSeparator();
        s1.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(28.24), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(0.28));
        this.jp_menuLateral.add(s1);
        final JPanel jp_opcionesMenuLateral = new JPanel();
        jp_opcionesMenuLateral.setOpaque(false);
        jp_opcionesMenuLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(29.17), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(59.72));
        this.jp_menuLateral.add(jp_opcionesMenuLateral);
        jp_opcionesMenuLateral.setLayout(null);
        final JPanel jp_btnMenuPrincipal = new JPanel();
        jp_btnMenuPrincipal.setBackground(Variables.color_tres);
        jp_btnMenuPrincipal.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnMenuPrincipal.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnMenuPrincipal);
        jp_btnMenuPrincipal.setLayout(null);
        (this.btnMenuPricipal = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnMenuPricipal.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnMenuPricipal.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_dos);
            }
        });
        this.btnMenuPricipal.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Compras.this.boton(4);
            }
        });
        jp_btnMenuPrincipal.add(this.btnMenuPricipal);
        final JLabel lblIconoBtn_menuPrincipal = new JLabel("");
        lblIconoBtn_menuPrincipal.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_menuPrincipal.setIcon(this.ajustes.ajustarImagen("/general_08_icono_menuprincipal", lblIconoBtn_menuPrincipal, 40, 35, 40, 35));
        jp_btnMenuPrincipal.add(lblIconoBtn_menuPrincipal);
        final JLabel lblNombreBtn_menuPrincipal = new JLabel("Menu Principal");
        lblNombreBtn_menuPrincipal.setForeground(Variables.color_uno);
        lblNombreBtn_menuPrincipal.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_menuPrincipal.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnMenuPrincipal.add(lblNombreBtn_menuPrincipal);
        final JPanel jp_btnConfiguracion = new JPanel();
        jp_btnConfiguracion.setLayout(null);
        jp_btnConfiguracion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnConfiguracion.setBackground(Variables.color_tres);
        jp_btnConfiguracion.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnConfiguracion);
        (this.btnConfiguracion = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnConfiguracion.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnConfiguracion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_dos);
            }
        });
        this.btnConfiguracion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Modulo en Mantenimiento", "ALERTA!", 2);
            }
        });
        jp_btnConfiguracion.add(this.btnConfiguracion);
        final JLabel lblIconoBtn_configuracion = new JLabel("");
        lblIconoBtn_configuracion.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_configuracion.setIcon(this.ajustes.ajustarImagen("/general_09_icono_configuracion", lblIconoBtn_configuracion, 40, 35, 40, 35));
        jp_btnConfiguracion.add(lblIconoBtn_configuracion);
        final JLabel lblNombreBtn_configuracion = new JLabel("Configuraci\u00f3n");
        lblNombreBtn_configuracion.setForeground(SystemColor.controlHighlight);
        lblNombreBtn_configuracion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_configuracion.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnConfiguracion.add(lblNombreBtn_configuracion);
        final JPanel jp_btnCerrarSesion = new JPanel();
        jp_btnCerrarSesion.setLayout(null);
        jp_btnCerrarSesion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnCerrarSesion.setBackground(Variables.color_tres);
        jp_btnCerrarSesion.setBounds(0, this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnCerrarSesion);
        (this.btnCerrarSesion = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnCerrarSesion.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnCerrarSesion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_dos);
            }
        });
        this.btnCerrarSesion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                Compras.this.boton(3);
            }
        });
        jp_btnCerrarSesion.add(this.btnCerrarSesion);
        final JLabel lblIconoBtn_cerrarSesion = new JLabel("");
        lblIconoBtn_cerrarSesion.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_cerrarSesion.setIcon(this.ajustes.ajustarImagen("/general_10_icono_cerrarSesion", lblIconoBtn_cerrarSesion, 35, 35, 35, 35));
        jp_btnCerrarSesion.add(lblIconoBtn_cerrarSesion);
        final JLabel lblNombreBtn_cerrarSesion = new JLabel("Cerrar Sesi\u00f3n");
        lblNombreBtn_cerrarSesion.setForeground(SystemColor.controlHighlight);
        lblNombreBtn_cerrarSesion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_cerrarSesion.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnCerrarSesion.add(lblNombreBtn_cerrarSesion);
        final JSeparator s2 = new JSeparator();
        s2.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.alto - this.ajustes.calcularPuntoY(9.72), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(0.28));
        this.jp_menuLateral.add(s2);
        (this.lblUsuarioLateral = new JLabel("usuario")).setForeground(Variables.color_tres);
        this.lblUsuarioLateral.setHorizontalAlignment(0);
        this.lblUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblUsuarioLateral.setBounds(0, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8), this.ajustes.calcularPuntoX(15.63), this.ajustes.calcularPuntoY(1.85));
        this.jp_menuLateral.add(this.lblUsuarioLateral);
        final JPanel jp_info = new JPanel();
        jp_info.setBackground(Variables.color_uno);
        jp_info.setBorder(new BevelBorder(0, null, null, null, null));
        jp_info.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_info.setLayout(null);
        this.contentPane.add(jp_info);
        (this.btnMinimizar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnMinimizar.setBounds(this.ajustes.ancho - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.65), this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.btnMinimizar.setIcon(this.ajustes.ajustarImagen("/general_03_icono_minimizar", this.btnMinimizar, 20, 20, 20, 20));
        this.btnMinimizar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Compras.this.cambioImage_(Compras.this.btnMinimizar, "/general_03_icono_minimizar_select", 20);
            }
        });
        this.btnMinimizar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Compras.this.cambioImage_(Compras.this.btnMinimizar, "/general_03_icono_minimizar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Compras.this.boton(1);
            }
        });
        jp_info.add(this.btnMinimizar);
        (this.btnCerrar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnCerrar.setBackground(Variables.color_uno);
        this.btnCerrar.setBounds(this.ajustes.ancho - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.btnCerrar.setIcon(this.ajustes.ajustarImagen("/general_04_icono_cerrar", this.btnCerrar, 20, 20, 20, 20));
        this.btnCerrar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Compras.this.cambioImage_(Compras.this.btnCerrar, "/general_04_icono_cerrar_select", 20);
            }
        });
        this.btnCerrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Compras.this.cambioImage_(Compras.this.btnCerrar, "/general_04_icono_cerrar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Compras.this.boton(3);
            }
        });
        jp_info.add(this.btnCerrar);
        final JLabel lblNombreVentana = new JLabel("Compras");
        lblNombreVentana.setForeground(Variables.color_dos);
        lblNombreVentana.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreVentana.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3, this.ajustes.calcularPuntoY(1.85));
        jp_info.add(lblNombreVentana);
        (this.lblNombreOficina = new JLabel("Nombre de Oficina")).setForeground(Variables.color_dos);
        this.lblNombreOficina.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreOficina.setBounds(this.ajustes.ancho / 3 + this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3, this.ajustes.calcularPuntoY(1.85));
        jp_info.add(this.lblNombreOficina);
        (this.lblFechaSistema = new JLabel("Fecha del Sistema")).setForeground(Variables.color_dos);
        this.lblFechaSistema.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaSistema.setBounds(this.ajustes.ancho / 3 + this.ajustes.ancho / 3 + this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3 - this.ajustes.calcularPuntoX(4.43), this.ajustes.calcularPuntoY(1.85));
        jp_info.add(this.lblFechaSistema);
        final JPanel jp_menu = new JPanel();
        jp_menu.setBackground(Variables.color_dos);
        jp_menu.setBorder(new LineBorder(Variables.color_dos));
        jp_menu.setBounds(0, this.ajustes.calcularPuntoY(2.78), this.ajustes.ancho, this.ajustes.calcularPuntoY(3.8));
        jp_menu.setLayout(null);
        this.contentPane.add(jp_menu);
        final JLabel btnMenuLateral = new JLabel("");
        btnMenuLateral.setCursor(Cursor.getPredefinedCursor(12));
        btnMenuLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.98), this.ajustes.calcularPuntoY(2.87));
        btnMenuLateral.setIcon(this.ajustes.ajustarImagen("/general_05_icono_menulateral", btnMenuLateral, 38, 31, 38, 31));
        btnMenuLateral.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Compras.this.cambioImage_(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
        });
        btnMenuLateral.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Compras.this.cambioImage_(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                Compras.this.boton(2);
            }
        });
        jp_menu.add(btnMenuLateral);
        final JPanel panel = new JPanel();
        panel.setBounds(this.ajustes.calcularPuntoX(32.55), 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(3.8));
        jp_menu.add(panel);
        panel.setBackground(Variables.color_dos);
        jp_menu.add(btnMenuLateral);
        final JMenuBar mnBar = new JMenuBar();
        mnBar.setBorder(null);
        mnBar.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
        mnBar.setBorderPainted(false);
        mnBar.setBounds(this.ajustes.calcularPuntoX(3.39), 0, this.ajustes.calcularPuntoX(14.84), this.ajustes.calcularPuntoY(3.8));
        jp_menu.add(mnBar);
        final JMenu mnOrdenDeCompra = new JMenu("Orden de Compra");
        mnOrdenDeCompra.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                mnOrdenDeCompra.setBackground(Variables.color_dos);
            }
        });
        mnOrdenDeCompra.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                mnOrdenDeCompra.setBackground(Variables.color_tres);
            }
        });
        mnOrdenDeCompra.setOpaque(true);
        mnOrdenDeCompra.setHideActionText(true);
        mnOrdenDeCompra.setBorder(null);
        mnOrdenDeCompra.setIcon(this.ajustes.ajustarImagen_menu("/general_26_icono_ordenCompra", 25, 25, this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.31)));
        mnOrdenDeCompra.setBackground(Variables.color_dos);
        mnOrdenDeCompra.setCursor(Cursor.getPredefinedCursor(12));
        mnOrdenDeCompra.setForeground(Variables.color_uno);
        mnOrdenDeCompra.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBar.add(mnOrdenDeCompra);
        final JMenuItem mntmNuevaOrdenDe = new JMenuItem("Nueva Orden de Compra");
        mntmNuevaOrdenDe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final NuevaOrdenCompra noc = new NuevaOrdenCompra();
                noc.setVisible(true);
            }
        });
        mntmNuevaOrdenDe.setBorderPainted(true);
        mntmNuevaOrdenDe.setOpaque(true);
        mntmNuevaOrdenDe.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmNuevaOrdenDe.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        mntmNuevaOrdenDe.setBorder(new BevelBorder(0, null, null, null, null));
        mntmNuevaOrdenDe.setBackground(Variables.color_tres);
        mntmNuevaOrdenDe.setCursor(Cursor.getPredefinedCursor(12));
        mntmNuevaOrdenDe.setForeground(Variables.color_uno);
        mntmNuevaOrdenDe.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnOrdenDeCompra.add(mntmNuevaOrdenDe);
        final JMenuItem mntmListadoDeOrden = new JMenuItem("Listado de Orden de Compra");
        mntmListadoDeOrden.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaOrdenCompra lic = new ListaOrdenCompra();
                lic.setVisible(true);
            }
        });
        mntmListadoDeOrden.setBorderPainted(true);
        mntmListadoDeOrden.setOpaque(true);
        mntmListadoDeOrden.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmListadoDeOrden.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-17-icono-lista.png")));
        mntmListadoDeOrden.setBorder(new BevelBorder(0, null, null, null, null));
        mntmListadoDeOrden.setBackground(Variables.color_tres);
        mntmListadoDeOrden.setCursor(Cursor.getPredefinedCursor(12));
        mntmListadoDeOrden.setForeground(Variables.color_uno);
        mntmListadoDeOrden.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnOrdenDeCompra.add(mntmListadoDeOrden);
        final JMenu mnCompras = new JMenu("Compras");
        mnCompras.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                mnCompras.setBackground(Variables.color_dos);
            }
        });
        mnCompras.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                mnCompras.setBackground(Variables.color_tres);
            }
        });
        mnCompras.setOpaque(true);
        mnCompras.setHideActionText(true);
        mnCompras.setBorder(null);
        mnCompras.setIcon(this.ajustes.ajustarImagen_menu("/general_26_icono_ordenCompra", 25, 25, this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.31)));
        mnCompras.setBackground(Variables.color_dos);
        mnCompras.setCursor(Cursor.getPredefinedCursor(12));
        mnCompras.setForeground(Variables.color_uno);
        mnCompras.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBar.add(mnCompras);
        final JMenuItem mntmIngresarOrdenDe = new JMenuItem("Ingresar Orden de Compras");
        mntmIngresarOrdenDe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final IngresoProducto ipr = new IngresoProducto();
                ipr.setVisible(true);
            }
        });
        mntmIngresarOrdenDe.setBorderPainted(true);
        mntmIngresarOrdenDe.setOpaque(true);
        mntmIngresarOrdenDe.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmIngresarOrdenDe.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        mntmIngresarOrdenDe.setBorder(new BevelBorder(0, null, null, null, null));
        mntmIngresarOrdenDe.setBackground(Variables.color_tres);
        mntmIngresarOrdenDe.setCursor(Cursor.getPredefinedCursor(12));
        mntmIngresarOrdenDe.setForeground(Variables.color_uno);
        mntmIngresarOrdenDe.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnCompras.add(mntmIngresarOrdenDe);
        final JPanel jp_contenedor = new JPanel();
        jp_contenedor.setOpaque(false);
        jp_contenedor.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        jp_contenedor.setLayout(null);
        this.contentPane.add(jp_contenedor);
        final JPanel jp_copyright = new JPanel();
        jp_copyright.setLayout(null);
        jp_copyright.setOpaque(false);
        jp_copyright.setBounds(this.ajustes.calcularPuntoX(47.66), this.ajustes.calcularPuntoY(98.15), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(1.3));
        this.contentPane.add(jp_copyright);
        final JLabel lblIconoCopyRight = new JLabel("");
        lblIconoCopyRight.setBounds(0, 0, this.ajustes.calcularPuntoX(0.73), this.ajustes.calcularPuntoY(1.3));
        lblIconoCopyRight.setIcon(this.ajustes.ajustarImagen("/general_00_icono_copyright_gris", lblIconoCopyRight, 14, 14, 14, 14));
        jp_copyright.add(lblIconoCopyRight);
        final JLabel lblNombreCopyRight = new JLabel(Variables.copyRight);
        lblNombreCopyRight.setForeground(Variables.color_uno);
        lblNombreCopyRight.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.3))));
        lblNombreCopyRight.setBounds(this.ajustes.calcularPuntoX(1.04), 0, this.ajustes.calcularPuntoX(3.65), this.ajustes.calcularPuntoY(1.3));
        jp_copyright.add(lblNombreCopyRight);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void cambioImage_(final JLabel lblImg, final String cadenaImagen, final int tamImg) {
        lblImg.setIcon(this.ajustes.ajustarImagen(cadenaImagen, lblImg, tamImg, tamImg, tamImg, tamImg));
    }
    
    public void boton(final int op) {
        switch (op) {
            case 0: {
                System.exit(2);
                break;
            }
            case 1: {
                this.setExtendedState(1);
                break;
            }
            case 2: {
                if (!this.bandera_menuLateral) {
                    Animacion.mover_derecha(this.ajustes.calcularPuntoX(15.63) * -1, 0, 5L, 5, this.jp_menuLateral);
                    this.bandera_menuLateral = true;
                    break;
                }
                Animacion.mover_izquierda(0, this.ajustes.calcularPuntoX(15.63) * -1, 5L, 5, this.jp_menuLateral);
                this.bandera_menuLateral = false;
                break;
            }
            case 3: {
                if (JOptionPane.showConfirmDialog(this.rootPane, "¿Desea Cerrar Sesi\u00f3n?", "Cerrar Sesi\u00f3n", 0) == 0) {
                    final Login login = new Login();
                    login.setVisible(true);
                    this.dispose();
                    break;
                }
                break;
            }
            case 4: {
                final Principal pri = new Principal();
                pri.setVisible(true);
                this.dispose();
                break;
            }
        }
    }
}
