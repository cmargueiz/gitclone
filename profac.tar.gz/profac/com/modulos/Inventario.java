// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.modulos;

import profac.com.login.Login;
import javax.swing.JComponent;
import Animacion.Animacion;
import profac.com.submodulo.inventario.ListaProductos;
import profac.com.submodulo.inventario.NuevoProducto;
import profac.com.submodulo.inventario.ListaRubroSubRubro;
import profac.com.submodulo.inventario.NuevoRubroSubRubro;
import profac.com.submodulo.inventario.RealizarMovimientos;
import profac.com.submodulo.inventario.VerIngreso;
import profac.com.submodulo.inventario.KardexProducto;
import profac.com.submodulo.inventario.ListaBodegas;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import profac.com.submodulo.inventario.NuevaBodega;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.Cursor;
import javax.swing.border.BevelBorder;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.WindowListener;
import profac.com.herramientas.Variables;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.EventQueue;
import javax.swing.JLabel;
import javax.swing.JPanel;
import profac.com.herramientas.Ajustes;
import javax.swing.JFrame;
import javax.swing.AbstractAction;
import javax.swing.Action;

public class Inventario extends JFrame
{
    private static final long serialVersionUID = 1L;
    public Ajustes ajustes;
    private JPanel contentPane;
    private JLabel btnMinimizar;
    private JLabel btnCerrar;
    public JLabel lblNombreOficina;
    public JLabel lblFechaSistema;
    private JPanel jp_menuLateral;
    public JLabel lblUsuarioLateral;
    public JLabel lblNombreUsuarioLateral;
    public JLabel lblCargoUsuarioLateral;
    public boolean bandera_menuLateral;
    private JLabel btnMenuPricipal;
    private JLabel btnConfiguracion;
    private JLabel btnCerrarSesion;
    private final Action action = new SwingAction();
    
    public static void main(final String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    final Inventario frame = new Inventario();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public Inventario() {
        this.ajustes = new Ajustes();
        this.bandera_menuLateral = false;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(final WindowEvent arg0) {
                Inventario.this.lblNombreUsuarioLateral.setText(Variables.nombreUsuario);
                Inventario.this.lblCargoUsuarioLateral.setText(Variables.cargoUsuario);
                Inventario.this.lblNombreOficina.setText(Variables.nombreOficina);
                Inventario.this.lblFechaSistema.setText(Variables.fechaSistema);
                Inventario.this.lblUsuarioLateral.setText(Variables.usuario);
            }
        });
        this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setUndecorated(true);
        this.setBounds(0, 0, this.ajustes.ancho, this.ajustes.alto);
        (this.contentPane = new JPanel()).setBackground(Variables.color_tres);
        this.contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        (this.jp_menuLateral = new JPanel()).setBackground(Variables.color_uno);
        this.jp_menuLateral.setBounds(this.ajustes.calcularPuntoX(15.63) * -1, this.ajustes.calcularPuntoY(6.57), this.ajustes.calcularPuntoX(15.63), this.ajustes.alto - this.ajustes.calcularPuntoY(6.57));
        this.contentPane.add(this.jp_menuLateral);
        this.jp_menuLateral.setLayout(null);
        final JLabel lblLogo = new JLabel("");
        lblLogo.setBounds(this.ajustes.calcularPuntoX(2.6), this.ajustes.calcularPuntoY(1.39), this.ajustes.calcularPuntoX(10.52), this.ajustes.calcularPuntoY(18.7));
        lblLogo.setIcon(this.ajustes.ajustarImagen("/general_07_icono_logo", lblLogo, 202, 202, 202, 202));
        this.jp_menuLateral.add(lblLogo);
        (this.lblNombreUsuarioLateral = new JLabel("Nombre de Usuario")).setForeground(Variables.color_dos);
        this.lblNombreUsuarioLateral.setHorizontalAlignment(0);
        this.lblNombreUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreUsuarioLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(21.76), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(1.85));
        this.jp_menuLateral.add(this.lblNombreUsuarioLateral);
        (this.lblCargoUsuarioLateral = new JLabel("Cargo de Usuario")).setForeground(Variables.color_dos);
        this.lblCargoUsuarioLateral.setHorizontalAlignment(0);
        this.lblCargoUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(2.31))));
        this.lblCargoUsuarioLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(25.46), this.ajustes.calcularPuntoX(14.32), this.ajustes.calcularPuntoY(2.31));
        this.jp_menuLateral.add(this.lblCargoUsuarioLateral);
        final JSeparator s1 = new JSeparator();
        s1.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(28.24), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(0.28));
        this.jp_menuLateral.add(s1);
        final JPanel jp_opcionesMenuLateral = new JPanel();
        jp_opcionesMenuLateral.setOpaque(false);
        jp_opcionesMenuLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(29.17), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(59.72));
        this.jp_menuLateral.add(jp_opcionesMenuLateral);
        jp_opcionesMenuLateral.setLayout(null);
        final JPanel jp_btnMenuPrincipal = new JPanel();
        jp_btnMenuPrincipal.setBackground(Variables.color_tres);
        jp_btnMenuPrincipal.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnMenuPrincipal.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnMenuPrincipal);
        jp_btnMenuPrincipal.setLayout(null);
        (this.btnMenuPricipal = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnMenuPricipal.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnMenuPricipal.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_dos);
            }
        });
        this.btnMenuPricipal.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnMenuPrincipal.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Inventario.this.boton(4);
            }
        });
        jp_btnMenuPrincipal.add(this.btnMenuPricipal);
        final JLabel lblIconoBtn_menuPrincipal = new JLabel("");
        lblIconoBtn_menuPrincipal.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_menuPrincipal.setIcon(this.ajustes.ajustarImagen("/general_08_icono_menuprincipal", lblIconoBtn_menuPrincipal, 40, 35, 40, 35));
        jp_btnMenuPrincipal.add(lblIconoBtn_menuPrincipal);
        final JLabel lblNombreBtn_menuPrincipal = new JLabel("Menu Principal");
        lblNombreBtn_menuPrincipal.setForeground(Variables.color_uno);
        lblNombreBtn_menuPrincipal.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_menuPrincipal.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnMenuPrincipal.add(lblNombreBtn_menuPrincipal);
        final JPanel jp_btnConfiguracion = new JPanel();
        jp_btnConfiguracion.setLayout(null);
        jp_btnConfiguracion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnConfiguracion.setBackground(Variables.color_tres);
        jp_btnConfiguracion.setBounds(0, this.ajustes.calcularPuntoY(5.56), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnConfiguracion);
        (this.btnConfiguracion = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnConfiguracion.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnConfiguracion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_dos);
            }
        });
        this.btnConfiguracion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnConfiguracion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                JOptionPane.showMessageDialog(null, "Modulo en Mantenimiento", "ALERTA!", 2);
            }
        });
        jp_btnConfiguracion.add(this.btnConfiguracion);
        final JLabel lblIconoBtn_configuracion = new JLabel("");
        lblIconoBtn_configuracion.setBounds(this.ajustes.calcularPuntoX(0.26), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(2.08), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_configuracion.setIcon(this.ajustes.ajustarImagen("/general_09_icono_configuracion", lblIconoBtn_configuracion, 40, 35, 40, 35));
        jp_btnConfiguracion.add(lblIconoBtn_configuracion);
        final JLabel lblNombreBtn_configuracion = new JLabel("Configuraci\u00f3n");
        lblNombreBtn_configuracion.setForeground(Variables.color_uno);
        lblNombreBtn_configuracion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_configuracion.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnConfiguracion.add(lblNombreBtn_configuracion);
        final JPanel jp_btnCerrarSesion = new JPanel();
        jp_btnCerrarSesion.setLayout(null);
        jp_btnCerrarSesion.setBorder(new BevelBorder(0, null, null, null, null));
        jp_btnCerrarSesion.setBackground(Variables.color_tres);
        jp_btnCerrarSesion.setBounds(0, this.ajustes.calcularPuntoY(11.11), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        jp_opcionesMenuLateral.add(jp_btnCerrarSesion);
        (this.btnCerrarSesion = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnCerrarSesion.setBounds(0, 0, this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(4.17));
        this.btnCerrarSesion.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_dos);
            }
        });
        this.btnCerrarSesion.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                jp_btnCerrarSesion.setBackground(Variables.color_tres);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                Inventario.this.boton(3);
            }
        });
        jp_btnCerrarSesion.add(this.btnCerrarSesion);
        final JLabel lblIconoBtn_cerrarSesion = new JLabel("");
        lblIconoBtn_cerrarSesion.setBounds(this.ajustes.calcularPuntoX(0.52), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.82), this.ajustes.calcularPuntoY(3.24));
        lblIconoBtn_cerrarSesion.setIcon(this.ajustes.ajustarImagen("/general_10_icono_cerrarSesion", lblIconoBtn_cerrarSesion, 35, 35, 35, 35));
        jp_btnCerrarSesion.add(lblIconoBtn_cerrarSesion);
        final JLabel lblNombreBtn_cerrarSesion = new JLabel("Cerrar Sesi\u00f3n");
        lblNombreBtn_cerrarSesion.setForeground(Variables.color_uno);
        lblNombreBtn_cerrarSesion.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreBtn_cerrarSesion.setBounds(this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(10.94), this.ajustes.calcularPuntoY(3.24));
        jp_btnCerrarSesion.add(lblNombreBtn_cerrarSesion);
        final JSeparator s2 = new JSeparator();
        s2.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.alto - this.ajustes.calcularPuntoY(9.72), this.ajustes.calcularPuntoX(14.06), this.ajustes.calcularPuntoY(0.28));
        this.jp_menuLateral.add(s2);
        (this.lblUsuarioLateral = new JLabel("usuario")).setForeground(Variables.color_tres);
        this.lblUsuarioLateral.setHorizontalAlignment(0);
        this.lblUsuarioLateral.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblUsuarioLateral.setBounds(0, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8), this.ajustes.calcularPuntoX(15.63), this.ajustes.calcularPuntoY(1.85));
        this.jp_menuLateral.add(this.lblUsuarioLateral);
        final JPanel jp_info = new JPanel();
        jp_info.setBackground(Variables.color_uno);
        jp_info.setBorder(new BevelBorder(0, null, null, null, null));
        jp_info.setBounds(0, 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(2.78));
        jp_info.setLayout(null);
        this.contentPane.add(jp_info);
        (this.btnMinimizar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnMinimizar.setBounds(this.ajustes.ancho - this.ajustes.calcularPuntoX(3.13), this.ajustes.calcularPuntoY(0.65), this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.btnMinimizar.setIcon(this.ajustes.ajustarImagen("/general_03_icono_minimizar", this.btnMinimizar, 20, 20, 20, 20));
        this.btnMinimizar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Inventario.this.cambioImage(Inventario.this.btnMinimizar, "/general_03_icono_minimizar_select", 20);
            }
        });
        this.btnMinimizar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Inventario.this.cambioImage(Inventario.this.btnMinimizar, "/general_03_icono_minimizar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Inventario.this.boton(1);
            }
        });
        jp_info.add(this.btnMinimizar);
        (this.btnCerrar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        this.btnCerrar.setBackground(Variables.color_uno);
        this.btnCerrar.setBounds(this.ajustes.ancho - this.ajustes.calcularPuntoX(1.56), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.04), this.ajustes.calcularPuntoY(1.85));
        this.btnCerrar.setIcon(this.ajustes.ajustarImagen("/general_04_icono_cerrar", this.btnCerrar, 20, 20, 20, 20));
        this.btnCerrar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Inventario.this.cambioImage(Inventario.this.btnCerrar, "/general_04_icono_cerrar_select", 20);
            }
        });
        this.btnCerrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Inventario.this.cambioImage(Inventario.this.btnCerrar, "/general_04_icono_cerrar", 20);
            }
            
            @Override
            public void mouseClicked(final MouseEvent e) {
                Inventario.this.boton(3);
            }
        });
        jp_info.add(this.btnCerrar);
        final JLabel lblNombreVentana = new JLabel("Inventario");
        lblNombreVentana.setForeground(Variables.color_dos);
        lblNombreVentana.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        lblNombreVentana.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3, this.ajustes.calcularPuntoY(1.85));
        jp_info.add(lblNombreVentana);
        (this.lblNombreOficina = new JLabel("Nombre de Oficina")).setForeground(Variables.color_dos);
        this.lblNombreOficina.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblNombreOficina.setBounds(this.ajustes.ancho / 3 + this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3, this.ajustes.calcularPuntoY(1.85));
        jp_info.add(this.lblNombreOficina);
        (this.lblFechaSistema = new JLabel("Fecha del Sistema")).setForeground(Variables.color_dos);
        this.lblFechaSistema.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        this.lblFechaSistema.setBounds(this.ajustes.ancho / 3 + this.ajustes.ancho / 3 + this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.ancho / 3 - this.ajustes.calcularPuntoX(4.43), this.ajustes.calcularPuntoY(1.85));
        jp_info.add(this.lblFechaSistema);
        final JPanel jp_menu = new JPanel();
        jp_menu.setBackground(Variables.color_dos);
        jp_menu.setBorder(new LineBorder(Variables.color_dos));
        jp_menu.setBounds(0, this.ajustes.calcularPuntoY(2.78), this.ajustes.ancho, this.ajustes.calcularPuntoY(3.8));
        jp_menu.setLayout(null);
        this.contentPane.add(jp_menu);
        final JLabel btnMenuLateral = new JLabel("");
        btnMenuLateral.setCursor(Cursor.getPredefinedCursor(12));
        btnMenuLateral.setBounds(this.ajustes.calcularPuntoX(0.78), this.ajustes.calcularPuntoY(0.46), this.ajustes.calcularPuntoX(1.98), this.ajustes.calcularPuntoY(2.87));
        btnMenuLateral.setIcon(this.ajustes.ajustarImagen("/general_05_icono_menulateral", btnMenuLateral, 38, 31, 38, 31));
        btnMenuLateral.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                Inventario.this.cambioImage(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
        });
        btnMenuLateral.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                Inventario.this.cambioImage(btnMenuLateral, "/general_05_icono_menulateral", 38);
            }
            
            @Override
            public void mouseClicked(final MouseEvent arg0) {
                Inventario.this.boton(2);
            }
        });
        final JPanel panel = new JPanel();
        panel.setBounds(this.ajustes.calcularPuntoX(32.55), 0, this.ajustes.ancho, this.ajustes.calcularPuntoY(3.8));
        jp_menu.add(panel);
        panel.setBackground(Variables.color_dos);
        jp_menu.add(btnMenuLateral);
        final JMenuBar mnBar = new JMenuBar();
        mnBar.setBorder(null);
        mnBar.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
        mnBar.setBorderPainted(false);
        mnBar.setBounds(this.ajustes.calcularPuntoX(3.39), 0, this.ajustes.calcularPuntoX(29.17), this.ajustes.calcularPuntoY(3.8));
        jp_menu.add(mnBar);
        final JMenu mnBodegas = new JMenu("Bodegas");
        mnBodegas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                mnBodegas.setBackground(Variables.color_dos);
            }
        });
        mnBodegas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                mnBodegas.setBackground(Variables.color_tres);
            }
        });
        mnBodegas.setOpaque(true);
        mnBodegas.setHideActionText(true);
        mnBodegas.setBorder(null);
        mnBodegas.setIcon(this.ajustes.ajustarImagen_menu("/general_23_icono_bodegas", 25, 25, this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.31)));
        mnBodegas.setBackground(Variables.color_dos);
        mnBodegas.setCursor(Cursor.getPredefinedCursor(12));
        mnBodegas.setForeground(Variables.color_uno);
        mnBodegas.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBar.add(mnBodegas);
        final JMenuItem mntmAgregarNuevaBodega = new JMenuItem("Agregar Nueva Bodega");
        mntmAgregarNuevaBodega.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final NuevaBodega nbo = new NuevaBodega();
                Variables.ventana_nuevaBodega = true;
                Variables.ventana_editarBodega = false;
                nbo.setVisible(true);
            }
        });
        mntmAgregarNuevaBodega.setBorderPainted(true);
        mntmAgregarNuevaBodega.setOpaque(true);
        mntmAgregarNuevaBodega.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmAgregarNuevaBodega.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        mntmAgregarNuevaBodega.setBorder(new BevelBorder(0, null, null, null, null));
        mntmAgregarNuevaBodega.setBackground(Variables.color_tres);
        mntmAgregarNuevaBodega.setCursor(Cursor.getPredefinedCursor(12));
        mntmAgregarNuevaBodega.setForeground(Variables.color_uno);
        mntmAgregarNuevaBodega.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBodegas.add(mntmAgregarNuevaBodega);
        final JMenuItem mntmListaDeBodegas = new JMenuItem("Lista de Bodegas");
        mntmListaDeBodegas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaBodegas lbo = new ListaBodegas();
                Variables.ventana_nuevaBodega = false;
                lbo.setVisible(Variables.ventana_editarBodega = true);
            }
        });
        mntmListaDeBodegas.setBorderPainted(true);
        mntmListaDeBodegas.setOpaque(true);
        mntmListaDeBodegas.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmListaDeBodegas.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-17-icono-lista.png")));
        mntmListaDeBodegas.setBorder(new BevelBorder(0, null, null, null, null));
        mntmListaDeBodegas.setBackground(Variables.color_tres);
        mntmListaDeBodegas.setCursor(Cursor.getPredefinedCursor(12));
        mntmListaDeBodegas.setForeground(Variables.color_uno);
        mntmListaDeBodegas.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBodegas.add(mntmListaDeBodegas);
        final JMenu mnRubrosSubrubros = new JMenu("Rubros y Sub-Rubros");
        mnRubrosSubrubros.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                mnRubrosSubrubros.setBackground(Variables.color_dos);
            }
        });
        mnRubrosSubrubros.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                mnRubrosSubrubros.setBackground(Variables.color_tres);
            }
        });
        mnRubrosSubrubros.setOpaque(true);
        mnRubrosSubrubros.setHideActionText(true);
        mnRubrosSubrubros.setBorder(null);
        mnRubrosSubrubros.setIcon(this.ajustes.ajustarImagen_menu("/general_11_icono_partidaDiario", 25, 25, this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.31)));
        mnRubrosSubrubros.setBackground(Variables.color_dos);
        mnRubrosSubrubros.setCursor(Cursor.getPredefinedCursor(12));
        mnRubrosSubrubros.setForeground(Variables.color_uno);
        mnRubrosSubrubros.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBar.add(mnRubrosSubrubros);
        final JMenuItem mntmAgregarRubroSubrubro = new JMenuItem("Agregar Rubro o Sub-Rubro");
        mntmAgregarRubroSubrubro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final NuevoRubroSubRubro nrs = new NuevoRubroSubRubro();
                Variables.ventana_NuevoRubroSubrubro = true;
                Variables.ventana_EditarRubroSubrubro = false;
                nrs.setVisible(true);
            }
        });
        mntmAgregarRubroSubrubro.setBorderPainted(true);
        mntmAgregarRubroSubrubro.setOpaque(true);
        mntmAgregarRubroSubrubro.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmAgregarRubroSubrubro.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        mntmAgregarRubroSubrubro.setBorder(new BevelBorder(0, null, null, null, null));
        mntmAgregarRubroSubrubro.setBackground(Variables.color_tres);
        mntmAgregarRubroSubrubro.setCursor(Cursor.getPredefinedCursor(12));
        mntmAgregarRubroSubrubro.setForeground(Variables.color_uno);
        mntmAgregarRubroSubrubro.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnRubrosSubrubros.add(mntmAgregarRubroSubrubro);
        final JMenuItem mntmListaRubroSubrubro = new JMenuItem("Lista de Rubro y Sub-Rubro");
        mntmListaRubroSubrubro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaRubroSubRubro lrs = new ListaRubroSubRubro();
                Variables.ventana_NuevoRubroSubrubro = false;
                Variables.ventana_EditarRubroSubrubro = false;
                lrs.setVisible(true);
            }
        });
        mntmListaRubroSubrubro.setBorderPainted(true);
        mntmListaRubroSubrubro.setOpaque(true);
        mntmListaRubroSubrubro.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmListaRubroSubrubro.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-17-icono-lista.png")));
        mntmListaRubroSubrubro.setBorder(new BevelBorder(0, null, null, null, null));
        mntmListaRubroSubrubro.setBackground(Variables.color_tres);
        mntmListaRubroSubrubro.setCursor(Cursor.getPredefinedCursor(12));
        mntmListaRubroSubrubro.setForeground(Variables.color_uno);
        mntmListaRubroSubrubro.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnRubrosSubrubros.add(mntmListaRubroSubrubro);
        final JMenu mnProductos = new JMenu("Productos");
        mnProductos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                mnProductos.setBackground(Variables.color_dos);
            }
        });
        mnProductos.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                mnProductos.setBackground(Variables.color_tres);
            }
        });
        mnProductos.setOpaque(true);
        mnProductos.setHideActionText(true);
        mnProductos.setBorder(null);
        mnProductos.setIcon(this.ajustes.ajustarImagen_menu("/general_24_icono_productos", 25, 25, this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.31)));
        mnProductos.setBackground(Variables.color_dos);
        mnProductos.setCursor(Cursor.getPredefinedCursor(12));
        mnProductos.setForeground(Variables.color_uno);
        mnProductos.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBar.add(mnProductos);
        final JMenuItem mntmAgregarNuevoProducto = new JMenuItem("Agregar Nuevo Producto");
        mntmAgregarNuevoProducto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final NuevoProducto npr = new NuevoProducto();
                Variables.ventana_nuevoProducto = true;
                Variables.ventana_editarProducto = false;
                npr.setVisible(true);
            }
        });
        mntmAgregarNuevoProducto.setBorderPainted(true);
        mntmAgregarNuevoProducto.setOpaque(true);
        mntmAgregarNuevoProducto.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmAgregarNuevoProducto.setIcon(new ImageIcon(Contabilidad.class.getResource("/images/general-12-icono-add.png")));
        mntmAgregarNuevoProducto.setBorder(new BevelBorder(0, null, null, null, null));
        mntmAgregarNuevoProducto.setBackground(Variables.color_tres);
        mntmAgregarNuevoProducto.setCursor(Cursor.getPredefinedCursor(12));
        mntmAgregarNuevoProducto.setForeground(Variables.color_uno);
        mntmAgregarNuevoProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnProductos.add(mntmAgregarNuevoProducto);
        final JMenuItem mntmListaProductos = new JMenuItem("Lista de Productos");
        mntmListaProductos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent arg0) {
                final ListaProductos lpr = new ListaProductos();
                Variables.ventana_nuevoProducto = true;
                Variables.ventana_editarProducto = false;
                lpr.setVisible(true);
            }
        });
        mntmListaProductos.setBorderPainted(true);
        mntmListaProductos.setOpaque(true);
        mntmListaProductos.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmListaProductos.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-17-icono-lista.png")));
        mntmListaProductos.setBorder(new BevelBorder(0, null, null, null, null));
        mntmListaProductos.setBackground(Variables.color_tres);
        mntmListaProductos.setCursor(Cursor.getPredefinedCursor(12));
        mntmListaProductos.setForeground(Variables.color_uno);
        mntmListaProductos.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnProductos.add(mntmListaProductos);
        final JMenu mnMovimientos = new JMenu("Movimientos");
        mnMovimientos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(final MouseEvent arg0) {
                mnMovimientos.setBackground(Variables.color_dos);
            }
        });
        mnMovimientos.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(final MouseEvent arg0) {
                mnMovimientos.setBackground(Variables.color_tres);
            }
        });
        mnMovimientos.setOpaque(true);
        mnMovimientos.setHideActionText(true);
        mnMovimientos.setBorder(null);
        mnMovimientos.setIcon(this.ajustes.ajustarImagen_menu("/general_25_icono_movimientos", 25, 25, this.ajustes.calcularPuntoX(1.3), this.ajustes.calcularPuntoY(2.31)));
        mnMovimientos.setBackground(Variables.color_dos);
        mnMovimientos.setCursor(Cursor.getPredefinedCursor(12));
        mnMovimientos.setForeground(Variables.color_uno);
        mnMovimientos.setFont(new Font(Variables.fuenteLetra, 1, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnBar.add(mnMovimientos);
        final JMenuItem mntmVerIngresos = new JMenuItem("Ver Ingresos");
        mntmVerIngresos.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		VerIngreso ingreso = new VerIngreso();
        		ingreso.setVisible(true);
        	}
        });
        mntmVerIngresos.setBorderPainted(true);
        mntmVerIngresos.setOpaque(true);
        mntmVerIngresos.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmVerIngresos.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-27-icono-ingresoProducto.png")));
        mntmVerIngresos.setBorder(new BevelBorder(0, null, null, null, null));
        mntmVerIngresos.setBackground(Variables.color_tres);
        mntmVerIngresos.setCursor(Cursor.getPredefinedCursor(12));
        mntmVerIngresos.setForeground(Variables.color_uno);
        mntmVerIngresos.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnMovimientos.add(mntmVerIngresos);
        final JMenuItem mntmKardexDeProducto = new JMenuItem("Kardex de Producto");
        mntmKardexDeProducto.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		KardexProducto ingreso = new KardexProducto();
        		ingreso.setVisible(true);
        	}
        });
        mntmKardexDeProducto.setBorderPainted(true);
        mntmKardexDeProducto.setOpaque(true);
        mntmKardexDeProducto.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmKardexDeProducto.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-26-icono-kardexProducto.png")));
        mntmKardexDeProducto.setBorder(new BevelBorder(0, null, null, null, null));
        mntmKardexDeProducto.setBackground(Variables.color_tres);
        mntmKardexDeProducto.setCursor(Cursor.getPredefinedCursor(12));
        mntmKardexDeProducto.setForeground(Variables.color_uno);
        mntmKardexDeProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnMovimientos.add(mntmKardexDeProducto);
        
        final JMenuItem mntmRealizarMovimientoProducto = new JMenuItem("Realizar Movimiento de Producto");
        mntmRealizarMovimientoProducto.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		RealizarMovimientos ingreso = new RealizarMovimientos();
        		ingreso.setVisible(true);
        	}
        });
        
        
        mntmRealizarMovimientoProducto.setBorderPainted(true);
        mntmRealizarMovimientoProducto.setOpaque(true);
        mntmRealizarMovimientoProducto.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmRealizarMovimientoProducto.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-28-icono-movimientoProducto.png")));
        mntmRealizarMovimientoProducto.setBorder(new BevelBorder(0, null, null, null, null));
        mntmRealizarMovimientoProducto.setBackground(Variables.color_tres);
        mntmRealizarMovimientoProducto.setCursor(Cursor.getPredefinedCursor(12));
        mntmRealizarMovimientoProducto.setForeground(Variables.color_uno);
        mntmRealizarMovimientoProducto.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnMovimientos.add(mntmRealizarMovimientoProducto);
        final JMenuItem mntmTomaDeInventario = new JMenuItem("Toma de Inventario");
        mntmTomaDeInventario.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        	}
        });
        mntmTomaDeInventario.setBorderPainted(true);
        mntmTomaDeInventario.setOpaque(true);
        mntmTomaDeInventario.setBounds(new Rectangle(0, 0, 0, this.ajustes.calcularPuntoY(2.78)));
        mntmTomaDeInventario.setIcon(new ImageIcon(Inventario.class.getResource("/images/general-29-icono-tomaInventario.png")));
        mntmTomaDeInventario.setBorder(new BevelBorder(0, null, null, null, null));
        mntmTomaDeInventario.setBackground(Variables.color_tres);
        mntmTomaDeInventario.setCursor(Cursor.getPredefinedCursor(12));
        mntmTomaDeInventario.setForeground(Variables.color_uno);
        mntmTomaDeInventario.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.85))));
        mnMovimientos.add(mntmTomaDeInventario);
        final JPanel jp_contenedor = new JPanel();
        jp_contenedor.setOpaque(false);
        jp_contenedor.setBounds(0, this.ajustes.calcularPuntoY(6.57), this.ajustes.ancho, this.ajustes.alto - this.ajustes.calcularPuntoY(8.8));
        jp_contenedor.setLayout(null);
        this.contentPane.add(jp_contenedor);
        final JPanel jp_copyright = new JPanel();
        jp_copyright.setLayout(null);
        jp_copyright.setOpaque(false);
        jp_copyright.setBounds(this.ajustes.calcularPuntoX(47.66), this.ajustes.calcularPuntoY(98.15), this.ajustes.calcularPuntoX(4.69), this.ajustes.calcularPuntoY(1.3));
        this.contentPane.add(jp_copyright);
        final JLabel lblIconoCopyRight = new JLabel("");
        lblIconoCopyRight.setBounds(0, 0, this.ajustes.calcularPuntoX(0.73), this.ajustes.calcularPuntoY(1.3));
        lblIconoCopyRight.setIcon(this.ajustes.ajustarImagen("/general_00_icono_copyright_gris", lblIconoCopyRight, 14, 14, 14, 14));
        jp_copyright.add(lblIconoCopyRight);
        final JLabel lblNombreCopyRight = new JLabel(Variables.copyRight);
        lblNombreCopyRight.setForeground(Variables.color_uno);
        lblNombreCopyRight.setFont(new Font(Variables.fuenteLetra, 0, this.ajustes.ajustarTexto(1, this.ajustes.calcularPuntoY(1.3))));
        lblNombreCopyRight.setBounds(this.ajustes.calcularPuntoX(1.04), 0, this.ajustes.calcularPuntoX(3.65), this.ajustes.calcularPuntoY(1.3));
        jp_copyright.add(lblNombreCopyRight);
    }
    
    @Override
    public void dispose() {
        this.getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void cambioImage(final JLabel lblImg, final String cadenaImagen, final int tamImg) {
        lblImg.setIcon(this.ajustes.ajustarImagen(cadenaImagen, lblImg, tamImg, tamImg, tamImg, tamImg));
    }
    
    public void boton(final int op) {
        switch (op) {
            case 0: {
                System.exit(2);
                break;
            }
            case 1: {
                this.setExtendedState(1);
                break;
            }
            case 2: {
                if (!this.bandera_menuLateral) {
                    Animacion.mover_derecha(this.ajustes.calcularPuntoX(15.63) * -1, 0, 5L, 5, this.jp_menuLateral);
                    this.bandera_menuLateral = true;
                    break;
                }
                Animacion.mover_izquierda(0, this.ajustes.calcularPuntoX(15.63) * -1, 5L, 5, this.jp_menuLateral);
                this.bandera_menuLateral = false;
                break;
            }
            case 3: {
                if (JOptionPane.showConfirmDialog(this.rootPane, "¿Desea Cerrar Sesi\u00f3n?", "Cerrar Sesi\u00f3n", 0) == 0) {
                    final Login login = new Login();
                    login.setVisible(true);
                    this.dispose();
                    break;
                }
                break;
            }
            case 4: {
                final Principal pri = new Principal();
                pri.setVisible(true);
                this.dispose();
                break;
            }
        }
    }
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
