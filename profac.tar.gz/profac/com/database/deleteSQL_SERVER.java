// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.database;

import profac.com.herramientas.Variables;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class deleteSQL_SERVER
{
    public String error;
    
    public deleteSQL_SERVER() {
        this.error = "";
    }
    
    public int deleteLecturasMes(final String anio, final String mes) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("delete from lecturasMedidor where anio = ? and mes = ?");
            sql.setString(1, anio);
            sql.setString(2, mes);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int deleteDistribucionContable(final String descripcion) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("delete from distribucionContableServicios where descripcion = ?");
            sql.setString(1, descripcion);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int deleteMovimientoContable(final int numeroPartida) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("delete from movimientosContables where partidaContable_idpartidaContable = ?");
            sql.setInt(1, numeroPartida);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int deletePartidaContable(final int numeroPartida) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("delete from partidaContable where idpartidaContable = ?");
            sql.setInt(1, numeroPartida);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int deleteCuentaContable(final String id, final String idOficina) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("delete from cuentaContable where id = ? and oficina_idoficina = ?");
            sql.setString(1, id);
            sql.setString(2, idOficina);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int deleteOrdenCompra(final int id) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("delete from ordenCompra where idordenCompra = ?");
            sql.setInt(1, id);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int deleteOrdenCompra_detalle(final int id) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("delete from detalleOrdenCompra where ordenCompra_idordenCompra = ?");
            sql.setInt(1, id);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
}
