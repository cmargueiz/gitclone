// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.database;

import profac.com.herramientas.Variables;
import java.sql.PreparedStatement;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.DefaultComboBoxModel;
import java.sql.Connection;

public class consultasSQL_SERVER extends conexionSQL_SERVER {
	public conexionSQL_SERVER conexionSql;
	public Connection cn;
	public String error;
	public String primerNombre_modificarUsuario;
	public String segundoNombre_modificarUsuario;
	public String primerApellido_modificarUsuario;
	public String segundoApellido_modificarUsuario;
	public String direccion_modificarUsuario;
	public String fechaNacimiento_modificarUsuario;
	public String telefono_modificarUsuario;
	public String grupo_modificarUsuario;
	public String oficina_modificarUsuario;
	public String puesto_modificarUsuario;
	public String usuario_modificarUsuario;
	public int estado_modificarUsuario;
	public String cuentaContableBanco;
	public String nombreCuentaContableBanco;
	public int idBanco;
	public int correlativoBanco;
	public String descripcionPartidaCreada;
	public String ciudad;
	public String dia;
	public String mes;
	public String anio;
	public String partida;
	public String descripcion;
	public double monto;
	public String nombreBanco;
	public String tipoCuenta;
	public String cuentaBancaria;
	public String cuentaContable;
	public String direccion_bodega;
	public String ciudad_bodega;
	public String telefono_bodega;
	public String idCategoria;
	public String idCategoriaPadre;
	public String nombreCategoriaPadre;
	public String nombreCategoria;
	public String descripcionCategoria;
	public String nombreCliente;
	public String oficina;
	public String fechaNacimiento;
	public String sexo;
	public String dui;
	public String nit;
	public String fechaVenDui;
	public String estadoCivil;
	public String direccion;
	public String caserio;
	public String municipio;
	public String departamento;
	public String telefonoFijo;
	public String telefonoCelular;
	public String nombreRef1;
	public String telefonoRef1;
	public String nombreRef2;
	public String telefonoRef2;
	public String nombreFam1;
	public String telefonoFam1;
	public String nombreFam2;
	public String telefonoFam2;
	public byte[] imgFDui;
	public byte[] imgTDui;
	public byte[] imgFNit;
	public byte[] imgTNit;
	public byte[] imgRiesgo;
	public String estadoServicio;
	public String fechaRegServicio;
	public String fechaModServicio;
	public String fechaVenServicio;
	public String califServicio;
	public String tipoServicio;
	public String lineaServicio;
	public Double montoSolServicio;
	public Double montoSugServicio;
	public Double montoAprServicio;
	public Double saldoActualServicio;
	public Double saldoAnteriorServicio;
	public int diaAtrServicio;
	public int periodoServicio;
	public int plazoServicio;
	public int cuotasServicio;

	public consultasSQL_SERVER() {
		this.conexionSql = new conexionSQL_SERVER();
		this.cn = conexionSQL_SERVER.getConnection();
		this.error = "";
		this.primerNombre_modificarUsuario = "";
		this.segundoNombre_modificarUsuario = "";
		this.primerApellido_modificarUsuario = "";
		this.segundoApellido_modificarUsuario = "";
		this.direccion_modificarUsuario = "";
		this.fechaNacimiento_modificarUsuario = "";
		this.telefono_modificarUsuario = "";
		this.grupo_modificarUsuario = "";
		this.oficina_modificarUsuario = "";
		this.puesto_modificarUsuario = "";
		this.usuario_modificarUsuario = "";
		this.estado_modificarUsuario = 0;
		this.cuentaContableBanco = "";
		this.nombreCuentaContableBanco = "";
		this.idBanco = 0;
		this.correlativoBanco = 0;
		this.descripcionPartidaCreada = "";
		this.ciudad = "";
		this.dia = "";
		this.mes = "";
		this.anio = "";
		this.partida = "";
		this.descripcion = "";
		this.monto = 0.0;
		this.nombreBanco = "";
		this.tipoCuenta = "";
		this.cuentaBancaria = "";
		this.cuentaContable = "";
		this.direccion_bodega = "";
		this.ciudad_bodega = "";
		this.telefono_bodega = "";
		this.idCategoria = "";
		this.idCategoriaPadre = "";
		this.nombreCategoriaPadre = "";
		this.nombreCategoria = "";
		this.descripcionCategoria = "";
		this.nombreCliente = "";
		this.oficina = "";
		this.fechaNacimiento = "";
		this.sexo = "";
		this.dui = "";
		this.nit = "";
		this.fechaVenDui = "";
		this.estadoCivil = "";
		this.direccion = "";
		this.caserio = "";
		this.municipio = "";
		this.departamento = "";
		this.telefonoFijo = "";
		this.telefonoCelular = "";
		this.nombreRef1 = "";
		this.telefonoRef1 = "";
		this.nombreRef2 = "";
		this.telefonoRef2 = "";
		this.nombreFam1 = "";
		this.telefonoFam1 = "";
		this.nombreFam2 = "";
		this.telefonoFam2 = "";
		this.imgFDui = null;
		this.imgTDui = null;
		this.imgFNit = null;
		this.imgTNit = null;
		this.imgRiesgo = null;
		this.estadoServicio = "";
		this.fechaRegServicio = "";
		this.fechaModServicio = "";
		this.fechaVenServicio = "";
		this.califServicio = "";
		this.tipoServicio = "";
		this.lineaServicio = "";
		this.montoSolServicio = 0.0;
		this.montoSugServicio = 0.0;
		this.montoAprServicio = 0.0;
		this.saldoActualServicio = 0.0;
		this.saldoAnteriorServicio = 0.0;
		this.diaAtrServicio = 0;
		this.periodoServicio = 0;
		this.plazoServicio = 0;
		this.cuotasServicio = 0;
	}

	public DefaultComboBoxModel<Object> getDataComboBox(final String sql) {
		final DefaultComboBoxModel<Object> modelo = new DefaultComboBoxModel<Object>();
		try {
			conexionSQL_SERVER.verificarConexionSql();
			final Statement st = this.cn.createStatement();
			final ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				modelo.addElement(rs.getString(1));
			}
			rs.close();
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaCuentasContables(final String nombreCuenta, final String idOficina,
			final int op) {
		final String consulta = "select cc.cuentaContable,cc.descripcion, pc.montoEjecutado, pc.montoPresupuesto,\r\ndisponible=(ISNULL(pc.montoPresupuesto-pc.montoEjecutado,0.00)),CONVERT(varchar, cc.fechaMod, 103) as fechaMod, \r\nCONCAT(us.segundoNombre,' ',us.primerApellido) as usuario\r\nfrom cuentaContable cc\r\ninner join usuario us on cc.usuario_idusuario=us.idusuario\r\ninner join presupuestoContable pc on cc.id=pc.cuentaContable_id\r\nwhere cc.descripcion like ? and cc.oficina_idoficina = ?\r\norder by cuentaContable asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreCuenta);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			switch (op) {
			case 0: {
				modelo.addColumn("Cuenta");
				modelo.addColumn("Descripci\u00f3n");
				modelo.addColumn("Ejecutado ($)");
				modelo.addColumn("Presupuesto ($)");
				modelo.addColumn("Disponible ($)");
				modelo.addColumn("Fecha Modificaci\u00f3n");
				modelo.addColumn("Nombre de Usuario");
				while (rs.next()) {
					final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
							rs.getString(5), rs.getString(6), rs.getString(7) };
					modelo.addRow(data);
				}
				break;
			}
			case 1: {
				modelo.addColumn("Cuenta");
				modelo.addColumn("Descripci\u00f3n");
				modelo.addColumn("Presupuesto ($)");
				while (rs.next()) {
					final String[] data = { rs.getString(1), rs.getString(2), rs.getString(4) };
					modelo.addRow(data);
				}
				break;
			}
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaCuentasContables_nombre(final String nombreCuenta, final String idOficina) {
		final String consulta = "select cuentaContable,descripcion \r\nfrom cuentaContable \r\nwhere descripcion like ? and oficina_idoficina = ?\r\norder by cuentaContable asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreCuenta);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Nº Cuenta");
			modelo.addColumn("Descripcion");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaCuentasContables_nuevaPartida(final String idOficina) {
		final String consulta = "select cuentaContable,descripcion \r\nfrom cuentaContable \r\nwhere oficina_idoficina = ?\r\norder by cuentaContable asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Cuenta");
			modelo.addColumn("Descripci\u00f3n");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public String obtenerIDOficina(final String nombreOficina) {
		final String consulta = "SELECT idoficina FROM oficina WHERE nombre = ?";
		String cadena = "";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
			}
			rs.close();
		} catch (Exception ex) {
		}
		return cadena;
	}

	public String obtenerIDGrupo(final String nombreGrupo) {
		final String consulta = "select idgrupo from grupo where nombre = ?";
		String cadena = "";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreGrupo);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
			}
			rs.close();
		} catch (Exception ex) {
		}
		return cadena;
	}

	public int login(final String user, final String password) {
		final String consulta = "select *from usuario where usuario=? and password=?";
		int resultado = 0;
		this.cn = conexionSQL_SERVER.getConnection();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, user);
			sentencia.setString(2, password);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++resultado;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public int obtenerOficinaUsuario(final String user, final String password) {
		final String consulta = "select oficina_idoficina from usuario where usuario = ? and password = ?";
		int resultado = 0;
		this.cn = conexionSQL_SERVER.getConnection();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, user);
			sentencia.setString(2, password);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++resultado;
				Variables.idOficina = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public DefaultTableModel llenarTablaOficinasUsuarios(final String usuario) {
		final String consulta = "select oficina.idoficina,oficina.nombre,oficina.giro \r\nfrom oficina \r\ninner join usuario on oficina.idoficina=usuario.oficina_idoficina \r\nwhere usuario.usuario = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, usuario);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("ID Oficina");
			modelo.addColumn("Nombre Oficina");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2) };
				modelo.addRow(data);
			}
		} catch (Exception e) {
			this.error = e.toString();
		}
		return modelo;
	}

	public ResultSet obtenerOpcionesOficina(final String idOficina) {
		final String consulta = "select * from opcionesOficina where oficina_idoficina = ?";
		ResultSet resultado = null;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = resultado = sentencia.executeQuery();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public int obtenerIdUsuario(final String user, final String idOficina) {
		final String consulta = "select idusuario from usuario where usuario = ? and oficina_idoficina = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, user);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public int obtenerIdUsuario_porNombre(final String nombreUsuario, final String idOficina) {
		final String consulta = "select idusuario \r\nfrom usuario \r\nwhere nombre = ? and oficina_idoficina = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreUsuario);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public boolean obtenerInfoUsuario(final String usuario, final String idOficina) {
		boolean resultado = false;
		final String consulta = "select CONCAT(us.primerNombre, ' ', us.primerApellido) as nombre, us.cargo, ofi.nombre, ofi.idoficina,\r\nCONVERT(varchar, ins.fechaSistema, 103) as fechaSistema\r\nfrom usuario us\r\ninner join oficina ofi on us.oficina_idoficina = ofi.idoficina\r\ninner join infoSistema ins on ofi.idoficina = ins.oficina_idoficina\r\nwhere us.usuario = ? and ofi.idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		ResultSet rs = null;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, usuario);
			sentencia.setString(2, idOficina);
			rs = sentencia.executeQuery();
			while (rs.next()) {
				Variables.nombreUsuario = rs.getString(1);
				Variables.cargoUsuario = rs.getString(2);
				Variables.nombreOficina = rs.getString(3);
				Variables.idOficina = rs.getString(4);
				Variables.fechaSistema = rs.getString(5);
				resultado = true;
			}
			rs.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return resultado;
	}

	public int obtenerNivelCuenta(final String cuenta, final String idOficina) {
		final String consulta = "select nivel \r\nfrom cuentaContable \r\nwhere cuentaContable = ? and oficina_idoficina = ?";
		int valor = 0;
		conexionSQL_SERVER.verificarConexionSql();
		ResultSet rs = null;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cuenta);
			sentencia.setString(2, idOficina);
			rs = sentencia.executeQuery();
			while (rs.next()) {
				valor = rs.getInt(1);
			}
		} catch (Exception e) {
			this.error = e.toString();
			System.out.println(this.error);
		}
		return valor;
	}

	public String obtenerCorrelativoCuentaContable(final String idOficina) {
		final String consulta = "select COUNT(id) as correlativo\r\nfrom cuentaContable\r\nwhere oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		String correlativo = "";
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				correlativo = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return correlativo;
	}

	public String obtenerNumeroPartidaContable() {
		final String consulta = "select top(1)idpartidaContable from partidaContable order by idpartidaContable desc";
		String cadena = "1";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
				int aux = Integer.parseInt(cadena);
				cadena = Integer.toString(++aux);
			}
			rs.close();
		} catch (Exception ex) {
		}
		return cadena;
	}

	public DefaultTableModel llenarTablaPartidasContables(final String idOficina) {
		final String consulta = "select partidaContable.idpartidaContable, partidaContable.numeroComprobante, partidaContable.descripcion,\r\nCONVERT(varchar,fechaMov,103) as fechaMov, CONCAT(usuario.primerNombre, ' ', usuario.primerApellido) as usuario\r\nfrom partidaContable\r\ninner join usuario on partidaContable.usuario_idusuario=usuario.idusuario\r\nwhere partidaContable.oficina_idoficina = ?\r\norder by partidaContable.idpartidaContable asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Numero Partida");
			modelo.addColumn("Numero Comprobante");
			modelo.addColumn("Descripcion");
			modelo.addColumn("Fecha Contable");
			modelo.addColumn("Nombre de Usuario");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaPartidasContablesMontos(final String idOficina) {
		final String consulta = "select pco.idpartidaContable,pco.descripcion,CONVERT(varchar,pco.fechaMov,103) as fechaMov\r\nfrom partidaContable pco\r\nwhere pco.numeroComprobante like '%PCHK%' and pco.oficina_idoficina = ?\r\norder by pco.idpartidaContable asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Nº");
			modelo.addColumn("Descripcion");
			modelo.addColumn("Fecha Contable");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaPartidasContablesFechas(final String idOficina, final String fechaInicio,
			final String fechaFin) {
		final String consulta = "select idpartidaContable,numeroComprobante,descripcion,\r\nCONVERT(varchar,fechaMov,103) as fechaMov,CONVERT(varchar,fechaDoc,103) as fechaDoc\r\nfrom partidaContable \r\nwhere oficina_idoficina = ? and fechaMov between ? and ?\r\norder by idpartidaContable asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			sentencia.setString(2, fechaInicio);
			sentencia.setString(3, fechaFin);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Numero Partida");
			modelo.addColumn("Numero Comprobante");
			modelo.addColumn("Descripcion");
			modelo.addColumn("Fecha Contable");
			modelo.addColumn("Fecha Documento");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaPartidaContableModificar(final int partidaSeleccionada,
			final String idOficina) {
		final String consulta = "select cc.cuentaContable,cc.descripcion,CONVERT(varchar,mc.fechaMod,103) as fechaMod,mc.debe,mc.haber\r\nfrom movimientosContables mc\r\ninner join cuentaContable cc on mc.cuentaContable_id=cc.id\r\nwhere mc.partidaContable_idpartidaContable = ? and mc.oficina_idoficina = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, partidaSeleccionada);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Cuenta");
			modelo.addColumn("Descripcion");
			modelo.addColumn("Fecha");
			modelo.addColumn("Cargo");
			modelo.addColumn("Abono");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public Double obtenerCargoMovimientoContable(final int numeroPartida, final String cuentaContable) {
		final String consulta = "SELECT debe FROM movimientosContables WHERE partidaContable_idpartidaContable = ? and cuentaContable_idcuentaContable = ?";
		conexionSQL_SERVER.verificarConexionSql();
		Double cargo = 0.0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, numeroPartida);
			sentencia.setString(2, cuentaContable);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cargo = rs.getDouble(1);
			}
			rs.close();
		} catch (Exception ex) {
		}
		return cargo;
	}

	public Double obtenerAbonoMovimientoContable(final int numeroPartida, final String cuentaContable) {
		final String consulta = "SELECT haber FROM movimientosContables WHERE partidaContable_idpartidaContable = ? and cuentaContable_idcuentaContable = ?";
		conexionSQL_SERVER.verificarConexionSql();
		Double abono = 0.0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, numeroPartida);
			sentencia.setString(2, cuentaContable);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				abono = rs.getDouble(1);
			}
			rs.close();
		} catch (Exception ex) {
		}
		return abono;
	}

	public DefaultTableModel llenarTablaBusquedaPartidaContable(final int tipoBusqueda, final int numeroPartida,
			final String descripcion, final String idOficina) {
		final String consulta1 = "select partidaContable.idpartidaContable, partidaContable.numeroComprobante, partidaContable.descripcion,\r\nCONVERT(varchar,fechaMov,103) as fechaMov, CONCAT(usuario.primerNombre, ' ', usuario.primerApellido) as usuario\r\nfrom partidaContable\r\ninner join usuario on partidaContable.usuario_idusuario=usuario.idusuario\r\nwhere partidaContable.oficina_idoficina = ? and partidaContable.idpartidaContable = ?\r\norder by partidaContable.idpartidaContable asc";
		final String consulta2 = "select partidaContable.idpartidaContable, partidaContable.numeroComprobante, partidaContable.descripcion,\r\nCONVERT(varchar,fechaMov,103) as fechaMov, CONCAT(usuario.primerNombre, ' ', usuario.primerApellido) as usuario\r\nfrom partidaContable\r\ninner join usuario on partidaContable.usuario_idusuario=usuario.idusuario\r\nwhere partidaContable.oficina_idoficina = ? and partidaContable.descripcion like ?\r\norder by partidaContable.idpartidaContable asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("Numero Partida");
		modelo.addColumn("Numero Comprobante");
		modelo.addColumn("Descripcion");
		modelo.addColumn("Fecha Contable");
		modelo.addColumn("Nombre de Usuario");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			switch (tipoBusqueda) {
			case 1: {
				final PreparedStatement sentencia = this.cn.prepareStatement(consulta1);
				sentencia.setString(1, idOficina);
				sentencia.setInt(2, numeroPartida);
				final ResultSet rs = sentencia.executeQuery();
				while (rs.next()) {
					final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
							rs.getString(5) };
					modelo.addRow(data);
				}
				break;
			}
			case 2: {
				final PreparedStatement sentencia = this.cn.prepareStatement(consulta2);
				sentencia.setString(1, idOficina);
				sentencia.setString(2, descripcion);
				final ResultSet rs = sentencia.executeQuery();
				while (rs.next()) {
					final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
							rs.getString(5) };
					modelo.addRow(data);
				}
				break;
			}
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public String obtenerConceptoPartida(final int numPartida) {
		final String consulta = "select descripcion from partidaContable where idpartidaContable = ?";
		String cadena = null;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, numPartida);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cadena;
	}

	public DefaultTableModel llenarTablaListaUsuarios(final String idOficina) {
		final String consulta = "select usuario.usuario,usuario.nombre,usuario.fechaNacimiento,usuario.telefono,usuario.cargo,grupo.nombre\r\nfrom usuario\r\ninner join grupo on usuario.grupo_idgrupo=grupo.idgrupo\r\nwhere oficina_idoficina = ?\r\norder by usuario.nombre asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Usuario");
			modelo.addColumn("Nombre");
			modelo.addColumn("Fecha Nacimiento");
			modelo.addColumn("Telefono");
			modelo.addColumn("Cargo");
			modelo.addColumn("Grupo");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaListaUsuarios_Nombre(final String nombre) {
		final String consulta = "select usuario.usuario,usuario.nombre,usuario.fechaNacimiento,usuario.telefono,usuario.cargo,grupo.nombre\r\nfrom usuario\r\ninner join grupo on usuario.grupo_idgrupo=grupo.idgrupo\r\nwhere usuario.nombre like ?\r\norder by usuario.nombre asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombre);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Usuario");
			modelo.addColumn("Nombre");
			modelo.addColumn("Fecha Nacimiento");
			modelo.addColumn("Telefono");
			modelo.addColumn("Cargo");
			modelo.addColumn("Grupo");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public void obtenerInfoUsuarioModificar(final String usuario) {
		final String consulta = "select usuario.primerNombre,usuario.segundoNombre,usuario.primerApellido,usuario.segundoApellido,\r\nusuario.direccion,CONVERT(varchar,usuario.fechaNacimiento,103) as fechaNacimiento,\r\nusuario.telefono,grupo.nombre,oficina.nombre,cargo,usuario,estado\r\nfrom usuario\r\ninner join grupo on usuario.grupo_idgrupo=grupo.idgrupo\r\ninner join oficina on usuario.oficina_idoficina=oficina.idoficina\r\nwhere usuario = ?";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, usuario);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				this.primerNombre_modificarUsuario = rs.getString(1);
				this.segundoNombre_modificarUsuario = rs.getString(2);
				this.primerApellido_modificarUsuario = rs.getString(3);
				this.segundoApellido_modificarUsuario = rs.getString(4);
				this.direccion_modificarUsuario = rs.getString(5);
				this.fechaNacimiento_modificarUsuario = rs.getString(6);
				this.telefono_modificarUsuario = rs.getString(7);
				this.grupo_modificarUsuario = rs.getString(8);
				this.oficina_modificarUsuario = rs.getString(9);
				this.puesto_modificarUsuario = rs.getString(10);
				this.usuario_modificarUsuario = rs.getString(11);
				this.estado_modificarUsuario = rs.getInt(12);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
	}

	public int verificarUsuario(final String usuario) {
		final String consulta = "select * from usuario where usuario = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int cantFilas = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, usuario);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++cantFilas;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cantFilas;
	}

	public Double obtenerSaldoInicial(final String cuentaContable) {
		final String consulta = "select saldoInicial from cuentaContable where idcuentaContable = ?";
		conexionSQL_SERVER.verificarConexionSql();
		Double saldoInicial = 0.0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cuentaContable);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				saldoInicial = rs.getDouble(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return saldoInicial;
	}

	public DefaultComboBoxModel<Object> getDataComboBoxAnios() {
		final String sql = "CREATE TABLE #temp\r\n(\r\nlist_year INT\r\n)\r\n \r\nDECLARE @YEAR INT\r\n \r\nSET @YEAR=2015\r\nwhile @year<=2030\r\nBEGIN\r\n    INSERT INTO #temp VALUES (@YEAR)\r\n    SET @YEAR=@YEAR+1       \r\nEND\r\nSELECT * FROM #temp\r\n \r\nDROP TABLE #temp";
		final DefaultComboBoxModel<Object> modelo = new DefaultComboBoxModel<Object>();
		try {
			conexionSQL_SERVER.verificarConexionSql();
			final PreparedStatement sentencia = this.cn.prepareStatement(sql);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				modelo.addElement(rs.getString(1));
			}
			rs.close();
		} catch (Exception e) {
			System.out.println("ERROR -- " + e.toString());
		}
		return modelo;
	}

	public int verificarBalanceComprobacion(String fecha1, String fecha2, String usuario, String idOficina) {
		final String consulta = "declare @fecha1 varchar(max)    = ? \n" + "declare @fecha2 varchar(max)    = ? \n"
				+ "declare @usuario varchar(max)   = ? \n" + "declare @oficina varchar(max)   = ?\n"
				+ "declare @sumDebe decimal(10,2)  = 0.0\n" + "declare @sumHaber decimal(10,2) = 0.0\n"
				+ "declare @tablaAux_cuentasContables table(id varchar(max), cuentaContable varchar(max), cuentaContableSup varchar(max), claseCuenta varchar(max), nivel int)\n"
				+ "insert into @tablaAux_cuentasContables(id, cuentaContable,cuentaContableSup,claseCuenta,nivel)select id, cuentaContable, cuentaContableSup, claseCuenta, nivel from cuentaContable where oficina_idoficina = @oficina\n"
				+ "declare @cantFilas_cuentasContables int=(select COUNT(*)from @tablaAux_cuentasContables)\n"
				+ "delete from tblLibroContable where usuario=@usuario\n"
				+ "while @cantFilas_cuentasContables>0 begin\n"
				+ "	declare @id varchar(max)=(select top(1)id from @tablaAux_cuentasContables)\n"
				+ "	declare @cuentaContable varchar(max)=(select cuentaContable from @tablaAux_cuentasContables where id=@id)\n"
				+ "	declare @cuentaContableSup varchar(max)=(select cuentaContableSup from @tablaAux_cuentasContables where id=@id)\n"
				+ "	declare @claseCuenta varchar(max)=(select claseCuenta from @tablaAux_cuentasContables where id=@id)\n"
				+ "	declare @nivel int=(select nivel from @tablaAux_cuentasContables where id=@id)\n"
				+ "	declare @descripcion varchar(max)=(select descripcion from cuentaContable where id=@id)\n"
				+ "	declare @saldoInicial float = (select saldoInicial from tblRespaldoSaldo where cuentaContable_id=@id and fecha<=@fecha1)\n"
				+ "	set @sumDebe  = (select isnull(SUM(debe) , 0.00) from movimientosContables inner join cuentaContable on movimientosContables.cuentaContable_id=cuentaContable.id where cuentaContable.cuentaContableSup like CONCAT(SUBSTRING(@cuentaContable, 1, @nivel), '%') and cuentaContable.oficina_idoficina = @oficina)\n"
				+ "	set @sumHaber = (select isnull(SUM(haber), 0.00) from movimientosContables inner join cuentaContable on movimientosContables.cuentaContable_id=cuentaContable.id where cuentaContable.cuentaContableSup like CONCAT(SUBSTRING(@cuentaContable, 1, @nivel), '%') and cuentaContable.oficina_idoficina = @oficina)\n"
				+ "	insert into tblLibroContable (idCuentaContable, idCuentaContableSup, nivel, cuenta, descripcion, saldoInicial, debe, haber, claseCuenta, usuario, partida, fecha, saldoFinal) select @cuentaContable, @cuentaContableSup, @nivel, SUBSTRING(@cuentaContable, 1, @nivel), @descripcion,\n"
				+ "	@saldoInicial, @sumDebe, @sumHaber, @claseCuenta, @usuario, '' as partida, '' as fecha, 0.00 as saldoFinal\n"
				+ "	delete from @tablaAux_cuentasContables where cuentaContable=@cuentaContable\n"
				+ "	set @cantFilas_cuentasContables=(select COUNT(*)from @tablaAux_cuentasContables)\n" + "end\n"
				+ "select *from tblLibroContable order by idCuentaContable\n" + "";
		conexionSQL_SERVER.verificarConexionSql();
		int cantFilas = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, fecha1);
			sentencia.setString(2, fecha2);
			sentencia.setString(3, usuario);
			sentencia.setString(4, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++cantFilas;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cantFilas;
	}

	public int verificarCuentaContable(final String cuenta) {
		final String consulta = "select * from cuentaContable where cuentaContableSup = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int cantFilas = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cuenta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++cantFilas;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cantFilas;
	}

	public int verificarCuentaContableLike() {
		final String consulta = "select * from cuentaContable where cuentaContableSup NOT LIKE ''";
		conexionSQL_SERVER.verificarConexionSql();
		int cantFilas = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
//			sentencia.setString(1, cuenta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++cantFilas;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cantFilas;
	}
	
	public int verificarPartidaContableImprimir(final int partida, final String usuario) {
		final String consulta = "declare @partida int = ?\r\ndeclare @usuario varchar(max)=?\r\ndeclare @tablaAux_cuentaSup table(cuentaSup varchar(max))\r\ndeclare @tablaAux_cuentaContable table(cuentaContable varchar(max))\r\ndeclare @tablaAux_resultado table(cuentaContable varchar(max),idCuentaContableSup varchar(max),descripcion varchar(max),debe float,haber float,claseCuenta varchar(max),usuario varchar(max))\r\ninsert into @tablaAux_cuentaSup(cuentaSup)SELECT cc.cuentaContableSup FROM movimientosContables mc INNER JOIN cuentaContable cc ON mc.cuentaContable_idcuentaContable=cc.idcuentaContable WHERE mc.partidaContable_idpartidaContable = @partida GROUP BY cc.cuentaContableSup ORDER BY cc.cuentaContableSup ASC\r\ndeclare @cantFilas_cuentaSup int=(select COUNT(*) from @tablaAux_cuentaSup)\r\ndeclare @cantFilas_cuentaContable int=0\r\ndeclare @sumDebe float=0.0\r\ndeclare @sumHaber float=0.0\r\ndelete from tablaLibroContable where usuario=@usuario\r\ndeclare @fechaMov varchar(max)=(select top(1)CONVERT(varchar,fechaMov,103) as fechaMov from movimientosContables where partidaContable_idpartidaContable=@partida)\r\nwhile @cantFilas_cuentaSup>0 begin\r\n\tdeclare @cuentaSup varchar(max)=(select top(1)cuentaSup from @tablaAux_cuentaSup)\r\n\tdeclare @descriCuentaSup varchar(max)=(select descripcion from cuentaContable where idcuentaContable=@cuentaSup)\r\n\tdeclare @claseCuentaSup varchar(max)=(select claseCuenta from cuentaContable where idcuentaContable=@cuentaSup)\r\n\tinsert into @tablaAux_resultado(cuentaContable,idCuentaContableSup,descripcion,debe,haber,claseCuenta,usuario)select @cuentaSup,@fechaMov,@descriCuentaSup,0,0,@claseCuentaSup,@usuario\r\n\tdelete from @tablaAux_cuentaContable\r\n\tset @cantFilas_cuentaContable=0\r\n\tinsert into @tablaAux_cuentaContable(cuentaContable)select idcuentaContable from cuentaContable where cuentaContableSup=@cuentaSup\r\n\tset @cantFilas_cuentaContable=(select COUNT(*)from @tablaAux_cuentaContable)\r\n\twhile @cantFilas_cuentaContable>0 begin\r\n\t\tdeclare @cuentaContable varchar(max)=(select top(1)cuentaContable from @tablaAux_cuentaContable)\r\n\t\tdeclare @descriCuentaContable varchar(max)=(select descripcion from cuentaContable where idcuentaContable=@cuentaContable)\r\n\t\tdeclare @claseCuentaContable varchar(max)=(select claseCuenta from cuentaContable where idcuentaContable=@cuentaContable)\r\n\t\tdeclare @debeAux decimal(10,2)=(select isnull(sum(debe),0.0) from movimientosContables where partidaContable_idpartidaContable=@partida and cuentaContable_idcuentaContable=@cuentaContable)\r\n\t\tdeclare @haberAux decimal(10,2)=(select isnull(sum(haber),0.0) from movimientosContables where partidaContable_idpartidaContable=@partida and cuentaContable_idcuentaContable=@cuentaContable)\r\n\t\tif @debeAux>0.0 or @haberAux>0.0 begin\r\n\t\t\tset @sumDebe=@sumDebe+@debeAux\r\n\t\t\tset @sumHaber=@sumHaber+@haberAux\r\n\t\t\tinsert into @tablaAux_resultado(cuentaContable,idCuentaContableSup,descripcion,debe,haber,claseCuenta,usuario)select @cuentaContable,@fechaMov,@descriCuentaContable,@debeAux,@haberAux,@claseCuentaContable,@usuario\r\n\t\tend\r\n\t\tdelete from @tablaAux_cuentaContable where cuentaContable=@cuentaContable\r\n\t\tset @cantFilas_cuentaContable=(select COUNT(*)from @tablaAux_cuentaContable)\r\n\tend\r\n\tupdate @tablaAux_resultado set debe=@sumDebe,haber=@sumHaber where cuentaContable=@cuentaSup\r\n\tset @sumDebe=0.0 set @sumHaber=0.0\r\n\tdelete from @tablaAux_cuentaSup where cuentaSup=@cuentaSup\r\n\tset @cantFilas_cuentaSup=(select COUNT(*) from @tablaAux_cuentaSup)\r\nend\r\ninsert into tablaLibroContable(idcuentaContable,idCuentaContableSup,nivel,cuenta,descripcion,saldoInicial,debe,haber,claseCuenta,usuario,partida,fecha,saldoFinal)select cuentaContable,idCuentaContableSup,0,'',descripcion,0,debe,haber,claseCuenta,usuario,@partida,idCuentaContableSup,0 from @tablaAux_resultado\r\nselect *from tablaLibroContable";
		conexionSQL_SERVER.verificarConexionSql();
		int cantFilas = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, partida);
			sentencia.setString(2, usuario);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++cantFilas;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cantFilas;
	}

	public String obtenerCorrelativoCheque(final String nombreBanco, final String idOficina) {
		final String consulta = "select bc.correlativoCheque,cc.cuentaContable,cc.descripcion,bc.idbancos\r\nfrom bancos bc\r\ninner join cuentaContable cc on cc.id = bc.cuentaContable_id\r\ninner join oficina ofi on cc.oficina_idoficina = ofi.idoficina\r\nwhere bc.nombreBanco = ? and ofi.idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		String correlativo = "";
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreBanco);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				correlativo = rs.getString(1);
				this.cuentaContableBanco = rs.getString(2);
				this.nombreCuentaContableBanco = rs.getString(3);
				this.idBanco = rs.getInt(4);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return correlativo;
	}

	public int obtenerInfoPartidaCreada(final int numeroPartida, final String idOficina) {
		int resultado = 0;
		final String consulta = "select cc.cuentaContable,bn.nombreBanco,bn.correlativoCheque,pc.descripcion,mc.haber\r\nfrom movimientosContables mc\r\ninner join bancos bn on mc.cuentaContable_id=bn.cuentaContable_id\r\ninner join partidaContable pc on mc.partidaContable_idpartidaContable=pc.idpartidaContable\r\ninner join cuentaContable cc on mc.cuentaContable_id=cc.id\r\nwhere mc.oficina_idoficina = ? and mc.partidaContable_idpartidaContable = ?";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			sentencia.setInt(2, numeroPartida);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++resultado;
				this.cuentaContableBanco = rs.getString(1);
				this.nombreCuentaContableBanco = rs.getString(2);
				this.correlativoBanco = rs.getInt(3);
				this.descripcionPartidaCreada = rs.getString(4);
				this.monto = rs.getDouble(5);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
			System.out.println(this.error);
		}
		return resultado;
	}

	public void obtenerInfoCheque(final int numeroPartida, final String idOficina) {
		final String consulta = "declare @numeroPartida int = ?\r\ndeclare @oficina varchar(max) = ?\r\nselect numeroPartida=(select idpartidaContable from partidaContable where idpartidaContable=@numeroPartida),\r\n\t   descripcion=(select descripcion from partidaContable where idpartidaContable=@numeroPartida),\r\n\t   fechaDoc=(select convert(varchar,fechaDoc,103) from partidaContable where idpartidaContable=@numeroPartida),\r\n\t   dia=(select DAY(fechaDoc) from partidaContable where idpartidaContable=@numeroPartida),\r\n\t   mes=(SELECT DATENAME(\"MM\", fechaDoc) FROM partidaContable where idpartidaContable=@numeroPartida),\r\n\t   anio=(select YEAR(fechaDoc) from partidaContable where idpartidaContable=@numeroPartida),\r\n\t   ciudad=(select ciudad from oficina where idoficina=@oficina)\r\n\t   ";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, numeroPartida);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				this.ciudad = rs.getString(7);
				this.dia = rs.getString(4);
				this.mes = rs.getString(5);
				this.anio = rs.getString(6);
				this.partida = rs.getString(1);
				this.descripcion = rs.getString(2);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
	}

	public DefaultTableModel llenarTablaCatalogoCheques(final String descripcion, final String nombreBanco,
			final String idOficina, final String fechaInicio, final String fechaFin, final int op) {
		final String consulta1 = "SELECT chq.partidaContable_idpartidaContable, chq.idcheques, chq.nombreCheque, chq.descripcion,\r\nban.nombreBanco, chq.montoCheque, chq.fechaMov, CONCAT(usu.primerNombre, ' ', usu.primerApellido) as usuario\r\nFROM cheques chq\r\nINNER JOIN bancos ban ON chq.bancos_idbancos=ban.idbancos\r\nINNER JOIN partidaContable pco ON chq.partidaContable_idpartidaContable=pco.idpartidaContable\r\nINNER JOIN usuario usu ON pco.usuario_idusuario=usu.idusuario\r\nWHERE chq.descripcion like ? and ban.nombreBanco like ? and pco.oficina_idoficina = ?";
		final String consulta2 = "SELECT chq.partidaContable_idpartidaContable, chq.idcheques, chq.nombreCheque, chq.descripcion,\r\nban.nombreBanco, chq.montoCheque, chq.fechaMov, CONCAT(usu.primerNombre, ' ', usu.primerApellido) as usuario\r\nFROM cheques chq\r\nINNER JOIN bancos ban ON chq.bancos_idbancos=ban.idbancos\r\nINNER JOIN partidaContable pco ON chq.partidaContable_idpartidaContable=pco.idpartidaContable\r\nINNER JOIN usuario usu ON pco.usuario_idusuario=usu.idusuario\r\nWHERE chq.descripcion like ? and ban.nombreBanco like ? and pco.oficina_idoficina = ? and chq.fechaMov>=? and chq.fechaMov<=?";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			switch (op) {
			case 0: {
				final PreparedStatement sentencia = this.cn.prepareStatement(consulta1);
				sentencia.setString(1, descripcion);
				sentencia.setString(2, nombreBanco);
				sentencia.setString(3, idOficina);
				final ResultSet rs = sentencia.executeQuery();
				modelo.addColumn("N° Partida");
				modelo.addColumn("N° Cheque");
				modelo.addColumn("Nombre de Cheque");
				modelo.addColumn("Descripcion");
				modelo.addColumn("Nombre de Banco");
				modelo.addColumn("Monto ($)");
				modelo.addColumn("Fecha");
				modelo.addColumn("Usuario");
				while (rs.next()) {
					final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
							rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8) };
					modelo.addRow(data);
				}
				break;
			}
			case 1: {
				final PreparedStatement sentencia = this.cn.prepareStatement(consulta2);
				sentencia.setString(1, descripcion);
				sentencia.setString(2, nombreBanco);
				sentencia.setString(3, idOficina);
				sentencia.setString(4, fechaInicio);
				sentencia.setString(5, fechaFin);
				final ResultSet rs = sentencia.executeQuery();
				modelo.addColumn("N° Partida");
				modelo.addColumn("N° Cheque");
				modelo.addColumn("Nombre de Cheque");
				modelo.addColumn("Descripcion");
				modelo.addColumn("Nombre de Banco");
				modelo.addColumn("Monto ($)");
				modelo.addColumn("Fecha");
				modelo.addColumn("Usuario");
				while (rs.next()) {
					final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
							rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8) };
					modelo.addRow(data);
				}
				break;
			}
			}
		} catch (Exception e) {
			this.error = e.toString();
		}
		return modelo;
	}

	public int verificarLibroAuxiliar(final String fecha1, final String fecha2, final String usuario) {
		final String consulta = "declare  @fecha1 varchar(max) = ? declare @fecha2 varchar(max) = ? declare @usuario varchar(max) = ?\r\ndeclare @tablaAux_cuentaContable table(cuenta varchar(max))\r\ninsert into @tablaAux_cuentaContable(cuenta)select idcuentaContable from tablaLibroContable\r\ndeclare @contFilas_cuentasContables int=(select COUNT(*) from @tablaAux_cuentaContable)\r\nupdate tablaLibroContable set partida='',fecha='',saldoFinal=0.0\r\nwhile @contFilas_cuentasContables>0 begin\r\n\tdeclare @cuentaContable varchar(max)=(select top(1)cuenta from @tablaAux_cuentaContable)\r\n\tdeclare @saldoInicial decimal(10,2)=(select saldoInicial from cuentaContable where idcuentaContable=@cuentaContable)\r\n\r\n\tdeclare @tablaAux_movimientoContable table(partida int,cuenta varchar(max),debe decimal(10,2),haber decimal(10,2),concepto varchar(max),fecha varchar(max))\r\n\tdelete from @tablaAux_movimientoContable\r\n\tinsert into @tablaAux_movimientoContable(partida,cuenta,debe,haber,concepto,fecha)select partidaContable_idpartidaContable,cuentaContable_idcuentaContable,debe,haber,concepto,convert(varchar,fechaMov,103) as fecha from movimientosContables where cuentaContable_idcuentaContable=@cuentaContable  and fechaMov between @fecha1 and @fecha2  order by partidaContable_idpartidaContable asc\r\n\tdeclare @contFilas_movimientoContable int=(select COUNT(*) from @tablaAux_movimientoContable)\r\n\twhile @contFilas_movimientoContable>0 begin\r\n\t\tdeclare @partida int=(select top(1)partida from @tablaAux_movimientoContable)\r\n\t\tdeclare @cuenta varchar(max)=(select cuenta from @tablaAux_movimientoContable where partida=@partida)\r\n\t\tdeclare @debe decimal(10,2)=(select debe from @tablaAux_movimientoContable where partida=@partida)\r\n\t\tdeclare @haber decimal(10,2)=(select haber from @tablaAux_movimientoContable where partida=@partida)\r\n\t\tdeclare @concepto varchar(max)=(select concepto from @tablaAux_movimientoContable where partida=@partida)\r\n\t\tdeclare @fecha varchar(max)=(select fecha from @tablaAux_movimientoContable where partida=@partida)\r\n\t\tdeclare @saldoFinal decimal(10,2)=(@saldoInicial+@debe-@haber)\r\n\t\t\r\n\t\tinsert into tablaLibroContable values(@cuenta,'',0,'',@concepto,@saldoInicial,@debe,@haber,'',@usuario,@partida,@fecha,@saldoFinal)\r\n\r\n\t\tset @saldoInicial=@saldoFinal\r\n\r\n\t\tdelete from @tablaAux_movimientoContable where partida=@partida\r\n\t\tset @contFilas_movimientoContable=(select COUNT(*) from @tablaAux_movimientoContable)\r\n\tend\r\n\tset @saldoInicial=(select saldoInicial from cuentaContable where idcuentaContable=@cuentaContable)\r\n\tdeclare @debeCuenta decimal(10,2)=(select debe from tablaLibroContable where idcuentaContable=@cuentaContable and nivel<>0)\r\n\tdeclare @haberCuenta decimal(10,2)=(select haber from tablaLibroContable where idcuentaContable=@cuentaContable and nivel<>0)\r\n\tupdate tablaLibroContable set saldoFinal=(@saldoInicial+@debeCuenta-@haberCuenta) where idcuentaContable=@cuentaContable and nivel<>0\r\n\r\n\tdelete from @tablaAux_cuentaContable where cuenta=@cuentaContable\r\n\tset @contFilas_cuentasContables=(select COUNT(*) from @tablaAux_cuentaContable)\r\nend\r\nselect * \r\nfrom tablaLibroContable\r\nWHERE usuario=@usuario\r\norder by idcuentaContable,idCuentaContableSup desc\r\n";
		conexionSQL_SERVER.verificarConexionSql();
		int cantFilas = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, fecha1);
			sentencia.setString(2, fecha2);
			sentencia.setString(3, usuario);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++cantFilas;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cantFilas;
	}

	public int verificarLibroDiarioGeneral(final String fecha1, final String fecha2, final String usuario) {
		final String consulta = "declare @fecha1 varchar(max) = ? declare @fecha2 varchar(max) = ? declare @usuario varchar(max) = ?\r\ndelete from tablaLibroContable where usuario=@usuario\r\ndeclare @tablaAux_partidas table(partida int)\r\ninsert into @tablaAux_partidas(partida)select idpartidaContable from partidaContable where fechaMov between @fecha1 and @fecha2\r\ndeclare @contFilas_partida int=(select COUNT(*)from @tablaAux_partidas)\r\ndeclare @contador int=0\r\nwhile @contFilas_partida>0 begin\r\n\tdeclare @partida int=(select top(1)partida from @tablaAux_partidas)\r\n\t\r\n\tdeclare @tablaAux_movimientoContable table(cuenta varchar(max))\r\n\tdelete from @tablaAux_movimientoContable\r\n\tinsert into @tablaAux_movimientoContable(cuenta)select cuentaContable_idcuentaContable from movimientosContables where partidaContable_idpartidaContable=@partida\r\n\tdeclare @contFilas_movimientoContable int=(select COUNT(*)from @tablaAux_movimientoContable)\r\n\twhile @contFilas_movimientoContable>0 begin\r\n\t\tdeclare @cuentaContable varchar(max)=(select top(1)cuenta from @tablaAux_movimientoContable)\r\n\t\tdeclare @nivel int=(select nivel from cuentaContable where idcuentaContable=@cuentaContable)\r\n\t\tdeclare @claseCuenta varchar(max)=(select claseCuenta from cuentaContable where idcuentaContable=@cuentaContable)\r\n\t\tdeclare @cuenta varchar(max)\r\n\t\tif @nivel=1 begin set @cuenta=(SUBSTRING(@cuentaContable,1,1)) end if @nivel=2 begin set @cuenta=(SUBSTRING(@cuentaContable,1,2)) end if @nivel=4 begin set @cuenta=(SUBSTRING(@cuentaContable,1,4)) end if @nivel=6 begin set @cuenta=(SUBSTRING(@cuentaContable,1,6)) end if @nivel=8 begin set @cuenta=(SUBSTRING(@cuentaContable,1,8)) end if @nivel=10 begin set @cuenta=(SUBSTRING(@cuentaContable,1,10)) end if @nivel=12 begin set @cuenta=(SUBSTRING(@cuentaContable,1,12)) end if @nivel=14 begin set @cuenta=(SUBSTRING(@cuentaContable,1,14)) end\r\n\t\tdeclare @nombreCuenta varchar(max)=(select descripcion from cuentaContable where idcuentaContable=@cuentaContable)\r\n\t\tdeclare @concepto varchar(max)=(select concepto from movimientosContables where cuentaContable_idcuentaContable=@cuentaContable and partidaContable_idpartidaContable=@partida)\r\n\t\tdeclare @debe decimal(10,2)=(select debe from movimientosContables where cuentaContable_idcuentaContable=@cuentaContable and partidaContable_idpartidaContable=@partida)\r\n\t\tdeclare @haber decimal(10,2)=(select haber from movimientosContables where cuentaContable_idcuentaContable=@cuentaContable and partidaContable_idpartidaContable=@partida)\r\n\t\tdeclare @fecha varchar(max)=(select convert(varchar,fechaMov,103) as fecha from movimientosContables where cuentaContable_idcuentaContable=@cuentaContable and partidaContable_idpartidaContable=@partida)\r\n\t\tdeclare @descripPartida varchar(max)=(select descripcion from partidaContable where idpartidaContable=@partida)\r\n\t\tset @contador=@contador+1\r\n\t\tinsert into tablaLibroContable values(@concepto,@descripPartida,@contador,@cuenta,@nombreCuenta,0.0,@debe,@haber,@claseCuenta,@usuario,@partida,@fecha,0.0)\r\n\r\n\t\tdelete from @tablaAux_movimientoContable where cuenta=@cuentaContable\r\n\t\tset @contFilas_movimientoContable=(select COUNT(*)from @tablaAux_movimientoContable)\r\n\tend\r\n\t\r\n\tdelete from @tablaAux_partidas where partida=@partida\r\n\tset @contFilas_partida=(select COUNT(*)from @tablaAux_partidas)\r\nend\r\nselect * \r\nfrom tablaLibroContable\r\nWHERE usuario=@usuario\r\n";
		conexionSQL_SERVER.verificarConexionSql();
		int cantFilas = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, fecha1);
			sentencia.setString(2, fecha2);
			sentencia.setString(3, usuario);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++cantFilas;
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cantFilas;
	}

	public int verificarBanco(final String idCuentaContable) {
		final String consulta = "select *from bancos where cuentaContable_id = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idCuentaContable);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++resultado;
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public DefaultTableModel llenarTablaCatalogoBancos(final String idOficina) {
		final String consulta = "select bn.idbancos, bn.nombreBanco, bn.tipoCuenta, bn.cuentaBancaria, \r\ncc.cuentaContable, CONVERT(varchar, bn.fechaMod, 103) as fechaMod, \r\nCONCAT(usu.primerNombre, ' ', usu.primerApellido) as usuario\r\nfrom bancos bn\r\ninner join cuentaContable cc on cc.id=bn.cuentaContable_id\r\ninner join usuario usu on usu.idusuario=bn.usuario_idusuario\r\nwhere cc.oficina_idoficina = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("ID Banco");
			modelo.addColumn("Nombre Banco");
			modelo.addColumn("Tipo de Cuenta");
			modelo.addColumn("Cuenta Bancaria");
			modelo.addColumn("Cuenta Contable");
			modelo.addColumn("Fecha Modificaci\u00f3n");
			modelo.addColumn("Usuario");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public void obtenerInfoBanco(final int idBanco) {
		final String consulta = "select * from bancos where idbancos=?";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idBanco);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				this.nombreBanco = rs.getString(2);
				this.tipoCuenta = rs.getString(3);
				this.cuentaBancaria = rs.getString(4);
				this.cuentaContable = rs.getString(5);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
	}

	public String obtenerIdBanco(final String idOficina, final String nombreBanco) {
		final String consulta = "select idbancos from bancos \r\ninner join cuentaContable on bancos.cuentaContable_id=cuentaContable.id \r\nwhere cuentaContable.oficina_idoficina = ? and bancos.nombreBanco=?";
		String cadena = "";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			sentencia.setString(2, nombreBanco);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
			}
			rs.close();
		} catch (Exception ex) {
		}
		return cadena;
	}

	public int obtenerSigIdBodega(final String idOficina) {
		final String consulta = "select count(*) as numeroBodegas \r\nfrom bodega \r\nwhere oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public void obtenerInfoOficina(final String nombreOficina, final String idOficina) {
		final String consulta = "select direccion,ciudad,telefono \r\nfrom oficina \r\nwhere nombre = ? and idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreOficina);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				this.direccion_bodega = rs.getString(1);
				this.ciudad_bodega = rs.getString(2);
				this.telefono_bodega = rs.getString(3);
			}
			rs.close();
		} catch (Exception ex) {
		}
	}

	public DefaultTableModel llenarTablaListaBodegas(final String idOficina) {
		final String consulta = "select bodega.idbodega, bodega.nombreBodega, usuario.nombre, CONVERT(varchar, bodega.fechaMod, 103) as fechaMod,\r\nnombre2=(select CONCAT(primerNombre, ' ', primerApellido) from  usuario where idusuario=bodega.usuario_idusuario2)\r\nfrom bodega\r\ninner join oficina on bodega.oficina_idoficina=oficina.idoficina\r\ninner join usuario on bodega.usuario_idusuario=usuario.idusuario\r\nwhere oficina.idoficina = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("ID");
			modelo.addColumn("Nombre de Bodega");
			modelo.addColumn("Encargado");
			modelo.addColumn("Fecha");
			modelo.addColumn("Usuario");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public void obtenerInfoBodega(final int idBodega, final String idOficina) {
		final String consulta = "select *from bodega where idbodega = ? and oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idBodega);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				Variables.direccionBodega = rs.getString(6);
				Variables.descripcionBodega = rs.getString(5);
				Variables.ciudadBodega = rs.getString(7);
				Variables.telefonoBodega = rs.getString(8);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
	}

	public int obtenerSigIdRubro(final String idOficina) {
		final String consulta = "select count(*) as numeroRubro from categoria where oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public int obtenerSigIdSubrubro(final String idOficina) {
		final String consulta = "select count(*) as numeroRubro from subcategoria where oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public int obtenerIdRubro(final String nombreRubro, final String idOficina) {
		final String consulta = "select idcategoria from categoria where nombre = ? and oficina_idoficina = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreRubro);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public int obtenerIdSubrubro(final String nombreRubro, final String idOficina) {
		final String consulta = "select idSubcategoria,categoria_idcategoria \r\nfrom subcategoria \r\nwhere nombre = ? and oficina_idoficina = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreRubro);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
				Variables.idRubro = rs.getString(2);
				Variables.idSubrubro = rs.getString(1);
				Variables.idSubrubro_ = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public int obtenerIdProveedor(final String nombreProveedor) {
		final String consulta = "select idproveedor from proveedor where nombre = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreProveedor);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public int obtenerSigProducto(final int idSubRubro) {
		final String consulta = "select COUNT(*) as numProducto from producto where subcategoria_idSubcategoria = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idSubRubro);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public int obtenerSigIdProducto() {
		final String consulta = "select COUNT(*) as numProducto from producto";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public DefaultTableModel llenarTablaListaRubroSubRubro(final String nombreRubro, final String idOficina,
			final int tipoBusqueda) {
		String consulta = "select categoria.idcategoria, categoria.nombre,\r\ncase when categoria.idcategoriaPadre = -1 then 'RUBRO' else 'SUB-RUBRO' end as tipo,\r\nCONVERT(varchar,categoria.fechaCre,103) as fecha,\r\nmodificado=(CONCAT(usuario.primerNombre,' ',usuario.primerApellido))\r\nfrom categoria \r\ninner join usuario on categoria.usuario_idusuario=usuario.idusuario \r\nwhere categoria.nombre like ? and categoria.oficina_idoficina = ?";
		if (tipoBusqueda == 1) {
			consulta = String.valueOf(consulta) + " and categoria.idcategoriaPadre = -1";
		} else if (tipoBusqueda == 2) {
			consulta = String.valueOf(consulta) + " and categoria.idcategoriaPadre <> -1";
		}
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Decripcion");
		modelo.addColumn("Tipo");
		modelo.addColumn("Fecha Ultima Modificacion");
		modelo.addColumn("Usuario Ultima Modificacion");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreRubro);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5) };
				modelo.addRow(data);
			}
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return modelo;
	}

	public int obtenerIdPadre(final String nombreSubRubro) {
		final String consulta = "select idcategoriaPadre from categoria where nombre = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreSubRubro);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public void obtenerInfoRubroSubRubro(final int idRubroSeleccionado) {
		final String consulta = "declare @idRubroSeleccionado int = ?\r\ndeclare @idCategoria int=(select idCategoria from categoria where idcategoria=@idRubroSeleccionado)\r\ndeclare @idCategoriaPadre int=(select idCategoriaPadre from categoria where idcategoria=@idRubroSeleccionado)\r\ndeclare @rubro varchar(max)=''\r\nif @idCategoriaPadre <> -1 begin set @rubro=(select nombre from categoria where idcategoria=@idCategoriaPadre) end\r\ndeclare @nombre varchar(max)=(select nombre from categoria where idcategoria=@idCategoria)\r\ndeclare @descripcion varchar(max)=(select descripcion from categoria where idcategoria=@idCategoria)\r\nselect @idCategoria,@idCategoriaPadre,@rubro,@nombre,@descripcion";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idRubroSeleccionado);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				this.idCategoria = rs.getString(1);
				this.idCategoriaPadre = rs.getString(2);
				this.nombreCategoriaPadre = rs.getString(3);
				this.nombreCategoria = rs.getString(4);
				this.descripcionCategoria = rs.getString(5);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
	}

	public int obtenerSigIdCliente() {
		final String consulta = "select count(*) as numeroCliente from cliente";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public DefaultTableModel llenarTablaListaClientes(final String cadena, final int formaBusqueda) {
		final String consulta_nombre = "select cliente.idcliente,cliente.nombre,cliente.numeroDui,cliente.numeroNit,cliente.fechaReg,usuario.usuario\r\nfrom cliente inner join usuario on cliente.usuario_idusuario=usuario.idusuario\r\nwhere cliente.nombre like ?";
		final String consulta_dui = "select cliente.idcliente,cliente.nombre,cliente.numeroDui,cliente.numeroNit,cliente.fechaReg,usuario.usuario\r\nfrom cliente inner join usuario on cliente.usuario_idusuario=usuario.idusuario\r\nwhere cliente.numeroDui like ?";
		final String consulta_nit = "select cliente.idcliente,cliente.nombre,cliente.numeroDui,cliente.numeroNit,cliente.fechaReg,usuario.usuario\r\nfrom cliente inner join usuario on cliente.usuario_idusuario=usuario.idusuario\r\nwhere cliente.numeroNit like ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID Cliente");
		modelo.addColumn("Nombre Cliente");
		modelo.addColumn("Nº D.U.I");
		modelo.addColumn("Nº N.I.T");
		modelo.addColumn("Fecha Registro");
		modelo.addColumn("Usuario");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			switch (formaBusqueda) {
			case 0: {
				sentencia = this.cn.prepareStatement(consulta_nombre);
				break;
			}
			case 1: {
				sentencia = this.cn.prepareStatement(consulta_dui);
				break;
			}
			case 2: {
				sentencia = this.cn.prepareStatement(consulta_nit);
				break;
			}
			}
			sentencia.setString(1, cadena);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaListaClientes_2(final String cadena) {
		final String consulta_nombre = "select cliente.idcliente,cliente.nombre\r\nfrom cliente\r\nwhere cliente.nombre like ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID Cliente");
		modelo.addColumn("Nombre Cliente");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta_nombre);
			sentencia.setString(1, cadena);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

    public void obtenerInfoCliente(String idClienteSeleccionado) {
        String consulta = "select cliente.idCliente, CONCAT(cliente.primerNombre, ' ', cliente.segundoNombre, ' ', primerApellido, ' ', segundoApellido) as nombre, '' as direccion, '' as telefonoMovil,\r\n" + 
        		"cliente.numeroDui, cliente.numeroNit\r\n" + 
        		"from cliente inner join oficina on cliente.oficina_idoficina=oficina.idoficina\r\n" + 
        		"where cliente.idcliente = ?";
        conexionSQL_SERVER.verificarConexionSql();
        try {
            PreparedStatement sentencia = this.cn.prepareStatement(consulta);
            sentencia.setString(1, idClienteSeleccionado);
            ResultSet rs = sentencia.executeQuery();
            while (rs.next()) {
                Variables.codCliente = rs.getString(1);
                Variables.nombreCliente = rs.getString(2);
                Variables.duiCliente = rs.getString(5);
                Variables.nitCliente = rs.getString(6);
                Variables.direccionCliente = rs.getString(3);
                Variables.telefonoCliente = rs.getString(4);
            }
            rs.close();
        }
        catch (Exception e) {
            this.error = e.toString();
        }
    }

	public DefaultTableModel llenarTablaGastosServicios(final String cadena) {
		final String consulta = "select CONCAT(lineaServicio.tipoServicios_idtipoServicios,lineaServicio.idlineaServicio) as lineaServicio,tipoGastos.nombre,gastoServicios.montoValor,\r\ngastoServicios.montoPorcentaje,CASE when tipoGastos.estado=1 then 'ACTIVO' else 'INACTIVO' end as estado,CONVERT(varchar,lineaServicio.fechaMod,103) as fechaMod\r\nfrom lineaServicio\r\ninner join gastoServicios on lineaServicio.idlineaServicio=gastoServicios.lineaServicio_idlineaServicio\r\ninner join tipoGastos on gastoServicios.tipoGastos_idtipoGasto=tipoGastos.idtipoGasto\r\nwhere lineaServicio.idlineaServicio = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Descripcion");
		modelo.addColumn("Monto");
		modelo.addColumn("Porcentaje");
		modelo.addColumn("Estado");
		modelo.addColumn("Fecha Modificacion");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cadena);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public String obtenerNombreZona(final String cadena, final int tipo) {
		String consulta = "";
		switch (tipo) {
		case 1: {
			consulta = "select CONCAT(idzona,' - ',descripcion) as descripcion from zona where tipoZona = 1 and descripcion like ?";
			break;
		}
		case 2: {
			consulta = "select CONCAT(idzona,' - ',descripcion) as descripcion from zona where tipoZona = 2 and descripcion like ?";
			break;
		}
		case 3: {
			consulta = "select CONCAT(idzona,' - ',descripcion) as descripcion from zona where tipoZona = 3 and descripcion like ?";
			break;
		}
		}
		conexionSQL_SERVER.verificarConexionSql();
		String cadenaReturn = "";
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cadena);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadenaReturn = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cadenaReturn;
	}

	public int obtenerSigIdServicio() {
		final String consulta = "select count(*) as numeroServicio from infoServicio";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public DefaultTableModel llenarTablaServiciosGuardados(final String cadena) {
		final String consulta = "select infoServicio.idinfoServicio,cliente.nombre,lineaServicio.nombreLineaServicio,case when infoServicio.estado='V' then 'VIGENTE' \r\nwhen infoServicio.estado='S' then 'SOLICITUD' when infoServicio.estado='C' then 'CANCELADO' when infoServicio.estado='R' then 'RECHAZADO' \r\nwhen infoServicio.estado='A' then 'APROBADO' end as estado,CONVERT(varchar,infoServicio.fechaMod,103) as fechaMod,\r\nCONCAT(usuario.primerNombre,' ',usuario.primerApellido) as usuario\r\nfrom infoServicio\r\ninner join cliente on infoServicio.cliente_idcliente=cliente.idcliente\r\ninner join lineaServicio on infoServicio.lineaServicio_idlineaServicio=lineaServicio.idlineaServicio\r\ninner join usuario ON infoServicio.usuario_idusuario=usuario.idusuario\r\nwhere infoServicio.oficina_idoficina = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Nombre Cliente");
		modelo.addColumn("Linea de Servicio");
		modelo.addColumn("Estado");
		modelo.addColumn("Fecha Ultima Modificacion");
		modelo.addColumn("Usuario");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cadena);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public String obtenerIdCliente_Servicio(final String cadena) {
		final String consulta = "select cliente_idcliente from infoServicio where idinfoServicio = ?";
		conexionSQL_SERVER.verificarConexionSql();
		String cadenaReturn = "";
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cadena);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadenaReturn = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cadenaReturn;
	}

	public void obtenerDatosServicio(final String servicioSeleccionado) {
		final String consulta = "select infoServicio.estado,CONVERT(varchar,infoServicio.fechaReg,103) as fechaReg,CONVERT(varchar,infoServicio.fechaMod,103) as fechaMod,\r\nCONVERT(varchar,infoServicio.fechaVen,103) as fechaVen,infoServicio.montoSol,infoServicio.montoSug,infoServicio.montoApr,\r\ninfoServicio.diaAtr,infoServicio.calif,infoServicio.saldoActual,infoServicio.saldoAnterior,infoServicio.periodo,infoServicio.plazo,infoServicio.cuotas,\r\nCONCAT(idtipoServicios,' - ',nombreServicio) as tipoServicios,CONCAT(tipoServicios_idtipoServicios,idlineaServicio,' - ',nombreLineaServicio) as lineaServicio\r\nfrom infoServicio\r\ninner join lineaServicio on infoServicio.lineaServicio_idlineaServicio=lineaServicio.idlineaServicio\r\ninner join tipoServicios on lineaServicio.tipoServicios_idtipoServicios=tipoServicios.idtipoServicios\r\nwhere idinfoServicio = ?";
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, servicioSeleccionado);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				this.estadoServicio = rs.getString(1);
				this.fechaRegServicio = rs.getString(2);
				this.fechaModServicio = rs.getString(3);
				this.fechaVenServicio = rs.getString(4);
				this.montoSolServicio = rs.getDouble(5);
				this.montoSugServicio = rs.getDouble(6);
				this.montoAprServicio = rs.getDouble(7);
				this.diaAtrServicio = rs.getInt(8);
				this.califServicio = rs.getString(9);
				this.saldoActualServicio = rs.getDouble(10);
				this.saldoAnteriorServicio = rs.getDouble(11);
				this.periodoServicio = rs.getInt(12);
				this.plazoServicio = rs.getInt(13);
				this.cuotasServicio = rs.getInt(14);
				this.tipoServicio = rs.getString(15);
				this.lineaServicio = rs.getString(16);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
	}

	public DefaultTableModel llenarTablaServicios_lecturaMedidor(final String fecha, final String caserio) {
		final String consulta = "select infoServicio.idinfoServicio,cliente.nombre,zona.descripcion,cliente.direccion,\r\ncase when (select COUNT(*) from lecturasMedidor where fechaReg> = ? and fechaReg<=DATEADD(day,-1,DATEADD(month,1,?))) = 0 then 'PENDIENTE' else 'PROCESADO' end\r\nfrom infoServicio\r\ninner join cliente on infoServicio.cliente_idcliente=cliente.idcliente\r\ninner join zona on infoServicio.zona_idzona=zona.idzona\r\nwhere infoServicio.estado='V' and infoServicio.fechaReg<=DATEADD(day,-1,DATEADD(month,1,?)) and infoServicio.zona_idzona = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Nombre Cliente");
		modelo.addColumn("Caserio");
		modelo.addColumn("Direccion");
		modelo.addColumn("Estado");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, fecha);
			sentencia.setString(2, fecha);
			sentencia.setString(3, fecha);
			sentencia.setString(4, caserio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public int obtenerUltimaLectura(final String idServicio) {
		final String consulta = "select top(1)lecturaActual\r\nfrom lecturasMedidor \r\nwhere infoServicio_idinfoServicio = ?\r\norder by fechaReg desc";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idServicio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public DefaultTableModel llenarTablaLecturasProcesar(final String fecha, final String caserio) {
		final String consulta = "select infoServicio_idinfoServicio,lecturaAnterior,lecturaActual,usuario_idusuario,anio,mes,estado,fechaMod\r\nfrom lecturasMedidor \r\nwhere fechaReg>=? and fechaReg<=DATEADD(day,-1,DATEADD(month,1,?)) and estado='P' and infoServicio_idinfoServicio like ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID Servicio");
		modelo.addColumn("Lectura Inicial");
		modelo.addColumn("Lectura Final");
		modelo.addColumn("ID Usuario");
		modelo.addColumn("A\u00f1o");
		modelo.addColumn("Mes");
		modelo.addColumn("Fecha Registro");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, fecha);
			sentencia.setString(2, fecha);
			sentencia.setString(3, caserio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaGastosLineaServicio(final String idLineaServicio) {
		final String consulta = "select lineaServicio_idlineaServicio,montoValor,montoPorcentaje,formaCobro, \r\ncase when montoValor>0 then 'VALOR' else 'PORCENTAJE' end \r\nfrom gastoServicios \r\nwhere lineaServicio_idlineaServicio = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Monto Valor");
		modelo.addColumn("Monto Porcentaje");
		modelo.addColumn("Forma Cobro");
		modelo.addColumn("Tipo Calculo");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idLineaServicio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public int obtenerNumeroCuota(final String idServicio) {
		final String consulta = "select COUNT(*) from planPagos where infoServicio_idinfoServicio = ? and tipoOperacion='P'";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idServicio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public int obtenerReciboGenerado(final String idServicio, final String anio, final String mes) {
		final String consulta = "select idrecibosGenerados from recibosGenerados where infoServicio_idinfoServicio = ? and anio = ? and mes = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idServicio);
			sentencia.setString(2, anio);
			sentencia.setString(3, mes);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public int verificarRecibo(final String idServicio, final String anio, final String mes) {
		final String consulta = "select COUNT(*) from recibosGenerados where infoServicio_idinfoServicio = ? and anio = ? and mes = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idServicio);
			sentencia.setString(2, anio);
			sentencia.setString(3, mes);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public DefaultTableModel llenarTablaMontosPendientes(final String idLineaServicio) {
		final String consulta = "select SUM(montoCapPen),SUM(montoIntPen),SUM(montoMorPen),SUM(montoSegPen),SUM(montoOtrPen),SUM(montoCuoPen)\r\nfrom planPagos \r\nwhere infoServicio_idinfoServicio = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("capital pendiente");
		modelo.addColumn("interes pendiente");
		modelo.addColumn("mora pendiente");
		modelo.addColumn("seguro pendiente");
		modelo.addColumn("otros pendientes");
		modelo.addColumn("cuota pendiente");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idLineaServicio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaListaRecibosGenerados(final String anio, final String mes, final String caserio,
			final String idOficina) {
		final String consulta = "select recibosGenerados.idrecibosGenerados,recibosGenerados.infoServicio_idinfoServicio,cliente.nombre,CONVERT(varchar,planPagos.fechaMod,103),\r\nCONVERT(varchar,planPagos.fechaVen,103),planPagos.montoCuoPen\r\nfrom recibosGenerados\r\ninner join infoServicio on recibosGenerados.infoServicio_idinfoServicio=infoServicio.idinfoServicio\r\ninner join cliente on infoServicio.cliente_idcliente=cliente.idcliente\r\ninner join planPagos on recibosGenerados.idrecibosGenerados=planPagos.numeroRecibo\r\nwhere recibosGenerados.anio = ? and recibosGenerados.mes = ? and infoServicio.zona_idzona = ? and recibosGenerados.estado = 'P' and \r\ninfoServicio.oficina_idoficina = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("Nº Recibo");
		modelo.addColumn("ID Servicio");
		modelo.addColumn("Nombre Cliente");
		modelo.addColumn("Corte");
		modelo.addColumn("Pago");
		modelo.addColumn("Monto de Deuda ($)");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, anio);
			sentencia.setString(2, mes);
			sentencia.setString(3, caserio);
			sentencia.setString(4, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public int obtenerSigIdCuentaContable(final String idOficina) {
		final String consulta = "select COUNT(*) from cuentaContable where oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public String obtenerIdCuentaContable(final String cuentaContable, final String idOficina) {
		final String consulta = "select id \r\nfrom cuentaContable \r\nwhere cuentaContable = ? and oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		String cadena = "";
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cuentaContable);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cadena;
	}

	public DefaultTableModel llenarTablaTipoOperaciones(final String idOficina) {
		final String consulta = "select idOperaciones,descripcion from tipoOperaciones where oficina_idoficina = ? order by tipoOperacion asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Descripcion");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerDistribucionContable_generacionRecibos(final String idOficina) {
		final String consulta = "select tipoOperaciones_idOperaciones,cuentaContable_id,tipoServicios_idtipoServicios,formaPago_idformaPago,tipoOperaciones.tipoOperacion,tipoOperaciones.descripcion\r\nfrom distribucionContableServicios\r\ninner join tipoOperaciones on distribucionContableServicios.tipoOperaciones_idOperaciones=tipoOperaciones.idOperaciones\r\nwhere tipoOperaciones.oficina_idoficina = ? and tipoOperaciones_idOperaciones like 'PEN%'\r\norder by ordenOperacion asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("idOperacion");
		modelo.addColumn("idCuenta");
		modelo.addColumn("idTipoServicio");
		modelo.addColumn("idFormaPago");
		modelo.addColumn("tipoOperacion");
		modelo.addColumn("descripcion");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public String obtenerCuentaContable(final String idCuentaContable) {
		final String consulta = "select cuentaContable from cuentaContable where id = ?";
		conexionSQL_SERVER.verificarConexionSql();
		String cadena = "";
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, this.cuentaContable);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cadena;
	}

	public int obtenerSigIdPartidaContable() {
		final String consulta = "select COUNT(*) from partidaContable";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public int verificarMovimientoRecibo(final String idServicio, final String anio, final String mes) {
		final String consulta = "select COUNT(*) from recibosGenerados where infoServicio_idinfoServicio = ? and anio = ? and mes = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idServicio);
			sentencia.setString(2, anio);
			sentencia.setString(3, mes);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public DefaultTableModel obtenerInfoPago_servicios(final String idServicio, final String anio, final String mes,
			final int numRecibo) {
		final String consulta = "select recibosGenerados.idrecibosGenerados,infoServicio.idinfoServicio,cliente.nombre,cliente.direccion,tipoServicios.nombreServicio,\r\nlineaServicio.nombreLineaServicio,planPagos.montoCap,planPagos.montoInt,planPagos.montoMor,planPagos.montoSeg,planPagos.montoOtr,planPagos.montoCuo,\r\nplanPagos.fechaVen,planPagos.montoCapPen,planPagos.montoIntPen,planPagos.montoMorPen,planPagos.montoSegPen,planPagos.montoOtrPen,planPagos.montoCuoPen\r\nfrom infoServicio\r\ninner join cliente on infoServicio.cliente_idcliente=cliente.idcliente\r\ninner join recibosGenerados on infoServicio.idinfoServicio=recibosGenerados.infoServicio_idinfoServicio\r\ninner join lineaServicio on infoServicio.lineaServicio_idlineaServicio=lineaServicio.idlineaServicio\r\ninner join tipoServicios on lineaServicio.tipoServicios_idtipoServicios=tipoServicios.idtipoServicios\r\ninner join planPagos on recibosGenerados.idrecibosGenerados=planPagos.numeroRecibo\r\nwhere infoServicio.idinfoServicio = ? and recibosGenerados.anio = ? and recibosGenerados.mes = ? and recibosGenerados.idrecibosGenerados = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("idRecibo");
		modelo.addColumn("idServicio");
		modelo.addColumn("nombre");
		modelo.addColumn("direccion");
		modelo.addColumn("nombreServicio");
		modelo.addColumn("lineaServicio");
		modelo.addColumn("cap1");
		modelo.addColumn("int1");
		modelo.addColumn("mor1");
		modelo.addColumn("seg1");
		modelo.addColumn("otr1");
		modelo.addColumn("cuo1");
		modelo.addColumn("fechaVen");
		modelo.addColumn("cap2");
		modelo.addColumn("int2");
		modelo.addColumn("mor2");
		modelo.addColumn("seg2");
		modelo.addColumn("otr2");
		modelo.addColumn("cuo2");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idServicio);
			sentencia.setString(2, anio);
			sentencia.setString(3, mes);
			sentencia.setInt(4, numRecibo);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
						rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14),
						rs.getString(15), rs.getString(16), rs.getString(17), rs.getString(18), rs.getString(19) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public int obtenerSigComprobanteFacturaServicio() {
		final String consulta = "select COUNT(*) from facturasServicios";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public DefaultTableModel obtenerDistribucionContable_pagoRecibos(final String idOficina, final String formaPago,
			final String idTipoServicio) {
		final String consulta = "select tipoOperaciones_idOperaciones,cuentaContable_id,tipoServicios_idtipoServicios,formaPago_idformaPago,tipoOperaciones.tipoOperacion,tipoOperaciones.descripcion\r\nfrom distribucionContableServicios\r\ninner join tipoOperaciones on distribucionContableServicios.tipoOperaciones_idOperaciones=tipoOperaciones.idOperaciones\r\nwhere tipoOperaciones.oficina_idoficina = ? and distribucionContableServicios.formaPago_idformaPago like ? and tipoServicios_idtipoServicios = ?\r\norder by ordenOperacion asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("idOperacion");
		modelo.addColumn("idCuenta");
		modelo.addColumn("idTipoServicio");
		modelo.addColumn("idFormaPago");
		modelo.addColumn("tipoOperacion");
		modelo.addColumn("descripcion");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			sentencia.setString(2, formaPago);
			sentencia.setString(3, idTipoServicio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public String obtenerIdTipoServicio(final String nombreTipoServicio) {
		final String consulta = "select idtipoServicios from tipoServicios where nombreServicio=?";
		conexionSQL_SERVER.verificarConexionSql();
		String cadena = "";
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreTipoServicio);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				cadena = rs.getString(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return cadena;
	}

	public int obtenerIdFactura_servicio(final int nPartidaContable) {
		final String consulta = "select idfacturasServicios from facturasServicios where partidaContable_idpartidaContable=?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, nPartidaContable);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception ex) {
		}
		return resultado;
	}

	public DefaultTableModel llenarTablaListaProductos(final String nombreProducto) {
		final String consulta_nombre = "select producto.idproducto, producto.nombreProducto, SUM(kardexProducto.cantMovimiento) as cantidad, producto.precio, producto.descuento1, \r\nproducto.descuento2, producto.descuento3,CONVERT(varchar, producto.fechaMod, 103) as fechaMod, CONCAT(usuario.primerNombre, ' ', usuario.primerApellido) as nombre\r\nfrom producto\r\ninner join usuario on producto.usuario_idusuario=usuario.idusuario\r\ninner join kardexProducto on producto.idproducto=kardexProducto.producto_idproducto\r\nwhere producto.nombreProducto like ?\r\ngroup by producto.idproducto,producto.nombreProducto,producto.precio,producto.descuento1,producto.descuento2,producto.descuento3,producto.fechaMod,usuario.primerNombre,\r\nusuario.primerApellido";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Nombre Producto");
		modelo.addColumn("Cantidad");
		modelo.addColumn("Precio");
		modelo.addColumn("Precio D1");
		modelo.addColumn("Precio D2");
		modelo.addColumn("Precio D3");
		modelo.addColumn("Fecha Mod.");
		modelo.addColumn("Usuario");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta_nombre);
			sentencia.setString(1, nombreProducto);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel llenarTablaListaProductos_ordenCompra(final String nombreProducto) {
		final String consulta_nombre = "select idproducto, nombreProducto, cant = 0.00\r\nfrom producto\r\ninner join usuario on producto.usuario_idusuario=usuario.idusuario\r\nwhere producto.nombreProducto like ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Nombre Producto");
		modelo.addColumn("Cant.");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta_nombre);
			sentencia.setString(1, nombreProducto);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public int obtenerSigIdOrdenCompra() {
		final String consulta = "select COUNT(*) from ordenCompra";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public DefaultTableModel llenarTablaListaOrdenCompra(final String descripcion) {
		final String consulta_nombre = "select ordenCompra.idordenCompra, ordenCompra.descripcion, proveedor.nombre, SUM(detalleOrdenCompra.precioTotal) as precioTotal,\r\nCONVERT(varchar, ordenCompra.fechaMod, 103) as fechaMod, CONCAT(usuario.primerNombre, ' ', usuario.primerApellido) as usuario\r\nfrom ordenCompra\r\ninner join detalleOrdenCompra on ordenCompra.idordenCompra=detalleOrdenCompra.ordenCompra_idordenCompra\r\ninner join proveedor on ordenCompra.proveedor_idproveedor=proveedor.idproveedor\r\ninner join usuario on ordenCompra.usuario_idusuario=usuario.idusuario\r\nwhere descripcion like ?\r\ngroup by ordenCompra.idordenCompra, ordenCompra.descripcion, proveedor.nombre, ordenCompra.fechaMod,usuario.primerNombre, usuario.primerApellido";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Descripci\u00f3n");
		modelo.addColumn("Proveedor");
		modelo.addColumn("Precio Total $");
		modelo.addColumn("Fecha Mod.");
		modelo.addColumn("Usuario");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta_nombre);
			sentencia.setString(1, descripcion);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerOrdenCompra(final int idOrdenCompra) {
		final String consulta = "select producto.idproducto, producto.nombreProducto, CONVERT(decimal(12,2), detalleOrdenCompra.cantidad),\r\nCONVERT(decimal(12,2),detalleOrdenCompra.precioUnitario), 0.00 as iva, CONVERT(decimal(12,2), detalleOrdenCompra.precioTotal)\r\nfrom detalleOrdenCompra\r\ninner join producto on detalleOrdenCompra.producto_idproducto=producto.idproducto\r\nwhere detalleOrdenCompra.ordenCompra_idordenCompra = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("ID");
		modelo.addColumn("Nombre Producto");
		modelo.addColumn("Cantidad");
		modelo.addColumn("Precio");
		modelo.addColumn("IVA");
		modelo.addColumn("Total");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idOrdenCompra);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final Double ivaAux = rs.getDouble(6) * 0.13;
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						Double.toString(ivaAux), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public int obtenerIdBodega_nombre(final String nombreBodega, final String idOficina) {
		final String consulta = "select idbodega from bodega where nombreBodega = ? and oficina_idoficina = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreBodega);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public int obtenerIdSubRubro(final int idProducto) {
		final String consulta = "select subcategoria_idSubcategoria from producto where idproducto = ?";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idProducto);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public DefaultTableModel obtenerDisconIngresoProducto(final int subCategoria, final String idOficina,
			final String idTipoMovimiento) {
		final String consulta = "select cuentaContable_id,tipoMovimiento_idtipoMovimiento, ordenOperacion, tipoOperaciones_idOperaciones, tipoOperaciones.descripcion, \r\ntipoOperaciones.tipoOperacion \r\nfrom disconInventario \r\ninner join tipoOperaciones on disconInventario.tipoOperaciones_idOperaciones = tipoOperaciones.idOperaciones \r\nwhere subcategoria_idSubcategoria = ? and disconInventario.oficina_idoficina = ? and tipoMovimiento_idtipoMovimiento = ? \r\norder by ordenOperacion asc";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("idCuenta");
		modelo.addColumn("tipoMovimiento");
		modelo.addColumn("ordenOperacion");
		modelo.addColumn("tipoOperacion");
		modelo.addColumn("descrip");
		modelo.addColumn("debehaber");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, subCategoria);
			sentencia.setString(2, idOficina);
			sentencia.setString(3, idTipoMovimiento);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public Double obtenerCantidadProductoBodega(final int idProducto, final String idOficina) {
		final String consulta = "select SUM(cantMovimiento)\r\nfrom kardexProducto \r\nwhere producto_idproducto = ? and kardexProducto.oficina_idoficina = ?\r\n";
		Double resultado = 0.0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idProducto);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getDouble(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public int obtenerSigIdPedido() {
		final String consulta = "select COUNT(*) from pedidoVenta";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public int obtenerIdPedido(final String idOficina, final String codCliente, final String fechaActual,
			final int idUsuario, final Double montoTotal) {
		final String consulta = "select idPedido\r\nfrom pedidoVenta \r\nwhere oficina_idoficina = ? and cliente_idcliente = ? and fechaReg = ? and usuario_idusuario = ? and monto = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			sentencia.setString(2, codCliente);
			sentencia.setString(3, fechaActual);
			sentencia.setInt(4, idUsuario);
			sentencia.setDouble(5, montoTotal);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public Double obtenerCostoProducto(final int idProducto) {
		final String consulta = "select costo from producto where idproducto = ?";
		Double resultado = 0.0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idProducto);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getDouble(1);
			}
			rs.close();
		} catch (Exception e) {
			Variables.error = e.toString();
		}
		return resultado;
	}

	public int obtenerCorrelativoFactura(final String tipoFactura, final String idOficina) {
		final String consulta = "select correlativoFactura from tipoFactura where idtipoFactura = ? and oficina_idoficina = ?";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, tipoFactura);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado + 1;
	}

	public int obtenerDatosProducto(final int codigoProducto) {
		final String consulta = "select producto.idproducto, producto.nombreProducto, SUM(kardexProducto.cantMovimiento), producto.precio\r\nfrom producto\r\ninner join kardexProducto on producto.idproducto=kardexProducto.producto_idproducto\r\nwhere idproducto = ?\r\ngroup by producto.idproducto, producto.nombreProducto, producto.precio";
		int resultado = 0;
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, codigoProducto);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				++resultado;
				Variables.idProductoSeleccionado = rs.getString(1);
				Variables.descripcionProductoSeleccionado = rs.getString(2);
				Variables.cantidadProductoSeleccionado = rs.getString(3);
				Variables.precioProductoSeleccionado = rs.getString(4);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	public DefaultTableModel obtenerListaFacturas() {
		final String consulta = "select movimientosContables.numeroComprobante, cliente.nombre, formaPago.descripcion, facturasVentas.monto, facturasVentas.fechaMod,\r\nCONCAT(usuario.primerNombre, ' ', usuario.primerApellido)\r\nfrom facturasVentas\r\ninner join movimientosContables on facturasVentas.partidaContable_idpartidaContable=movimientosContables.partidaContable_idpartidaContable\r\ninner join pedidoVenta on facturasVentas.pedidoVenta_idPedido=pedidoVenta.idPedido\r\ninner join cliente on pedidoVenta.cliente_idcliente=cliente.idcliente\r\ninner join formaPago on facturasVentas.formaPago_idformaPago=formaPago.idformaPago\r\ninner join usuario on movimientosContables.usuario_idusuario=usuario.idusuario\r\ngroup by movimientosContables.numeroComprobante, cliente.nombre, formaPago.descripcion, facturasVentas.monto, facturasVentas.fechaMod,\r\nusuario.primerNombre, usuario.primerApellido\r\n";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("# Factura");
		modelo.addColumn("Cliente");
		modelo.addColumn("Forma de Pago");
		modelo.addColumn("Monto ($)");
		modelo.addColumn("Fecha");
		modelo.addColumn("Usuario");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerCuentasContables(final String idOficina) {
		final String consulta = "select id, cuentaContable, cuentaContableSup, descripcion, nivel, \r\n0.00 as saldoInicial, 0.00 as debe, 0.00 as haber\r\nfrom cuentaContable\r\nwhere oficina_idoficina = ? and cuentaContableSup = '11010101000000'";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("id");
			modelo.addColumn("cuenta");
			modelo.addColumn("cuentaSup");
			modelo.addColumn("nombre");
			modelo.addColumn("nivel");
			modelo.addColumn("saldoInicial");
			modelo.addColumn("debe");
			modelo.addColumn("haber");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerSumaCuentasContables(final String idOficina, final String cuentaContable) {
		final String consulta = "select isnull(SUM(debe),0.00), isnull(SUM(haber),0.00)\r\nfrom movimientosContables\r\ninner join cuentaContable on movimientosContables.cuentaContable_id=cuentaContable.id\r\nwhere cuentaContable.cuentaContableSup like ? and cuentaContable.oficina_idoficina = ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cuentaContable);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("debe");
			modelo.addColumn("haber");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerDatosIngresoProductosByFecha(final String fechaIni, final String fechaFin,
			final String idOficina) {
		final String consulta = "SELECT\n" + "	DISTINCT \n"
				+ "	ingresoProducto.idingresoProducto as CodigoIngreso,\n"
				+ "	ordenCompra.idordenCompra as NumeroOrden,\n" + "	Producto.nombreProducto as Producto,\n"
				+ "	Proveedor.nombre as proveedor,\n" + "	kardexProducto.cantMovimiento  as Cantidad,\n"
				+ "	ingresoProducto.fechaReg,\n"
				+ "	CONCAT(usuario.primerNombre,' ',usuario.primerApellido) as UsuarioRegistro\n"
				+ "from ingresoProducto\n" + "inner join ordenCompra\n"
				+ "on ingresoProducto.ordenCompra_idordenCompra = ordenCompra.idordenCompra\n" + "inner join usuario\n"
				+ "on ingresoProducto.usuario_idusuario = usuario.idusuario\n" + "inner join proveedor \n"
				+ "on ordenCompra.proveedor_idproveedor = proveedor.idproveedor \n" + "inner join producto\n"
				+ "on proveedor.idproveedor = producto.idproducto\n" + "inner JOIN kardexProducto\n"
				+ "on producto.idproducto = kardexProducto.producto_idproducto \n" + "where \n"
				+ "(ingresoProducto .fechaReg>= ? and ingresoProducto.fechaReg<=?) and ingresoProducto .oficina_idoficina = ? ";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, fechaIni);
			sentencia.setString(2, fechaFin);
			sentencia.setString(3, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Codigo Ingreso");
			modelo.addColumn("Numero Orden");
			modelo.addColumn("Producto");
			modelo.addColumn("Proveedor");
			modelo.addColumn("Cantidad");
			modelo.addColumn("Fecha de Ingreso");
			modelo.addColumn("Usuario que Registra");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerDatosIngresoProductosByNombreProducto(final String idOficina,
			final String nombreProducto) {
		final String consulta = "SELECT\n" + "	DISTINCT \n"
				+ "	ingresoProducto.idingresoProducto as CodigoIngreso,\n"
				+ "	ordenCompra.idordenCompra as NumeroOrden,\n" + "	Producto.nombreProducto as Producto,\n"
				+ "	Proveedor.nombre as proveedor,\n" + "	kardexProducto.cantMovimiento  as Cantidad,\n"
				+ "	ordenCompra.fechaReg as FechaIngreso,\n"
				+ "	CONCAT(usuario.primerNombre,' ',usuario.primerApellido) as UsuarioRegistro\n"
				+ "from ingresoProducto\n" + "inner join ordenCompra\n"
				+ "on ingresoProducto.ordenCompra_idordenCompra = ordenCompra.idordenCompra\n" + "inner join usuario\n"
				+ "on ingresoProducto.usuario_idusuario = usuario.idusuario\n" + "inner join proveedor \n"
				+ "on ordenCompra.proveedor_idproveedor = proveedor.idproveedor \n" + "inner join producto\n"
				+ "on proveedor.idproveedor = producto.idproducto\n" + "inner JOIN kardexProducto\n"
				+ "on producto.idproducto = kardexProducto.producto_idproducto \n" + "where \n"
				+ "Producto.nombreProducto LIKE ? and ingresoProducto .oficina_idoficina = ? ";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);

			sentencia.setString(1, nombreProducto);
			sentencia.setString(2, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Codigo Ingreso");
			modelo.addColumn("Numero Orden");
			modelo.addColumn("Producto");
			modelo.addColumn("Proveedor");
			modelo.addColumn("Cantidad");
			modelo.addColumn("Fecha de Ingreso");
			modelo.addColumn("Usuario que Registra");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerDatosIngresoProductosByFechaNombreProducto(final String fechaIni,
			final String fechaFin, final String idOficina, final String nombreProducto) {
		final String consulta = "SELECT\n" + "	DISTINCT \n"
				+ "	ingresoProducto.idingresoProducto as CodigoIngreso,\n"
				+ "	ordenCompra.idordenCompra as NumeroOrden,\n" + "	Producto.nombreProducto as Producto,\n"
				+ "	Proveedor.nombre as proveedor,\n" + "	kardexProducto.cantMovimiento  as Cantidad,\n"
				+ "	ordenCompra.fechaReg as FechaIngreso,\n"
				+ "	CONCAT(usuario.primerNombre,' ',usuario.primerApellido) as UsuarioRegistro\n"
				+ "from ingresoProducto\n" + "inner join ordenCompra\n"
				+ "on ingresoProducto.ordenCompra_idordenCompra = ordenCompra.idordenCompra\n" + "inner join usuario\n"
				+ "on ingresoProducto.usuario_idusuario = usuario.idusuario\n" + "inner join proveedor \n"
				+ "on ordenCompra.proveedor_idproveedor = proveedor.idproveedor \n" + "inner join producto\n"
				+ "on proveedor.idproveedor = producto.idproducto\n" + "inner JOIN kardexProducto\n"
				+ "on producto.idproducto = kardexProducto.producto_idproducto \n" + "where \n"
				+ "(ingresoProducto .fechaMod >= ? and ingresoProducto.fechaMod<=? or Producto.nombreProducto LIKE ?) and ingresoProducto .oficina_idoficina = ? ";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, fechaIni);
			sentencia.setString(2, fechaFin);
			sentencia.setString(3, nombreProducto);
			sentencia.setString(4, idOficina);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Codigo Ingreso");
			modelo.addColumn("Numero Orden");
			modelo.addColumn("Producto");
			modelo.addColumn("Proveedor");
			modelo.addColumn("Cantidad");
			modelo.addColumn("Fecha de Ingreso");
			modelo.addColumn("Usuario que Registra");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

//    CONSULTAS Y MODELOS PARA FORMULARIO VINCULAR CUENTAS

	public ResultSet obtenerResultSetConsultas(final String sql) {

		try {
			conexionSQL_SERVER.verificarConexionSql();
			final Statement st = this.cn.createStatement();
			final ResultSet rs = st.executeQuery(sql);
			return rs;
		} catch (Exception ex) {
		}
		return null;
	}

	public DefaultTableModel obtenerDatosVincularCuentas(final boolean producto) {
		final String consultaCuentaContable = "select\n" + "	 cuentaContable.id,\n"
				+ "	 cuentaContable.cuentaContable\n" + "FROM cuentaContable\n" + "inner join disconInventario\n"
				+ "on cuentaContable .id = disconInventario.cuentaContable_id;";

		final String consultaTipoOperaciones = "select \n" + "	tipoOperaciones.descripcion as tipoOperaciones\n"
				+ "from tipoOperaciones\n" + "inner join disconInventario\n"
				+ "on tipoOperaciones.idOperaciones = disconInventario.tipoOperaciones_idOperaciones ;";

		final String consultaRubro = "select \n" + "	subcategoria.nombre as rubro\n" + "from subcategoria\n"
				+ "inner join disconInventario \n"
				+ "on subcategoria.idSubcategoria = disconInventario.subcategoria_idSubcategoria ;";

		final String consultaTipoMovimiento = "select \n" + "	tipoMovimiento.descripcion as tipoMovimiento \n"
				+ "from tipoMovimiento\n" + "inner join disconInventario\n"
				+ "on tipoMovimiento.idtipoMovimiento = disconInventario.tipoMovimiento_idtipoMovimiento; ";

		final String consultaServicio = "select \n" + "	tipoServicios.nombreServicio as tipoServicio\n"
				+ "from tipoServicios \n" + "inner join distribucionContableServicios\n"
				+ "on tipoServicios.idtipoServicios =distribucionContableServicios.tipoServicios_idtipoServicios;";
		final String consultaFormaPago = "SELECT \n" + "	formaPago.descripcion as formaPago\n" + "from formaPago\n"
				+ "inner join distribucionContableServicios \n"
				+ "on formaPago.idformaPago = distribucionContableServicios.formaPago_idformaPago ;";

		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {

			modelo.addColumn("ID Cuenta");
			modelo.addColumn("Cuenta Contable");
			modelo.addColumn("Tipo Operacion");

			final ResultSet rsTipoOperaciones = obtenerResultSetConsultas(consultaTipoOperaciones);
			final ResultSet rsCuentaContable = obtenerResultSetConsultas(consultaCuentaContable);
			if (producto) {
				final ResultSet rsTipoMovimiento = obtenerResultSetConsultas(consultaTipoMovimiento);
				final ResultSet rsRubro = obtenerResultSetConsultas(consultaRubro);
				modelo.addColumn("Tipo Movimiento");
				modelo.addColumn("Rubro");
				while (rsCuentaContable.next() && rsTipoMovimiento.next() && rsTipoOperaciones.next() && rsRubro.next()) {
					final String[] data = { rsCuentaContable.getString(1), rsCuentaContable.getString(2), rsTipoOperaciones.getString(1),rsTipoMovimiento.getString(1), rsRubro.getString(1) };
					modelo.addRow(data);
				}
			} else {
				final ResultSet rsTipoServicios = obtenerResultSetConsultas(consultaServicio);
				final ResultSet rsFormaPago = obtenerResultSetConsultas(consultaFormaPago);
				modelo.addColumn("TipoServicio");
				modelo.addColumn("Forma de Pago");
				while (rsCuentaContable.next() && rsTipoServicios.next() && rsTipoOperaciones.next() && rsFormaPago.next()) {
					final String[] data = { rsCuentaContable.getString(1), rsCuentaContable.getString(2),rsTipoOperaciones.getString(1),rsTipoServicios.getString(1),rsFormaPago.getString(1) };
					modelo.addRow(data);
				}
			}

		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerTablaTipoOperacionesLike(String tipoOperacion) {
		tipoOperacion = (tipoOperacion == null) ? tipoOperacion = "%%" :tipoOperacion + "%";
		final String consulta = "select idOperaciones,descripcion from tipoOperaciones where descripcion LIKE ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("Cod Operacion");
		modelo.addColumn("Tipo Operacion");
		conexionSQL_SERVER.verificarConexionSql();
		try {
			PreparedStatement sentencia = null;
			sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, tipoOperacion);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	public DefaultTableModel obtenerCuentasContablesLike(String cuentaContable) {
		cuentaContable = (cuentaContable == null) ? cuentaContable = "%%" : "%"+cuentaContable+"%";
		final String consulta = "select id, cuentaContable,cuentaContableSup,descripcion  from cuentaContable where descripcion LIKE ?";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, cuentaContable);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Cod Cuenta");
			modelo.addColumn("Cuenta");
			modelo.addColumn("Cuenta Sup");;
			modelo.addColumn("Descripcion");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}

	
	public int contarRegistrosDisconInvetario() {
		final String consulta = "select count(*) as numeroCliente from disconInventario";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}
	
	public int contarRegistrosDistribucionesContables() {
		final String consulta = "select count(*) as numeroCliente from distribucionContableServicios";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}


	public DefaultTableModel obtenerDatosProductos(String nombreProducto) {
		
		nombreProducto = (nombreProducto==null)? nombreProducto="%%" : "%"+nombreProducto+"%";
		
		final String consulta = "select \n"
				+ " producto.idproducto,"
				+ "	producto.codigo,\n"
				+ "	producto.nombreProducto ,\n"
				+ "	producto.stockmin ,\n"
				+ "	producto.stockmax ,\n"
				+ "	producto.costo ,\n"
				+ "	producto.precio ,\n"
				+ "	proveedor.nombre \n"
				+ "from producto  \n"
				+ "inner join proveedor\n"
				+ "on producto.proveedor_idproveedor = proveedor.idproveedor \n"
				+ "where nombreProducto LIKE ?;";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreProducto);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Id");
			modelo.addColumn("Cod Producto");
			modelo.addColumn("Nombre Producto");
			modelo.addColumn("Stock Min");
			modelo.addColumn("Stock Max");
			modelo.addColumn("Costo");
			modelo.addColumn("Precio");
			modelo.addColumn("Proveedor");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),	"$ " + rs.getString(5), "$ "+rs.getString(6), rs.getString(7),rs.getString(8) };
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}
	
	public int contarRegistrosKardex() {
		final String consulta = "select count(*) as num from kardexProducto";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}

	
	public int contarProveedores() {
		final String consulta = "select count(*) as num from proveedor";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}
	
	
	public DefaultTableModel obtenerDatosProductosCotizacion(String nombreProducto, final int cod) {
		
		nombreProducto = (nombreProducto==null)? nombreProducto="%%" : "%"+nombreProducto+"%";
		final String consulta = "select \n"
				+ " producto.idproducto,"
				+ "	producto.codigo,\n"
				+ "	producto.nombreProducto"
				+ "from producto  \n"
				+ "where nombreProducto LIKE ? or producto.idproducto=?;";
		final DefaultTableModel modelo = new DefaultTableModel();
		conexionSQL_SERVER.verificarConexionSql();
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setString(1, nombreProducto);
			sentencia.setInt(2, cod);
			final ResultSet rs = sentencia.executeQuery();
			modelo.addColumn("Id");
			modelo.addColumn("Cod Producto");
			modelo.addColumn("Nombre Producto");
			while (rs.next()) {
				final String[] data = { rs.getString(1), rs.getString(2), rs.getString(3)};
				modelo.addRow(data);
			}
		} catch (Exception ex) {
		}
		return modelo;
	}
	
	public int stockProducto(final int idProducto) {
		final String consulta = "select sum(kp.cantMovimiento) from kardexProducto kp where kp.producto_idproducto = ?;";
		conexionSQL_SERVER.verificarConexionSql();
		int resultado = 0;
		try {
			final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
			sentencia.setInt(1, idProducto);
			final ResultSet rs = sentencia.executeQuery();
			while (rs.next()) {
				resultado = rs.getInt(1);
			}
			rs.close();
		} catch (Exception e) {
			this.error = e.toString();
		}
		return resultado;
	}
	
	
	
	
	
	
}
