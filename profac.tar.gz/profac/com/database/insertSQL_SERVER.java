// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.database;

import java.io.InputStream;
import java.lang.annotation.Retention;
import java.io.FileInputStream;
import java.io.File;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Connection;
import profac.com.herramientas.Variables;

public class insertSQL_SERVER extends conexionSQL_SERVER
{
    public String error;
    public consultasSQL_SERVER consultasSql;
    
    public insertSQL_SERVER() {
        this.error = "";
        this.consultasSql = new consultasSQL_SERVER();
    }
    
    public int insertNuevoUsuario(final String usuario, final String password, final String direccion, final String telefono, final String puesto, final String nombre, final String fechaNac, final int edad, final String fechaActual, final int estado, final String nombre1, final String nombre2, final String nombre3, final String nombre4) {
        final int resultado = 0;
        return resultado;
    }
    
    public int insertNuevaCuenta(final String id, final String cuenta, final String cuentaSup, final int tipoCuenta, final int nivel, final int clase, final String descripcion, final String fechaReg, final String fechaMod, final int usuario, final String claseCuenta, final Double saldoInicial, final Double saldoFinal, final String idOficina) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("INSERT INTO cuentaContable VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            sql.setString(1, id);
            sql.setString(2, cuenta);
            sql.setString(3, cuentaSup);
            sql.setInt(4, tipoCuenta);
            sql.setInt(5, nivel);
            sql.setInt(6, clase);
            sql.setString(7, descripcion);
            sql.setString(8, fechaReg);
            sql.setString(9, fechaMod);
            sql.setInt(10, usuario);
            sql.setString(11, claseCuenta);
            sql.setDouble(12, saldoInicial);
            sql.setDouble(13, saldoFinal);
            sql.setString(14, idOficina);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertPrecupuestoCuenta(final String idOficina, final int idUsuario, final String idCuenta, final Double montoPres, final Double montoEjec, final String fechaActual) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("INSERT INTO presupuestoContable VALUES(?,?,?,?,?,?,?)");
            sql.setString(1, idOficina);
            sql.setInt(2, idUsuario);
            sql.setString(3, idCuenta);
            sql.setDouble(4, montoPres);
            sql.setDouble(5, montoEjec);
            sql.setString(6, fechaActual);
            sql.setString(7, fechaActual);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertRespaldoContable(final String idOficina, final int idUsuario, final String fecha, final String hora, final String cuentaContable, final Double saldoInicial) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("INSERT INTO tablaRespaldoSaldos VALUES(?,?,?,?,?,?)");
            sql.setString(1, idOficina);
            sql.setInt(2, idUsuario);
            sql.setString(3, fecha);
            sql.setString(4, hora);
            sql.setString(5, cuentaContable);
            sql.setDouble(6, saldoInicial);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevaPartidaContable(final int numPartida, final String oficina, final String comprobante, final String descripcion, final String fechaDoc, final String fechaMov, final String fechaMod, final int usuario) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("INSERT INTO partidaContable VALUES(?,?,?,?,?,?,?,?)");
            sql.setInt(1, numPartida);
            sql.setString(2, oficina);
            sql.setString(3, comprobante);
            sql.setString(4, descripcion);
            sql.setString(5, fechaDoc);
            sql.setString(6, fechaMov);
            sql.setString(7, fechaMod);
            sql.setInt(8, usuario);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoMovimientoContable(final int tipoMovimiento, final int numPartida, final String cuentaContable, final double debe, final double haber, final String numeroComprobante, final String fechaMov, final String concepto, final String poliza, final String oficina, final String fechaMod, final int usuario, final int idBanco, final String nombreCheque, final String idServicio) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into movimientosContables values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            sql.setInt(1, tipoMovimiento);
            sql.setInt(2, numPartida);
            sql.setString(3, cuentaContable);
            sql.setDouble(4, debe);
            sql.setDouble(5, haber);
            sql.setString(6, numeroComprobante);
            sql.setString(7, fechaMov);
            sql.setString(8, concepto);
            sql.setString(9, poliza);
            sql.setString(10, oficina);
            sql.setString(11, fechaMod);
            sql.setInt(12, usuario);
            sql.setInt(13, idBanco);
            sql.setString(14, nombreCheque);
            sql.setString(15, idServicio);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoBanco(final String nombreBanco, final String tipoCuenta, final String cuentaBancaria, final String idCuentaContable, final int correlativoCheque, final int idUsuario, final String fechaRegistro) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into bancos values(?,?,?,?,?,?,?,?)");
            sql.setString(1, nombreBanco);
            sql.setString(2, tipoCuenta);
            sql.setString(3, cuentaBancaria);
            sql.setString(4, idCuentaContable);
            sql.setInt(5, correlativoCheque);
            sql.setInt(6, idUsuario);
            sql.setString(7, fechaRegistro);
            sql.setString(8, fechaRegistro);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoCheque(final int partidaContable, final int idBanco, final int numeroCheque, final String nombreCheque, final Double montoCheque, final String fechaMov, final String descripcion) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into cheques values(?,?,?,?,?,?,?)");
            sql.setInt(1, partidaContable);
            sql.setInt(2, idBanco);
            sql.setInt(3, numeroCheque);
            sql.setString(4, nombreCheque);
            sql.setDouble(5, montoCheque);
            sql.setString(6, fechaMov);
            sql.setString(7, descripcion);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevaBodega(final int idBodega, final String nombreBodega, final String idOficina, final int idUsuario, final String descripcion, final String direccion, final String ciudad, final String telefono, final String fechaActual, final int idUsuario2) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into bodega values(?,?,?,?,?,?,?,?,?,?,?)");
            sql.setInt(1, idBodega);
            sql.setString(2, nombreBodega);
            sql.setString(3, idOficina);
            sql.setInt(4, idUsuario);
            sql.setString(5, descripcion);
            sql.setString(6, direccion);
            sql.setString(7, ciudad);
            sql.setString(8, telefono);
            sql.setString(9, fechaActual);
            sql.setString(10, fechaActual);
            sql.setInt(11, idUsuario2);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoRubro(final int idCategoria, final int idCategoriaPadre, final String nombre, final String fechaCre, final int idUsuario, final String descripcion, final String idOficina) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into categoria values(?,?,?,?,?,?,?)");
            sql.setInt(1, idCategoria);
            sql.setInt(2, idCategoriaPadre);
            sql.setString(3, nombre);
            sql.setString(4, fechaCre);
            sql.setInt(5, idUsuario);
            sql.setString(6, descripcion);
            sql.setString(7, idOficina);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoSubRubro(final int idCategoria, final int idCategoriaPadre, final String nombre, final String fechaCre, final int idUsuario, final String descripcion, final String idOficina) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into subcategoria values(?,?,?,?,?,?,?)");
            sql.setInt(1, idCategoria);
            sql.setInt(2, idCategoriaPadre);
            sql.setString(3, nombre);
            sql.setString(4, fechaCre);
            sql.setInt(5, idUsuario);
            sql.setString(6, descripcion);
            sql.setString(7, idOficina);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoProducto(final String codigoProducto, final int idProveedor, final String nombreProducto, final String descripcion, final String fechaActual, final int idUsuario, final Double pesoProducto, final String unidadMedida, final Double stockMinimo, final Double stockMaximo, final Double costoProducto, final Double precioProducto, final Double descuento1, final Double descuento2, final Double descuento3, final String rutaImgProducto, final String tipoProducto, final int estadoProducto, final int idSubrubro) {
        final File imgProducto = new File(rutaImgProducto);
        FileInputStream fis_imgProducto = null;
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into producto values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            sql.setString(1, codigoProducto);
            sql.setInt(2, idProveedor);
            sql.setString(3, nombreProducto);
            sql.setString(4, descripcion);
            sql.setString(5, fechaActual);
            sql.setString(6, fechaActual);
            sql.setInt(7, idUsuario);
            sql.setDouble(8, pesoProducto);
            sql.setString(9, unidadMedida);
            sql.setDouble(10, stockMinimo);
            sql.setDouble(11, stockMaximo);
            sql.setDouble(12, costoProducto);
            sql.setDouble(13, precioProducto);
            sql.setDouble(14, descuento1);
            sql.setDouble(15, descuento2);
            sql.setDouble(16, descuento3);
            if (rutaImgProducto.length() == 0) {
                fis_imgProducto = null;
            }
            else {
                fis_imgProducto = new FileInputStream(imgProducto);
            }
            sql.setBinaryStream(17, fis_imgProducto, (int)imgProducto.length());
            sql.setString(18, tipoProducto);
            sql.setInt(19, estadoProducto);
            sql.setInt(20, idSubrubro);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoCliente(final String idCliente, final String idOficina, final String nombre, final String fechaNacimiento, final String sexo, final String fechaVencimientoDui, final String NDui, final String NNit, final String estadoCivil, final String direccion, final String telefonoFijo, final String telefonoCelular, final String departamento, final String ciudad, final String pais, final String nombreRef1, final String telefonoRef1, final String nombreRef2, final String telefonoRef2, final String nombreFam1, final String telefonoFam1, final String nombreFam2, final String telefonoFam2, final String rutaImgFDui, final String rutaImgTDui, final String rutaImgFNit, final String rutaImgTNit, final String rutaImgRiesgo, final String fechaReg, final String fechaMod, final int idUsuario) {
        int resultado = 0;
        final File imgFDui = new File(rutaImgFDui);
        final File imgTDui = new File(rutaImgTDui);
        final File imgFNit = new File(rutaImgFNit);
        final File imgTNit = new File(rutaImgTNit);
        final File imgRies = new File(rutaImgRiesgo);
        FileInputStream fis_imgFDui = null;
        FileInputStream fis_imgTDui = null;
        FileInputStream fis_imgFNit = null;
        FileInputStream fis_imgTNit = null;
        FileInputStream fis_imgRies = null;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into cliente values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            sql.setString(1, idCliente);
            sql.setString(2, idOficina);
            sql.setString(3, nombre);
            sql.setString(4, fechaNacimiento);
            sql.setString(5, sexo);
            sql.setString(6, fechaVencimientoDui);
            sql.setString(7, NDui);
            sql.setString(8, NNit);
            sql.setString(9, estadoCivil);
            sql.setString(10, direccion);
            sql.setString(11, telefonoFijo);
            sql.setString(12, telefonoCelular);
            sql.setString(13, departamento);
            sql.setString(14, ciudad);
            sql.setString(15, pais);
            sql.setString(16, nombreRef1);
            sql.setString(17, telefonoRef1);
            sql.setString(18, nombreRef2);
            sql.setString(19, telefonoRef2);
            sql.setString(20, nombreFam1);
            sql.setString(21, telefonoFam1);
            sql.setString(22, nombreFam2);
            sql.setString(23, telefonoFam2);
            if (rutaImgFDui.length() == 0) {
                fis_imgFDui = null;
            }
            else {
                fis_imgFDui = new FileInputStream(imgFDui);
            }
            if (rutaImgTDui.length() == 0) {
                fis_imgTDui = null;
            }
            else {
                fis_imgTDui = new FileInputStream(imgTDui);
            }
            if (rutaImgFNit.length() == 0) {
                fis_imgFNit = null;
            }
            else {
                fis_imgFNit = new FileInputStream(imgFNit);
            }
            if (rutaImgTNit.length() == 0) {
                fis_imgTNit = null;
            }
            else {
                fis_imgTNit = new FileInputStream(imgTNit);
            }
            if (rutaImgRiesgo.length() == 0) {
                fis_imgRies = null;
            }
            else {
                fis_imgRies = new FileInputStream(imgRies);
            }
            sql.setBinaryStream(24, fis_imgFDui, (int)imgFDui.length());
            sql.setBinaryStream(25, fis_imgTDui, (int)imgTDui.length());
            sql.setBinaryStream(26, fis_imgFNit, (int)imgFNit.length());
            sql.setBinaryStream(27, fis_imgTNit, (int)imgTNit.length());
            sql.setBinaryStream(28, fis_imgRies, (int)imgRies.length());
            sql.setString(29, fechaReg);
            sql.setString(30, fechaMod);
            sql.setInt(31, idUsuario);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertInfoServicio(final String idInfoServicio, final String idOficina, final String idCliente, final String estado, final String zona, final String idLineaServicio, final String fechaReg, final String fechaMod, final String fechaVen, final Double montoSol, final Double montoSug, final Double montoApr, final int diaAtr, final String calif, final int idUsuario, final Double saldoActual, final Double saldoAnterior, final int periodo, final int plazo, final int cuotas) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into infoServicio values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            sql.setString(1, idInfoServicio);
            sql.setString(2, idOficina);
            sql.setString(3, idCliente);
            sql.setString(4, estado);
            sql.setString(5, zona);
            sql.setString(6, idLineaServicio);
            sql.setString(7, fechaReg);
            sql.setString(8, fechaMod);
            sql.setString(9, fechaVen);
            sql.setDouble(10, montoSol);
            sql.setDouble(11, montoSug);
            sql.setDouble(12, montoApr);
            sql.setInt(13, diaAtr);
            sql.setString(14, calif);
            sql.setInt(15, idUsuario);
            sql.setDouble(16, saldoActual);
            sql.setDouble(17, saldoAnterior);
            sql.setInt(18, periodo);
            sql.setInt(19, plazo);
            sql.setInt(20, cuotas);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertNuevoPlanPagos(final String idInfoServicio, final String fechaReg, final String fechaVen, final Double montoCap, final Double montoInt, final Double montoMor, final Double montoSeg, final Double montoOtr, final Double montoCuo, final String tipoOperacion, final int idUsuario, final String estado, final String fechaMod, final Double montoCapPen, final Double montoIntPen, final Double montoMorPen, final Double montoSegPen, final Double montoOtrPen, final Double montoCuoPen, final int numeroCuota, final int numeroRecibo) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into planPagos values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            sql.setString(1, idInfoServicio);
            sql.setString(2, fechaReg);
            sql.setString(3, fechaVen);
            sql.setDouble(4, montoCap);
            sql.setDouble(5, montoInt);
            sql.setDouble(6, montoMor);
            sql.setDouble(7, montoSeg);
            sql.setDouble(8, montoOtr);
            sql.setDouble(9, montoCuo);
            sql.setString(10, tipoOperacion);
            sql.setInt(11, idUsuario);
            sql.setString(12, estado);
            sql.setString(13, fechaMod);
            sql.setDouble(14, montoCapPen);
            sql.setDouble(15, montoIntPen);
            sql.setDouble(16, montoMorPen);
            sql.setDouble(17, montoSegPen);
            sql.setDouble(18, montoOtrPen);
            sql.setDouble(19, montoCuoPen);
            sql.setInt(20, numeroCuota);
            sql.setInt(21, numeroRecibo);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertLecturaMedidor(final String idServicio, final Double lecturaInicial, final Double lecturaFinal, final int idUsuario, final String fechaMod, final String anio, final String mes, final String fechaReg, final String estado) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into lecturasMedidor values(?,?,?,?,?,?,?,?,?)");
            sql.setString(1, idServicio);
            sql.setDouble(2, lecturaInicial);
            sql.setDouble(3, lecturaFinal);
            sql.setInt(4, idUsuario);
            sql.setString(5, fechaMod);
            sql.setString(6, anio);
            sql.setString(7, mes);
            sql.setString(8, fechaReg);
            sql.setString(9, estado);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertReciboGenerado(final String idServicio, final String estado, final String fechaReg, final String fechaMod, final String fechaVen, final int idUsuario, final String anio, final String mes) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into recibosGenerados values(?,?,?,?,?,?,?,?)");
            sql.setString(1, idServicio);
            sql.setString(2, estado);
            sql.setString(3, fechaReg);
            sql.setString(4, fechaMod);
            sql.setString(5, fechaVen);
            sql.setInt(6, idUsuario);
            sql.setString(7, anio);
            sql.setString(8, mes);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertDistribucionContable(final String idOperaciones, final String idCuentaContable, final String idTipoServicio, final int idUsuario, final int ordenOperacion, final String descripcion, final String idFormaPago) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into distribucionContableServicios values(?,?,?,?,?,?,?)");
            sql.setString(1, idOperaciones);
            sql.setString(2, idCuentaContable);
            sql.setString(3, idTipoServicio);
            sql.setInt(4, idUsuario);
            sql.setInt(5, ordenOperacion);
            sql.setString(6, descripcion);
            sql.setString(7, idFormaPago);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertFactura_servicio(final int ncomprobante, final int idPartidaContable, final String idCliente, final String fechaSistema, final Double monto) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into facturasServicios values(?,?,?,?,?,?)");
            sql.setInt(1, ncomprobante);
            sql.setInt(2, idPartidaContable);
            sql.setString(3, idCliente);
            sql.setString(4, fechaSistema);
            sql.setDouble(5, monto);
            sql.setString(6, fechaSistema);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertKardex_servicio(final String idServicio, final String fechaSistema, final String idFormaPago, final int idFactura, final Double monto, final Double montoIva) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into kardexServicios values(?,?,?,?,?,?,?,?)");
            sql.setString(1, idServicio);
            sql.setString(2, fechaSistema);
            sql.setString(3, fechaSistema);
            sql.setString(4, idFormaPago);
            sql.setInt(5, idFactura);
            sql.setDouble(6, monto);
            sql.setDouble(7, montoIva);
            sql.setString(8, fechaSistema);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int insertOrdenCompra(final int idProveedor, final String fechaReg, final String fechaPag, final String descripcion, final int idUsuario, final String idOficina) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into ordenCompra values(?,?,?,?,?,?,?)");
            sql.setInt(1, idProveedor);
            sql.setString(2, fechaReg);
            sql.setString(3, fechaReg);
            sql.setString(4, fechaPag);
            sql.setString(5, descripcion);
            sql.setInt(6, idUsuario);
            sql.setString(7, idOficina);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertOrdenCompra_detalle(final int idOrdenCompra, final int idProducto, final Double cantidad, final Double precioUnitario, final Double precioTotal) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into detalleOrdenCompra values(?,?,?,?,?)");
            sql.setInt(1, idOrdenCompra);
            sql.setInt(2, idProducto);
            sql.setDouble(3, cantidad);
            sql.setDouble(4, precioUnitario);
            sql.setDouble(5, precioTotal);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertIngresoProducto(final int idOrdenCompra, final String tipoFactura, final String numeroFactura, final String idFormaPago, final String fechaRegistro, final int idUsuario, final String idOficina, final int idProveedor) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into ingresoProducto values(?,?,?,?,?,?,?,?,?)");
            sql.setInt(1, idOrdenCompra);
            sql.setString(2, tipoFactura);
            sql.setString(3, numeroFactura);
            sql.setString(4, idFormaPago);
            sql.setString(5, fechaRegistro);
            sql.setString(6, fechaRegistro);
            sql.setInt(7, idUsuario);
            sql.setString(8, idOficina);
            sql.setInt(9, idProveedor);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertKardexProducto(final int idProducto, final String idTipoMovimiento, final int idBodega, final String numeroDocumento, final Double catMovimiento, final String fechaReg, final int idUsuario, final String idOficina) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into kardexProducto values(?,?,?,?,?,?,?,?,?)");
            sql.setInt(1, idProducto);
            sql.setString(2, idTipoMovimiento);
            sql.setInt(3, idBodega);
            sql.setString(4, numeroDocumento);
            sql.setDouble(5, catMovimiento);
            sql.setString(6, fechaReg);
            sql.setString(7, fechaReg);
            sql.setInt(8, idUsuario);
            sql.setString(9, idOficina);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertPedidoVenta(final String idOficina, final String codCliente, final String fechaReg, final int idUsuario, final Double montoTotal) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into pedidoVenta values(?,?,?,?,?,?)");
            sql.setString(1, idOficina);
            sql.setString(2, codCliente);
            sql.setString(3, fechaReg);
            sql.setString(4, fechaReg);
            sql.setInt(5, idUsuario);
            sql.setDouble(6, montoTotal);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertPedidoVenta_detalle(final int idPedido, final int idProducto, final int idBodega, final Double cantidad, final Double precioUnitario, final Double precioTotal) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into detallePedido values(?,?,?,?,?,?)");
            sql.setInt(1, idPedido);
            sql.setInt(2, idProducto);
            sql.setInt(3, idBodega);
            sql.setDouble(4, cantidad);
            sql.setDouble(5, precioUnitario);
            sql.setDouble(6, precioTotal);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertFacturaVenta(final String idFormaPago, final int idPedido, final int idPartidaContable, final String fechaReg, final Double monto, final String idTipoFactura) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into facturasVentas values(?,?,?,?,?,?,?)");
            sql.setString(1, idFormaPago);
            sql.setInt(2, idPedido);
            sql.setInt(3, idPartidaContable);
            sql.setString(4, fechaReg);
            sql.setString(5, fechaReg);
            sql.setDouble(6, monto);
            sql.setString(7, idTipoFactura);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int insertDistribucionContableServicios
    	(
    			final String idTipoOperaciones,
    			final String cuentaContable,
    			final String idTipoServicios,
    			final String idUsuario,
    			final String ordenOperacion,
    			final String descripcion,
    			final String idFormaPago
    			) {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into distribucionContableServicios values(?,?,?,?,?,?,?)");
            sql.setString(1, idTipoOperaciones);
            sql.setString(2, cuentaContable);
            sql.setString(3, idTipoServicios);
            sql.setInt(4, Integer.parseInt(idUsuario));
            sql.setInt(5, Integer.parseInt(ordenOperacion));
            sql.setString(6, descripcion);
            sql.setString(7, idFormaPago);
            resultado = sql.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    
    public int insertDisconInventario
    	(
    			final String cuentaContableId,
    			final String idOficina,
    			final String idUsuario,
    			final String idTipoMovimiento,
    			final String ordenOperacion,
    			final String subrubro,
    			final String idTipoOperaciones
    		) 
    {
        int resultado = 0;
        final Connection cn = conexionSQL_SERVER.getConnection();
        PreparedStatement sql = null;
        try {
            sql = cn.prepareStatement("insert into disconInventario values (?,?,?,?,?,?,?);");
            sql.setString(1, cuentaContableId);
            sql.setString(2, idOficina);
            sql.setInt(3, Integer.parseInt(idUsuario));
            sql.setString(4, idTipoMovimiento);
            sql.setInt(5, Integer.parseInt(ordenOperacion));
            sql.setInt(6, Integer.parseInt(subrubro));
            sql.setString(7, idTipoOperaciones);
            resultado = sql.executeUpdate();
        }
        catch (SQLException e) {
            resultado = 0;
            Variables.error = e.toString();
            System.out.println(e.toString());
        }
        return resultado;
    }
    

    public int insertKardexProducto
	(
			final String productoId,
			final String tipoMovimientoId,
			final String bodegaId,
			final String numDoc,
			final String canMov,
			final String fechaReg,
			final String fechaMod,
			final String usuarioId,
			final String oficinaId 
		) 
{
    int resultado = 0;
    final Connection cn = conexionSQL_SERVER.getConnection();
    PreparedStatement sql = null;
    try {
        sql = cn.prepareStatement("insert into kardexProducto values (?,?,?,?,?,?,?,?,?);");
        sql.setInt(1, Integer.parseInt(productoId));
        sql.setString(2, tipoMovimientoId);
        sql.setInt(3, Integer.parseInt(bodegaId));
        sql.setString(4, numDoc);
        sql.setDouble(5, Double.parseDouble(canMov));
        sql.setString(6, fechaReg);
        sql.setString(7, fechaMod);
        sql.setInt(8, Integer.parseInt(usuarioId));
        sql.setString(9, oficinaId);
        resultado = sql.executeUpdate();
    }
    catch (SQLException e) {
        resultado = 0;
        Variables.error = e.toString();
        System.out.println(e.toString());
    }
    return resultado;
}
    
    
    public int insertProveedor
	(
			
			final String nombre,
			final String zona_idZona,
			final String direccion,
			final String fechaReg,
			final String fechaMod,
			final int usuarioId,
			final String nit,
			final String nrc,
			final String tipoProveedor,
			final String cuentaContableId,
			final int porcentajeRetencion,
			final String pais,
			final String telefono1,
			final String telefono2,
			final String telefono3,
			final String personaContacto,
			final String ext1,
			final String ext2,
			final String ext3,
			final String estado
		) 
{
    int resultado = 0;
    final Connection cn = conexionSQL_SERVER.getConnection();
    PreparedStatement sql = null;
    try {
        sql = cn.prepareStatement("insert into proveedor values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
        sql.setString(1, nombre);
        sql.setString(2, zona_idZona);
        sql.setString(3, direccion);
        sql.setString(4, fechaReg);
        sql.setString(5, fechaMod);
        sql.setInt(6, usuarioId);
        sql.setString(7,nit);
        sql.setString(8, nrc);
        sql.setString(9, tipoProveedor);
        sql.setString(10, cuentaContableId);
        sql.setInt(11, porcentajeRetencion);
        sql.setString(12,pais);
        sql.setString(13, telefono1);
        sql.setString(14, telefono2);
        sql.setString(15, telefono3);
        sql.setString(16, personaContacto);
        sql.setString(17, ext1);
        sql.setString(18, ext2);
        sql.setString(19, ext3);
        sql.setString(20, estado);
        resultado = sql.executeUpdate();
    }
    catch (SQLException e) {
        resultado = 0;
        Variables.error = e.toString();
        System.out.println(e.toString());
    }
    return resultado;
}
    
    
    public int insertCotizacionProducto
	(
			final String fechaReg,
			final int usuarioId,
			final Double monto
		) 
{
    int resultado = 0;
    final Connection cn = conexionSQL_SERVER.getConnection();
    PreparedStatement sql = null;
    try {
        sql = cn.prepareStatement("insert into cotizacionProducto values (?,?,?);");
        sql.setString(1, fechaReg);
        sql.setInt(2, usuarioId);
        sql.setDouble(3, monto);
        
        resultado = sql.executeUpdate();
    }
    catch (SQLException e) {
        resultado = 0;
        Variables.error = e.toString();
        System.out.println(e.toString());
    }
    return resultado;
}

    public int insertDetalleCotizacionProducto
	(
			final String idCotizacion,
			final String idProducto,
			final String cantidad,
			final String precio,
			final String precioTotal
		) 
{
    int resultado = 0;
    final Connection cn = conexionSQL_SERVER.getConnection();
    PreparedStatement sql = null;
    try {
        sql = cn.prepareStatement("insert into detalleCotizacion values (?,?,?,?,?);");
        sql.setInt(1, Integer.parseInt(idCotizacion));
        sql.setInt(2, Integer.parseInt(idProducto));
        sql.setInt(3, Integer.parseInt(cantidad));
        sql.setDouble(4, Double.parseDouble(precio));
        sql.setDouble(5, Double.parseDouble(precioTotal));
        
        resultado = sql.executeUpdate();
    }
    catch (SQLException e) {
        resultado = 0;
        Variables.error = e.toString();
        System.out.println(e.toString());
    }
    return resultado;
}

    
    
    
}
