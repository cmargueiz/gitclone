// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.database;

import java.awt.Component;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.Connection;
import profac.com.herramientas.Ajustes;

public class conexionSQL_SERVER
{
    public static Ajustes ajustes;
    public static Connection cn;
    
    static {
        conexionSQL_SERVER.ajustes = new Ajustes();
    }
    
    public static Connection getConnection() {
        try {
            final String ipServer = conexionSQL_SERVER.ajustes.leerArchivo("C:/ProFacV1/Config/ip.conf");
            final String nameDataBase = conexionSQL_SERVER.ajustes.leerArchivo("C:/ProFacV1/Config/name.conf");
            final String usuarioDateBase = conexionSQL_SERVER.ajustes.leerArchivo("C:/ProFacV1/Config/user.conf");
            final String passwordDataBase = conexionSQL_SERVER.ajustes.leerArchivo("C:/ProFacV1/Config/pass.conf");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conexionSQL_SERVER.cn = DriverManager.getConnection("jdbc:sqlserver://" + ipServer + ":1433;databaseName=" + nameDataBase, usuarioDateBase, passwordDataBase);
        }
        catch (Exception e) {
            conexionSQL_SERVER.cn = null;
        }
        return conexionSQL_SERVER.cn;
    }
    
    public static void verificarConexionSql() {
        conexionSQL_SERVER.cn = getConnection();
        if (conexionSQL_SERVER.cn == null) {
            JOptionPane.showMessageDialog(null, "no se pudo conectar a la base de datos", "ERROR!", 0);
        }
    }
}
