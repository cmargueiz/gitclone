// 
// Decompiled by Procyon v0.5.36
// 

package profac.com.database;

import profac.com.herramientas.Variables;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;

public class updateSQL_SERVER
{
    public Connection cn;
    public String error;
    
    public updateSQL_SERVER() {
        this.cn = conexionSQL_SERVER.getConnection();
    }
    
    public int modificarCargoPartidaContable(final int numeroPartidaContable, final String cuentaContable, final Double montoCargo, final String fecha) {
        final String updateDebe = "update movimientosContables set fechaMod = ?,debe = ? \r\nwhere partidaContable_idpartidaContable = ? and cuentaContable_id = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(updateDebe);
            sentencia.setString(1, fecha);
            sentencia.setDouble(2, montoCargo);
            sentencia.setInt(3, numeroPartidaContable);
            sentencia.setString(4, cuentaContable);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarAbonoPartidaContable(final int numeroPartidaContable, final String cuentaContable, final Double montoAbono, final String fecha) {
        final String updateHaber = "update movimientosContables set fechaMod = ?,haber = ? \r\nwhere partidaContable_idpartidaContable = ? and cuentaContable_id = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(updateHaber);
            sentencia.setString(1, fecha);
            sentencia.setDouble(2, montoAbono);
            sentencia.setInt(3, numeroPartidaContable);
            sentencia.setString(4, cuentaContable);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarUsuario(final String sql, final String valor, final int tipo, final String usuario) {
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(sql);
            if (tipo == 1) {
                sentencia.setInt(1, Integer.parseInt(valor));
            }
            else {
                sentencia.setString(1, valor);
            }
            sentencia.setString(2, usuario);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarPassword(final String usuario, final String password) {
        final String update = "update usuario set password = ? where usuario = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, password);
            sentencia.setString(2, usuario);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarSaldoInicial(final String cuentaContable, final Double saldoInicial, final String fechaActal, final int idUsuario) {
        final String update = "update cuentaContable set saldoInicial = ?,fechaMod = ?,usuario_idusuario = ? where idcuentaContable = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setDouble(1, saldoInicial);
            sentencia.setString(2, fechaActal);
            sentencia.setInt(3, idUsuario);
            sentencia.setString(4, cuentaContable);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarCorrelativoCheque(final int correlativo, final int idBanco) {
        final String update = "update bancos set correlativoCheque = ? where idbancos = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setInt(1, correlativo);
            sentencia.setInt(2, idBanco);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarPartidaContable(final String numeroComprobante, final String fechaMod, final int numeroPartida, final String idOficina) {
        final String update = "update partidaContable set numeroComprobante = ?,fechaMod = ? where idpartidaContable = ? and oficina_idoficina = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, numeroComprobante);
            sentencia.setString(2, fechaMod);
            sentencia.setInt(3, numeroPartida);
            sentencia.setString(4, idOficina);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarMovimientosContables(final String numeroComprobante, final String fechaMod, final int numeroPartida, final String cuentaContable, final int idBanco, final String nombreCheque, final String idOficina) {
        final String update = "update movimientosContables set numeroComprobante = ?,fechaMod = ?,idBanco = ?,nombreCheque = ? \r\nwhere partidaContable_idpartidaContable = ? and cuentaContable_id = ? and oficina_idoficina = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, numeroComprobante);
            sentencia.setString(2, fechaMod);
            sentencia.setInt(3, idBanco);
            sentencia.setString(4, nombreCheque);
            sentencia.setInt(5, numeroPartida);
            sentencia.setString(6, cuentaContable);
            sentencia.setString(7, idOficina);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarSaldosIniciales_mayorizacion(final String fecha1, final String fecha2, final String usuario, final String fechaActual, final String idOficina, final int idUsuario, final String hora) {
        final String consulta = "declare @fecha1 varchar(max) = ? declare @fecha2 varchar(max) = ? declare @usuario varchar(max) = ?\r\ndeclare @sumDebe decimal(10,2)=0.0 declare @sumHaber decimal(10,2)=0.0\r\ndeclare @tablaAux_cuentasContables table(idCuentaContable varchar(max),idCuentaContableSup varchar(max),claseCuenta varchar(max),nivel int)\r\ndeclare @tablaAux_cuentasContablesSumar table(idCuentaContable varchar(max),idCuentaContableSup varchar(max),claseCuenta varchar(max),nivel int)\r\ndeclare @tablaAux_resultado table(idCuentaContable varchar(max),idCuentaContableSup varchar(max),debe decimal(10,2),haber decimal(10,2),nivel int)\r\ndeclare @tablaAux_resultado2 table(idCuentaContable varchar(max),idCuentaContableSup varchar(max),debe decimal(10,2),haber decimal(10,2),nivel int)\r\ninsert into @tablaAux_cuentasContables(idCuentaContable,idCuentaContableSup,claseCuenta,nivel)select idcuentaContable,cuentaContableSup,claseCuenta,nivel from cuentaContable\r\ndeclare @cantFilas_cuentasContables int=(select COUNT(*)from @tablaAux_cuentasContables)\r\nwhile @cantFilas_cuentasContables>0 begin\r\n\tdeclare @cuentaContable varchar(max)=(select top(1)idcuentaContable from @tablaAux_cuentasContables)\r\n\tdeclare @nivel int=(select nivel from @tablaAux_cuentasContables where idCuentaContable=@cuentaContable)\r\n\tdelete from @tablaAux_cuentasContablesSumar insert into @tablaAux_cuentasContablesSumar(idCuentaContable,idCuentaContableSup,claseCuenta,nivel)select idcuentaContable,cuentaContableSup,claseCuenta,nivel from cuentaContable where cuentaContableSup=@cuentaContable\r\n\tdeclare @cantFilas_cuentasContablesSumar int=(select COUNT(*)from @tablaAux_cuentasContablesSumar)\r\n\twhile @cantFilas_cuentasContablesSumar>0 begin\r\n\t\tdeclare @cuentaContableSumar varchar(max)=(select top(1)idcuentaContable from @tablaAux_cuentasContablesSumar)\r\n\t\tset @sumDebe=@sumDebe+(select isnull(SUM(debe),0.0) from movimientosContables where cuentaContable_idcuentaContable=@cuentaContableSumar and fechaMov>=@fecha1 and fechaMov<=@fecha2)\r\n\t\tset @sumHaber=@sumHaber+(select isnull(SUM(haber),0.0) from movimientosContables where cuentaContable_idcuentaContable=@cuentaContableSumar and fechaMov>=@fecha1 and fechaMov<=@fecha2)\r\n\t\tdelete from @tablaAux_cuentasContablesSumar where idCuentaContable=@cuentaContableSumar\r\n\t\tset @cantFilas_cuentasContablesSumar=(select COUNT(*)from @tablaAux_cuentasContablesSumar)\r\n\tend\r\n\tdeclare @cuentaPadre varchar(max)=(select cuentaContableSup from cuentaContable where idcuentaContable=@cuentaContable)\r\n\tinsert into @tablaAux_resultado(idCuentaContable,idCuentaContableSup,debe,haber,nivel)select @cuentaContable,@cuentaPadre,@sumDebe,@sumHaber,@nivel\r\n\tset @sumDebe=0.0 set @sumHaber=0.0\r\n\tdelete from @tablaAux_cuentasContables where idCuentaContable=@cuentaContable\r\n\tset @cantFilas_cuentasContables=(select COUNT(*)from @tablaAux_cuentasContables)\r\nend\r\ndeclare @tablaAux_resultadoAux table(idCuentaContable varchar(max),idCuentaContableSup varchar(max),debe decimal(10,2),haber decimal(10,2),nivel int)\r\ninsert into @tablaAux_resultadoAux(idCuentaContable,idCuentaContableSup,debe,haber,nivel)select *from @tablaAux_resultado\r\ndeclare @cantFilas_resultado int=(select COUNT(*) from @tablaAux_resultadoAux)\r\nwhile @cantFilas_resultado>0 begin\r\n\tdeclare @cuentaContableResultado varchar(max)=(select top(1)idCuentaContable from @tablaAux_resultadoAux)\r\n\tdeclare @debeAux decimal(10,2)=(select debe from @tablaAux_resultadoAux where idCuentaContable=@cuentaContableResultado)\r\n\tdeclare @haberAux decimal(10,2)=(select haber from @tablaAux_resultadoAux where idCuentaContable=@cuentaContableResultado)\r\n\tdeclare @sumDebeAux decimal(10,2)=(select isnull(SUM(debe),0.0) from movimientosContables where cuentaContable_idcuentaContable=@cuentaContableResultado and fechaMov>=@fecha1 and fechaMov<=@fecha2)\r\n\tdeclare @sumHaberAux decimal(10,2)=(select isnull(SUM(haber),0.0) from movimientosContables where cuentaContable_idcuentaContable=@cuentaContableResultado and fechaMov>=@fecha1 and fechaMov<=@fecha2)\r\n\tif @debeAux<>@sumDebeAux begin update @tablaAux_resultado set debe=@sumDebeAux+@debeAux where idCuentaContable=@cuentaContableResultado end\r\n\tif @haberAux<>@sumHaberAux begin update @tablaAux_resultado set haber=@sumHaberAux+@haberAux where idCuentaContable=@cuentaContableResultado end\r\n\tdelete from @tablaAux_resultadoAux where idCuentaContable=@cuentaContableResultado\r\n\tset @cantFilas_resultado=(select COUNT(*) from @tablaAux_resultadoAux)\r\nend\r\ndelete from @tablaAux_resultadoAux\r\ninsert into @tablaAux_resultadoAux(idCuentaContable,idCuentaContableSup,debe,haber,nivel)select *from @tablaAux_resultado\r\nset @cantFilas_resultado=(select COUNT(*) from @tablaAux_resultadoAux)\r\nwhile @cantFilas_resultado>0 begin\r\n\tdeclare @cuentaContableResultado2 varchar(max)=(select top(1)idCuentaContable from @tablaAux_resultadoAux order by nivel desc)\r\n\tdeclare @nivelAux int=(select nivel from @tablaAux_resultadoAux where idCuentaContable=@cuentaContableResultado2)\r\n\tdeclare @claseCuenta varchar(max)=(select claseCuenta from cuentaContable where idcuentaContable=@cuentaContableResultado2)\r\n\tdeclare @sumDebeAuxRE decimal(10,2)=0.0\r\n\tdeclare @sumHaberAuxRE decimal(10,2)=0.0\r\n\tif @nivelAux=1 and @claseCuenta='RE' begin set @sumDebeAuxRE=(select SUM(debe)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) set @sumHaberAuxRE=(select SUM(haber)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) update @tablaAux_resultado set debe=@sumDebeAuxRE,haber=@sumHaberAuxRE where idCuentaContable=@cuentaContableResultado2 end\r\n\tif @nivelAux=2 and @claseCuenta='RE' begin set @sumDebeAuxRE=(select SUM(debe)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) set @sumHaberAuxRE=(select SUM(haber)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) update @tablaAux_resultado set debe=@sumDebeAuxRE,haber=@sumHaberAuxRE where idCuentaContable=@cuentaContableResultado2 end\r\n\tif @nivelAux=4 and @claseCuenta='RE' begin set @sumDebeAuxRE=(select SUM(debe)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) set @sumHaberAuxRE=(select SUM(haber)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) update @tablaAux_resultado set debe=@sumDebeAuxRE,haber=@sumHaberAuxRE where idCuentaContable=@cuentaContableResultado2 end\r\n\tif @nivelAux=6 and @claseCuenta='RE' begin set @sumDebeAuxRE=(select SUM(debe)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) set @sumHaberAuxRE=(select SUM(haber)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) update @tablaAux_resultado set debe=@sumDebeAuxRE,haber=@sumHaberAuxRE where idCuentaContable=@cuentaContableResultado2 end\r\n\tif @nivelAux=8 and @claseCuenta='RE' begin set @sumDebeAuxRE=(select SUM(debe)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) set @sumHaberAuxRE=(select SUM(haber)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) update @tablaAux_resultado set debe=@sumDebeAuxRE,haber=@sumHaberAuxRE where idCuentaContable=@cuentaContableResultado2 end\r\n\tif @nivelAux=10 and @claseCuenta='RE' begin set @sumDebeAuxRE=(select SUM(debe)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) set @sumHaberAuxRE=(select SUM(haber)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) update @tablaAux_resultado set debe=@sumDebeAuxRE,haber=@sumHaberAuxRE where idCuentaContable=@cuentaContableResultado2 end\r\n\tif @nivelAux=12 and @claseCuenta='RE' begin set @sumDebeAuxRE=(select SUM(debe)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) set @sumHaberAuxRE=(select SUM(haber)from @tablaAux_resultado where idCuentaContableSup=@cuentaContableResultado2) update @tablaAux_resultado set debe=@sumDebeAuxRE,haber=@sumHaberAuxRE where idCuentaContable=@cuentaContableResultado2 end\r\n\r\n\tdelete from @tablaAux_resultadoAux where idCuentaContable=@cuentaContableResultado2\r\n\tset @cantFilas_resultado=(select COUNT(*) from @tablaAux_resultadoAux)\r\nend\r\ndelete from tablaLibroContable where usuario=@usuario\r\ninsert into @tablaAux_resultado2(idCuentaContable,idCuentaContableSup,debe,haber,nivel)select *from @tablaAux_resultado\r\ndeclare @contRS int=(select COUNT(*)from @tablaAux_resultado2)\r\nwhile @contRS>0 begin\r\n\tdeclare @cuentaRS varchar(max)=(select top(1)idCuentaContable from @tablaAux_resultado2)\r\n\tdeclare @cuentaSupRS varchar(max)=(select idCuentaContableSup from @tablaAux_resultado where idCuentaContable=@cuentaRS)\r\n\tdeclare @nivelRS int=(select nivel from @tablaAux_resultado where idCuentaContable=@cuentaRS)\r\n\tdeclare @cuentaRS_ varchar(max)=(SUBSTRING(@cuentaRS,1,@nivel))\r\n\tdeclare @descripcionRS varchar(max)=(select descripcion from cuentaContable where idcuentaContable=@cuentaRS)\r\n\tdeclare @saldoIniciasRS float=(select top(1)saldoIncial from tablaRespaldoSaldos where fecha<=@fecha1 and cuentaContable_idcuentaContable=@cuentaRS order by fecha desc)\r\n\tdeclare @debe float=(select debe from @tablaAux_resultado where idCuentaContable=@cuentaRS)\r\n\tdeclare @haber float=(select haber from @tablaAux_resultado where idCuentaContable=@cuentaRS)\r\n\tdeclare @claseCuentaRS varchar(max)=(select claseCuenta from cuentaContable where idcuentaContable=@cuentaRS)\r\n\tinsert into tablaLibroContable(idcuentaContable,idCuentaContableSup,nivel,cuenta,descripcion,saldoInicial,debe,haber,claseCuenta,usuario,partida,fecha,saldoFinal)select @cuentaRS,@cuentaSupRS,@nivel,@cuentaRS_,@descripcionRS,@saldoIniciasRS,@debe,@haber,@claseCuentaRS,@usuario,partidaContable='',convert(date,SYSDATETIME()),0.0\r\n\tdelete from @tablaAux_resultado2 where idCuentaContable=@cuentaRS\r\n\tset @contRS=(select COUNT(*)from @tablaAux_resultado2)\r\nend\r\nselect * from tablaLibroContable";
        conexionSQL_SERVER.verificarConexionSql();
        int cantFilas = 0;
        int resultado = 0;
        this.error = "";
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(consulta);
            sentencia.setString(1, fecha1);
            sentencia.setString(2, fecha2);
            sentencia.setString(3, usuario);
            final ResultSet rs = sentencia.executeQuery();
            while (rs.next()) {
                ++cantFilas;
                final String cuenta = rs.getString(1);
                final Double saldoInicial = rs.getDouble(6);
                final Double debe = rs.getDouble(7);
                final Double haber = rs.getDouble(8);
                final Double saldoFinal = saldoInicial + debe - haber;
                final String update = "INSERT INTO tablaRespaldoSaldos VALUES(?,?,?,?,?,?)";
                try {
                    final PreparedStatement sentenciaUpdate = this.cn.prepareStatement(update);
                    sentenciaUpdate.setString(1, idOficina);
                    sentenciaUpdate.setInt(2, idUsuario);
                    sentenciaUpdate.setString(3, fechaActual);
                    sentenciaUpdate.setString(4, hora);
                    sentenciaUpdate.setString(5, cuenta);
                    sentenciaUpdate.setDouble(6, saldoFinal);
                    resultado = sentenciaUpdate.executeUpdate();
                }
                catch (Exception e2) {
                    resultado = 0;
                    this.error = String.valueOf(this.error) + cuenta + ",";
                }
            }
            rs.close();
        }
        catch (Exception e) {
            this.error = e.toString();
        }
        return cantFilas;
    }
    
    public int modificarCambioFecha(final String fechaActual) {
        final String update = "update infoSistema set fechaSistema=DATEADD(day,1,?)";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, fechaActual);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarBanco(final String nombreBanco, final String tipoCuenta, final String cuentaBancaria, final String idCuentaContable, final int idBanco) {
        final String update = "update bancos set nombreBanco = ?,tipoCuenta = ?,cuentaBancaria = ?,cuentaContable_id = ? where idbancos = ?";
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, nombreBanco);
            sentencia.setString(2, tipoCuenta);
            sentencia.setString(3, cuentaBancaria);
            sentencia.setString(4, idCuentaContable);
            sentencia.setInt(5, idBanco);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarBodega(final int idBodega, final String nombreBodega, final String idOficina, final int idUsuario, final String descripcion, final String direccion, final String ciudad, final String telefono, final String fechaMod, final int idUsuario2) {
        final String update = "update bodega set nombreBodega = ?,\r\n                  usuario_idusuario = ?, \r\n\t\t\t\t   descripcion = ?,\r\n\t\t\t\t   direccion = ?,\r\n\t\t\t\t   ciudad = ?,\r\n\t\t\t\t   telefono = ?,\r\n\t\t\t\t   fechaMod = ?,\r\n\t\t\t\t   usuario_idusuario2 = ?\r\nwhere idbodega = ? and oficina_idoficina = ?";
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, nombreBodega);
            sentencia.setInt(2, idUsuario);
            sentencia.setString(3, descripcion);
            sentencia.setString(4, direccion);
            sentencia.setString(5, ciudad);
            sentencia.setString(6, telefono);
            sentencia.setString(7, fechaMod);
            sentencia.setInt(8, idUsuario2);
            sentencia.setInt(9, idBodega);
            sentencia.setString(10, idOficina);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            Variables.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarRubroSubRubro(final int idCategoria, final int idCategoriaPadre, final String nombre, final String fechaModificacion, final int usuario, final String descripcion) {
        final String update = "update categoria set idcategoriaPadre = ?,nombre = ?,fechaCre = ?,usuario_idusuario = ?,descripcion = ? where idcategoria = ?";
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setInt(1, idCategoriaPadre);
            sentencia.setString(2, nombre);
            sentencia.setString(3, fechaModificacion);
            sentencia.setInt(4, usuario);
            sentencia.setString(5, descripcion);
            sentencia.setInt(6, idCategoria);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarInfoServicio(final String estado, final String lineaServicio, final String fechaMod, final String fechaVen, final Double montoApr, final int idUsuario, final int periodo, final int plazo, final int cuotas, final String idInfoServicio) {
        final String update = "update infoServicio set estado = ?,lineaServicio_idlineaServicio = ?,fechaMod = ?,fechaVen = ?,\r\nmontoApr = ?,usuario_idusuario = ?,periodo = ?,plazo = ?,cuotas = ? \r\nwhere idinfoServicio = ?";
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, estado);
            sentencia.setString(2, lineaServicio);
            sentencia.setString(3, fechaMod);
            sentencia.setString(4, fechaVen);
            sentencia.setDouble(5, montoApr);
            sentencia.setInt(6, idUsuario);
            sentencia.setInt(7, periodo);
            sentencia.setInt(8, plazo);
            sentencia.setInt(9, cuotas);
            sentencia.setString(10, idInfoServicio);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarEstadoLecturaMedidor(final String estado, final String anio, final String mes, final String idInfoServicio) {
        final String update = "update lecturasMedidor set estado = ? where anio = ? and mes = ? and infoServicio_idinfoServicio = ?";
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, estado);
            sentencia.setString(2, anio);
            sentencia.setString(3, mes);
            sentencia.setString(4, idInfoServicio);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
    
    public int modificarSaldosPlanPagos_servicios(final String tipo, final Double monto, final int numeroRecibo) {
        String update = "";
        System.out.println("tipo: " + tipo);
        System.out.println("monto: " + monto);
        System.out.println("numeroRecibo: " + numeroRecibo);
        switch (tipo) {
            case "CAP": {
                update = "Update planPagos set montoCapPen=montoCapPen-?,montoCuoPen=montoCuoPen-? where numeroRecibo = ?";
                break;
            }
            case "FON": {
                update = "Update planPagos set montoSegPen=montoSegPen-?,montoCuoPen=montoCuoPen-? where numeroRecibo = ?";
                break;
            }
            case "INT": {
                update = "Update planPagos set montoIntPen=montoIntPen-?,montoCuoPen=montoCuoPen-? where numeroRecibo = ?";
                break;
            }
            case "MOR": {
                update = "Update planPagos set montoMorPen=montoMorPen-?,montoCuoPen=montoCuoPen-? where numeroRecibo = ?";
                break;
            }
            case "OTR": {
                update = "Update planPagos set montoOtrPen=montoOtrPen-?,montoCuoPen=montoCuoPen-? where numeroRecibo = ?";
                break;
            }
            default:
                break;
        }
        System.out.println("update a realizar - " + update);
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setDouble(1, monto);
            sentencia.setDouble(2, monto);
            sentencia.setInt(3, numeroRecibo);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        System.out.println("hay algun error: " + this.error);
        return resultado;
    }
    
    public int modificarEstadoPagoPlanPagos_servicios(final int numeroRecibo, final String estadoPago, final String fechaSistema) {
        final String update = "Update planPagos set estado=?,fechaMod=? where numeroRecibo = ?";
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, estadoPago);
            sentencia.setString(2, fechaSistema);
            sentencia.setInt(3, numeroRecibo);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        System.out.println("hay algun error: " + this.error);
        return resultado;
    }
    
    public int modificarEstadoReciboGenerado_servicio(final String estadoRecibo, final String fechaSistema, final int idRecibo, final String idServicio) {
        final String update = "UPDATE recibosGenerados set estado=?,fechaMod=? where idrecibosGenerados=? and infoServicio_idinfoServicio=?";
        conexionSQL_SERVER.verificarConexionSql();
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setString(1, estadoRecibo);
            sentencia.setString(2, fechaSistema);
            sentencia.setInt(3, idRecibo);
            sentencia.setString(4, idServicio);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        System.out.println("hay algun error: " + this.error);
        return resultado;
    }
    
    public int modificarCorrelativoTipoFactura(final int nuevoCorrelativo, final String idOficina, final String idTipoFactura) {
        final String update = "update tipoFactura set correlativoFactura = ? where oficina_idoficina = ? and idtipoFactura = ?";
        int resultado = 0;
        try {
            final PreparedStatement sentencia = this.cn.prepareStatement(update);
            sentencia.setInt(1, nuevoCorrelativo);
            sentencia.setString(2, idOficina);
            sentencia.setString(3, idTipoFactura);
            resultado = sentencia.executeUpdate();
        }
        catch (Exception e) {
            resultado = 0;
            this.error = e.toString();
        }
        return resultado;
    }
}
