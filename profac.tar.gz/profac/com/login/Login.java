package profac.com.login;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;

import org.apache.commons.codec.digest.DigestUtils;

import profac.com.database.conexionSQL_SERVER;
import profac.com.database.consultasSQL_SERVER;
import profac.com.herramientas.Ajustes;
import profac.com.herramientas.Texto;
import profac.com.herramientas.Variables;
import profac.com.modulos.Principal;

public class Login extends JFrame{
    
	/**
	* @author Frank Castro
	*/
	
	private static final long serialVersionUID = 1L;
	
	public Ajustes ajustes = new Ajustes();
    public Texto lm = new Texto();
    public consultasSQL_SERVER consultasSql = new consultasSQL_SERVER();
    
    private JPanel contentPane;
    private JPasswordField txtPassword;
    private JTextField txtUsuario;
    private JLabel btnLogin;
    private JLabel lblBtnCerrar;
    private JLabel lblBtnMinimizar;
    private JLabel lblBtnred;
    private JLabel lblFondoBtn;
    private JTable tblOficinas;
    private JPanel jp_oficinas;
    private JLabel lblError;
    private JPanel jp_conexion;
    private JTextField txtIpServidor;
    private JTextField txtBaseDatos;
    private JTextField txtUsuarioBD;
    private JPasswordField txtContra;
    private JLabel lblUsuario;
    private JLabel lblPassword;
    private JLabel lblNombreBtn_Guardar;
    private JLabel btnGuardar;
    private JPanel jp_btnGuardar;
    private JPanel jp_btnCancelar;
    private JLabel btnCancelar;
    private JLabel lblIconoBtn_Cancelar;
    private JLabel lblNombreBtn_Cancelar;
    private JLabel lblNombreCopyRight;
    private JPanel jp_copyright;
    private JLabel lblIconoCopyRight;
    
    public boolean bandera_btnRed = false;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    Login frame = new Login();
                    frame.setVisible(true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public Login() {
        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                ventana(1);
            }
        });
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent arg0) {
                ventana(0);
            }
        });
        setUndecorated(true);
        setResizable(false);
        setDefaultCloseOperation(0);
        setBounds(ajustes.calcularPuntoX(5.21), ajustes.calcularPuntoY(9.26), ajustes.calcularPuntoX(33.02), ajustes.calcularPuntoY(58.7));
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        setLocationRelativeTo(null);
        ajustes.setOpaque_login(this, false);
        
        JLabel lblLogo = new JLabel("");
        lblLogo.setBounds(ajustes.calcularPuntoX(11.2), 0, ajustes.calcularPuntoX(10.52), ajustes.calcularPuntoY(18.7));
        lblLogo.setIcon(ajustes.ajustarImagen("/general_07_icono_logo", lblLogo, 202, 202, 202, 202));
        contentPane.add(lblLogo);
        
        JLabel lblNombre = new JLabel(Variables.nombreSoftware1);
        lblNombre.setForeground(Variables.color_dos);
        lblNombre.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(4.17))));
        lblNombre.setHorizontalAlignment(0);
        lblNombre.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(19.44), ajustes.calcularPuntoX(27.71), ajustes.calcularPuntoY(3.7));
        contentPane.add(lblNombre);
        
        JLabel lblNombre2 = new JLabel(Variables.nombreSoftware2);
        lblNombre2.setForeground(Variables.color_dos);
        lblNombre2.setHorizontalAlignment(0);
        lblNombre2.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblNombre2.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(22.69), ajustes.calcularPuntoX(27.71), ajustes.calcularPuntoY(1.85));
        contentPane.add(lblNombre2);
        
        lblUsuario = new JLabel("");
        lblUsuario.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(25.56), ajustes.calcularPuntoX(3.8), ajustes.calcularPuntoY(6.76));
        lblUsuario.setIcon(ajustes.ajustarImagen("/login_04_icono_user", lblUsuario, 73, 73, 73, 73));
        contentPane.add(lblUsuario);
        
        txtUsuario = new JTextField();
        txtUsuario.setForeground(Variables.color_uno);
        txtUsuario.setBorder(null);
        txtUsuario.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(3.24))));
        txtUsuario.setText("PRUEBA");
        txtUsuario.setBounds(ajustes.calcularPuntoX(6.41), ajustes.calcularPuntoY(25.56), ajustes.calcularPuntoX(23.96), ajustes.calcularPuntoY(6.67));
        txtUsuario.setBackground(Variables.color_tres);
        txtUsuario.setColumns(10);
        txtUsuario.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent arg0) {
                switch (arg0.getKeyCode()) {
                    case 10: {
                        txtPassword.requestFocus();
                        txtPassword.setText("");
                        break;
                    }
                }
            }
            
            @Override
            public void keyTyped(KeyEvent arg0) {
                lm.convertirMinusculaMayuscula(arg0);
            }
        });
        txtUsuario.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
                txtUsuario.setText("");
            }
        });
        contentPane.add(txtUsuario);
        
        lblPassword = new JLabel("");
        lblPassword.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(32.41), ajustes.calcularPuntoX(3.8), ajustes.calcularPuntoY(6.76));
        lblPassword.setIcon(ajustes.ajustarImagen("/login_03_icono_password", lblPassword, 73, 73, 73, 73));
        contentPane.add(lblPassword);
        
        txtPassword = new JPasswordField();
        txtPassword.setForeground(Variables.color_uno);
        txtPassword.setBorder(null);
        txtPassword.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(3.24))));
        txtPassword.setText("1234");
        txtPassword.setBounds(ajustes.calcularPuntoX(6.41), ajustes.calcularPuntoY(32.5), ajustes.calcularPuntoX(23.96), ajustes.calcularPuntoY(6.67));
        txtPassword.setBackground(Variables.color_tres);
        txtPassword.setColumns(10);
        txtPassword.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent arg0) {
                switch (arg0.getKeyCode()) {
                    case 10: {
                        boton(3);
                        break;
                    }
                }
            }
        });
        txtPassword.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent arg0) {
                txtPassword.setText("");
            }
        });
        contentPane.add(txtPassword);
        
        lblBtnred = new JLabel("");
        lblBtnred.setCursor(Cursor.getPredefinedCursor(12));
        lblBtnred.setBounds(ajustes.calcularPuntoX(0.52), ajustes.calcularPuntoY(10.19), ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(3.7));
        lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_red", lblBtnred, 50, 40, 50, 40));
        lblBtnred.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                if (!bandera_btnRed) {
                    lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_malred_select", lblBtnred, 50, 40, 50, 40));
                }
                else {
                    lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_red_select", lblBtnred, 50, 40, 50, 40));
                }
            }
        });
        lblBtnred.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                if (!bandera_btnRed) {
                    lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_malred", lblBtnred, 50, 40, 50, 40));
                }
                else {
                    lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_red", lblBtnred, 50, 40, 50, 40));
                }
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                boton(2);
            }
        });
        contentPane.add(lblBtnred);
        
        lblError = new JLabel("");
        lblError.setHorizontalAlignment(0);
        lblError.setForeground(Color.RED);
        lblError.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(2.31))));
        lblError.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(43.06), ajustes.calcularPuntoX(27.6), ajustes.calcularPuntoY(3.7));
        contentPane.add(lblError);
        
        jp_conexion = new JPanel();
        jp_conexion.setOpaque(false);
        jp_conexion.setVisible(false);
        jp_conexion.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(25.0), ajustes.calcularPuntoX(27.6), ajustes.calcularPuntoY(25.0));
        jp_conexion.setLayout(null);
        contentPane.add(jp_conexion);
        
        JLabel lblModificarConexionServer = new JLabel("Modificar Conexion Servidor");
        lblModificarConexionServer.setForeground(Variables.color_dos);
        lblModificarConexionServer.setHorizontalAlignment(0);
        lblModificarConexionServer.setFont(new Font("Tahoma", 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(2.78))));
        lblModificarConexionServer.setBounds(0, 0, ajustes.calcularPuntoX(27.6), ajustes.calcularPuntoY(3.24));
        jp_conexion.add(lblModificarConexionServer);
        
        JLabel lblIpServidor = new JLabel("IP Servidor:");
        lblIpServidor.setForeground(Variables.color_dos);
        lblIpServidor.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblIpServidor.setBounds(0, ajustes.calcularPuntoY(3.7), ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(lblIpServidor);
        
        txtIpServidor = new JTextField();
        txtIpServidor.setBorder(null);
        txtIpServidor.setForeground(Variables.color_uno);
        txtIpServidor.setBackground(Variables.color_tres);
        txtIpServidor.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        txtIpServidor.setColumns(10);
        txtIpServidor.setBounds(ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(3.7), ajustes.calcularPuntoX(20.31), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(txtIpServidor);
        
        JLabel lblBaseDatos = new JLabel("Base de Datos:");
        lblBaseDatos.setForeground(Variables.color_dos);
        lblBaseDatos.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblBaseDatos.setBounds(0, ajustes.calcularPuntoY(7.41), ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(lblBaseDatos);
        
        txtBaseDatos = new JTextField();
        txtBaseDatos.setBorder(null);
        txtBaseDatos.setForeground(Variables.color_uno);
        txtBaseDatos.setBackground(Variables.color_tres);
        txtBaseDatos.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        txtBaseDatos.setColumns(10);
        txtBaseDatos.setBounds(ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(7.41), ajustes.calcularPuntoX(20.31), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(txtBaseDatos);
        
        JLabel lblUsuarioDB = new JLabel("Usuario:");
        lblUsuarioDB.setForeground(Variables.color_dos);
        lblUsuarioDB.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblUsuarioDB.setBounds(0, ajustes.calcularPuntoY(11.11), ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(lblUsuarioDB);
        
        txtUsuarioBD = new JTextField();
        txtUsuarioBD.setBorder(null);
        txtUsuarioBD.setForeground(Variables.color_uno);
        txtUsuarioBD.setBackground(Variables.color_tres);
        txtUsuarioBD.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        txtUsuarioBD.setColumns(10);
        txtUsuarioBD.setBounds(ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(11.11), ajustes.calcularPuntoX(20.31), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(txtUsuarioBD);
        
        JLabel lblContra = new JLabel("Contrase\u00f1a:");
        lblContra.setForeground(Variables.color_dos);
        lblContra.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        lblContra.setBounds(0, ajustes.calcularPuntoY(14.81), ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(lblContra);
        (txtContra = new JPasswordField()).setBorder(null);
        txtContra.setForeground(Variables.color_uno);
        txtContra.setBackground(Variables.color_tres);
        txtContra.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        txtContra.setBounds(ajustes.calcularPuntoX(7.29), ajustes.calcularPuntoY(14.81), ajustes.calcularPuntoX(20.31), ajustes.calcularPuntoY(2.78));
        jp_conexion.add(txtContra);
        
        jp_btnCancelar = new JPanel();
        jp_btnCancelar.setLayout(null);
        jp_btnCancelar.setBorder(new BevelBorder(0, Color.BLACK, null, null, null));
        jp_btnCancelar.setBackground(Variables.color_dos);
        jp_btnCancelar.setBounds(ajustes.calcularPuntoX(15.63), ajustes.calcularPuntoY(18.98), ajustes.calcularPuntoX(10.42), ajustes.calcularPuntoY(5.56));
        jp_conexion.add(jp_btnCancelar);
        
        (btnCancelar = new JLabel("")).setCursor(Cursor.getPredefinedCursor(12));
        btnCancelar.setBounds(0, 0, ajustes.calcularPuntoX(10.42), ajustes.calcularPuntoY(5.56));
        btnCancelar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnCancelar.setBackground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                boton(4);
            }
        });
        btnCancelar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnCancelar.setBackground(Variables.color_tres);
            }
        });
        jp_btnCancelar.add(btnCancelar);
        
        lblIconoBtn_Cancelar = new JLabel("");
        lblIconoBtn_Cancelar.setBounds(ajustes.calcularPuntoX(0.52), ajustes.calcularPuntoY(0.93), ajustes.calcularPuntoX(2.08), ajustes.calcularPuntoY(3.7));
        lblIconoBtn_Cancelar.setIcon(ajustes.ajustarImagen_("/images/general-02-icono-cancelar.png", lblIconoBtn_Cancelar));
        jp_btnCancelar.add(lblIconoBtn_Cancelar);
        
        lblNombreBtn_Cancelar = new JLabel("Cancelar");
        lblNombreBtn_Cancelar.setHorizontalAlignment(0);
        lblNombreBtn_Cancelar.setForeground(Variables.color_uno);
        lblNombreBtn_Cancelar.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(2.78))));
        lblNombreBtn_Cancelar.setBounds(ajustes.calcularPuntoX(2.6), 0, ajustes.calcularPuntoX(7.03), ajustes.calcularPuntoY(5.56));
        jp_btnCancelar.add(lblNombreBtn_Cancelar);
        
        jp_btnGuardar = new JPanel();
        jp_btnGuardar.setBackground(Variables.color_dos);
        jp_btnGuardar.setBorder(new BevelBorder(0, Color.BLACK, null, null, null));
        jp_btnGuardar.setBounds(ajustes.calcularPuntoX(1.56), ajustes.calcularPuntoY(18.98), ajustes.calcularPuntoX(10.42), ajustes.calcularPuntoY(5.56));
        jp_btnGuardar.setLayout(null);
        jp_conexion.add(jp_btnGuardar);
        
        btnGuardar = new JLabel("");
        btnGuardar.setCursor(Cursor.getPredefinedCursor(12));
        btnGuardar.setBounds(0, 0, ajustes.calcularPuntoX(10.42), ajustes.calcularPuntoY(5.56));
        btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_dos);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                modificarArchivoConfiguracion();
                boton(4);
            }
        });
        btnGuardar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                jp_btnGuardar.setBackground(Variables.color_tres);
            }
        });
        jp_btnGuardar.add(btnGuardar);
        
        JLabel lblIconoBtn_guardar = new JLabel("");
        lblIconoBtn_guardar.setBounds(ajustes.calcularPuntoX(0.52), ajustes.calcularPuntoY(0.93), ajustes.calcularPuntoX(2.08), ajustes.calcularPuntoY(3.7));
        lblIconoBtn_guardar.setIcon(ajustes.ajustarImagen_("/images/general-01-icono-guardar.png", lblIconoBtn_guardar));
        jp_btnGuardar.add(lblIconoBtn_guardar);
        
        lblNombreBtn_Guardar = new JLabel("Guardar");
        lblNombreBtn_Guardar.setForeground(Variables.color_uno);
        lblNombreBtn_Guardar.setHorizontalAlignment(0);
        lblNombreBtn_Guardar.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(2.78))));
        lblNombreBtn_Guardar.setBounds(ajustes.calcularPuntoX(2.6), 0, ajustes.calcularPuntoX(7.03), ajustes.calcularPuntoY(5.56));
        jp_btnGuardar.add(lblNombreBtn_Guardar);
        
        jp_oficinas = new JPanel();
        jp_oficinas.setVisible(false);
        jp_oficinas.setBorder(new BevelBorder(0, null, null, null, null));
        jp_oficinas.setBounds(ajustes.calcularPuntoX(2.6), ajustes.calcularPuntoY(39.35), ajustes.calcularPuntoX(27.6), ajustes.calcularPuntoY(11.11));
        jp_oficinas.setLayout(null);
        contentPane.add(jp_oficinas);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(0, 0, ajustes.calcularPuntoX(27.6), ajustes.calcularPuntoY(11.11));
        jp_oficinas.add(scrollPane);
        
        tblOficinas = new JTable();
        tblOficinas.setCursor(Cursor.getPredefinedCursor(12));
        tblOficinas.setForeground(Variables.color_dos);
        tblOficinas.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85))));
        tblOficinas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
                Variables.idOficina = tblOficinas.getValueAt(tblOficinas.getSelectedRow(), 0).toString();
                boton(5);
            }
        });
        scrollPane.setViewportView(tblOficinas);
        jp_copyright = new JPanel();
        jp_copyright.setOpaque(false);
        jp_copyright.setBounds(ajustes.calcularPuntoX(14.11), ajustes.calcularPuntoY(49.35), ajustes.calcularPuntoX(4.69), ajustes.calcularPuntoY(1.3));
        contentPane.add(jp_copyright);
        jp_copyright.setLayout(null);
        
        lblIconoCopyRight = new JLabel("");
        lblIconoCopyRight.setBounds(0, 0, ajustes.calcularPuntoX(0.73), ajustes.calcularPuntoY(1.3));
        lblIconoCopyRight.setIcon(ajustes.ajustarImagen("/general_00_icono_copyright", lblIconoCopyRight, 14, 14, 14, 14));
        jp_copyright.add(lblIconoCopyRight);
        
        lblNombreCopyRight = new JLabel(Variables.copyRight);
        lblNombreCopyRight.setForeground(Variables.color_dos);
        lblNombreCopyRight.setFont(new Font(Variables.fuenteLetra, 0, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.3))));
        lblNombreCopyRight.setBounds(ajustes.calcularPuntoX(1.04), 0, ajustes.calcularPuntoX(3.65), ajustes.calcularPuntoY(1.3));
        jp_copyright.add(lblNombreCopyRight);
        
        lblBtnMinimizar = new JLabel("");
        lblBtnMinimizar.setCursor(Cursor.getPredefinedCursor(12));
        lblBtnMinimizar.setBounds(ajustes.calcularPuntoX(29.69), ajustes.calcularPuntoY(11.11), ajustes.calcularPuntoX(1.04), ajustes.calcularPuntoY(1.85));
        lblBtnMinimizar.setIcon(ajustes.ajustarImagen("/general_03_icono_minimizar", lblBtnMinimizar, 20, 20, 20, 20));
        lblBtnMinimizar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                lblBtnMinimizar.setIcon(ajustes.ajustarImagen("/general_03_icono_minimizar_select", lblBtnMinimizar, 20, 20, 20, 20));
            }
        });
        lblBtnMinimizar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                lblBtnMinimizar.setIcon(ajustes.ajustarImagen("/general_03_icono_minimizar", lblBtnMinimizar, 20, 20, 20, 20));
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                boton(1);
            }
        });
        contentPane.add(lblBtnMinimizar);
        
        lblBtnCerrar = new JLabel("");
        lblBtnCerrar.setCursor(Cursor.getPredefinedCursor(12));
        lblBtnCerrar.setBounds(ajustes.calcularPuntoX(31.25), ajustes.calcularPuntoY(11.11), ajustes.calcularPuntoX(1.04), ajustes.calcularPuntoY(1.85));
        lblBtnCerrar.setIcon(ajustes.ajustarImagen("/general_04_icono_cerrar", lblBtnCerrar, 20, 20, 20, 20));
        lblBtnCerrar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                lblBtnCerrar.setIcon(ajustes.ajustarImagen("/general_04_icono_cerrar_select", lblBtnCerrar, 20, 20, 20, 20));
            }
        });
        lblBtnCerrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                lblBtnCerrar.setIcon(ajustes.ajustarImagen("/general_04_icono_cerrar", lblBtnCerrar, 20, 20, 20, 20));
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                boton(0);
            }
        });
        contentPane.add(lblBtnCerrar);
        
        JLabel lblFondo = new JLabel("");
        lblFondo.setBounds(0, ajustes.calcularPuntoY(9.26), ajustes.calcularPuntoX(32.92), ajustes.calcularPuntoY(41.94));
        lblFondo.setIcon(ajustes.ajustarImagen_("/images/login-01-fondo.png", lblFondo));
        contentPane.add(lblFondo);
        
        btnLogin = new JLabel("Entrar");
        btnLogin.setCursor(Cursor.getPredefinedCursor(12));
        btnLogin.setForeground(Variables.color_uno);
        btnLogin.setFont(new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(3.7))));
        btnLogin.setHorizontalAlignment(0);
        btnLogin.setBounds(ajustes.calcularPuntoX(3.49), ajustes.calcularPuntoY(51.2), ajustes.calcularPuntoX(25.94), ajustes.calcularPuntoY(6.76));
        btnLogin.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent arg0) {
                lblFondoBtn.setIcon(ajustes.ajustarImagen_("/images/login-02-fondo-btn-select.png", lblFondoBtn));
            }
        });
        btnLogin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent arg0) {
                lblFondoBtn.setIcon(ajustes.ajustarImagen_("/images/login-02-fondo-btn.png", lblFondoBtn));
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                boton(3);
            }
        });
        contentPane.add(btnLogin);
        
        lblFondoBtn = new JLabel("");
        lblFondoBtn.setCursor(Cursor.getPredefinedCursor(12));
        lblFondoBtn.setBounds(ajustes.calcularPuntoX(3.49), ajustes.calcularPuntoY(51.2), ajustes.calcularPuntoX(25.94), ajustes.calcularPuntoY(6.76));
        lblFondoBtn.setIcon(ajustes.ajustarImagen_("/images/login-02-fondo-btn.png", lblFondoBtn));
        contentPane.add(lblFondoBtn);
    }
    
    @Override
    public void dispose() {
        getFrame().setVisible(true);
        super.dispose();
    }
    
    private JFrame getFrame() {
        return this;
    }
    
    public void boton(int op) {
        switch (op) {
            case 0: {
                System.exit(2);
                break;
            }
            case 1: {
                setExtendedState(1);
                break;
            }
            case 2: {
                lblUsuario.setVisible(false);
                txtUsuario.setVisible(false);
                lblPassword.setVisible(false);
                txtPassword.setVisible(false);
                lblError.setVisible(false);
                jp_oficinas.setVisible(false);
                btnLogin.setVisible(false);
                lblFondoBtn.setVisible(false);
                jp_conexion.setVisible(true);
                jp_copyright.setVisible(false);
                txtIpServidor.setText(ajustes.leerArchivo("C:/ProFacV1/Config/ip.conf"));
                txtBaseDatos.setText(ajustes.leerArchivo("C:/ProFacV1/Config/name.conf"));
                txtUsuarioBD.setText(ajustes.leerArchivo("C:/ProFacV1/Config/user.conf"));
                txtContra.setText(ajustes.leerArchivo("C:/ProFacV1/Config/pass.conf"));
                break;
            }
            case 3: {
                if (conexionSQL_SERVER.cn == null) {
                    JOptionPane.showMessageDialog(null, "No hay conexion a la base de datos, favor cambiar la cadena de conexion", "ERROR!", 0);
                    return;
                }
                lblBtnred.setIcon(new ImageIcon(Login.class.getResource("/images/login-06-icono-red.png")));
                lblError.setVisible(false);
                login();
                break;
            }
            case 4: {
                lblUsuario.setVisible(true);
                txtUsuario.setVisible(true);
                lblPassword.setVisible(true);
                txtPassword.setVisible(true);
                lblError.setVisible(false);
                jp_oficinas.setVisible(false);
                btnLogin.setVisible(true);
                lblFondoBtn.setVisible(true);
                jp_conexion.setVisible(false);
                jp_copyright.setVisible(true);
                ventana(1);
                break;
            }
            case 5: {
                if (consultasSql.obtenerInfoUsuario(txtUsuario.getText(), Variables.idOficina)) {
                    Variables.usuario = txtUsuario.getText().toString();
                    Variables.idUsuario = consultasSql.obtenerIdUsuario(Variables.usuario, Variables.idOficina);
                    DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    Variables.fechaActual = LocalDate.now().format(fmt);
                    Principal pri = new Principal();
                    pri.setVisible(true);
                    dispose();
                    break;
                }
                jp_oficinas.setVisible(false);
                jp_copyright.setVisible(true);
                lblError.setText("ERROR, al obtener los datos del usuario, llamar al administrador.");
                lblError.setVisible(true);
            }
        }
    }
    
    public void ventana(int op) {
        switch (op) {
            case 0: {
                ajustes.verificarCarpetaConfiguracion();
                if (conexionSQL_SERVER.cn == null) {
                    lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_malred", lblBtnred, 50, 40, 50, 40));
                    lblError.setText("ERROR! No se Pudo Conectar a la Base de Datos.");
                    lblError.setVisible(true);
                    bandera_btnRed = false;
                    break;
                }
                lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_red", lblBtnred, 50, 40, 50, 40));
                lblError.setVisible(false);
                bandera_btnRed = true;
                break;
            }
            case 1: {
                conexionSQL_SERVER.getConnection();
                if (conexionSQL_SERVER.cn == null) {
                    lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_malred", lblBtnred, 50, 40, 50, 40));
                    lblError.setText("ERROR! No se Pudo Conectar a la Base de Datos.");
                    lblError.setVisible(true);
                    bandera_btnRed = false;
                    break;
                }
                lblBtnred.setIcon(ajustes.ajustarImagen("/login_06_icono_red", lblBtnred, 50, 40, 50, 40));
                lblError.setVisible(false);
                bandera_btnRed = true;
                break;
            }
        }
    }
    
    @SuppressWarnings("deprecation")
	public void login() {
        lblError.setVisible(false);
        String password = DigestUtils.md5Hex(txtPassword.getText());
        int resul = consultasSql.login(txtUsuario.getText().toString(), password);
        if (resul == 1) {
            consultasSql.obtenerOficinaUsuario(txtUsuario.getText().toString(), password);
            boton(5);
        }
        else if (resul > 1) {
            tblOficinas.setModel(consultasSql.llenarTablaOficinasUsuarios(txtUsuario.getText().toString()));
            configurarTabla();
            jp_oficinas.setVisible(true);
            jp_oficinas.setEnabled(true);
            jp_copyright.setVisible(false);
        }
        else {
            lblError.setText("ERROR! usuario o contrase\u00f1a incorrectos.");
            lblError.setVisible(true);
        }
    }
    
    public void configurarTabla() {
        DefaultTableCellRenderer alinear = new DefaultTableCellRenderer();
        TableColumnModel columnModel = tblOficinas.getColumnModel();
        JTableHeader header = new JTableHeader();
        header = tblOficinas.getTableHeader();
        Font fuente = new Font(Variables.fuenteLetra, 1, ajustes.ajustarTexto(1, ajustes.calcularPuntoY(1.85)));
        header.setFont(fuente);
        alinear.setHorizontalAlignment(0);
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(0).setCellRenderer(alinear);
        columnModel.getColumn(1).setPreferredWidth(250);
    }
    
    @SuppressWarnings("deprecation")
	public void modificarArchivoConfiguracion() {
        String rutaArchivosConfiguracion = "C:/ProFacV1/Config";
        if (!ajustes.modificarArchivoConfiguracion(rutaArchivosConfiguracion, txtIpServidor.getText(), "/ip.conf")) {
            JOptionPane.showMessageDialog(null, "No se pudo modificar el dato IP", "ERROR!", 0);
            return;
        }
        if (!ajustes.modificarArchivoConfiguracion(rutaArchivosConfiguracion, txtBaseDatos.getText(), "/name.conf")) {
            JOptionPane.showMessageDialog(null, "No se pudo modificar el dato BASE DE DATOS", "ERROR!", 0);
            return;
        }
        if (!ajustes.modificarArchivoConfiguracion(rutaArchivosConfiguracion, txtUsuarioBD.getText(), "/user.conf")) {
            JOptionPane.showMessageDialog(null, "No se pudo modificar el dato USUARIO", "ERROR!", 0);
            return;
        }
        if (ajustes.modificarArchivoConfiguracion(rutaArchivosConfiguracion, txtContra.getText(), "/pass.conf")) {
            boton(4);
            return;
        }
        JOptionPane.showMessageDialog(null, "No se pudo modificar el dato CONTRASE\u00d1A", "ERROR!", 0);
    }
}
